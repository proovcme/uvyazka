(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=e=>e.graph?.objects[0]?.fields??{};function t(e){return typeof e==`number`&&Number.isSafeInteger(e)||typeof e==`string`?String(e):e&&typeof e==`object`?t(e.m_id64??e.m_id):null}function n(t){let n=e(t);return String(n.m_viewName||n.m_viewDescription||`${t.class_name} #${t.identity.element_id}`)}function r(t){let n=e(t);return t.kind===`placement`?`placements`:n.m_isTemplate===!0?`templates`:t.kind===`schedule`?`schedules`:t.class_name===`DBViewDrafting`&&typeof n.m_sheetNumber==`string`&&n.m_sheetNumber.trim()?`sheets`:t.class_name===`DBView3d`?`3d`:[`DBViewPlan`,`DBViewSection`].includes(t.class_name)?`views`:`other`}function i(e,t,n){if(!n||typeof n!=`object`||n.pointer_token===0||!Number.isInteger(n.offset))return null;let r=e.graph?.edges.filter(e=>e.source_object_index===t&&e.pointer_offset===n.offset)??[];if(r.length!==1)return null;let i=r[0].target_object_index;return e.graph?.objects[i]?i:null}function a(n){let r=n.graph?.objects??[],a=e(n),o=i(n,0,a.m_pSchema),s=o!==null&&r[o].class_name===`ScheduleSchema`?r[o]:null,c=[],l=[],u=[];if(s&&o!==null){let e=s.fields.m_pFields??[],a=s.fields.m_fieldIds??[];e.forEach((s,l)=>{let d=i(n,o,s);d===null||r[d].class_name!==`ScheduleField`?u.push(`Поле ${l}: ссылка не разрешена`):c.push({order:l,id:a.length===e.length?t(a[l]):null,properties:r[d].fields,path:[`graph`,`objects`,d,`fields`]})})}else u.push(`Определение таблицы не прочитано`);let d=i(n,0,a.m_pData);if(d!==null&&[`ScheduleData`,`PanelScheduleData`,`MEPSystemScheduleData`].includes(r[d].class_name))for(let e of r[d].fields.m_SectionData??[]){let t=i(n,d,e);if(t===null){u.push(`Секция таблицы не разрешена`);continue}let a=r[t].fields;for(let e of a.m_tableCells??[]){let o=i(n,t,e),s=o!==null&&r[o].class_name===`TableRowCellData`,c=s?r[o].fields.m_arrCells??[]:Array.isArray(e)?e:[e];for(let e of c){let c=i(n,s?o:t,e);if(c===null||r[c].class_name!==`TableCellData`){u.push(`Ячейка не разрешена`);continue}let d=r[c].fields;l.push({section:a.m_index,row:Number.isInteger(d.m_row)?d.m_row:null,column:Number.isInteger(d.m_column)?d.m_column:null,text:typeof d.m_text==`string`?d.m_text:null,properties:d,path:[`graph`,`objects`,c,`fields`]})}}}else u.push(`Сохранённые ячейки недоступны для этой структуры таблицы`);let f=[];if(s&&o!==null)for(let e of[`m_filterArr`,`m_sortFieldArr`,`m_pEmbeddedSchema`]){let t=s.fields[e];for(let a of Array.isArray(t)?t:t?[t]:[]){let t=i(n,o,a);t===null?a?.pointer_token!==0&&u.push(`${e}: ссылка не разрешена`):f.push({field:e,properties:r[t].fields,path:[`graph`,`objects`,t,`fields`]})}}return{columns:c,cells:l,issues:u,rules:f,schema:s?.fields??null}}function o(t){if(![`DBView3d`,`DBViewPlan`,`DBViewSection`].includes(t.class_name)||e(t).m_isTemplate===!0)return null;let n=e=>Array.isArray(e)&&e.length===3&&e.every(e=>typeof e==`number`&&Number.isFinite(e))&&Math.hypot(...e)>1e-8,r=e(t),i=r.m_viewDir,a=r.m_vertDir;if(!n(i)||!n(a))return null;let o=[i[1]*a[2]-i[2]*a[1],i[2]*a[0]-i[0]*a[2],i[0]*a[1]-i[1]*a[0]];return Math.hypot(...o)>1e-8?{direction:i,up:a}:null}function s(n,r){let i=t(e(n).m_dbDrawingId),a=String(n.identity.element_id);return r.filter(n=>{if(n.kind!==`placement`)return!1;let r=e(n);return t(r.m_dbViewId)===a?!1:t(r.m_ownerDBViewId)===a||!!i&&i!==`-1`&&t(r.m_dbDrawingId)===i})}function c(e){let t=e==null?``:String(e);return/^[=+@\-\t\r]/.test(t)&&(t=`'`+t),`"`+t.replaceAll(`"`,`""`)+`"`}function l(e){return`﻿`+[[`Секция`,`Строка (исходная)`,`Колонка (исходная)`,`Сохранённый текст`,`Путь в записи`],...a(e).cells.map(e=>[e.section,e.row,e.column,e.text,JSON.stringify(e.path)])].map(e=>e.map(c).join(`,`)).join(`\r
`)}function u(e){let t=new Map;for(let n of e){let e=JSON.stringify(n.section)??`unknown`,r=t.get(e);if(r||(r={section:n.section,rows:[],columns:[],cells:new Map,unpositioned:[]},t.set(e,r)),n.row===null||n.column===null||!Number.isSafeInteger(n.row)||!Number.isSafeInteger(n.column)||n.row<0||n.column<0){r.unpositioned.push(n);continue}let i=`${n.row}:${n.column}`,a=r.cells.get(i)??[];a.push(n),r.cells.set(i,a)}for(let e of t.values()){let t=new Set,n=new Set;for(let r of e.cells.values())t.add(r[0].row),n.add(r[0].column);e.rows=[...t].sort((e,t)=>e-t),e.columns=[...n].sort((e,t)=>e-t)}return[...t.values()]}function d(e){return e.length?e.length>1?`conflict`:e[0].text===null?`unreadable`:e[0].text===``?`empty`:`text`:`missing`}function f(e){let t=e.revit?.element_id;if(t&&/^\d+$/.test(String(t)))return{element_id:String(t),unique_id:e.revit?.unique_id||null,basis:{ifc_tag_revit_export:`Tag в IFC, экспортированном из Revit`,rvt_converter_tag:`RVT ElementId, сохранённый конвертером`}[e.revit?.id_basis||``]||e.revit?.id_basis||`Прочитанный Revit ElementId`,status:`read`};let n=new Set,r=null;for(let[t,i]of Object.entries(e.property_sets??{}))for(let[e,a]of Object.entries(i))(/^(Revit ?Element ?I[dD]|Revit ?I[dD])$/.test(e)||/revit/i.test(t)&&/^Element ?I[dD]$/.test(e))&&/^\d+$/.test(String(a))&&n.add(String(a)),/revit/i.test(t)&&/^(UniqueId|Unique ID)$/i.test(e)&&typeof a==`string`&&(r=a);return{element_id:n.size===1?[...n][0]:null,unique_id:r,basis:n.size>1?`Противоречащие Revit ID в свойствах`:n.size?`Явный параметр ElementId`:`Revit ElementId не прочитан`,status:n.size>1?`conflict`:n.size?`read`:`unavailable`}}var p=new WeakMap;function m(e){let t=p.get(e);return t===void 0&&(t=JSON.stringify(e).toLocaleLowerCase(),p.set(e,t)),t}function h(e,t){let n=t.trim().toLocaleLowerCase();if(!n)return!0;let r=/^revit\s*:\s*(\d+)$/.exec(n);if(r){let t=e.revit_identity,n=e.revit;return String(t?.element_id??n?.element_id??``)===r[1]}let i=m(e);return n.split(/\s+/).every(e=>i.includes(e))}var g=new WeakMap;function _(e,t){let n=t.trim().toLocaleLowerCase();if(!n)return!0;let r=/^revit\s*:\s*(\d+)$/.exec(n);if(r)return f(e).element_id===r[1];if(n.startsWith(`#`))return e.id.toLocaleLowerCase()===n.slice(1)||String(e.step_id)===n.slice(1);let i=g.get(e);if(i===void 0){let t=[];for(let n of Object.values(e.property_sets??{}))for(let[e,r]of Object.entries(n))/family|семейство|^тип(?:оразмер)?$|^type(?: name)?$|typename/i.test(e)&&t.push(r);let n=f(e);i=[e.name,e.long_name,e.class,e.id,e.step_id,e.global_id,e.tag,n.element_id,n.unique_id,...t].map(e=>e==null?``:typeof e==`object`?JSON.stringify(e):String(e)).join(` `).toLocaleLowerCase(),g.set(e,i)}return n.split(/\s+/).every(e=>i.includes(e))}function v(e,t){let n=t.federation?.members.find(t=>t.instance_id===e.source_instance_id);if(t.source.format===`nwd`||n?.source_format===`nwd`)return{key:JSON.stringify([`nwd`,e.class]),name:e.class===`NwdLineFragment`?`Линейные фрагменты`:`Треугольные фрагменты`,format:`NWD`};if(t.source.format!==`rvt`&&n?.source_format!==`rvt`&&e.revit?.id_basis!==`rvt_converter_tag`)return{key:JSON.stringify([`ifc`,e.class]),name:e.class,format:`IFC`};let r=e.property_sets?.Other?.Category,i=typeof r==`string`&&r.trim()?r.trim():`Категория Revit не прочитана`;return{key:JSON.stringify([`rvt`,i]),name:i,format:`RVT`}}function y(e,t){let n=(n,r)=>({state:n,reason:r,filter:e,cell:t??null});if(!t||t.state!==`value`)return n(`unknown`,`Значение отсутствует, конфликтует или не поддержано; это не отрицательный результат фильтра.`);if(e.operator===`has_value`)return n(`pass`,`Прочитано типизированное значение (включая ноль и пустую строку).`);let r=t.value,i=e.value;if(typeof r!=typeof i||![`string`,`number`].includes(typeof r))return n(`unknown`,`Тип порога не совпадает с типом значения.`);if(typeof r==`number`&&(!Number.isFinite(r)||!Number.isFinite(i)||t.unit!==e.unit))return n(`unknown`,`Единицы порога не подтверждены или число не является конечным.`);if(t.storage_type===`ElementId`&&![`equal`,`not_equal`].includes(e.operator))return n(`unknown`,`Порядок ElementId не задаёт порядок уровней, фаз или типов.`);let a;switch(e.operator){case`equal`:a=r===i;break;case`not_equal`:a=r!==i;break;case`greater`:case`greater_equal`:case`less`:case`less_equal`:if(typeof r!=`number`||typeof i!=`number`)return n(`unknown`,`Сравнение порядка поддержано только для чисел.`);a=e.operator===`greater`?r>i:e.operator===`greater_equal`?r>=i:e.operator===`less`?r<i:r<=i;break;case`contains`:case`not_contains`:case`begins`:case`ends`:if(typeof r!=`string`||typeof i!=`string`)return n(`unknown`,`Текстовый фильтр требует строку.`);a=e.operator===`contains`?r.includes(i):e.operator===`not_contains`?!r.includes(i):e.operator===`begins`?r.startsWith(i):r.endsWith(i);break;default:return n(`unknown`,`Оператор не поддержан.`)}return n(a?`pass`:`fail`,`Правило сверки Увязки: точное сравнение в исходных единицах; текст с учётом регистра.`)}function b(e,t,n){let r=e=>e?.state===`value`&&e.storage_type!==`ElementId`;return!r(e)||!r(t)?Number(r(t))-Number(r(e)):e.storage_type!==t.storage_type||e.unit!==t.unit?JSON.stringify([e.storage_type,e.unit])<JSON.stringify([t.storage_type,t.unit])?-1:1:typeof e.value==`number`&&typeof t.value==`number`?(e.value-t.value)*n:typeof e.value==`string`&&typeof t.value==`string`?(e.value<t.value?-1:+(e.value>t.value))*n:0}function x(e){let t=e.flatMap(e=>e.evidence);if(!e.length)return{state:`missing`,reason:`Нет подтверждённых строк для суммы.`,evidence:t};if(e.some(e=>e.state!==`value`||typeof e.value!=`number`||!Number.isFinite(e.value)||![`Double`,`Integer`].includes(e.storage_type??``)))return{state:`unsupported`,reason:`Сумма неполная: нужны числовые значения всех включённых экземпляров.`,evidence:t};if(new Set(e.map(e=>JSON.stringify([e.storage_type,e.unit]))).size!==1)return{state:`conflict`,reason:`Типы или единицы слагаемых различаются.`,evidence:t};let n=0,r=0;for(let t of e){let e=t.value-r,i=n+e;r=i-n-e,n=i}return!Number.isFinite(n)||e[0].storage_type===`Integer`&&!Number.isSafeInteger(n)?{state:`unsupported`,reason:`Переполнение суммы.`,evidence:t}:{state:`value`,value:n,storage_type:e[0].storage_type,unit:e[0].unit,evidence:t}}var S={"-1001301":{storage:`Double`,unit:`ft`},"-1001300":{storage:`Double`,unit:`ft`},"-1001405":{storage:`String`},"-1010103":{storage:`String`},"-1001206":{storage:`String`}},C=e=>({state:`missing`,reason:e,evidence:[]});function w(e,t){if(!e?.saved_metadata)return C(`Параметры владельца не прочитаны`);let n=e.saved_metadata,r=[],i=(t,n,i,a)=>r.push({owner_id:String(e.identity.element_id),value:t,storage_type:n,path:[`saved_metadata`,...i],location:e.source,rule:a});(n.parameter_sets??[]).forEach((e,n)=>(e.parameters??[]).forEach((e,r)=>{String(e.serialized_parameter_id)===t&&i(e.raw_value,e.storage_type,[`parameter_sets`,n,`parameters`,r])})),(n.raw_field_parameters??[]).forEach((e,n)=>{String(e.parameter_id)===t&&i(e.raw_value,e.storage_type,[`raw_field_parameters`,n],e.projection_rule)}),(n.resolved_family_parameters??[]).forEach((e,n)=>{String(e.parameter_id)===t&&e.has_value===!0&&i(e.raw_value,e.storage_type,[`resolved_family_parameters`,n])});let a=(n.family_parameter_slots??[]).map((e,t)=>({p:e,i:t})).filter(({p:e})=>String(e.parameter_id)===t),o=S[t];if(o)for(let{p:e,i:t}of a){let n=o.storage===`Double`?`double_slot`:`string_slot`;i(e[n],o.storage,[`family_parameter_slots`,t,n],`pinned-rvt-rs/partition_type_parameters.rs:RE-77/RE-93`)}return r.length?(n.declared_custom_parameters??[]).some(e=>String(e.parameter_id)===t&&e.has_value===!1)?{state:`conflict`,reason:`Значение противоречит сохранённому признаку HasValue`,evidence:r}:r.every(e=>e.storage_type===`String`?typeof e.value==`string`:[`Double`,`Integer`,`ElementId`].includes(e.storage_type)&&typeof e.value==`number`&&Number.isFinite(e.value)&&(e.storage_type===`Double`||Number.isSafeInteger(e.value)))?new Set(r.map(e=>JSON.stringify([e.storage_type,e.value]))).size>1?{state:`conflict`,reason:`Несколько разных значений одного параметра`,evidence:r}:{state:`value`,value:r[0].value,storage_type:r[0].storage_type,unit:o?.unit??(r[0].storage_type===`Double`?`native`:void 0),evidence:r}:{state:`unsupported`,reason:`Неподдержанное представление значения`,evidence:r}:{state:a.length?`unsupported`:`missing`,reason:a.length?`Тип хранения слота не подтверждён`:`Значение не прочитано`,evidence:a.map(({p:t,i:n})=>({owner_id:String(e.identity.element_id),path:[`saved_metadata`,`family_parameter_slots`,n],value:t,storage_type:`unresolved`,location:e.source}))}}function T(e){if(e.length===1)return e[0];let t=[...new Map(e.flatMap(e=>e.evidence).map(e=>[JSON.stringify(e),e])).values()];return e.some(e=>e.state===`conflict`)?{state:`conflict`,reason:`Конфликт в одном из экземпляров`,evidence:t}:e.some(e=>e.state===`unsupported`)?{state:`unsupported`,reason:`Тип или правило одного из значений не поддержаны`,evidence:t}:e.some(e=>e.state===`missing`)?{state:`missing`,reason:`Не все экземпляры имеют прочитанное значение`,evidence:t}:new Set(e.map(e=>JSON.stringify([e.state,e.storage_type,e.value,e.unit]))).size>1?{state:`mixed`,reason:`Разные значения у экземпляров группы`,evidence:t}:{...e[0],evidence:t}}function E(e,n,r={grouping:`schedule`}){let i=typeof r==`boolean`?{grouping:r?`type`:`instances`}:r,o=i.grouping??`schedule`,s=o===`type`,c=a(e),l=c.schema,u=n.schedule_data,d=c.columns,f=d.flatMap((e,t)=>e.properties.m_hidden===!0?[]:[t]),p=f.map(e=>d[e]),m=[`Сверочная выборка экземпляров семейств. Стадии, варианты, область видимости и связи не применены. Статус отбора относится только к проверенным условиям, не ко всей видимости Revit.`],h=[],g=[],_=[],v=0,S=Array.isArray(l?.m_filterArr)?l.m_filterArr.length:null,C=S===null||S>0,E=c.rules.filter(e=>e.field===`m_sortFieldArr`),D=e=>e===null?-1:d.filter(t=>t.id===e).length===1?d.findIndex(t=>t.id===e):-1,O=E.map(e=>{let n=e.properties;return{index:D(t(n.m_fieldId)),direction:n.m_sortOrder===0?1:n.m_sortOrder===1?-1:null,path:e.path,properties:n}}),k=Array.isArray(l?.m_sortFieldArr)&&O.length===l.m_sortFieldArr.length&&O.every(e=>e.index>=0&&e.direction!==null),A={profile:`uvyazka-schedule-review-v1`,native_filters:{state:C?`unsupported`:`none`,count:S,rules:c.rules.filter(e=>e.field===`m_filterArr`)},sorting:{state:k?`interpreted_requires_review`:`unsupported`,keys:O},grouping:o,review_filters:i.filters??[],sum_fields:i.sum_fields??[]},j=()=>({status:`partial`,rows:h,columns:p,all_columns:d,issues:m,selection:g,totals:_,rule_audit:A,unresolved_instances:v,source:n.source,schedule_id:e.identity.element_id,category_id:t(l?.m_categoryId),group_by_type:s,instance_count:h.reduce((e,t)=>e+t.element_ids.length,0),passed_instances:g.filter(e=>e.state===`pass`).length,unknown_instances:g.filter(e=>e.state===`unknown`).length,excluded_instances:g.filter(e=>e.state===`fail`).length});if(!u)return m.push(`Параметры элементов пока не прочитаны.`),j();if(!n.source?.sha256||u.source_sha256!==n.source.sha256)return m.push(`SHA-256 параметров не совпадает с исходным RVT.`),j();if(!l)return m.push(`Определение спецификации не прочитано.`),j();let ee=t(l.m_categoryId);if(!ee||ee===`-1`)return m.push(`Категория не определена; выборка не построена.`),j();if(l.m_bMaterialSchedule||l.m_bRefTable||l.m_isEmbedded)return m.push(`Материальная, ключевая или вложенная спецификация не поддерживается.`),j();C&&m.push(`Фильтры RVT не расшифрованы: отбор кандидатов имеет статус «Неизвестно». Явные фильтры сверки не заменяют исходные фильтры.`),O.length&&m.push(`Ключи сортировки и группировки прочитаны из RVT. Профиль Увязки трактует порядок 0/1 как возрастание/убывание; точность относительно Revit требует сверки. Текст сортируется с учётом регистра, ElementId не упорядочиваются.`),k||m.push(`Не все ключи сортировки разрешены: сортировка и объединение по правилам RVT отключены.`),o===`schedule`&&typeof l.m_bInstanceSchedule!=`boolean`&&m.push(`Режим объединения исходной таблицы неизвестен: экземпляры оставлены отдельно.`),O.some(e=>e.properties.m_groupingFlags)&&m.push(`Заголовки, подытоги и разделители групп Revit не воспроизводятся.`),(u.status===`partial`||u.error)&&m.push(`Нативное извлечение параметров неполное`+(u.error?`: `+u.error:`.`)),c.issues.length&&m.push(...c.issues);let M=new Map;for(let e of u.records){let n=t(e.identity.element_id);n!==null&&M.set(n,[...M.get(n)??[],e])}let te=e=>{let t=e===null?void 0:M.get(e);return t?.length===1?t[0]:void 0},ne=[];for(let e of u.records){if(e.class_name!==`FamilyInstance`)continue;let n=t(e.identity.element_id);if(n===null||M.get(n)?.length!==1){v++;continue}let r=w(e,`-1140363`);if(r.state!==`value`){v++;continue}if(String(r.value)!==ee)continue;let a=t(e.saved_metadata?.root_references?.m_masterSymbolId),o=te(a),s=o?.class_name===`FamilySymbol`?o:void 0,c=d.map(r=>{let i=r.properties,a=t(i.m_paramElemId);return i.m_pExpression?.pointer_token!==0&&i.m_pExpression?.pointer_token!==void 0||i.m_oCustomFieldData?.pointer_token||i.m_combineParameters?.length||t(i.m_percentageOfId)!==null&&t(i.m_percentageOfId)!==`-1`?{state:`unsupported`,reason:`Формула, процент, объединённое или пользовательское поле не вычисляется`,evidence:[]}:i.m_sourceType===2&&a===`-1152353`?{state:`value`,value:1,storage_type:`Integer`,evidence:[{owner_id:n,path:[`identity`,`element_id`],value:1,storage_type:`Integer`,location:e.source,rule:`one_per_observed_unique_family_instance`}]}:!a||![0,1].includes(i.m_sourceType)?{state:`unsupported`,reason:`Источник поля не поддержан`,evidence:[]}:w(i.m_sourceType===1?s:e,a)}),l=(i.filters??[]).map(e=>y(e,c[D(e.field_id)])),u=l.some(e=>e.state===`fail`)?`fail`:C||l.some(e=>e.state===`unknown`)?`unknown`:`pass`;g.push({element_id:n,state:u,filters:l,native_filters_unresolved:C}),u!==`fail`&&ne.push({element_ids:[n],type_id:s?a:null,cells:c,membership:u})}k&&ne.sort((e,t)=>{for(let n of O){let r=b(e.cells[n.index],t.cells[n.index],n.direction);if(r)return r}return 0});let re=new Map;for(let e of ne){let t=`instance:`+e.element_ids[0];s&&e.type_id&&(t=`type:`+e.type_id),o===`schedule`&&l.m_bInstanceSchedule===!1&&k&&O.every(t=>e.cells[t.index]?.state===`value`)&&(t=`schedule:`+JSON.stringify(O.map(t=>{let n=e.cells[t.index];return[n.storage_type,n.unit,n.value]}))),t=e.membership+`:`+t;let n=re.get(t);n?n.push(e):re.set(t,[e])}for(let e of re.values())h.push({element_ids:e.flatMap(e=>e.element_ids),type_id:e.every(t=>t.type_id===e[0].type_id)?e[0].type_id:null,membership:e[0].membership,cells:f.map(n=>d[n].properties.m_sourceType===2&&t(d[n].properties.m_paramElemId)===`-1152353`&&e.every(e=>e.cells[n].state===`value`)?{state:`value`,value:e.length,storage_type:`Integer`,evidence:e.flatMap(e=>e.cells[n].evidence)}:T(e.map(e=>e.cells[n])))});let ie=ne.filter(e=>e.membership===`pass`);for(let e of new Set(i.sum_fields??[])){let t=D(e);_.push({field_id:e,cell:t<0?{state:`unsupported`,reason:`Поле суммы не разрешено.`,evidence:[]}:x(ie.map(e=>e.cells[t])),scope:`passed_review_filters_only_before_grouping`,instance_count:ie.length})}return g.some(e=>e.state===`unknown`)&&m.push(`Неопределённые строки показаны отдельно и не включены в контрольные суммы. Причина отбора каждого элемента сохранена в JSON.`),v&&m.push(`${v} записей экземпляров с неизвестной категорией или неоднозначным ID исключены; полнота не подтверждена.`),h.length||m.push(`В показанной выборке нет строк. Это не нулевое количество в проекте.`),j()}function D(e){return e.state===`value`?e.value===``?`Пустая строка`:e.unit===`ft`&&typeof e.value==`number`?`${Number((e.value*304.8).toFixed(6)).toLocaleString(`ru-RU`)} мм`:e.storage_type===`ElementId`?`ID ${e.value}`:`${e.value}${e.unit===`ft`?` ft`:e.unit===`native`?` (исх. ед.)`:``}`:{missing:`Не прочитано`,conflict:`Конфликт`,unsupported:`Не поддержано`,mixed:`Разные значения`}[e.state]}function O(e){return`﻿`+[[`SHA-256 RVT`,`ID спецификации`,`Статус`,`Ограничения`,`ElementId экземпляров`,`ID типа`,`Отбор`,`Правила отбора и группировки`,...e.columns.flatMap(e=>[String(e.properties.m_columnHeading??e.id),`Статус ячейки`,`Единицы`,`Источники`])],...e.rows.map(t=>[e.source?.sha256,e.schedule_id,`partial — review selection`,e.issues.join(` | `),t.element_ids.join(`;`),t.type_id,t.membership,JSON.stringify(e.rule_audit),...t.cells.flatMap(e=>[e.state===`value`?e.value:null,e.state,e.unit??``,JSON.stringify(e.evidence)])])].map(e=>e.map(c).join(`,`)).join(`\r
`)}var k=(...e)=>JSON.stringify(e),A=(e=`Значение не прочитано`)=>({state:`missing`,reason:e,evidence:[]});function j(e,t,n,r){let i=[{owner_id:t.key,path:n,value:e,storage_type:typeof e==`number`?`Double`:`String`,location:{file_sha256:t.source_sha256,scene_id:t.scene_id,native_source:t.native?.source}}];return e==null?{...A(),evidence:i}:typeof e==`boolean`?{state:`value`,value:e?`true`:`false`,storage_type:`String`,evidence:i}:typeof e!=`string`&&typeof e!=`number`||typeof e==`number`&&!Number.isFinite(e)?{state:`unsupported`,reason:`Структурное или неподдержанное значение; исходник сохранён в доказательствах`,evidence:i}:{state:`value`,value:e,storage_type:typeof e==`number`?`Double`:`String`,unit:r,evidence:i}}function ee(e,n=[]){let r=[],i=new Map,a=[`Выборка прочитанных записей. Полнота исходной модели, стадии, варианты и видимость Revit не подтверждены. Это новая таблица Увязки, а не пересчёт сохранённой спецификации Revit.`];for(let[e,t]of[[`name`,`Наименование`],[`category`,`Категория`],[`class`,`Класс / тип записи`],[`level`,`Уровень`],[`model`,`Файл`],[`id`,`ID сцены`],[`revit`,`Revit ElementId`],[`global`,`IFC GlobalId`],[`material`,`Материалы`],[`count`,`Количество записей`]])i.set(e,{id:e,label:t,kind:`base`});let o=new Map;for(let e of n){let n=e.source?.sha256;if(!n||e.schedule_data?.source_sha256!==n){e.schedule_data&&a.push(`Отброшены параметры RVT без совпадения SHA-256 источника`);continue}if(o.has(n)){a.push(`Повторные каталоги RVT одного источника не объединены`);continue}let r=new Map;for(let n of e.schedule_data.records){let e=t(n.identity.element_id);e&&r.set(e,[...r.get(e)??[],n])}o.set(n,{document:e,records:r}),(e.schedule_data.status===`partial`||e.schedule_data.error)&&a.push(`Извлечение RVT неполное: `+(e.schedule_data.error||`есть непрочитанные записи`))}let s=new Set,c=new WeakMap;for(let t of e?.elements??[]){if(![`element`,`space`].includes(t.role))continue;let n=e.federation?.members.find(e=>e.instance_id===t.source_instance_id)?.source_sha256??(e.source.format===`rvt`?e.source.sha256:t.source.file_sha256||e.source.sha256),i=o.get(n),a=f(t).element_id,c=a?i?.records.get(a):null,l=c?.length===1?c[0]:void 0;r.push({key:k(n,t.id),scene_id:t.id,source_sha256:n,name:t.name,element:t,native:l,document:i?.document}),a&&s.add(k(n,a))}for(let[e,t]of o)for(let[n,i]of t.records){if(i.length!==1){a.push(`Неоднозначный Revit ID `+n+`; параметры не присоединены автоматически`);continue}let o=i[0];o.class_name!==`FamilyInstance`||s.has(k(e,n))||r.push({key:k(e,`rvt:`+n),scene_id:null,source_sha256:e,name:`Revit #`+n,native:o,document:t.document})}let l=(e,t,n=[])=>{if(t&&typeof t==`object`&&!Array.isArray(t)&&!(`value_si`in t)&&!(`value`in t&&`unit`in t)){for(let[r,i]of Object.entries(t))l(e,i,[...n,r]);return}if(!n.length)return;let r=k(e,...n);i.set(r,{id:r,label:{property_sets:`Свойства`,quantity_sets:`Количества`,source_quantities:`Величины источника`}[e]+` · `+n.join(` · `),kind:`property`,path:[e,...n]})};for(let e of r){let n=o.get(e.source_sha256),r=t(e.native?.saved_metadata?.root_references?.m_masterSymbolId),s=r?n?.records.get(r):null;if(e.type=s?.length===1&&s[0].class_name===`FamilySymbol`?s[0]:void 0,e.element){for(let t of[`property_sets`,`quantity_sets`,`source_quantities`])l(t,e.element[t]);e.element.semantic_kind===`geometry_fragment`&&!a.some(e=>e.startsWith(`NWD:`))&&a.push(`NWD: строки соответствуют геометрическим фрагментам. Сумма записей не является количеством оборудования.`)}for(let n of[`instance`,`type`]){let r=(n===`instance`?e.native:e.type)?.saved_metadata;if(!r)continue;let a=[...(r.parameter_sets??[]).flatMap(e=>e.parameters??[]),...r.raw_field_parameters??[],...r.resolved_family_parameters??[],...r.family_parameter_slots??[]];for(let s of a){let a=t(s.serialized_parameter_id??s.parameter_id);if(!a)continue;let l=c.get(r);if(!l){l=new Map;let e=new Map;for(let n of[...r.parameter_definitions??[],...r.builtin_parameter_definitions??[]]){let r=t(n.parameter_id);if(r&&typeof n.caption==`string`&&n.caption.trim()){let t=e.get(r)??new Set;t.add(n.caption),e.set(r,t)}}for(let[t,n]of e)n.size===1&&l.set(t,[...n][0]);c.set(r,l)}let u=l.get(a)??{"-1001301":`Ширина`,"-1001300":`Высота`,"-1001405":`Марка типа`,"-1010103":`Описание`,"-1001206":`Огнестойкость`}[a],d=k(`rvt`,e.source_sha256,n,a);i.has(d)||i.set(d,{id:d,label:`RVT · ${n===`instance`?`экземпляр`:`тип`} · ${u?u+` · `:``}#${a}${o.size>1?` · `+(e.document?.source?.filename??e.source_sha256.slice(0,8)):``}`,kind:`rvt`,scope:n,parameter_id:a,source_sha256:e.source_sha256})}}}return{model:e,source_metadata:{engine:`uvyazka-parameter-specification-v1`,model:e?{model_id:e.model_id,source:e.source,importer_version:e.importer_version,members:e.federation?.members}:null,native_catalogues:[...o.values()].map(({document:e})=>({source:e.source,schema_version:e.schema_version,schema_sha256:e.schema_sha256,status:e.status,scope:e.schedule_data?.scope,shared_store:e.shared_store}))},columns:[...i.values()],rows:r,issues:[...new Set(a)],source_hashes:[...new Set(r.map(e=>e.source_sha256))].sort()}}function M(e,t,n){if(n.kind===`rvt`&&n.source_sha256!==t.source_sha256)return A(`Параметр другого исходного файла`);if(n.kind===`rvt`)return w(n.scope===`type`?t.type:t.native,n.parameter_id);if(n.kind===`property`){let e=t.element;for(let t of n.path??[])e=e?.[t];let r;return e&&typeof e==`object`&&!Array.isArray(e)&&(`value_si`in e?(r=typeof e.unit==`string`?e.unit:void 0,e=e.value_si):`value`in e&&`unit`in e&&(r=typeof e.unit==`string`?e.unit:void 0,e=e.value)),j(e,t,n.path??[],r)}let r=t.element,i=e.model,a=j({name:t.name,category:r&&i?v(r,i).name:void 0,class:r?.class??t.native?.class_name,level:i?.storeys.find(e=>e.id===r?.storey_id)?.name,model:t.document?.source?.filename??i?.federation?.members.find(e=>e.source_sha256===t.source_sha256)?.label??i?.source.filename,id:t.scene_id??void 0,revit:r?f(r).element_id:t.native?.identity.element_id,global:r?.global_id||void 0,material:r?.materials.length?r.materials.join(`; `):void 0,count:1}[n.id],t,[n.id],n.id===`count`?`record`:void 0);return n.id===`count`&&(a.storage_type=`Integer`),a}function te(e){if(e.length===1)return e[0];let t=e.flatMap(e=>e.evidence);return e.some(e=>e.state!==`value`)?{state:e.some(e=>e.state===`conflict`)?`conflict`:e.some(e=>e.state===`unsupported`)?`unsupported`:e.some(e=>e.state===`mixed`)?`mixed`:`missing`,reason:`Значение прочитано не для всех записей группы`,evidence:t}:new Set(e.map(e=>JSON.stringify([e.value,e.storage_type,e.unit]))).size>1?{state:`mixed`,reason:`В группе разные значения`,evidence:t}:{...e[0],evidence:t}}function ne(e,t){if(e.some(e=>!e.unit||e.unit===`native`||e.unit.startsWith(`unknown`)))return{state:`unsupported`,reason:`Итог не рассчитан: единицы части значений не подтверждены`,evidence:e.flatMap(e=>e.evidence)};let n=x(e);return n.state!==`value`||t===`sum`?n:{...e.reduce((e,n)=>t===`min`?Number(n.value)<Number(e.value)?n:e:Number(n.value)>Number(e.value)?n:e),evidence:e.flatMap(e=>e.evidence)}}function re(e){return{version:1,name:`Ведомость по параметрам`,model_id:e.model?.model_id??null,source_hashes:e.source_hashes,columns:[`name`,`category`,e.model?.source.format===`nwd`?`id`:e.model?.source.format===`rvt`||!e.model&&e.rows.some(e=>e.native)?`revit`:`global`,`count`].map(t=>({id:t,label:e.columns.find(e=>e.id===t).label,aggregate:t===`count`?`sum`:`none`})),group_by:[],filters:[],sort:null,scope:`all`}}function ie(e){let t=e;if(!t||t.version!==1||typeof t.name!=`string`||!t.name.trim()||t.name.length>120||!Array.isArray(t.source_hashes)||t.source_hashes.length>1e3||t.source_hashes.some(e=>!/^([a-f0-9]{64})$/.test(e))||t.model_id!==null&&!/^[a-f0-9]{64}$/.test(t.model_id))throw Error(`Неверная версия или источники спецификации`);if(!Array.isArray(t.columns)||!t.columns.length||t.columns.length>40||new Set(t.columns.map(e=>e.id)).size!==t.columns.length||t.columns.some(e=>typeof e.id!=`string`||e.id.length>2048||typeof e.label!=`string`||e.label.length>256||![`none`,`sum`,`min`,`max`].includes(e.aggregate)))throw Error(`Нужны 1–40 уникальных полей`);if(!Array.isArray(t.group_by)||t.group_by.some(e=>!t.columns.some(t=>t.id===e))||![`all`,`matches`,`selection`].includes(t.scope)||t.scope_ids&&(!Array.isArray(t.scope_ids)||t.scope_ids.length>5e5||t.scope_ids.some(e=>typeof e!=`string`)))throw Error(`Неверная область или группировка`);if(!Array.isArray(t.filters)||t.filters.length>100||t.filters.some(e=>!e||typeof e.field_id!=`string`||![`equal`,`not_equal`,`greater`,`greater_equal`,`less`,`less_equal`,`contains`,`not_contains`,`begins`,`ends`,`has_value`].includes(e.operator)||e.value!==void 0&&typeof e.value!=`string`&&!(typeof e.value==`number`&&Number.isFinite(e.value))||e.unit!==void 0&&typeof e.unit!=`string`))throw Error(`Неверные условия отбора`);if(t.sort&&(!t.columns.some(e=>e.id===t.sort.id)||![1,-1].includes(t.sort.direction)))throw Error(`Неверная сортировка`);return structuredClone(t)}function ae(e,t,n){let r=ie(t);if(r.model_id!==(e.model?.model_id??null)||JSON.stringify([...r.source_hashes].sort())!==JSON.stringify(e.source_hashes))throw Error(`Настройки относятся к другому источнику или ревизии модели`);let i=new Map(e.columns.map(e=>[e.id,e]));for(let e of r.columns)if(!i.has(e.id))throw Error(`Поле не найдено в текущих данных: `+e.label);let a=r.scope===`all`?null:new Set(n??r.scope_ids??[]);a&&(r.scope_ids=[...a]);let o=0,s=0,c=0,l=0,u=[],d=[];for(let t of e.rows){if(a&&(!t.scene_id||!a.has(t.scene_id)))continue;l++;let n=new Map,f=r=>{let a=n.get(r);return a||(a=i.has(r)?M(e,t,i.get(r)):A(`Поле фильтра не найдено`),n.set(r,a)),a},p=r.filters.map(e=>{let t=f(e.field_id);return e.operator!==`has_value`&&typeof t.value==`number`&&t.storage_type!==`ElementId`&&(!t.unit||t.unit===`native`)?{state:`unknown`,reason:`Единицы числового значения не подтверждены`,filter:e,cell:t}:y(e,t)});if(p.some(e=>e.state===`fail`)){u.push({key:t.key,state:`fail`,decisions:p}),c++;continue}let m=p.some(e=>e.state===`unknown`)?`unknown`:`pass`;u.push({key:t.key,state:m,decisions:p}),m===`pass`?o++:s++;for(let e of r.columns)f(e.id);d.push({row:t,cells:n,membership:m})}let f=new Map;for(let e of d){let t=r.group_by.map(t=>e.cells.get(t)),n=r.group_by.length&&t.every(e=>e.state===`value`)?JSON.stringify([e.membership,...t.map(e=>[e.storage_type,e.value,e.unit])]):e.row.key,i=f.get(n);i?i.push(e):f.set(n,[e])}let p=[...f.values()].map(e=>({keys:e.map(e=>e.row.key),scene_ids:e.flatMap(e=>e.row.scene_id?[e.row.scene_id]:[]),membership:e[0].membership,cells:r.columns.map(t=>t.aggregate===`none`?te(e.map(e=>e.cells.get(t.id))):e[0].membership===`unknown`?{state:`unsupported`,reason:`Итог группы не рассчитан: отбор не подтверждён`,evidence:e.flatMap(e=>e.cells.get(t.id).evidence)}:ne(e.map(e=>e.cells.get(t.id)),t.aggregate))}));if(r.sort){let e=r.columns.findIndex(e=>e.id===r.sort.id);p.sort((t,n)=>b(t.cells[e],n.cells[e],r.sort.direction))}return{contract:`UvyazkaParameterSpecification`,version:1,source_metadata:e.source_metadata,definition:r,selection:u,coverage:{observed:e.rows.length,in_scope:l,passed:o,unknown:s,excluded:c,rows:p.length},rows:p,totals:r.columns.filter(e=>e.aggregate!==`none`).map(e=>({id:e.id,cell:ne(d.filter(e=>e.membership===`pass`).map(t=>t.cells.get(e.id)),e.aggregate)})),issues:[...e.issues,...s?[`Итоги включают только записи с подтверждённым отбором; строки «Неизвестно» показаны отдельно.`]:[]]}}function oe(e){let t=e=>{let t=String(e??``);return/^[\s]*[=+@-]/.test(t)&&(t=`'`+t),`"`+t.replaceAll(`"`,`""`)+`"`},n=[[`Источники SHA-256`,`ID записей`,`ID сцены`,`Отбор`,...e.definition.columns.flatMap(e=>[e.label,e.label+` · единица`,e.label+` · статус`])]];for(let t of e.rows)n.push([e.definition.source_hashes.join(`;`),t.keys.join(`;`),t.scene_ids.join(`;`),t.membership,...t.cells.flatMap(e=>[e.state===`value`?e.value:e.reason,e.unit??``,e.state])]);return n.push([`Итоги подтверждённого отбора`,``,``,``,...e.definition.columns.flatMap(t=>{let n=e.totals.find(e=>e.id===t.id)?.cell;return n?[n.state===`value`?n.value:n.reason,n.unit??``,n.state]:[``,``,``]})]),`﻿`+n.map(e=>e.map(t).join(`,`)).join(`\r
`)}function se(e){return e.state===`value`?String(e.value===``?`Пустая строка`:e.value)+(e.unit?` `+(e.unit===`record`?`зап.`:e.unit===`native`?`(исх. ед.)`:e.unit):``):{missing:`Не прочитано`,conflict:`Конфликт`,unsupported:`Не поддержано`,mixed:`Разные значения`}[e.state]}var N=(e,t)=>{let n=document.createElement(e);return t!==void 0&&(n.textContent=t),n};function ce(e){let t=N(`dialog`);t.className=`specification-dialog`,t.setAttribute(`aria-labelledby`,`specification-title`),t.innerHTML=`<div class="panel-head"><div><h2 id="specification-title">Спецификации по параметрам</h2><small>Элементы → поля → условия → группировка → итоги</small></div><button data-close aria-label="Закрыть спецификации">✕</button></div><div class="spec-message" role="status"></div><div class="spec-workbench"><section class="spec-settings" aria-label="Настройки спецификации"><label>Название<input data-name maxlength="120"></label><label>Область<select data-scope><option value="all">Все прочитанные записи</option><option value="matches">Найденные в дереве</option><option value="selection">Выбранные в модели</option></select></label><label>Добавить поле<input data-field-query type="search" placeholder="Имя, параметр или ID"></label><select data-field aria-label="Поле спецификации"></select><button data-add>+ Добавить поле</button><div data-columns></div><details><summary>Условия отбора (И)</summary><label>Поле<select data-filter-field></select></label><label>Условие<select data-filter-op><option value="contains">Содержит</option><option value="equal">Равно</option><option value="not_equal">Не равно</option><option value="greater">Больше</option><option value="greater_equal">Не меньше</option><option value="less">Меньше</option><option value="less_equal">Не больше</option><option value="has_value">Значение прочитано</option></select></label><label>Тип порога<select data-filter-type><option value="string">Текст</option><option value="number">Число</option></select></label><label>Значение<input data-filter-value></label><label>Единица числового порога<input data-filter-unit placeholder="Например, m, m2, ft"></label><button data-add-filter>Добавить условие</button><div data-filters></div><p>Пропущенное или конфликтующее значение даёт статус «Неизвестно», а не ноль.</p></details><label>Сортировать по<select data-sort><option value="">Без сортировки</option></select></label><label>Направление<select data-direction><option value="1">По возрастанию</option><option value="-1">По убыванию</option></select></label><button data-build class="spec-primary">Построить таблицу</button><details><summary>Шаблоны и перенос</summary><select data-presets aria-label="Сохранённый шаблон"></select><button data-load>Открыть шаблон</button><button data-save>Сохранить шаблон</button><button data-export-definition>Настройки JSON</button><label>Импорт настроек<input data-import type="file" accept=".json,application/json"></label><p>Шаблоны сохраняются в браузере и входят в снимок рабочего места. Источники и ревизия проверяются при построении.</p></details></section><section class="spec-result" aria-label="Результат спецификации"><div class="spec-result-tools"><span data-summary></span><button data-csv disabled>CSV</button><button data-json disabled>JSON с источниками</button></div><div data-table class="spec-table"></div><div class="spec-pages"><button data-prev disabled>Назад</button><span data-page></span><button data-next disabled>Далее</button></div><details data-evidence><summary>Источник выбранной ячейки</summary><pre></pre></details><details data-limitations><summary>Полнота и ограничения</summary><div></div></details></section></div>`,document.body.append(t);let n=e=>t.querySelector(e),r=N(`button`,`Спецификации`);r.id=`open-specifications`,r.title=`Создать таблицу по параметрам RVT, IFC или NWD`,document.getElementById(`theme-toggle`).before(r);let i=ee(null),a=re(i),o=null,s=0,c=[],l=(e,t=!1)=>{n(`.spec-message`).textContent=e,n(`.spec-message`).classList.toggle(`error`,t)},u=()=>{o=null,n(`[data-csv]`).disabled=!0,n(`[data-json]`).disabled=!0,n(`[data-summary]`).textContent=`Настройки изменились — постройте таблицу заново`},d=()=>`uvyazka-specifications:`+e.project(),f=()=>{try{let e=JSON.parse(localStorage.getItem(d())??`[]`);c=Array.isArray(e)?e.slice(0,30).map(ie):[]}catch(e){c=[],l(`Шаблоны не восстановлены: `+String(e),!0)}p()},p=()=>{n(`[data-presets]`).replaceChildren(...c.map((e,t)=>new Option(e.name+` · `+e.source_hashes.map(e=>e.slice(0,8)).join(`, `),String(t))))},m=(e,t,n=`application/json`)=>{let r=URL.createObjectURL(new Blob([e],{type:n})),i=N(`a`);i.href=r,i.download=t,i.click(),setTimeout(()=>URL.revokeObjectURL(r),1e3)};function h(){let e=n(`[data-field-query]`).value.toLocaleLowerCase();n(`[data-field]`).replaceChildren(...i.columns.filter(t=>!a.columns.some(e=>e.id===t.id)&&t.label.toLocaleLowerCase().includes(e)).slice(0,1e3).map(e=>new Option(e.label,e.id)))}function g(){let e=n(`[data-columns]`);e.replaceChildren(),a.columns.forEach((t,n)=>{let r=N(`div`);r.className=`spec-column`;let o=N(`input`);o.value=t.label,o.maxLength=256,o.setAttribute(`aria-label`,`Заголовок поля `+(n+1)),o.oninput=()=>{t.label=o.value,u(),_()},r.append(o);let s=N(`small`,i.columns.find(e=>e.id===t.id)?.label??t.id);r.append(s);let c=N(`div`);c.className=`spec-column-actions`;let l=N(`label`),d=N(`input`);d.type=`checkbox`,d.checked=a.group_by.includes(t.id),d.onchange=()=>{a.group_by=d.checked?[...a.group_by,t.id]:a.group_by.filter(e=>e!==t.id),u()},l.append(d,document.createTextNode(`Группа`)),c.append(l);let f=N(`select`);f.setAttribute(`aria-label`,`Итог поля `+(n+1));for(let[e,t]of[[`none`,`Без итога`],[`sum`,`Сумма`],[`min`,`Минимум`],[`max`,`Максимум`]])f.add(new Option(t,e));f.value=t.aggregate,f.onchange=()=>{t.aggregate=f.value,u()},c.append(f);for(let[e,t]of[[`Выше`,-1],[`Ниже`,1]]){let r=N(`button`,t===-1?`↑`:`↓`);r.title=e,r.setAttribute(`aria-label`,e+` поле `+(n+1)),r.disabled=n+t<0||n+t>=a.columns.length,r.onclick=()=>{[a.columns[n],a.columns[n+t]]=[a.columns[n+t],a.columns[n]],u(),g()},c.append(r)}let p=N(`button`,`×`);p.setAttribute(`aria-label`,`Удалить поле `+(n+1)),p.onclick=()=>{a.columns.splice(n,1),a.group_by=a.group_by.filter(e=>e!==t.id),a.sort?.id===t.id&&(a.sort=null),u(),g(),h()},c.append(p),r.append(c),e.append(r)}),_()}function _(){let e=n(`[data-sort]`);e.replaceChildren(new Option(`Без сортировки`,``),...a.columns.map(e=>new Option(e.label,e.id))),e.value=a.sort?.id??``}function v(){let e=n(`[data-filters]`);e.replaceChildren(),a.filters.forEach((t,n)=>{let r=N(`p`);r.append(document.createTextNode(`${i.columns.find(e=>e.id===t.field_id)?.label??t.field_id} ${t.operator} ${t.value??``} ${t.unit??``} `));let o=N(`button`,`Удалить`);o.onclick=()=>{a.filters.splice(n,1),v(),u()},r.append(o),e.append(r)})}function y(e){a=ie(e),n(`[data-name]`).value=a.name,n(`[data-scope]`).value=a.scope,n(`[data-direction]`).value=String(a.sort?.direction??1),g(),v(),h(),u()}function b(){if(!o)return;let r=n(`[data-table]`);r.replaceChildren();let i=N(`table`),a=N(`thead`),c=N(`tr`);for(let e of[`Записи / отбор`,...o.definition.columns.map(e=>e.label)])c.append(N(`th`,e));a.append(c),i.append(a);let l=N(`tbody`);for(let r of o.rows.slice(s*50,s*50+50)){let i=N(`tr`),a=N(`td`),s=N(`button`,`${r.keys.length} зап. · ${r.membership===`pass`?`Прошли условия`:`Неизвестно`}`);s.disabled=!r.scene_ids.length,s.title=`Выделить связанные элементы модели`,s.onclick=()=>{t.close(),e.show(r.scene_ids)},a.append(s),i.append(a),r.cells.forEach((e,t)=>{let a=N(`td`),s=N(`button`,se(e));s.className=`spec-cell`,s.dataset.state=e.state,s.onclick=()=>{n(`[data-evidence] summary`).textContent=`Источник: `+o.definition.columns[t].label,n(`[data-evidence] pre`).textContent=JSON.stringify({source_hashes:o.definition.source_hashes,records:r.keys,column:o.definition.columns[t],cell:e},null,2),n(`[data-evidence]`).open=!0},a.append(s),i.append(a)}),l.append(i)}i.append(l);let u=N(`tfoot`),d=N(`tr`);d.append(N(`th`,`Итоги подтверждённого отбора`));for(let e of o.definition.columns){let t=o.totals.find(t=>t.id===e.id);d.append(N(`td`,t?se(t.cell):``))}u.append(d),i.append(u),r.append(i),o.rows.length||r.append(N(`p`,`Записей в этой области нет. Это не доказывает отсутствие элементов в проекте.`)),n(`[data-page]`).textContent=`${o.rows.length?s*50+1:0}–${Math.min((s+1)*50,o.rows.length)} из ${o.rows.length}`,n(`[data-prev]`).disabled=s===0,n(`[data-next]`).disabled=(s+1)*50>=o.rows.length}function x(){i=ee(e.model(),e.documents()),y(re(i)),n(`[data-filter-field]`).replaceChildren(...i.columns.map(e=>new Option(e.label,e.id))),n(`[data-table]`).replaceChildren(),n(`[data-page]`).textContent=``,n(`[data-limitations] div`).replaceChildren(...i.issues.map(e=>N(`p`,e))),n(`[data-limitations]`).open=!i.rows.length,f(),l(`Прочитано ${i.rows.length} записей · доступно ${i.columns.length} полей. Выберите состав таблицы.`)}let S=n(`[data-build]`);n(`[data-summary]`).before(S),r.onclick=()=>{x(),t.showModal()},n(`[data-close]`).onclick=()=>t.close(),n(`[data-field-query]`).oninput=h,n(`[data-add]`).onclick=()=>{let e=i.columns.find(e=>e.id===n(`[data-field]`).value);e&&(a.columns.length>=40?l(`В одной таблице поддержано до 40 полей`,!0):(a.columns.push({id:e.id,label:e.label,aggregate:`none`}),u(),g(),h()))};for(let e of[`[data-name]`,`[data-scope]`,`[data-sort]`,`[data-direction]`])n(e).onchange=()=>{a.name=n(`[data-name]`).value,a.scope=n(`[data-scope]`).value;let e=n(`[data-sort]`).value;a.sort=e?{id:e,direction:Number(n(`[data-direction]`).value)}:null,u()};n(`[data-filter-field]`).onchange=()=>{let e=i.columns.find(e=>e.id===n(`[data-filter-field]`).value),t=e?i.rows.slice(0,1e3).map(t=>M(i,t,e)).find(e=>e.state===`value`):null;n(`[data-filter-type]`).value=typeof t?.value==`number`?`number`:`string`,n(`[data-filter-unit]`).value=t?.unit??``},n(`[data-add-filter]`).onclick=()=>{let e=n(`[data-filter-value]`).value,t=n(`[data-filter-type]`).value===`number`;t&&n(`[data-filter-op]`).value!==`has_value`&&(!e.trim()||!Number.isFinite(Number(e.replace(`,`,`.`))))?l(`Укажите конечное число для порога`,!0):(a.filters.push({field_id:n(`[data-filter-field]`).value,operator:n(`[data-filter-op]`).value,value:t?Number(e.replace(`,`,`.`)):e,unit:t&&n(`[data-filter-unit]`).value||void 0}),v(),u())};function C(){a.name=n(`[data-name]`).value,t.querySelectorAll(`.spec-column input[aria-label]`).forEach((e,t)=>{a.columns[t]&&(a.columns[t].label=e.value)})}return n(`[data-build]`).onclick=()=>{try{C(),o=ae(i,a,a.scope===`matches`?e.matches():a.scope===`selection`?e.selection():void 0),s=0,b();let t=o.coverage;n(`[data-summary]`).textContent=`В области ${t.in_scope} · прошли ${t.passed} · неизвестно ${t.unknown} · исключено ${t.excluded}`,l(`${o.rows.length} строк. Итоги считаются по исходным записям, до объединения групп.`),n(`[data-csv]`).disabled=!1,n(`[data-json]`).disabled=!1,n(`[data-limitations] div`).replaceChildren(...o.issues.map(e=>N(`p`,e)))}catch(e){l(String(e),!0)}},n(`[data-prev]`).onclick=()=>{s--,b()},n(`[data-next]`).onclick=()=>{s++,b()},n(`[data-csv]`).onclick=()=>{o&&m(oe(o),`uvyazka-specification.csv`,`text/csv;charset=utf-8`)},n(`[data-json]`).onclick=()=>{o&&m(JSON.stringify(o,null,2),`uvyazka-specification.json`)},n(`[data-export-definition]`).onclick=()=>{try{C(),m(JSON.stringify(ie(a),null,2),`uvyazka-specification-settings.json`)}catch(e){l(String(e),!0)}},n(`[data-save]`).onclick=()=>{try{C();let t=ie(a);c=c.filter(e=>e.name!==t.name||e.model_id!==t.model_id),c.unshift(t),c=c.slice(0,30),localStorage.setItem(d(),JSON.stringify(c)),p(),l(e.shared?`Шаблон сохранён в браузере. Для общей базы сохраните рабочее место.`:`Шаблон сохранён на устройстве. Перенос доступен через JSON или снимок рабочего места.`)}catch(e){l(`Шаблон не сохранён: `+String(e),!0)}},n(`[data-load]`).onclick=()=>{try{let e=c[Number(n(`[data-presets]`).value)];if(!e)throw Error(`Нет сохранённого шаблона`);if(e.model_id!==(i.model?.model_id??null)||JSON.stringify(e.source_hashes)!==JSON.stringify(i.source_hashes))throw Error(`Шаблон относится к другому источнику или ревизии. Можно перенести состав через JSON после проверки ID полей.`);y(e)}catch(e){l(String(e),!0)}},n(`[data-import]`).onchange=async()=>{let e=n(`[data-import]`),t=e.files?.[0];if(e.value=``,t)try{if(t.size>2*1024**2)throw Error(`Настройки превышают 2 МиБ`);y(ie(JSON.parse(await t.text()))),l(`Настройки прочитаны. Построение проверит источники и ID полей.`)}catch(e){l(String(e),!0)}},document.addEventListener(`model-data-changed`,()=>{t.open&&x()}),{definitions:()=>(f(),structuredClone(c)),restore:e=>{c=e.map(ie),localStorage.setItem(d(),JSON.stringify(c)),p()}}}var le={membership:`В составе системы / цепи`,port_owner:`Порт принадлежит элементу`,port_connection:`Соединение портов`,element_connection:`Соединение элементов`,control:`Связь управления`,base_equipment:`Базовое оборудование системы / цепи`},ue=new WeakMap;function de(e){let t=ue.get(e);if(t)return t;let n=new Map,r=[],i=new Set,a=[],o=new Map(e.elements.map(e=>[e.id,e]));for(let t of e.elements)n.set(t.id,{id:t.id,name:t.name,class:t.class,role:(t.hierarchy??[]).includes(`IfcPort`)?`port`:`element`,geometry:!!t.mesh});for(let t of e.systems??[])n.set(t.id,{id:t.id,name:t.name||t.class,class:t.class,role:`system`,geometry:!1});let s=(t,a,s,c,l,u)=>{if(!t||!a||t===a)return;let d=[s,c,t,a].join(`|`);if(i.has(d))return;i.add(d);let f={sha256:(o.get(t)??o.get(a))?.source.file_sha256??e.source.sha256,relation_id:c,relation_class:l,...u?{locator:u}:{}};r.push({id:d,from:t,to:a,kind:s,source:f});for(let e of[t,a])n.has(e)||n.set(e,{id:e,name:`Не прочитано · `+e,class:`Unknown`,role:`unread`,geometry:!1})},c=new Set((e.engineering_links??[]).filter(e=>e.kind===`membership`&&e.source?.sha256&&e.source.relation_id&&e.source.relation_class).map(e=>e.from+`|`+e.to));for(let t of e.relationships??[]){let e=(t.source_instance_id?t.source_instance_id+`:`:``)+t.step_id;for(let r of t.child_ids)t.class===`IfcRelAssignsToGroup`&&n.get(t.parent_id)?.role===`system`&&(s(t.parent_id,r,`membership`,String(e),t.class),c.add(t.parent_id+`|`+r)),t.class===`IfcRelConnectsPortToElement`&&s(t.parent_id,r,`port_owner`,String(e),t.class),t.class===`IfcRelNests`&&n.get(r)?.role===`port`&&s(t.parent_id,r,`port_owner`,String(e),t.class),t.class===`IfcRelConnectsPorts`&&s(t.parent_id,r,`port_connection`,String(e),t.class),(t.class===`IfcRelConnectsElements`||t.class===`IfcRelConnectsPathElements`)&&s(t.parent_id,r,`element_connection`,String(e),t.class),t.class===`IfcRelFlowControlElements`&&s(t.parent_id,r,`control`,String(e),t.class)}for(let t of e.systems??[])for(let e of new Set(t.member_ids))c.has(t.id+`|`+e)||s(t.id,e,`membership`,t.id,`ExtractedSystemMembership`,`systems.member_ids`);for(let t of e.engineering_links??[]){if(!t.source?.sha256||!t.source.relation_class||!t.source.relation_id){a.push(`Пропущена связь без источника`);continue}if(!Object.hasOwn(le,t.kind)){a.push(`Неизвестный тип связи`);continue}let e=r.length;s(t.from,t.to,t.kind,t.source.relation_id,t.source.relation_class,t.source.locator),r.length>e&&(r[r.length-1].source={...t.source})}let l=new Map;for(let e of r)for(let t of[e.from,e.to]){let n=l.get(t)??[];n.push(e),l.set(t,n)}a.push(...(e.diagnostics??[]).filter(e=>e.kind===`native_mep`).map(e=>e.message));let u=[...n.values()].filter(e=>e.role===`unread`).length;u&&a.push(`${u} участников связей не прочитаны`),r.some(e=>e.kind===`port_connection`||e.kind===`element_connection`)||a.push(`Физическая топология не прочитана. Членство в системе не доказывает подключение.`);let d={nodes:n,links:r,adjacency:l,issues:a};return ue.set(e,d),d}function fe(e,t,n){return(e.adjacency.get(t)??[]).filter(e=>!n||n.includes(e.kind)).map(n=>({link:n,node:e.nodes.get(n.from===t?n.to:n.from)}))}function pe(e,t,n,r=`physical`,i=2e4){if(!e.nodes.has(t)||!e.nodes.has(n)||e.nodes.get(t)?.role===`unread`||e.nodes.get(n)?.role===`unread`)return{status:`unknown_endpoint`,nodes:[],links:[]};if(t===n)return{status:`found`,nodes:[t],links:[]};let a=r===`physical`?[`port_owner`,`port_connection`,`element_connection`]:r===`membership`?[`membership`,`base_equipment`]:Object.keys(le),o=[t],s=new Map,c=new Set([t]),l=0;for(;l<o.length;){let r=o[l++];if(l>i)return{status:`budget_exceeded`,nodes:[],links:[]};for(let{node:i,link:l}of fe(e,r,a))if(!(c.has(i.id)||i.role===`unread`)&&(c.add(i.id),s.set(i.id,{id:r,link:l}),o.push(i.id),i.id===n)){let e=[n],r=[],i=n;for(;i!==t;){let t=s.get(i);r.unshift(t.link),e.unshift(t.id),i=t.id}return{status:`found`,nodes:e,links:r}}}return{status:`not_found_in_read_graph`,nodes:[],links:[]}}function me(e,t,n,r=2e4){let i=n===`physical`?[`port_owner`,`port_connection`,`element_connection`]:[`membership`,`base_equipment`];if(!e.nodes.has(t)||e.nodes.get(t)?.role===`unread`)return{ids:[],truncated:!1};let a=new Set,o=[t],s=new Set([t]),c=0;for(;c<o.length&&c<r;){let t=o[c++];if(!a.has(t)){a.add(t);for(let n of fe(e,t,i))n.node.role!==`unread`&&!s.has(n.node.id)&&(s.add(n.node.id),o.push(n.node.id))}}return{ids:[...a],truncated:c<o.length}}function he(e,t,n){let r=null,i=null,a=`physical`,o=(t,n,r=e)=>{let i=document.createElement(t);return i.textContent=n,r.append(i),i},s=(t,n,r=e)=>{let i=o(`button`,t,r);return i.type=`button`,i.onclick=n,i};function c(e){r=e,l()}function l(){e.replaceChildren();let d=t();if(!d){o(`p`,`Сначала откройте модель.`);return}let f=de(d),p=r?f.nodes.get(r):null;o(`p`,`Связи из файла`,e).className=`eyebrow`;let m=o(`p`,`Системы, соединения и ссылки на базовое оборудование показаны отдельно. Путь по связям файла не подтверждает питание, проходимость, расход, защиту или работоспособность сети.`);m.className=`network-note`;let h=document.createElement(`select`);if(h.setAttribute(`aria-label`,`Тип цепочки`),h.append(new Option(`Физические соединения`,`physical`),new Option(`Системы и базовое оборудование`,`membership`)),h.value=a,h.onchange=()=>{a=h.value,l()},e.append(h),!p)o(`p`,`Выберите оборудование или элемент модели.`);else{o(`h3`,p.name),o(`p`,`${p.class} · ${p.id}${p.geometry?``:` · без геометрии`}`);let e=o(`div`,``);e.className=`network-actions`,s(`Начало пути`,()=>{i=p.id,l()},e),s(`Подсветить сеть`,()=>{let e=me(f,p.id,a);n.highlight(e.ids),g.textContent=e.truncated?`Достигнут лимит обхода: показана часть сети.`:`В прочитанном графе: ${e.ids.length} узлов`},e),s(`Только сеть`,()=>{let e=me(f,p.id,a);n.isolate(e.ids.filter(e=>f.nodes.get(e)?.geometry)),e.truncated&&(g.textContent=`Показана часть сети: достигнут лимит обхода.`)},e),i&&(o(`p`,`Начало: `+(f.nodes.get(i)?.name??i)),s(`Путь до выбранного`,()=>{let e=pe(f,i,p.id,a);if(n.highlight([...e.nodes]),g.textContent=e.status===`found`?`Цепочка: ${e.links.length} связей`:`Путь не найден в прочитанных данных. Это не доказательство отсутствия подключения.`,e.status===`found`)for(let t of e.links)u(le[t.kind],t.source)}),s(`Сбросить начало`,()=>{i=null,l()}));let t=fe(f,p.id);o(`h4`,`Связи элемента · ${t.length}`);for(let{node:e,link:r}of t.slice(0,150)){let t=o(`div`,``);t.className=`network-row`;let i=s(e.name,()=>{(e.role===`element`||e.role===`port`)&&n.select(e.id),c(e.id)},t);i.disabled=e.role===`unread`,o(`small`,`${le[r.kind]} · ${e.class} · ${e.id}`,t),u(`Источник связи`,r.source,t)}t.length>150&&o(`p`,`Показаны первые 150 связей. Экспорт содержит полный граф.`),t.length||o(`p`,`Связи этого элемента не прочитаны. Подключение не проверено.`)}let g=o(`p`,``);g.setAttribute(`role`,`status`);let _=o(`details`,``);o(`summary`,`Покрытие и ограничения`,_);for(let e of f.issues)o(`p`,e,_);o(`p`,`${f.nodes.size} узлов · ${f.links.length} связей. Источник: ${d.source.sha256}`,_),s(`Снять подсветку`,()=>n.highlight([])),s(`Скачать граф JSON`,()=>{let e=URL.createObjectURL(new Blob([JSON.stringify({model_id:d.model_id,source:d.source,nodes:[...f.nodes.values()],links:f.links,issues:f.issues},null,2)],{type:`application/json`})),t=document.createElement(`a`);t.href=e,t.download=`engineering-graph.json`,t.click(),setTimeout(()=>URL.revokeObjectURL(e),1e3)})}function u(t,n,r=e){let i=o(`details`,``,r);o(`summary`,t,i),o(`pre`,JSON.stringify(n,null,2),i)}return{open:c,reset:()=>{i=null,r=null,l()}}}function ge(){return new Promise((e,t)=>{let n=indexedDB.open(`uvyazka-viewer-workspaces`,1);n.onupgradeneeded=()=>n.result.createObjectStore(`scenes`,{keyPath:`id`}),n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)})}async function _e(e,t){let n=await ge();try{return await new Promise((r,i)=>{let a=n.transaction(`scenes`,e===`put`||e===`delete`?`readwrite`:`readonly`),o=a.objectStore(`scenes`),s=e===`put`?o.put(t):e===`delete`?o.delete(t):e===`get`?o.get(t):o.getAll(),c;s.onsuccess=()=>{c=s.result},a.oncomplete=()=>r(c),a.onabort=()=>i(a.error??s.error),a.onerror=()=>i(a.error??s.error)})}finally{n.close()}}async function ve(e,t,n,r){let i=`/api/viewer/workspace?project_id=`+encodeURIComponent(e);if(t===`get`){let e=await fetch(i);if(!e.ok)throw Error(`Общая база недоступна: `+e.status);return e.json()}let a=await fetch(`/api/viewer/config`).then(async e=>{if(!e.ok)throw Error(`Общая база недоступна`);return e.json()}),o=await fetch(i,{method:`POST`,headers:{"Content-Type":`application/json`,"X-Uvyazka-Token":a.token},body:JSON.stringify({state:n,expected_revision:r??0,request_id:crypto.randomUUID()})}),s=await o.json();if(!o.ok)throw Error(s.error??`Не удалось сохранить рабочее место`);return s}var ye=e=>e&&typeof e==`object`?Array.isArray(e)?`[`+e.map(ye).join(`,`)+`]`:`{`+Object.entries(e).sort(([e],[t])=>e.localeCompare(t)).map(([e,t])=>JSON.stringify(e)+`:`+ye(t)).join(`,`)+`}`:JSON.stringify(e)??`null`;function be(e){let t=f(e);return t.unique_id?`revit-unique:`+t.unique_id:e.global_id?`ifc-global:`+e.global_id:t.element_id?`revit-id:`+t.element_id:null}function xe(e,t,n){if(!n)throw Error(`Подтвердите, что это ревизии одной модели, с одинаковым размещением.`);let r=e=>{let t=new Map;for(let n of e.elements.filter(e=>e.role===`element`)){let e=be(n);e&&t.set(e,[...t.get(e)??[],n])}return t},i=r(e),a=r(t),o=[];for(let e of new Set([...i.keys(),...a.keys()])){let t=i.get(e)??[],n=a.get(e)??[],r=t[0],s=n[0];if(t.length>1||n.length>1){o.push({kind:`question`,key:e,name:s?.name??r?.name??e,changes:[`Неоднозначный идентификатор: `+t.length+` → `+n.length]});continue}if(!r||!s){o.push({kind:r?`removed`:`added`,key:e,before_id:r?.id,after_id:s?.id,name:(s??r).name,changes:[]});continue}let c=[];for(let e of[`name`,`class`,`predefined_type`,`materials`,`property_sets`,`quantity_sets`])ye(r[e])!==ye(s[e])&&c.push(e);if(!!r.mesh!=!!s.mesh)c.push(`geometry_availability`);else if(r.mesh&&s.mesh){let e=[...r.mesh.bbox_min_m,...r.mesh.bbox_max_m],t=[...s.mesh.bbox_min_m,...s.mesh.bbox_max_m];e.some((e,n)=>Math.abs(e-t[n])>.001)&&c.push(`bounding_box_m`)}c.length&&o.push({kind:`changed`,key:e,before_id:r.id,after_id:s.id,name:s.name,changes:c})}for(let[n,r]of[[e,`before`],[t,`after`]])for(let e of n.elements.filter(e=>e.role===`element`&&!be(e)))o.push({kind:`question`,key:r+`:`+e.id,name:e.name,changes:[`Устойчивый идентификатор не прочитан`],...r===`before`?{before_id:e.id}:{after_id:e.id}});return{contract:`RevisionComparison`,version:1,before:{model_id:e.model_id,sha256:e.source.sha256},after:{model_id:t.model_id,sha256:t.source.sha256},basis:`explicit_identity_same_lineage_confirmed_by_user`,limitations:`Габариты сравниваются с допуском 1 мм. Изменение габаритов не отличает перенос от изменения формы; равные габариты не доказывают равную геометрию. Идентификаторы и STEP номера не сопоставляются по именам.`,rows:o}}function Se(e){let t=document.createElement(`dialog`);t.className=`viewer-workspace-dialog`,t.setAttribute(`aria-label`,`Рабочее место, подборки и ревизии`),document.body.append(t);let n=null,r,i=``,a=()=>`uvyazka:selection-sets:v1:`+encodeURIComponent(e.project());function o(){let e=JSON.parse(localStorage.getItem(a())??`[]`);if(!Array.isArray(e))throw Error(`Повреждены подборки`);return e}function s(e){localStorage.setItem(a(),JSON.stringify(e))}let c=(e,t,n)=>{let r=document.createElement(t);return r.textContent=n,e.append(r),r},l=(t,n,r)=>{let i=c(t,`button`,n);return i.type=`button`,i.onclick=async()=>{i.disabled=!0;try{await r()}catch(t){e.error(t)}finally{i.disabled=!1}},i};async function u(){t.replaceChildren();let a=c(t,`div`,``);a.className=`panel-head`,c(a,`h2`,`Рабочее место`),l(a,`Закрыть`,()=>t.close());let d=c(t,`div`,``);d.className=`dialog-content`;let f=c(d,`p`,``);f.setAttribute(`role`,`status`);let p=c(d,`label`,`Название снимка`),m=document.createElement(`input`);m.placeholder=`Проверка оборудования · вариант 1`,m.maxLength=120,p.append(m),c(d,`p`,`Снимок сохраняет состав сцены и размещения, производную геометрию, камеру, сечения, видимость, фильтры, подборки и журнал замеров. Исходные RVT/IFC не сохраняются.`),l(d,`Сохранить в этом браузере`,async()=>{let t={...e.capture(),id:crypto.randomUUID(),project_id:e.project(),name:m.value.trim()||`Рабочее место`,created_at:new Date().toISOString()};t.state.sets=o(),await _e(`put`,t),await u()});let h=c(d,`div`,``);h.className=`workspace-snapshots`;let g=(await _e(`list`,``)).filter(t=>t.project_id===e.project()).sort((e,t)=>t.created_at.localeCompare(e.created_at));for(let r of g){let i=c(h,`div`,``);i.className=`workspace-snapshot`,c(i,`strong`,r.name),c(i,`small`,new Date(r.created_at).toLocaleString()+` · `+r.model.source.filename),l(i,`Открыть`,async()=>{await e.restore(r),s(r.state.sets),t.close()}),l(i,`Сравнить с текущей`,()=>{n=r.model,S()}),l(i,`Удалить снимок`,async()=>{await _e(`delete`,r.id),await u()})}if(g.length||c(h,`p`,`Сохранённых рабочих мест пока нет.`),e.shared){let t=c(d,`details`,``);c(t,`summary`,`Общая база проекта · человек и MCP`),c(t,`p`,`В SQLite передаётся состояние и наблюдения, без геометрии. Для восстановления нужен тот же пакет модели. Запись проверяет ревизию, старые версии сохраняются.`),i!==e.project()&&(r=void 0,i=e.project()),l(t,`Прочитать из базы`,async()=>{let t=e.project(),n=await ve(t,`get`);if(t!==e.project())throw Error(`Проект изменился`);n.state&&e.apply(n.state),r=n.revision,n.state&&s(n.state.sets),f.textContent=n.state?`Прочитана ревизия ${n.revision}`:`Состояние в базе ещё не записано`}),l(t,`Сохранить в базу`,async()=>{let t=e.project();if(r===void 0){if((await ve(t,`get`)).revision)throw Error(`В базе уже есть рабочее место. Сначала прочитайте его, чтобы не перезаписать чужие изменения.`);r=0}let n=e.capture().state;n.sets=o();let i=await ve(t,`save`,n,r);t===e.project()&&(r=i.revision),f.textContent=`В базе сохранена ревизия ${i.revision}`})}let _=c(d,`details`,``);_.open=!0,c(_,`summary`,`Подборки элементов`);let v=document.createElement(`input`);v.placeholder=`Имя подборки`,v.setAttribute(`aria-label`,`Название подборки`),v.maxLength=120,_.append(v);function y(t){let n=e.capture().state,r=t===`explicit`?e.selection():e.matches();if(t===`explicit`&&!r.length)throw Error(`Выберите элементы через Ctrl + щелчок`);let i={id:crypto.randomUUID(),name:v.value.trim()||`Подборка`,kind:t,ids:t===`explicit`?r:[],model_id:n.model_id,source_sha256:n.source_sha256,created_at:new Date().toISOString(),...t===`rule`?{filters:n.filters}:{}};s([...o(),i]),u()}l(_,`Сохранить выбранные`,()=>y(`explicit`)),l(_,`Сохранить условия поиска`,()=>y(`rule`));for(let n of o()){let r=c(_,`div`,``);r.className=`workspace-snapshot`,c(r,`strong`,n.name+` · `+(n.kind===`rule`?`условия`:`элементы`)),c(r,`small`,`Источник `+n.source_sha256.slice(0,12)),l(r,`Открыть подборку`,()=>{let r=e.capture().state;if(n.model_id!==r.model_id||n.source_sha256!==r.source_sha256)throw Error(`Подборка относится к другой модели / ревизии. Автоматическое сопоставление не выполнено.`);n.kind===`rule`&&n.filters?(e.apply({...r,filters:n.filters}),e.show(e.matches())):e.show(n.ids),t.close()}),l(r,`Удалить подборку`,()=>{s(o().filter(e=>e.id!==n.id)),u()})}let b=c(d,`details`,``);c(b,`summary`,`Сравнение ревизий`);let x=c(b,`div`,``);function S(){b.open=!0,x.replaceChildren(),c(x,`p`,n?`База: `+n.source.filename:`Выберите снимок как базу или запомните текущую модель.`),l(x,`Запомнить текущую как базу`,()=>{n=e.capture().model,S()});let t=c(x,`label`,``),r=document.createElement(`input`);r.type=`checkbox`,t.append(r,document.createTextNode(`Это ревизии одной модели в одинаковом размещении`)),l(x,`Сравнить`,()=>{if(!n)throw Error(`Не выбрана базовая ревизия`);let t=xe(n,e.capture().model,r.checked),i=c(x,`div`,``);c(i,`p`,t.limitations);for(let n of[`added`,`removed`,`changed`,`question`]){let r=t.rows.filter(e=>e.kind===n),a={added:`Добавлено`,removed:`Удалено`,changed:`Изменено`,question:`Вопросы`},o=c(i,`details`,``);c(o,`summary`,`${a[n]} · ${r.length}`),n!==`removed`&&l(o,`Подсветить`,()=>e.highlight(r.flatMap(e=>e.after_id?[e.after_id]:[])));for(let e of r.slice(0,200))c(o,`p`,e.name+` · `+e.key+(e.changes.length?` · `+e.changes.join(`, `):``));r.length>200&&c(o,`p`,`Полный список — в JSON.`)}l(i,`Скачать сравнение JSON`,()=>{let e=URL.createObjectURL(new Blob([JSON.stringify(t,null,2)],{type:`application/json`})),n=document.createElement(`a`);n.href=e,n.download=`revision-comparison.json`,n.click(),setTimeout(()=>URL.revokeObjectURL(e),1e3)})})}S()}return document.getElementById(`open-workspace`).onclick=()=>{u().then(()=>t.showModal()).catch(e.error)},{sets:o,putSets:s}}function Ce(e,t,n){if(![...e,...t].every(Number.isFinite))throw Error(`Координаты замера должны быть конечными`);let r=t.map((t,n)=>t-e[n]),i=Math.hypot(...r);return{delta_m:r,distance_m:i,value_m:n===`distance`?i:Math.abs(r[{X:0,Y:1,Z:2}[n]])}}function P(e,t){let n=e.elements.find(e=>e.id===t.element_id);if(!n)throw Error(`Элемент замера отсутствует в модели`);return{...t,source_sha256:n.source.file_sha256,source_model_id:n.source_model_id??e.model_id,source_element_id:n.source_element_id??n.id,global_id:n.global_id,geometry_evidence:n.geometry_evidence??null}}function we(e,t,n,r,i){return{contract:`SpatialMeasurement`,version:1,id:crypto.randomUUID(),created_at:new Date().toISOString(),project_id:e,model_id:t.model_id,source_sha256:t.source.sha256,filename:t.source.filename,importer_version:t.importer_version,coordinate_system:`scene_world_metres_Z_up`,placements:t.federation?.members??[],method:`two_picked_mesh_surface_points`,axis:i,review_status:`unreviewed`,note:`Между двумя выбранными точками сетки. Не минимальный зазор между телами; точность зависит от исходной геометрии. Проекция на ось не меняет исходные точки.`,points:[P(t,n),P(t,r)],...Ce(n.point_m,r.point_m,i)}}var Te=e=>`uvyazka:spatial-measurements:v1:`+encodeURIComponent(e),Ee=e=>e===`dark`?`dark`:`light`;function F(){let e=null;try{e=localStorage.getItem(`uvyazka-theme`)}catch{}let t=e=>{document.documentElement.dataset.theme=e,document.querySelector(`meta[name="theme-color"]`)?.setAttribute(`content`,e===`light`?`#f4f6f8`:`#12181d`),document.dispatchEvent(new CustomEvent(`theme-change`,{detail:e}))};t(Ee(e));let n=document.getElementById(`theme-toggle`);n.innerHTML=`<svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/></svg><span></span>`;let r=()=>{let e=document.documentElement.dataset.theme===`dark`;n.querySelector(`span`).textContent=e?`Светлая тема`:`Тёмная тема`;let t=`Включить `+(e?`светлую`:`тёмную`)+` тему`;n.setAttribute(`aria-label`,t),n.title=t};r(),n.onclick=()=>{let e=document.documentElement.dataset.theme===`dark`?`light`:`dark`;t(e);try{localStorage.setItem(`uvyazka-theme`,e)}catch{}r()}}function De(e,t){if(e.contract!==`ModelPackage`||e.contract_version!==`0.1.0`)throw Error(`Неподдерживаемая версия пакета модели`);if(t.byteLength!==e.statistics.binary_bytes)throw Error(`Геометрия загружена не полностью`);for(let n of e.elements){let e=n.mesh;if(e){for(let[r,i,a]of[[e.position_byte_offset,e.vertex_count,3],[e.index_byte_offset,e.index_count,1]])if(!Number.isInteger(r)||r<0||r%4!=0||!Number.isInteger(i)||i<0||r+i*a*4>t.byteLength)throw Error(`Неверный диапазон геометрии элемента #${n.step_id}`)}}}function I(e,t,n){let r=n*Math.PI/180,i=Math.cos(r),a=Math.sin(r);return[e[0]*i-e[1]*a+t[0],e[0]*a+e[1]*i+t[1],e[2]+t[2]]}async function Oe(e){if(!e.length)throw Error(`Добавьте хотя бы одну модель`);let t=new Set;for(let n of e){if(t.has(n.instanceId)||!n.instanceId||n.model.federation)throw Error(`Повторный ID или вложенная сводная модель`);if(t.add(n.instanceId),De(n.model,n.binary),n.offset.length!==3||![...n.offset,n.rotation].every(Number.isFinite))throw Error(`Смещение и поворот должны быть конечными числами`)}let n=e.map(e=>({model_id:e.model.model_id,source_sha256:e.model.source.sha256,source_format:e.model.source.format??`ifc`,importer_version:e.model.importer_version,instance_id:e.instanceId,label:e.model.source.filename,offset_m:e.offset,rotation_deg:e.rotation,coordinate_alignment_verified:!1})),r=Array.from(new Uint8Array(await crypto.subtle.digest(`SHA-256`,new TextEncoder().encode(JSON.stringify({version:1,records:n})))),e=>e.toString(16).padStart(2,`0`)).join(``),i=[],a=[],o=[],s=[],c=[],l=[1/0,1/0,1/0],u=[-1/0,-1/0,-1/0],d=0;for(let t of e){let e=t.model,n=e=>t.instanceId+`:`+e;for(let r of e.elements){let a=structuredClone(r);if(a.id=n(a.id),a.storey_id=a.storey_id===null?null:n(a.storey_id),a.source_model_id=e.model_id,a.source_instance_id=t.instanceId,a.source_element_id=r.id,a.source_step_id=r.step_id,a.mesh){let n=a.mesh;n.position_byte_offset=d,d+=n.vertex_count*12,n.index_byte_offset=d,d+=n.index_count*4;let i=[1/0,1/0,1/0],o=[-1/0,-1/0,-1/0],s=new Float32Array(t.binary,r.mesh.position_byte_offset,n.vertex_count*3);for(let n=0;n<s.length;n+=3){let r=I([s[n]+e.coordinate_system.render_origin_m[0],s[n+1]+e.coordinate_system.render_origin_m[1],s[n+2]+e.coordinate_system.render_origin_m[2]],t.offset,t.rotation);for(let e=0;e<3;e++){if(!Number.isFinite(r[e]))throw Error(`Некорректные координаты геометрии`);i[e]=Math.min(i[e],r[e]),o[e]=Math.max(o[e],r[e])}}if(n.bbox_min_m=i,n.bbox_max_m=o,n.vertex_count)for(let e=0;e<3;e++)l[e]=Math.min(l[e],i[e]),u[e]=Math.max(u[e],o[e])}i.push(a)}a.push(...e.storeys.map(r=>({...r,id:n(r.id),name:e.source.filename+` · `+r.name,elevation_m:r.elevation_m===null?null:r.elevation_m+t.offset[2],placement_origin_m:r.placement_origin_m?I(r.placement_origin_m,t.offset,t.rotation):null}))),o.push(...e.relationships.map(e=>({...e,source_instance_id:t.instanceId,parent_id:n(e.parent_id),child_ids:e.child_ids.map(n)}))),s.push(...e.diagnostics.map(e=>({...e,element_id:n(e.element_id)}))),c.push(...(e.systems??[]).map(e=>({...e,id:n(e.id),member_ids:e.member_ids.map(n)})))}if(!l.every(Number.isFinite))throw Error(`В сцене нет геометрии`);let f=[(l[0]+u[0])/2,(l[1]+u[1])/2,l[2]],p=new ArrayBuffer(d),m=0;for(let t of e)for(let e of t.model.elements){let n=i[m++];if(!n.mesh||!e.mesh)continue;let r=new Float32Array(t.binary,e.mesh.position_byte_offset,n.mesh.vertex_count*3),a=new Float32Array(p,n.mesh.position_byte_offset,r.length);for(let e=0;e<r.length;e+=3){let n=I([r[e]+t.model.coordinate_system.render_origin_m[0],r[e+1]+t.model.coordinate_system.render_origin_m[1],r[e+2]+t.model.coordinate_system.render_origin_m[2]],t.offset,t.rotation);for(let t=0;t<3;t++)a[e+t]=n[t]-f[t]}new Uint32Array(p,n.mesh.index_byte_offset,n.mesh.index_count).set(new Uint32Array(t.binary,e.mesh.index_byte_offset,n.mesh.index_count))}return{model:{contract:`ModelPackage`,contract_version:`0.1.0`,importer_version:`browser-federation-1`,model_id:r,source:{filename:`Сводная модель · ${e.length} файлов`,sha256:r,size_bytes:e.reduce((e,t)=>e+t.model.source.size_bytes,0),schema:`Federation`,format:`federation`,exported_at:``,exporter:`uvyazka`},coordinate_system:{length_to_m:1,render_origin_m:f,up_axis:`Z`,bounds_min_m:l,bounds_max_m:u},elements:i,storeys:a,relationships:o,diagnostics:s,systems:c,engineering_links:e.flatMap(e=>(e.model.engineering_links??[]).map(t=>({...t,id:e.instanceId+`:`+t.id,from:e.instanceId+`:`+t.from,to:e.instanceId+`:`+t.to}))),federation:{members:n,note:`Исходные координаты в метрах + заданные пользователем смещения и повороты. Совмещение не подтверждено.`},phase_sources:Object.fromEntries(e.map(e=>[e.instanceId,e.model.revit??{status:`unavailable`,phases:[]}])),statistics:{products:i.length,physical_elements:i.filter(e=>e.role===`element`&&e.semantic_kind!==`geometry_fragment`).length,meshes:i.filter(e=>e.mesh).length,triangles:e.reduce((e,t)=>e+t.model.statistics.triangles,0),geometry_errors:i.filter(e=>e.geometry_error).length,binary_bytes:d},capabilities:{read:!0,geometry_ready:!0,technology_resolved:!1,schedule_ready:!1}},binary:p}}function ke(e,t){return new Set(e?.systems?.find(e=>e.id===t)?.member_ids??[])}function Ae(e,t){let n=ke(e,t),r=new Map(e.elements.map(e=>[e.id,e])),i=0,a=0;for(let e of n){let t=r.get(e);t&&(i++,t.mesh&&a++)}return{declared:n.size,present:i,geometry:a,missing:n.size-i,withoutGeometry:i-a}}function je(e,t){return(e?.systems??[]).filter(e=>e.member_ids.includes(t))}var Me={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Ne={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Pe=1e3,Fe=1001,Ie=1002,Le=1003,Re=1004,ze=1005,Be=1006,Ve=1007,He=1008,Ue=1009,We=1010,Ge=1011,Ke=1012,qe=1013,Je=1014,Ye=1015,Xe=1016,Ze=1017,Qe=1018,$e=1020,et=35902,tt=35899,nt=1021,rt=1022,it=1023,at=1026,ot=1027,st=1028,ct=1029,lt=1030,ut=1031,dt=1033,ft=33776,pt=33777,mt=33778,ht=33779,gt=35840,_t=35841,vt=35842,yt=35843,bt=36196,xt=37492,St=37496,Ct=37488,wt=37489,Tt=37490,Et=37491,Dt=37808,Ot=37809,kt=37810,At=37811,jt=37812,Mt=37813,Nt=37814,Pt=37815,Ft=37816,It=37817,Lt=37818,Rt=37819,zt=37820,Bt=37821,Vt=36492,Ht=36494,Ut=36495,Wt=36283,Gt=36284,Kt=36285,qt=36286,Jt=2300,Yt=2301,Xt=2302,Zt=2303,Qt=2400,$t=2401,en=2402,tn=3200,nn=`srgb`,rn=`srgb-linear`,an=`linear`,on=`srgb`,sn=7680,cn=35044,ln=2e3;function un(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function dn(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function fn(e){return document.createElementNS(`http://www.w3.org/1999/xhtml`,e)}function pn(){let e=fn(`canvas`);return e.style.display=`block`,e}var mn={};function hn(...e){let t=`THREE.`+e.shift();console.log(t,...e)}function gn(e){let t=e[0];if(typeof t==`string`&&t.startsWith(`TSL:`)){let t=e[1];t&&t.isStackTrace?e[0]+=` `+t.getLocation():e[1]=`Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.`}return e}function L(...e){e=gn(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...e)}}function R(...e){e=gn(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...e)}}function _n(...e){let t=e.join(` `);t in mn||(mn[t]=!0,L(...e))}function vn(e,t,n){return new Promise(function(r,i){function a(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:i();break;case e.TIMEOUT_EXPIRED:setTimeout(a,n);break;default:r()}}setTimeout(a,n)})}var yn={0:1,2:6,4:7,3:5,1:0,6:2,7:4,5:3},bn=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n!==void 0&&n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let r=n[e];if(r!==void 0){let e=r.indexOf(t);e!==-1&&r.splice(e,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let t=n.slice(0);for(let n=0,r=t.length;n<r;n++)t[n].call(this,e);e.target=null}}},xn=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),Sn=1234567,Cn=Math.PI/180,wn=180/Math.PI;function Tn(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(xn[e&255]+xn[e>>8&255]+xn[e>>16&255]+xn[e>>24&255]+`-`+xn[t&255]+xn[t>>8&255]+`-`+xn[t>>16&15|64]+xn[t>>24&255]+`-`+xn[n&63|128]+xn[n>>8&255]+`-`+xn[n>>16&255]+xn[n>>24&255]+xn[r&255]+xn[r>>8&255]+xn[r>>16&255]+xn[r>>24&255]).toLowerCase()}function z(e,t,n){return Math.max(t,Math.min(n,e))}function En(e,t){return(e%t+t)%t}function Dn(e,t,n,r,i){return r+(e-t)*(i-r)/(n-t)}function On(e,t,n){return e===t?0:(n-e)/(t-e)}function kn(e,t,n){return(1-n)*e+n*t}function An(e,t,n,r){return kn(e,t,1-Math.exp(-n*r))}function jn(e,t=1){return t-Math.abs(En(e,t*2)-t)}function Mn(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*(3-2*e))}function Nn(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10))}function Pn(e,t){return e+Math.floor(Math.random()*(t-e+1))}function Fn(e,t){return e+Math.random()*(t-e)}function In(e){return e*(.5-Math.random())}function Ln(e){e!==void 0&&(Sn=e);let t=Sn+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Rn(e){return e*Cn}function zn(e){return e*wn}function Bn(e){return e>0&&Number.isInteger(e)&&2**Math.round(Math.log2(e))===e}function Vn(e){return 2**Math.ceil(Math.log(e)/Math.LN2)}function Hn(e){return 2**Math.floor(Math.log(e)/Math.LN2)}function Un(e,t,n,r,i){let a=Math.cos,o=Math.sin,s=a(n/2),c=o(n/2),l=a((t+r)/2),u=o((t+r)/2),d=a((t-r)/2),f=o((t-r)/2),p=a((r-t)/2),m=o((r-t)/2);switch(i){case`XYX`:e.set(s*u,c*d,c*f,s*l);break;case`YZY`:e.set(c*f,s*u,c*d,s*l);break;case`ZXZ`:e.set(c*d,c*f,s*u,s*l);break;case`XZX`:e.set(s*u,c*m,c*p,s*l);break;case`YXY`:e.set(c*p,s*u,c*m,s*l);break;case`ZYZ`:e.set(c*m,c*p,s*u,s*l);break;default:L(`MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: `+i)}}function Wn(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:case Uint8ClampedArray:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}function Gn(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}var Kn={DEG2RAD:Cn,RAD2DEG:wn,generateUUID:Tn,clamp:z,euclideanModulo:En,mapLinear:Dn,inverseLerp:On,lerp:kn,damp:An,pingpong:jn,smoothstep:Mn,smootherstep:Nn,randInt:Pn,randFloat:Fn,randFloatSpread:In,seededRandom:Ln,degToRad:Rn,radToDeg:zn,isPowerOfTwo:Bn,ceilPowerOfTwo:Vn,floorPowerOfTwo:Hn,setQuaternionFromProperEuler:Un,normalize:Gn,denormalize:Wn},B=class e{static{e.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`THREE.Vector2: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`THREE.Vector2: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=z(this.x,e.x,t.x),this.y=z(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=z(this.x,e,t),this.y=z(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(z(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(z(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},qn=class{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(u!==m||s!==d||c!==f||l!==p){let e=s*d+c*f+l*p+u*m;e<0&&(d=-d,f=-f,p=-p,m=-m,e=-e);let t=1-o;if(e<.9995){let n=Math.acos(e),r=Math.sin(n);t=Math.sin(t*n)/r,o=Math.sin(o*n)/r,s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o}else{s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o;let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:L(`Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(z(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,i=-i,a=-a,o=-o);let s=1-t;if(o<.9995){let e=Math.acos(o),c=Math.sin(e);s=Math.sin(s*e)/c,t=Math.sin(t*e)/c,this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this._onChangeCallback()}else this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},V=class e{static{e.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`THREE.Vector3: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`THREE.Vector3: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Yn.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Yn.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=z(this.x,e.x,t.x),this.y=z(this.y,e.y,t.y),this.z=z(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=z(this.x,e,t),this.y=z(this.y,e,t),this.z=z(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(z(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Jn.copy(this).projectOnVector(e),this.sub(Jn)}reflect(e){return this.sub(Jn.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(z(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Jn=new V,Yn=new qn,H=class e{static{e.prototype.isMatrix3=!0}constructor(e,t,n,r,i,a,o,s,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return _n(`Matrix3: .scale() is deprecated. Use .makeScale() instead.`),this.premultiply(Xn.makeScale(e,t)),this}rotate(e){return _n(`Matrix3: .rotate() is deprecated. Use .makeRotation() instead.`),this.premultiply(Xn.makeRotation(-e)),this}translate(e,t){return _n(`Matrix3: .translate() is deprecated. Use .makeTranslation() instead.`),this.premultiply(Xn.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Xn=new H,Zn=new H().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Qn=new H().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function $n(){let e={enabled:!0,workingColorSpace:rn,spaces:{},convert:function(e,t,n){return this.enabled===!1||t===n||!t||!n||(this.spaces[t].transfer===`srgb`&&(e.r=tr(e.r),e.g=tr(e.g),e.b=tr(e.b)),this.spaces[t].primaries!==this.spaces[n].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===`srgb`&&(e.r=nr(e.r),e.g=nr(e.g),e.b=nr(e.b))),e},workingToColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},colorSpaceToWorking:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===``?an:this.spaces[e].transfer},getToneMappingMode:function(e){return this.spaces[e].outputColorSpaceConfig.toneMappingMode||`standard`},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,n){return e.copy(this.spaces[t].toXYZ).multiply(this.spaces[n].fromXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(t,n){return _n(`ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().`),e.workingToColorSpace(t,n)},toWorkingColorSpace:function(t,n){return _n(`ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().`),e.colorSpaceToWorking(t,n)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],r=[.3127,.329];return e.define({[rn]:{primaries:t,whitePoint:r,transfer:an,toXYZ:Zn,fromXYZ:Qn,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:nn},outputColorSpaceConfig:{drawingBufferColorSpace:nn}},[nn]:{primaries:t,whitePoint:r,transfer:on,toXYZ:Zn,fromXYZ:Qn,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:nn}}}),e}var er=$n();function tr(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}function nr(e){return e<.0031308?e*12.92:1.055*e**.41666-.055}var rr,ir=class{static getDataURL(e,t=`image/png`){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>`u`)return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{rr===void 0&&(rr=fn(`canvas`)),rr.width=e.width,rr.height=e.height;let t=rr.getContext(`2d`);e instanceof ImageData?t.putImageData(e,0,0):t.drawImage(e,0,0,e.width,e.height),n=rr}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap){let t=fn(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);n.drawImage(e,0,0,e.width,e.height);let r=n.getImageData(0,0,e.width,e.height),i=r.data;for(let e=0;e<i.length;e++)i[e]=tr(i[e]/255)*255;return n.putImageData(r,0,0),t}if(e.data){let t=e.data.slice(0);for(let e=0;e<t.length;e++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[e]=Math.floor(tr(t[e]/255)*255):t[e]=tr(t[e]);return{data:t,width:e.width,height:e.height}}return L(`ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.`),e}},ar=0,or=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:ar++}),this.uuid=Tn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<`u`&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<`u`&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t===null?e.set(0,0,0):e.set(t.width,t.height,t.depth||0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:``},r=this.data;if(r!==null){let e;if(Array.isArray(r)){e=[];for(let t=0,n=r.length;t<n;t++)r[t].isDataTexture?e.push(sr(r[t].image)):e.push(sr(r[t]))}else e=sr(r);n.url=e}return t||(e.images[this.uuid]=n),n}};function sr(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap?ir.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(L(`Texture: Unable to serialize Texture.`),{})}var cr=0,lr=new V,ur=class e extends bn{constructor(t=e.DEFAULT_IMAGE,n=e.DEFAULT_MAPPING,r=Fe,i=Fe,a=Be,o=He,s=it,c=Ue,l=e.DEFAULT_ANISOTROPY,u=``){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:cr++}),this.uuid=Tn(),this.name=``,this.source=new or(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=r,this.wrapT=i,this.magFilter=a,this.minFilter=o,this.anisotropy=l,this.format=s,this.internalFormat=null,this.type=c,this.offset=new B(0,0),this.repeat=new B(1,1),this.center=new B(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new H,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(lr).x}get height(){return this.source.getSize(lr).y}get depth(){return this.source.getSize(lr).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){L(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?L(`Texture.setValues(): property '${t}' does not exist.`):r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:`Texture`,generator:`Texture.toJSON`},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:`dispose`})}transformUv(e){if(this.mapping!==300)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Pe:e.x-=Math.floor(e.x);break;case Fe:e.x=e.x<0?0:1;break;case Ie:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x-=Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case Pe:e.y-=Math.floor(e.y);break;case Fe:e.y=e.y<0?0:1;break;case Ie:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y-=Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};ur.DEFAULT_IMAGE=null,ur.DEFAULT_MAPPING=300,ur.DEFAULT_ANISOTROPY=1;var dr=class e{static{e.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`THREE.Vector4: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`THREE.Vector4: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w===void 0?1:e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=z(this.x,e.x,t.x),this.y=z(this.y,e.y,t.y),this.z=z(this.z,e.z,t.z),this.w=z(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=z(this.x,e,t),this.y=z(this.y,e,t),this.z=z(this.z,e,t),this.w=z(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(z(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},fr=class extends bn{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Be,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new dr(0,0,e,t),this.scissorTest=!1,this.viewport=new dr(0,0,e,t),this.textures=[];let r=new ur({width:e,height:t,depth:n.depth}),i=n.count;for(let e=0;e<i;e++)this.textures[e]=r.clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:Be,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let e=0;e<this.textures.length;e++)this.textures[e].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,i=this.textures.length;r<i;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let n=Object.assign({},e.textures[t].image);this.textures[t].source=new or(n)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null){if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture}return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:`dispose`})}},pr=class extends fr{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},mr=class extends ur{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Le,this.minFilter=Le,this.wrapR=Fe,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},hr=class extends ur{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Le,this.minFilter=Le,this.wrapR=Fe,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}},gr=class e{static{e.prototype.isMatrix4=!0}constructor(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,r=1/_r.setFromMatrixColumn(e,0).length(),i=1/_r.setFromMatrixColumn(e,1).length(),a=1/_r.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(yr,e,br)}lookAt(e,t,n){let r=this.elements;return Cr.subVectors(e,t),Cr.lengthSq()===0&&(Cr.z=1),Cr.normalize(),xr.crossVectors(n,Cr),xr.lengthSq()===0&&(Math.abs(n.z)===1?Cr.x+=1e-4:Cr.z+=1e-4,Cr.normalize(),xr.crossVectors(n,Cr)),xr.normalize(),Sr.crossVectors(Cr,xr),r[0]=xr.x,r[4]=Sr.x,r[8]=Cr.x,r[1]=xr.y,r[5]=Sr.y,r[9]=Cr.y,r[2]=xr.z,r[6]=Sr.z,r[10]=Cr.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],E=r[5],D=r[9],O=r[13],k=r[2],A=r[6],j=r[10],ee=r[14],M=r[3],te=r[7],ne=r[11],re=r[15];return i[0]=a*x+o*T+s*k+c*M,i[4]=a*S+o*E+s*A+c*te,i[8]=a*C+o*D+s*j+c*ne,i[12]=a*w+o*O+s*ee+c*re,i[1]=l*x+u*T+d*k+f*M,i[5]=l*S+u*E+d*A+f*te,i[9]=l*C+u*D+d*j+f*ne,i[13]=l*w+u*O+d*ee+f*re,i[2]=p*x+m*T+h*k+g*M,i[6]=p*S+m*E+h*A+g*te,i[10]=p*C+m*D+h*j+g*ne,i[14]=p*w+m*O+h*ee+g*re,i[3]=_*x+v*T+y*k+b*M,i[7]=_*S+v*E+y*A+b*te,i[11]=_*C+v*D+y*j+b*ne,i[15]=_*w+v*O+y*ee+b*re,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15],_=s*f-c*d,v=o*f-c*u,y=o*d-s*u,b=a*f-c*l,x=a*d-s*l,S=a*u-o*l;return t*(m*_-h*v+g*y)-n*(p*_-h*b+g*x)+r*(p*v-m*b+g*S)-i*(p*y-m*x+h*S)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[1],a=e[5],o=e[9],s=e[2],c=e[6],l=e[10];return t*(a*l-o*c)-n*(i*l-o*s)+r*(i*c-a*s)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=t*o-n*a,v=t*s-r*a,y=t*c-i*a,b=n*s-r*o,x=n*c-i*o,S=r*c-i*s,C=l*m-u*p,w=l*h-d*p,T=l*g-f*p,E=u*h-d*m,D=u*g-f*m,O=d*g-f*h,k=_*O-v*D+y*E+b*T-x*w+S*C;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/k;return e[0]=(o*O-s*D+c*E)*A,e[1]=(r*D-n*O-i*E)*A,e[2]=(m*S-h*x+g*b)*A,e[3]=(d*x-u*S-f*b)*A,e[4]=(s*T-a*O-c*w)*A,e[5]=(t*O-r*T+i*w)*A,e[6]=(h*y-p*S-g*v)*A,e[7]=(l*S-d*y+f*v)*A,e[8]=(a*D-o*T+c*C)*A,e[9]=(n*T-t*D-i*C)*A,e[10]=(p*x-m*y+g*_)*A,e[11]=(u*y-l*x-f*_)*A,e[12]=(o*w-a*E-s*C)*A,e[13]=(t*E-n*w+r*C)*A,e[14]=(m*v-p*b-h*_)*A,e[15]=(l*b-u*v+d*_)*A,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let i=this.determinantAffine();if(i===0)return n.set(1,1,1),t.identity(),this;let a=_r.set(r[0],r[1],r[2]).length(),o=_r.set(r[4],r[5],r[6]).length(),s=_r.set(r[8],r[9],r[10]).length();i<0&&(a=-a),vr.copy(this);let c=1/a,l=1/o,u=1/s;return vr.elements[0]*=c,vr.elements[1]*=c,vr.elements[2]*=c,vr.elements[4]*=l,vr.elements[5]*=l,vr.elements[6]*=l,vr.elements[8]*=u,vr.elements[9]*=u,vr.elements[10]*=u,t.setFromRotationMatrix(vr),n.x=a,n.y=o,n.z=s,this}makePerspective(e,t,n,r,i,a,o=ln,s=!1){let c=this.elements,l=2*i/(t-e),u=2*i/(n-r),d=(t+e)/(t-e),f=(n+r)/(n-r),p,m;if(s)p=i/(a-i),m=a*i/(a-i);else if(o===2e3)p=-(a+i)/(a-i),m=-2*a*i/(a-i);else if(o===2001)p=-a/(a-i),m=-a*i/(a-i);else throw Error(`THREE.Matrix4.makePerspective(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=ln,s=!1){let c=this.elements,l=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),f=-(n+r)/(n-r),p,m;if(s)p=1/(a-i),m=a/(a-i);else if(o===2e3)p=-2/(a-i),m=-(a+i)/(a-i);else if(o===2001)p=-1/(a-i),m=-i/(a-i);else throw Error(`THREE.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},_r=new V,vr=new gr,yr=new V(0,0,0),br=new V(1,1,1),xr=new V,Sr=new V,Cr=new V,wr=new gr,Tr=new qn,Er=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin(z(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-z(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin(z(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-z(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin(z(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-z(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:L(`Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return wr.makeRotationFromQuaternion(e),this.setFromRotationMatrix(wr,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Tr.setFromEuler(this),this.setFromQuaternion(Tr,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Er.DEFAULT_ORDER=`XYZ`;var Dr=class{constructor(){this.mask=1}set(e){this.mask=1<<e>>>0}enable(e){this.mask|=1<<e}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e}disable(e){this.mask&=~(1<<e)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return!!(this.mask&1<<e)}},Or=0,kr=new V,Ar=new qn,jr=new gr,Mr=new V,Nr=new V,Pr=new V,Fr=new qn,Ir=new V(1,0,0),Lr=new V(0,1,0),Rr=new V(0,0,1),zr={type:`added`},Br={type:`removed`},Vr={type:`childadded`,child:null},Hr={type:`childremoved`,child:null},Ur=class e extends bn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Or++}),this.uuid=Tn(),this.name=``,this.type=`Object3D`,this.parent=null,this.children=[],this.up=e.DEFAULT_UP.clone();let t=new V,n=new Er,r=new qn,i=new V(1,1,1);function a(){r.setFromEuler(n,!1)}function o(){n.setFromQuaternion(r,void 0,!1)}n._onChange(a),r._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new gr},normalMatrix:{value:new H}}),this.matrix=new gr,this.matrixWorld=new gr,this.matrixAutoUpdate=e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Dr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ar.setFromAxisAngle(e,t),this.quaternion.multiply(Ar),this}rotateOnWorldAxis(e,t){return Ar.setFromAxisAngle(e,t),this.quaternion.premultiply(Ar),this}rotateX(e){return this.rotateOnAxis(Ir,e)}rotateY(e){return this.rotateOnAxis(Lr,e)}rotateZ(e){return this.rotateOnAxis(Rr,e)}translateOnAxis(e,t){return kr.copy(e).applyQuaternion(this.quaternion),this.position.add(kr.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Ir,e)}translateY(e){return this.translateOnAxis(Lr,e)}translateZ(e){return this.translateOnAxis(Rr,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(jr.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Mr.copy(e):Mr.set(e,t,n);let r=this.parent;this.updateWorldMatrix(!0,!1),Nr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?jr.lookAt(Nr,Mr,this.up):jr.lookAt(Mr,Nr,this.up),this.quaternion.setFromRotationMatrix(jr),r&&(jr.extractRotation(r.matrixWorld),Ar.setFromRotationMatrix(jr),this.quaternion.premultiply(Ar.invert()))}add(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return e===this?(R(`Object3D.add: object can't be added as a child of itself.`,e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(zr),Vr.child=e,this.dispatchEvent(Vr),Vr.child=null):R(`Object3D.add: object not an instance of THREE.Object3D.`,e),this)}remove(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.remove(arguments[e]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Br),Hr.child=e,this.dispatchEvent(Hr),Hr.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),jr.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),jr.multiply(e.parent.matrixWorld)),e.applyMatrix4(jr),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(zr),Vr.child=e,this.dispatchEvent(Vr),Vr.child=null,this}getObjectById(e){return this.getObjectByProperty(`id`,e)}getObjectByName(e){return this.getObjectByProperty(`name`,e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Nr,e,Pr),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Nr,Fr,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,r=e.z,i=this.matrix.elements;i[12]+=t-i[0]*t-i[4]*n-i[8]*r,i[13]+=n-i[1]*t-i[5]*n-i[9]*r,i[14]+=r-i[2]*t-i[6]*n-i[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let e=this.children;for(let t=0,r=e.length;t<r;t++)e[t].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==`string`,n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:`Object`,generator:`Object3D.toJSON`});let r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type=`InstancedMesh`,r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type=`BatchedMesh`,r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(e=>({...e,boundingBox:e.boundingBox?e.boundingBox.toJSON():void 0,boundingSphere:e.boundingSphere?e.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(e=>({...e})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function i(t,n){return t[n.uuid]===void 0&&(t[n.uuid]=n.toJSON(e)),n.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=i(e.geometries,this.geometry);let t=this.geometry.parameters;if(t!==void 0&&t.shapes!==void 0){let n=t.shapes;if(Array.isArray(n))for(let t=0,r=n.length;t<r;t++){let r=n[t];i(e.shapes,r)}else i(e.shapes,n)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(i(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0){if(Array.isArray(this.material)){let t=[];for(let n=0,r=this.material.length;n<r;n++)t.push(i(e.materials,this.material[n]));r.material=t}else r.material=i(e.materials,this.material)}if(this.children.length>0){r.children=[];for(let t=0;t<this.children.length;t++)r.children.push(this.children[t].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let t=0;t<this.animations.length;t++){let n=this.animations[t];r.animations.push(i(e.animations,n))}}if(t){let t=a(e.geometries),r=a(e.materials),i=a(e.textures),o=a(e.images),s=a(e.shapes),c=a(e.skeletons),l=a(e.animations),u=a(e.nodes);t.length>0&&(n.geometries=t),r.length>0&&(n.materials=r),i.length>0&&(n.textures=i),o.length>0&&(n.images=o),s.length>0&&(n.shapes=s),c.length>0&&(n.skeletons=c),l.length>0&&(n.animations=l),u.length>0&&(n.nodes=u)}return n.object=r,n;function a(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot===null?null:e.pivot.clone(),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let t=0;t<e.children.length;t++){let n=e.children[t];this.add(n.clone())}return this}dispose(){this.dispatchEvent({type:`dispose`})}};Ur.DEFAULT_UP=new V(0,1,0),Ur.DEFAULT_MATRIX_AUTO_UPDATE=!0,Ur.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Wr=class extends Ur{constructor(){super(),this.isGroup=!0,this.type=`Group`}},Gr={type:`move`},Kr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Wr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Wr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new V,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new V),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Wr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new V,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new V,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:`connected`,data:e}),this}disconnect(e){return this.dispatchEvent({type:`disconnected`,data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,i=null,a=null,o=this._targetRay,s=this._grip,c=this._hand;if(e&&t.session.visibilityState!==`visible-blurred`){if(c&&e.hand){a=!0;for(let r of e.hand.values()){let e=t.getJointPose(r,n),i=this._getHandJoint(c,r);e!==null&&(i.matrix.fromArray(e.transform.matrix),i.matrix.decompose(i.position,i.rotation,i.scale),i.matrixWorldNeedsUpdate=!0,i.jointRadius=e.radius),i.visible=e!==null}let r=c.joints[`index-finger-tip`],i=c.joints[`thumb-tip`],o=r.position.distanceTo(i.position);c.inputState.pinching&&o>.025?(c.inputState.pinching=!1,this.dispatchEvent({type:`pinchend`,handedness:e.handedness,target:this})):!c.inputState.pinching&&o<=.015&&(c.inputState.pinching=!0,this.dispatchEvent({type:`pinchstart`,handedness:e.handedness,target:this}))}else s!==null&&e.gripSpace&&(i=t.getPose(e.gripSpace,n),i!==null&&(s.matrix.fromArray(i.transform.matrix),s.matrix.decompose(s.position,s.rotation,s.scale),s.matrixWorldNeedsUpdate=!0,i.linearVelocity?(s.hasLinearVelocity=!0,s.linearVelocity.copy(i.linearVelocity)):s.hasLinearVelocity=!1,i.angularVelocity?(s.hasAngularVelocity=!0,s.angularVelocity.copy(i.angularVelocity)):s.hasAngularVelocity=!1,s.eventsEnabled&&s.dispatchEvent({type:`gripUpdated`,data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&i!==null&&(r=i),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Gr)))}return o!==null&&(o.visible=r!==null),s!==null&&(s.visible=i!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new Wr;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},qr={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Jr={h:0,s:0,l:0},Yr={h:0,s:0,l:0};function Xr(e,t,n){return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*6*(2/3-n):e}var U=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let t=e;t&&t.isColor?this.copy(t):typeof t==`number`?this.setHex(t):typeof t==`string`&&this.setStyle(t)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=nn){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,er.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=er.workingColorSpace){return this.r=e,this.g=t,this.b=n,er.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=er.workingColorSpace){if(e=En(e,1),t=z(t,0,1),n=z(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,i=2*n-r;this.r=Xr(i,r,e+1/3),this.g=Xr(i,r,e),this.b=Xr(i,r,e-1/3)}return er.colorSpaceToWorking(this,r),this}setStyle(e,t=nn){function n(t){t!==void 0&&parseFloat(t)<1&&L(`Color: Alpha component of `+e+` will be ignored.`)}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let i,a=r[1],o=r[2];switch(a){case`rgb`:case`rgba`:if(i=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(255,parseInt(i[1],10))/255,Math.min(255,parseInt(i[2],10))/255,Math.min(255,parseInt(i[3],10))/255,t);if(i=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(100,parseInt(i[1],10))/100,Math.min(100,parseInt(i[2],10))/100,Math.min(100,parseInt(i[3],10))/100,t);break;case`hsl`:case`hsla`:if(i=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setHSL(parseFloat(i[1])/360,parseFloat(i[2])/100,parseFloat(i[3])/100,t);break;default:L(`Color: Unknown color model `+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let n=r[1],i=n.length;if(i===3)return this.setRGB(parseInt(n.charAt(0),16)/15,parseInt(n.charAt(1),16)/15,parseInt(n.charAt(2),16)/15,t);if(i===6)return this.setHex(parseInt(n,16),t);L(`Color: Invalid hex color `+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=nn){let n=qr[e.toLowerCase()];return n===void 0?L(`Color: Unknown color `+e):this.setHex(n,t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=tr(e.r),this.g=tr(e.g),this.b=tr(e.b),this}copyLinearToSRGB(e){return this.r=nr(e.r),this.g=nr(e.g),this.b=nr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=nn){return er.workingToColorSpace(Zr.copy(this),e),Math.round(z(Zr.r*255,0,255))*65536+Math.round(z(Zr.g*255,0,255))*256+Math.round(z(Zr.b*255,0,255))}getHexString(e=nn){return(`000000`+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=er.workingColorSpace){er.workingToColorSpace(Zr.copy(this),t);let n=Zr.r,r=Zr.g,i=Zr.b,a=Math.max(n,r,i),o=Math.min(n,r,i),s,c,l=(o+a)/2;if(o===a)s=0,c=0;else{let e=a-o;switch(c=l<=.5?e/(a+o):e/(2-a-o),a){case n:s=(r-i)/e+(r<i?6:0);break;case r:s=(i-n)/e+2;break;case i:s=(n-r)/e+4}s/=6}return e.h=s,e.s=c,e.l=l,e}getRGB(e,t=er.workingColorSpace){return er.workingToColorSpace(Zr.copy(this),t),e.r=Zr.r,e.g=Zr.g,e.b=Zr.b,e}getStyle(e=nn){er.workingToColorSpace(Zr.copy(this),e);let t=Zr.r,n=Zr.g,r=Zr.b;return e===`srgb`?`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`:`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`}offsetHSL(e,t,n){return this.getHSL(Jr),this.setHSL(Jr.h+e,Jr.s+t,Jr.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Jr),e.getHSL(Yr);let n=kn(Jr.h,Yr.h,t),r=kn(Jr.s,Yr.s,t),i=kn(Jr.l,Yr.l,t);return this.setHSL(n,r,i),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,r=this.b,i=e.elements;return this.r=i[0]*t+i[3]*n+i[6]*r,this.g=i[1]*t+i[4]*n+i[7]*r,this.b=i[2]*t+i[5]*n+i[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Zr=new U;U.NAMES=qr;var Qr=class extends Ur{constructor(){super(),this.isScene=!0,this.type=`Scene`,this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Er,this.environmentIntensity=1,this.environmentRotation=new Er,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},$r=new V,ei=new V,ti=new V,ni=new V,ri=new V,ii=new V,ai=new V,oi=new V,si=new V,ci=new V,li=new dr,ui=new dr,di=new dr,fi=class e{constructor(e=new V,t=new V,n=new V){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),$r.subVectors(e,t),r.cross($r);let i=r.lengthSq();return i>0?r.multiplyScalar(1/Math.sqrt(i)):r.set(0,0,0)}static getBarycoord(e,t,n,r,i){$r.subVectors(r,t),ei.subVectors(n,t),ti.subVectors(e,t);let a=$r.dot($r),o=$r.dot(ei),s=$r.dot(ti),c=ei.dot(ei),l=ei.dot(ti),u=a*c-o*o;if(u===0)return i.set(0,0,0),null;let d=1/u,f=(c*s-o*l)*d,p=(a*l-o*s)*d;return i.set(1-f-p,p,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,ni)!==null&&ni.x>=0&&ni.y>=0&&ni.x+ni.y<=1}static getInterpolation(e,t,n,r,i,a,o,s){return this.getBarycoord(e,t,n,r,ni)===null?(s.x=0,s.y=0,`z`in s&&(s.z=0),`w`in s&&(s.w=0),null):(s.setScalar(0),s.addScaledVector(i,ni.x),s.addScaledVector(a,ni.y),s.addScaledVector(o,ni.z),s)}static getInterpolatedAttribute(e,t,n,r,i,a){return li.setScalar(0),ui.setScalar(0),di.setScalar(0),li.fromBufferAttribute(e,t),ui.fromBufferAttribute(e,n),di.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(li,i.x),a.addScaledVector(ui,i.y),a.addScaledVector(di,i.z),a}static isFrontFacing(e,t,n,r){return $r.subVectors(n,t),ei.subVectors(e,t),$r.cross(ei).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return $r.subVectors(this.c,this.b),ei.subVectors(this.a,this.b),$r.cross(ei).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return e.getNormal(this.a,this.b,this.c,t)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return e.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,r,i,a){return e.getInterpolation(t,this.a,this.b,this.c,n,r,i,a)}containsPoint(t){return e.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return e.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,r=this.b,i=this.c,a,o;ri.subVectors(r,n),ii.subVectors(i,n),oi.subVectors(e,n);let s=ri.dot(oi),c=ii.dot(oi);if(s<=0&&c<=0)return t.copy(n);si.subVectors(e,r);let l=ri.dot(si),u=ii.dot(si);if(l>=0&&u<=l)return t.copy(r);let d=s*u-l*c;if(d<=0&&s>=0&&l<=0)return a=s/(s-l),t.copy(n).addScaledVector(ri,a);ci.subVectors(e,i);let f=ri.dot(ci),p=ii.dot(ci);if(p>=0&&f<=p)return t.copy(i);let m=f*c-s*p;if(m<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(n).addScaledVector(ii,o);let h=l*p-f*u;if(h<=0&&u-l>=0&&f-p>=0)return ai.subVectors(i,r),o=(u-l)/(u-l+(f-p)),t.copy(r).addScaledVector(ai,o);let g=1/(h+m+d);return a=m*g,o=d*g,t.copy(n).addScaledVector(ri,a).addScaledVector(ii,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},pi=class{constructor(e=new V(1/0,1/0,1/0),t=new V(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(hi.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(hi.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=hi.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute(`position`);if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let t=0,n=r.count;t<n;t++)e.isMesh===!0?e.getVertexPosition(t,hi):hi.fromBufferAttribute(r,t),hi.applyMatrix4(e.matrixWorld),this.expandByPoint(hi);else e.boundingBox===void 0?(n.boundingBox===null&&n.computeBoundingBox(),gi.copy(n.boundingBox)):(e.boundingBox===null&&e.computeBoundingBox(),gi.copy(e.boundingBox)),gi.applyMatrix4(e.matrixWorld),this.union(gi)}let r=e.children;for(let e=0,n=r.length;e<n;e++)this.expandByObject(r[e],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,hi),hi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Ci),wi.subVectors(this.max,Ci),_i.subVectors(e.a,Ci),vi.subVectors(e.b,Ci),yi.subVectors(e.c,Ci),bi.subVectors(vi,_i),xi.subVectors(yi,vi),Si.subVectors(_i,yi);let t=[0,-bi.z,bi.y,0,-xi.z,xi.y,0,-Si.z,Si.y,bi.z,0,-bi.x,xi.z,0,-xi.x,Si.z,0,-Si.x,-bi.y,bi.x,0,-xi.y,xi.x,0,-Si.y,Si.x,0];return!Di(t,_i,vi,yi,wi)||(t=[1,0,0,0,1,0,0,0,1],!Di(t,_i,vi,yi,wi))?!1:(Ti.crossVectors(bi,xi),t=[Ti.x,Ti.y,Ti.z],Di(t,_i,vi,yi,wi))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,hi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(hi).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(mi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),mi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),mi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),mi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),mi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),mi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),mi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),mi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(mi)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},mi=[new V,new V,new V,new V,new V,new V,new V,new V],hi=new V,gi=new pi,_i=new V,vi=new V,yi=new V,bi=new V,xi=new V,Si=new V,Ci=new V,wi=new V,Ti=new V,Ei=new V;function Di(e,t,n,r,i){for(let a=0,o=e.length-3;a<=o;a+=3){Ei.fromArray(e,a);let o=i.x*Math.abs(Ei.x)+i.y*Math.abs(Ei.y)+i.z*Math.abs(Ei.z),s=t.dot(Ei),c=n.dot(Ei),l=r.dot(Ei);if(Math.max(-Math.max(s,c,l),Math.min(s,c,l))>o)return!1}return!0}var Oi=new V,ki=new B,Ai=0,ji=class extends bn{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw TypeError(`THREE.BufferAttribute: array should be a Typed Array.`);this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Ai++}),this.name=``,this.array=e,this.itemSize=t,this.count=e===void 0?0:e.length/t,this.normalized=n,this.usage=cn,this.updateRanges=[],this.gpuType=Ye,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,i=this.itemSize;r<i;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)ki.fromBufferAttribute(this,t),ki.applyMatrix3(e),this.setXY(t,ki.x,ki.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Oi.fromBufferAttribute(this,t),Oi.applyMatrix3(e),this.setXYZ(t,Oi.x,Oi.y,Oi.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Oi.fromBufferAttribute(this,t),Oi.applyMatrix4(e),this.setXYZ(t,Oi.x,Oi.y,Oi.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Oi.fromBufferAttribute(this,t),Oi.applyNormalMatrix(e),this.setXYZ(t,Oi.x,Oi.y,Oi.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Oi.fromBufferAttribute(this,t),Oi.transformDirection(e),this.setXYZ(t,Oi.x,Oi.y,Oi.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Wn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Gn(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Wn(t,this.array)),t}setX(e,t){return this.normalized&&(t=Gn(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Wn(t,this.array)),t}setY(e,t){return this.normalized&&(t=Gn(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Wn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Gn(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Wn(t,this.array)),t}setW(e,t){return this.normalized&&(t=Gn(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Gn(t,this.array),n=Gn(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=Gn(t,this.array),n=Gn(n,this.array),r=Gn(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e*=this.itemSize,this.normalized&&(t=Gn(t,this.array),n=Gn(n,this.array),r=Gn(r,this.array),i=Gn(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=i,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:`dispose`})}},Mi=class extends ji{constructor(e,t,n){super(new Uint16Array(e),t,n)}},Ni=class extends ji{constructor(e,t,n){super(new Uint32Array(e),t,n)}},Pi=class extends ji{constructor(e,t,n){super(new Float32Array(e),t,n)}},Fi=new pi,Ii=new V,Li=new V,Ri=class{constructor(e=new V,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t===void 0?Fi.setFromPoints(e).getCenter(n):n.copy(t);let r=0;for(let t=0,i=e.length;t<i;t++)r=Math.max(r,n.distanceToSquared(e[t]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius*=e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ii.subVectors(e,this.center);let t=Ii.lengthSq();if(t>this.radius*this.radius){let e=Math.sqrt(t),n=(e-this.radius)*.5;this.center.addScaledVector(Ii,n/e),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Li.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ii.copy(e.center).add(Li)),this.expandByPoint(Ii.copy(e.center).sub(Li))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},zi=0,Bi=new gr,Vi=new Ur,Hi=new V,Ui=new pi,Wi=new pi,Gi=new V,Ki=class e extends bn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:zi++}),this.uuid=Tn(),this.name=``,this.type=`BufferGeometry`,this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return this.index=Array.isArray(e)?new(un(e)?Ni:Mi)(e,1):e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let t=new H().getNormalMatrix(e);n.applyNormalMatrix(t),n.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Bi.makeRotationFromQuaternion(e),this.applyMatrix4(Bi),this}rotateX(e){return Bi.makeRotationX(e),this.applyMatrix4(Bi),this}rotateY(e){return Bi.makeRotationY(e),this.applyMatrix4(Bi),this}rotateZ(e){return Bi.makeRotationZ(e),this.applyMatrix4(Bi),this}translate(e,t,n){return Bi.makeTranslation(e,t,n),this.applyMatrix4(Bi),this}scale(e,t,n){return Bi.makeScale(e,t,n),this.applyMatrix4(Bi),this}lookAt(e){return Vi.lookAt(e),Vi.updateMatrix(),this.applyMatrix4(Vi.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Hi).negate(),this.translate(Hi.x,Hi.y,Hi.z),this}setFromPoints(e){let t=this.getAttribute(`position`);if(t===void 0){let t=[];for(let n=0,r=e.length;n<r;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}this.setAttribute(`position`,new Pi(t,3))}else{let n=Math.min(e.length,t.count);for(let r=0;r<n;r++){let n=e[r];t.setXYZ(r,n.x,n.y,n.z||0)}e.length>t.count&&L(`BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.`),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new pi);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)R(`BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.`,this),this.boundingBox.set(new V(-1/0,-1/0,-1/0),new V(1/0,1/0,1/0));else{if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];Ui.setFromBufferAttribute(n),this.morphTargetsRelative?(Gi.addVectors(this.boundingBox.min,Ui.min),this.boundingBox.expandByPoint(Gi),Gi.addVectors(this.boundingBox.max,Ui.max),this.boundingBox.expandByPoint(Gi)):(this.boundingBox.expandByPoint(Ui.min),this.boundingBox.expandByPoint(Ui.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&R(`BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.`,this)}}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ri);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)R(`BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.`,this),this.boundingSphere.set(new V,1/0);else if(e){let n=this.boundingSphere.center;if(Ui.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];Wi.setFromBufferAttribute(n),this.morphTargetsRelative?(Gi.addVectors(Ui.min,Wi.min),Ui.expandByPoint(Gi),Gi.addVectors(Ui.max,Wi.max),Ui.expandByPoint(Gi)):(Ui.expandByPoint(Wi.min),Ui.expandByPoint(Wi.max))}Ui.getCenter(n);let r=0;for(let t=0,i=e.count;t<i;t++)Gi.fromBufferAttribute(e,t),r=Math.max(r,n.distanceToSquared(Gi));if(t)for(let i=0,a=t.length;i<a;i++){let a=t[i],o=this.morphTargetsRelative;for(let t=0,i=a.count;t<i;t++)Gi.fromBufferAttribute(a,t),o&&(Hi.fromBufferAttribute(e,t),Gi.add(Hi)),r=Math.max(r,n.distanceToSquared(Gi))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&R(`BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.`,this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){R(`BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)`);return}let n=t.position,r=t.normal,i=t.uv,a=this.getAttribute(`tangent`);(a===void 0||a.count!==n.count)&&(a=new ji(new Float32Array(4*n.count),4),this.setAttribute(`tangent`,a));let o=[],s=[];for(let e=0;e<n.count;e++)o[e]=new V,s[e]=new V;let c=new V,l=new V,u=new V,d=new B,f=new B,p=new B,m=new V,h=new V;function g(e,t,r){c.fromBufferAttribute(n,e),l.fromBufferAttribute(n,t),u.fromBufferAttribute(n,r),d.fromBufferAttribute(i,e),f.fromBufferAttribute(i,t),p.fromBufferAttribute(i,r),l.sub(c),u.sub(c),f.sub(d),p.sub(d);let a=1/(f.x*p.y-p.x*f.y);isFinite(a)&&(m.copy(l).multiplyScalar(p.y).addScaledVector(u,-f.y).multiplyScalar(a),h.copy(u).multiplyScalar(f.x).addScaledVector(l,-p.x).multiplyScalar(a),o[e].add(m),o[t].add(m),o[r].add(m),s[e].add(h),s[t].add(h),s[r].add(h))}let _=this.groups;_.length===0&&(_=[{start:0,count:e.count}]);for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)g(e.getX(t+0),e.getX(t+1),e.getX(t+2))}let v=new V,y=new V,b=new V,x=new V;function S(e){b.fromBufferAttribute(r,e),x.copy(b);let t=o[e];v.copy(t),v.sub(b.multiplyScalar(b.dot(t))).normalize(),y.crossVectors(x,t);let n=y.dot(s[e])<0?-1:1;a.setXYZW(e,v.x,v.y,v.z,n)}for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)S(e.getX(t+0)),S(e.getX(t+1)),S(e.getX(t+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute(`position`);if(t!==void 0){let n=this.getAttribute(`normal`);if(n===void 0||n.count!==t.count)n=new ji(new Float32Array(t.count*3),3),this.setAttribute(`normal`,n);else for(let e=0,t=n.count;e<t;e++)n.setXYZ(e,0,0,0);let r=new V,i=new V,a=new V,o=new V,s=new V,c=new V,l=new V,u=new V;if(e)for(let d=0,f=e.count;d<f;d+=3){let f=e.getX(d+0),p=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,f),i.fromBufferAttribute(t,p),a.fromBufferAttribute(t,m),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),o.fromBufferAttribute(n,f),s.fromBufferAttribute(n,p),c.fromBufferAttribute(n,m),o.add(l),s.add(l),c.add(l),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(p,s.x,s.y,s.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let e=0,o=t.count;e<o;e+=3)r.fromBufferAttribute(t,e+0),i.fromBufferAttribute(t,e+1),a.fromBufferAttribute(t,e+2),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),n.setXYZ(e+0,l.x,l.y,l.z),n.setXYZ(e+1,l.x,l.y,l.z),n.setXYZ(e+2,l.x,l.y,l.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Gi.fromBufferAttribute(e,t),Gi.normalize(),e.setXYZ(t,Gi.x,Gi.y,Gi.z)}toNonIndexed(){function t(e,t){let n=e.array,r=e.itemSize,i=e.normalized,a=new n.constructor(t.length*r),o=0,s=0;for(let i=0,c=t.length;i<c;i++){o=e.isInterleavedBufferAttribute?t[i]*e.data.stride+e.offset:t[i]*r;for(let e=0;e<r;e++)a[s++]=n[o++]}return new ji(a,r,i)}if(this.index===null)return L(`BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.`),this;let n=new e,r=this.index.array,i=this.attributes;for(let e in i){let a=i[e],o=t(a,r);n.setAttribute(e,o)}let a=this.morphAttributes;for(let e in a){let i=[],o=a[e];for(let e=0,n=o.length;e<n;e++){let n=o[e],a=t(n,r);i.push(a)}n.morphAttributes[e]=i}n.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let e=0,t=o.length;e<t;e++){let t=o[e];n.addGroup(t.start,t.count,t.materialIndex)}return n}toJSON(){let e={metadata:{version:4.7,type:`BufferGeometry`,generator:`BufferGeometry.toJSON`}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?`BufferGeometry`:this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let t=this.parameters;for(let n in t)t[n]!==void 0&&(e[n]=t[n]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let t in n){let r=n[t];e.data.attributes[t]=r.toJSON(e.data)}let r={},i=!1;for(let t in this.morphAttributes){let n=this.morphAttributes[t],a=[];for(let t=0,r=n.length;t<r;t++){let r=n[t];a.push(r.toJSON(e.data))}a.length>0&&(r[t]=a,i=!0)}i&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let r=e.attributes;for(let e in r){let n=r[e];this.setAttribute(e,n.clone(t))}let i=e.morphAttributes;for(let e in i){let n=[],r=i[e];for(let e=0,i=r.length;e<i;e++)n.push(r[e].clone(t));this.morphAttributes[e]=n}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let e=0,t=a.length;e<t;e++){let t=a[e];this.addGroup(t.start,t.count,t.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let s=e.boundingSphere;return s!==null&&(this.boundingSphere=s.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:`dispose`})}},qi=new V,Ji=new V,Yi=new H,Xi=class{constructor(e=new V(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let r=qi.subVectors(n,t).cross(Ji.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let r=e.delta(qi),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||Yi.getNormalMatrix(e),r=this.coplanarPoint(qi).applyMatrix4(e),i=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(i),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},Zi=0,Qi=class extends bn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Zi++}),this.uuid=Tn(),this.name=``,this.type=`Material`,this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new U(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=sn,this.stencilZFail=sn,this.stencilZPass=sn,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){L(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?L(`Material: '${t}' is not a property of THREE.${this.type}.`):r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:`Material`,generator:`Material.toJSON`}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(e=>e.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}if(t){let t=r(e.textures),i=r(e.images);t.length>0&&(n.textures=t),i.length>0&&(n.images=i)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new U().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(e=>new Xi().fromJSON(e))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(this.vertexColors=typeof e.vertexColors==`number`?e.vertexColors>0:e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let t=e.normalScale;Array.isArray(t)===!1&&(t=[t,t]),this.normalScale=new B().fromArray(t)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new B().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let e=t.length;n=Array(e);for(let r=0;r!==e;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:`dispose`})}set needsUpdate(e){e===!0&&this.version++}},$i=new V,ea=new V,ta=new V,na=new V,ra=class{constructor(e=new V,t=new V(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,$i)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=$i.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):($i.copy(this.origin).addScaledVector(this.direction,t),$i.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){ea.copy(e).add(t).multiplyScalar(.5),ta.copy(t).sub(e).normalize(),na.copy(this.origin).sub(ea);let i=e.distanceTo(t)*.5,a=-this.direction.dot(ta),o=na.dot(this.direction),s=-na.dot(ta),c=na.lengthSq(),l=Math.abs(1-a*a),u,d,f,p;if(l>0){if(u=a*s-o,d=a*o-s,p=i*l,u>=0){if(d>=-p){if(d<=p){let e=1/l;u*=e,d*=e,f=u*(u+a*d+2*o)+d*(a*u+d+2*s)+c}else d=i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d=-i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d<=-p?(u=Math.max(0,-(-a*i+o)),d=u>0?-i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c):d<=p?(u=0,d=Math.min(Math.max(-i,-s),i),f=d*(d+2*s)+c):(u=Math.max(0,-(a*i+o)),d=u>0?i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c)}else d=a>0?-i:i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(ea).addScaledVector(ta,d),f}intersectSphere(e,t){if(e.radius<0)return null;$i.subVectors(e.center,this.origin);let n=$i.dot(this.direction),r=$i.dot($i)-n*n,i=e.radius*e.radius;if(r>i)return null;let a=Math.sqrt(i-r),o=n-a,s=n+a;return s<0?null:o<0?this.at(s,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,i,a,o,s,c=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),l>=0?(i=(e.min.y-d.y)*l,a=(e.max.y-d.y)*l):(i=(e.max.y-d.y)*l,a=(e.min.y-d.y)*l),n>a||i>r||((i>n||isNaN(n))&&(n=i),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,s=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,s=(e.min.z-d.z)*u),n>s||o>r)||((o>n||n!==n)&&(n=o),(s<r||r!==r)&&(r=s),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,$i)!==null}intersectTriangle(e,t,n,r,i){let a=this.origin,o=this.direction,s=o.x,c=o.y,l=o.z,u=e.x-a.x,d=e.y-a.y,f=e.z-a.z,p=t.x-a.x,m=t.y-a.y,h=t.z-a.z,g=n.x-a.x,_=n.y-a.y,v=n.z-a.z,y=Math.abs(s),b=Math.abs(c),x=Math.abs(l),S,C,w,T,E,D,O,k,A,j,ee,M;if(y>=b&&y>=x?(w=s,D=u,A=p,M=g,s>=0?(S=c,C=l,T=d,E=f,O=m,k=h,j=_,ee=v):(S=l,C=c,T=f,E=d,O=h,k=m,j=v,ee=_)):b>=x?(w=c,D=d,A=m,M=_,c>=0?(S=l,C=s,T=f,E=u,O=h,k=p,j=v,ee=g):(S=s,C=l,T=u,E=f,O=p,k=h,j=g,ee=v)):(w=l,D=f,A=h,M=v,l>=0?(S=s,C=c,T=u,E=d,O=p,k=m,j=g,ee=_):(S=c,C=s,T=d,E=u,O=m,k=p,j=_,ee=g)),w===0)return null;let te=S/w,ne=C/w,re=1/w,ie=T-te*D,ae=E-ne*D,oe=O-te*A,se=k-ne*A,N=j-te*M,ce=ee-ne*M,le=N*se-ce*oe,ue=ie*ce-ae*N,de=oe*ae-se*ie;if(r){if(le<0||ue<0||de<0)return null}else if((le<0||ue<0||de<0)&&(le>0||ue>0||de>0))return null;let fe=le+ue+de;if(fe===0)return null;let pe=re*(le*D+ue*A+de*M);return(fe>0?pe<0:pe>0)?null:this.at(pe/fe,i)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ia=class extends Qi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type=`MeshBasicMaterial`,this.color=new U(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Er,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},aa=new gr,oa=new ra,sa=new Ri,ca=new V,la=new V,ua=new V,da=new V,fa=new V,pa=new V,ma=new V,ha=new V,ga=class extends Ur{constructor(e=new Ki,t=new ia){super(),this.isMesh=!0,this.type=`Mesh`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}getVertexPosition(e,t){let n=this.geometry,r=n.attributes.position,i=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);let o=this.morphTargetInfluences;if(i&&o){pa.set(0,0,0);for(let n=0,r=i.length;n<r;n++){let r=o[n],s=i[n];r!==0&&(fa.fromBufferAttribute(s,e),a?pa.addScaledVector(fa,r):pa.addScaledVector(fa.sub(t),r))}t.add(pa)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.material,i=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),sa.copy(n.boundingSphere),sa.applyMatrix4(i),oa.copy(e.ray).recast(e.near),!(sa.containsPoint(oa.origin)===!1&&(oa.intersectSphere(sa,ca)===null||oa.origin.distanceToSquared(ca)>(e.far-e.near)**2))&&(aa.copy(i).invert(),oa.copy(e.ray).applyMatrix4(aa),(n.boundingBox===null||oa.intersectsBox(n.boundingBox)!==!1)&&this._computeIntersections(e,t,oa)))}_computeIntersections(e,t,n){let r,i=this.geometry,a=this.material,o=i.index,s=i.attributes.position,c=i.attributes.uv,l=i.attributes.uv1,u=i.attributes.normal,d=i.groups,f=i.drawRange;if(o!==null){if(Array.isArray(a))for(let i=0,s=d.length;i<s;i++){let s=d[i],p=a[s.materialIndex],m=Math.max(s.start,f.start),h=Math.min(o.count,Math.min(s.start+s.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=o.getX(i),d=o.getX(i+1),f=o.getX(i+2);r=va(this,p,e,n,c,l,u,a,d,f),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=s.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),s=Math.min(o.count,f.start+f.count);for(let d=i,f=s;d<f;d+=3){let i=o.getX(d),s=o.getX(d+1),f=o.getX(d+2);r=va(this,a,e,n,c,l,u,i,s,f),r&&(r.faceIndex=Math.floor(d/3),t.push(r))}}}else if(s!==void 0){if(Array.isArray(a))for(let i=0,o=d.length;i<o;i++){let o=d[i],p=a[o.materialIndex],m=Math.max(o.start,f.start),h=Math.min(s.count,Math.min(o.start+o.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=i,s=i+1,d=i+2;r=va(this,p,e,n,c,l,u,a,s,d),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=o.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),o=Math.min(s.count,f.start+f.count);for(let s=i,d=o;s<d;s+=3){let i=s,o=s+1,d=s+2;r=va(this,a,e,n,c,l,u,i,o,d),r&&(r.faceIndex=Math.floor(s/3),t.push(r))}}}}};function _a(e,t,n,r,i,a,o,s){let c;if(c=t.side===1?r.intersectTriangle(o,a,i,!0,s):r.intersectTriangle(i,a,o,t.side===0,s),c===null)return null;ha.copy(s),ha.applyMatrix4(e.matrixWorld);let l=n.ray.origin.distanceTo(ha);return l<n.near||l>n.far?null:{distance:l,point:ha.clone(),object:e}}function va(e,t,n,r,i,a,o,s,c,l){e.getVertexPosition(s,la),e.getVertexPosition(c,ua),e.getVertexPosition(l,da);let u=_a(e,t,n,r,la,ua,da,ma);if(u){let e=new V;fi.getBarycoord(ma,la,ua,da,e),i&&(u.uv=fi.getInterpolatedAttribute(i,s,c,l,e,new B)),a&&(u.uv1=fi.getInterpolatedAttribute(a,s,c,l,e,new B)),o&&(u.normal=fi.getInterpolatedAttribute(o,s,c,l,e,new V),u.normal.dot(r.direction)>0&&u.normal.multiplyScalar(-1));let t={a:s,b:c,c:l,normal:new V,materialIndex:0};fi.getNormal(la,ua,da,t.normal),u.face=t,u.barycoord=e}return u}var ya=class extends ur{constructor(e=null,t=1,n=1,r,i,a,o,s,c=Le,l=Le,u,d){super(null,a,o,s,c,l,r,i,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},ba=new Ri,xa=new B(.5,.5),Sa=new V,Ca=class{constructor(e=new Xi,t=new Xi,n=new Xi,r=new Xi,i=new Xi,a=new Xi){this.planes=[e,t,n,r,i,a]}set(e,t,n,r,i,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(i),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ln,n=!1){let r=this.planes,i=e.elements,a=i[0],o=i[1],s=i[2],c=i[3],l=i[4],u=i[5],d=i[6],f=i[7],p=i[8],m=i[9],h=i[10],g=i[11],_=i[12],v=i[13],y=i[14],b=i[15];if(r[0].setComponents(c-a,f-l,g-p,b-_).normalize(),r[1].setComponents(c+a,f+l,g+p,b+_).normalize(),r[2].setComponents(c+o,f+u,g+m,b+v).normalize(),r[3].setComponents(c-o,f-u,g-m,b-v).normalize(),n)r[4].setComponents(s,d,h,y).normalize(),r[5].setComponents(c-s,f-d,g-h,b-y).normalize();else if(r[4].setComponents(c-s,f-d,g-h,b-y).normalize(),t===2e3)r[5].setComponents(c+s,f+d,g+h,b+y).normalize();else if(t===2001)r[5].setComponents(s,d,h,y).normalize();else throw Error(`THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: `+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ba.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ba.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ba)}intersectsSprite(e){return ba.center.set(0,0,0),ba.radius=.7071067811865476+xa.distanceTo(e.center),ba.applyMatrix4(e.matrixWorld),this.intersectsSphere(ba)}intersectsSphere(e){let t=this.planes,n=e.center,r=-e.radius;for(let e=0;e<6;e++)if(t[e].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let r=t[n];if(Sa.x=r.normal.x>0?e.max.x:e.min.x,Sa.y=r.normal.y>0?e.max.y:e.min.y,Sa.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Sa)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},wa=class extends Qi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type=`LineBasicMaterial`,this.color=new U(16777215),this.map=null,this.linewidth=1,this.linecap=`round`,this.linejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Ta=new V,Ea=new V,Da=new gr,Oa=new ra,ka=new Ri,Aa=new V,ja=new V,Ma=class extends Ur{constructor(e=new Ki,t=new wa){super(),this.isLine=!0,this.type=`Line`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let e=1,r=t.count;e<r;e++)Ta.fromBufferAttribute(t,e-1),Ea.fromBufferAttribute(t,e),n[e]=n[e-1],n[e]+=Ta.distanceTo(Ea);e.setAttribute(`lineDistance`,new Pi(n,1))}else L(`Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ka.copy(n.boundingSphere),ka.applyMatrix4(r),ka.radius+=i,e.ray.intersectsSphere(ka)===!1)return;Da.copy(r).invert(),Oa.copy(e.ray).applyMatrix4(Da);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=this.isLineSegments?2:1,l=n.index,u=n.attributes.position;if(l!==null){let n=Math.max(0,a.start),r=Math.min(l.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=l.getX(i),r=l.getX(i+1),a=Na(this,e,Oa,s,n,r,i);a&&t.push(a)}if(this.isLineLoop){let i=l.getX(r-1),a=l.getX(n),o=Na(this,e,Oa,s,i,a,r-1);o&&t.push(o)}}else{let n=Math.max(0,a.start),r=Math.min(u.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=Na(this,e,Oa,s,i,i+1,i);n&&t.push(n)}if(this.isLineLoop){let i=Na(this,e,Oa,s,r-1,n,r-1);i&&t.push(i)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Na(e,t,n,r,i,a,o){let s=e.geometry.attributes.position;if(Ta.fromBufferAttribute(s,i),Ea.fromBufferAttribute(s,a),n.distanceSqToSegment(Ta,Ea,Aa,ja)>r)return;Aa.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(Aa);if(!(c<t.near||c>t.far))return{distance:c,point:ja.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}var Pa=new V,Fa=new V,Ia=class extends Ma{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type=`LineSegments`}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let e=0,r=t.count;e<r;e+=2)Pa.fromBufferAttribute(t,e),Fa.fromBufferAttribute(t,e+1),n[e]=e===0?0:n[e-1],n[e+1]=n[e]+Pa.distanceTo(Fa);e.setAttribute(`lineDistance`,new Pi(n,1))}else L(`LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}},La=class extends Qi{constructor(e){super(),this.isPointsMaterial=!0,this.type=`PointsMaterial`,this.color=new U(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Ra=new gr,za=new ra,Ba=new Ri,Va=new V,Ha=class extends Ur{constructor(e=new Ki,t=new La){super(),this.isPoints=!0,this.type=`Points`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ba.copy(n.boundingSphere),Ba.applyMatrix4(r),Ba.radius+=i,e.ray.intersectsSphere(Ba)===!1)return;Ra.copy(r).invert(),za.copy(e.ray).applyMatrix4(Ra);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=n.index,l=n.attributes.position;if(c!==null){let n=Math.max(0,a.start),i=Math.min(c.count,a.start+a.count);for(let a=n,o=i;a<o;a++){let n=c.getX(a);Va.fromBufferAttribute(l,n),Ua(Va,n,s,r,e,t,this)}}else{let n=Math.max(0,a.start),i=Math.min(l.count,a.start+a.count);for(let a=n,o=i;a<o;a++)Va.fromBufferAttribute(l,a),Ua(Va,a,s,r,e,t,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Ua(e,t,n,r,i,a,o){let s=za.distanceSqToPoint(e);if(s<n){let n=new V;za.closestPointToPoint(e,n),n.applyMatrix4(r);let c=i.ray.origin.distanceTo(n);if(c<i.near||c>i.far)return;a.push({distance:c,distanceToRay:Math.sqrt(s),point:n,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}var Wa=class extends ur{constructor(e=[],t=301,n,r,i,a,o,s,c,l){super(e,t,n,r,i,a,o,s,c,l),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Ga=class extends ur{constructor(e,t,n,r,i,a,o,s,c){super(e,t,n,r,i,a,o,s,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Ka=class extends ur{constructor(e,t,n=Je,r,i,a,o=Le,s=Le,c,l=at,u=1){if(l!==1026&&l!==1027)throw Error(`THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat`);super({width:e,height:t,depth:u},r,i,a,o,s,l,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new or(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},qa=class extends Ka{constructor(e,t=Je,n=301,r,i,a=Le,o=Le,s,c=at){let l={width:e,height:e,depth:1},u=[l,l,l,l,l,l];super(e,e,t,n,r,i,a,o,s,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},Ja=class extends ur{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},Ya=class e extends Ki{constructor(e=1,t=1,n=1,r=1,i=1,a=1){super(),this.type=`BoxGeometry`,this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:i,depthSegments:a};let o=this;r=Math.floor(r),i=Math.floor(i),a=Math.floor(a);let s=[],c=[],l=[],u=[],d=0,f=0;p(`z`,`y`,`x`,-1,-1,n,t,e,a,i,0),p(`z`,`y`,`x`,1,-1,n,t,-e,a,i,1),p(`x`,`z`,`y`,1,1,e,n,t,r,a,2),p(`x`,`z`,`y`,1,-1,e,n,-t,r,a,3),p(`x`,`y`,`z`,1,-1,e,t,n,r,i,4),p(`x`,`y`,`z`,-1,-1,e,t,-n,r,i,5),this.setIndex(s),this.setAttribute(`position`,new Pi(c,3)),this.setAttribute(`normal`,new Pi(l,3)),this.setAttribute(`uv`,new Pi(u,2));function p(e,t,n,r,i,a,p,m,h,g,_){let v=a/h,y=p/g,b=a/2,x=p/2,S=m/2,C=h+1,w=g+1,T=0,E=0,D=new V;for(let a=0;a<w;a++){let o=a*y-x;for(let s=0;s<C;s++)D[e]=(s*v-b)*r,D[t]=o*i,D[n]=S,c.push(D.x,D.y,D.z),D[e]=0,D[t]=0,D[n]=m>0?1:-1,l.push(D.x,D.y,D.z),u.push(s/h),u.push(1-a/g),T+=1}for(let e=0;e<g;e++)for(let t=0;t<h;t++){let n=d+t+C*e,r=d+t+C*(e+1),i=d+(t+1)+C*(e+1),a=d+(t+1)+C*e;s.push(n,r,a),s.push(r,i,a),E+=6}o.addGroup(f,E,_),f+=E,d+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}},Xa=class e extends Ki{constructor(e=1,t=1,n=1,r=32,i=1,a=!1,o=0,s=Math.PI*2){super(),this.type=`CylinderGeometry`,this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:i,openEnded:a,thetaStart:o,thetaLength:s};let c=this;r=Math.floor(r),i=Math.floor(i);let l=[],u=[],d=[],f=[],p=0,m=[],h=n/2,g=0;_(),a===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(l),this.setAttribute(`position`,new Pi(u,3)),this.setAttribute(`normal`,new Pi(d,3)),this.setAttribute(`uv`,new Pi(f,2));function _(){let a=new V,_=new V,v=0,y=(t-e)/n;for(let c=0;c<=i;c++){let l=[],g=c/i,v=g*(t-e)+e;for(let e=0;e<=r;e++){let t=e/r,i=t*s+o,c=Math.sin(i),m=Math.cos(i);_.x=v*c,_.y=-g*n+h,_.z=v*m,u.push(_.x,_.y,_.z),a.set(c,y,m).normalize(),d.push(a.x,a.y,a.z),f.push(t,1-g),l.push(p++)}m.push(l)}for(let n=0;n<r;n++)for(let r=0;r<i;r++){let a=m[r][n],o=m[r+1][n],s=m[r+1][n+1],c=m[r][n+1];(e>0||r!==0)&&(l.push(a,o,c),v+=3),(t>0||r!==i-1)&&(l.push(o,s,c),v+=3)}c.addGroup(g,v,0),g+=v}function v(n){let i=p,a=new B,m=new V,_=0,v=n===!0?e:t,y=n===!0?1:-1;for(let e=1;e<=r;e++)u.push(0,h*y,0),d.push(0,y,0),f.push(.5,.5),p++;let b=p;for(let e=0;e<=r;e++){let t=e/r*s+o,n=Math.cos(t),i=Math.sin(t);m.x=v*i,m.y=h*y,m.z=v*n,u.push(m.x,m.y,m.z),d.push(0,y,0),a.x=n*.5+.5,a.y=i*.5*y+.5,f.push(a.x,a.y),p++}for(let e=0;e<r;e++){let t=i+e,r=b+e;n===!0?l.push(r,r+1,t):l.push(r+1,r,t),_+=3}c.addGroup(g,_,n===!0?1:2),g+=_}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Za=new V,Qa=new V,$a=new V,eo=new fi,to=class extends Ki{constructor(e=null,t=1){if(super(),this.type=`EdgesGeometry`,this.parameters={geometry:e,thresholdAngle:t},e!==null){let n=1e4,r=Math.cos(Cn*t),i=e.getIndex(),a=e.getAttribute(`position`),o=i?i.count:a.count,s=[0,0,0],c=[`a`,`b`,`c`],l=[,,,],u={},d=[];for(let e=0;e<o;e+=3){i?(s[0]=i.getX(e),s[1]=i.getX(e+1),s[2]=i.getX(e+2)):(s[0]=e,s[1]=e+1,s[2]=e+2);let{a:t,b:o,c:f}=eo;if(t.fromBufferAttribute(a,s[0]),o.fromBufferAttribute(a,s[1]),f.fromBufferAttribute(a,s[2]),eo.getNormal($a),l[0]=`${Math.round(t.x*n)},${Math.round(t.y*n)},${Math.round(t.z*n)}`,l[1]=`${Math.round(o.x*n)},${Math.round(o.y*n)},${Math.round(o.z*n)}`,l[2]=`${Math.round(f.x*n)},${Math.round(f.y*n)},${Math.round(f.z*n)}`,l[0]!==l[1]&&l[1]!==l[2]&&l[2]!==l[0])for(let e=0;e<3;e++){let t=(e+1)%3,n=l[e],i=l[t],a=eo[c[e]],o=eo[c[t]],f=`${n}_${i}`,p=`${i}_${n}`;p in u&&u[p]?($a.dot(u[p].normal)<=r&&(d.push(a.x,a.y,a.z),d.push(o.x,o.y,o.z)),u[p]=null):f in u||(u[f]={index0:s[e],index1:s[t],normal:$a.clone()})}}for(let e in u)if(u[e]){let{index0:t,index1:n}=u[e];Za.fromBufferAttribute(a,t),Qa.fromBufferAttribute(a,n),d.push(Za.x,Za.y,Za.z),d.push(Qa.x,Qa.y,Qa.z)}this.setAttribute(`position`,new Pi(d,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},no=class e extends Ki{constructor(e=1,t=1,n=1,r=1){super(),this.type=`PlaneGeometry`,this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};let i=e/2,a=t/2,o=Math.floor(n),s=Math.floor(r),c=o+1,l=s+1,u=e/o,d=t/s,f=[],p=[],m=[],h=[];for(let e=0;e<l;e++){let t=e*d-a;for(let n=0;n<c;n++){let r=n*u-i;p.push(r,-t,0),m.push(0,0,1),h.push(n/o),h.push(1-e/s)}}for(let e=0;e<s;e++)for(let t=0;t<o;t++){let n=t+c*e,r=t+c*(e+1),i=t+1+c*(e+1),a=t+1+c*e;f.push(n,r,a),f.push(r,i,a)}this.setIndex(f),this.setAttribute(`position`,new Pi(p,3)),this.setAttribute(`normal`,new Pi(m,3)),this.setAttribute(`uv`,new Pi(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.widthSegments,t.heightSegments)}},ro=class e extends Ki{constructor(e=1,t=32,n=16,r=0,i=Math.PI*2,a=0,o=Math.PI){super(),this.type=`SphereGeometry`,this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:i,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let s=Math.min(a+o,Math.PI),c=0,l=[],u=new V,d=new V,f=[],p=[],m=[],h=[];for(let f=0;f<=n;f++){let g=[],_=f/n,v=a+_*o,y=e*Math.cos(v),b=Math.sqrt(e*e-y*y),x=0;f===0&&a===0?x=.5/t:f===n&&s===Math.PI&&(x=-.5/t);for(let e=0;e<=t;e++){let n=e/t,a=r+n*i;u.x=-b*Math.cos(a),u.y=y,u.z=b*Math.sin(a),p.push(u.x,u.y,u.z),d.copy(u).normalize(),m.push(d.x,d.y,d.z),h.push(n+x,1-_),g.push(c++)}l.push(g)}for(let e=0;e<n;e++)for(let r=0;r<t;r++){let t=l[e][r+1],i=l[e][r],o=l[e+1][r],c=l[e+1][r+1];(e!==0||a>0)&&f.push(t,i,c),(e!==n-1||s<Math.PI)&&f.push(i,o,c)}this.setIndex(f),this.setAttribute(`position`,new Pi(p,3)),this.setAttribute(`normal`,new Pi(m,3)),this.setAttribute(`uv`,new Pi(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}},io=class extends Qi{constructor(e){super(),this.isShadowMaterial=!0,this.type=`ShadowMaterial`,this.color=new U(0),this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.fog=e.fog,this}};function ao(e){let t={};for(let n in e){t[n]={};for(let r in e[n]){let i=e[n][r];if(so(i))i.isRenderTargetTexture?(L(`UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().`),t[n][r]=null):t[n][r]=i.clone();else if(Array.isArray(i)){if(so(i[0])){let e=[];for(let t=0,n=i.length;t<n;t++)e[t]=i[t].clone();t[n][r]=e}else t[n][r]=i.slice()}else t[n][r]=i}}return t}function oo(e){let t={};for(let n=0;n<e.length;n++){let r=ao(e[n]);for(let e in r)t[e]=r[e]}return t}function so(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function co(e){let t=[];for(let n=0;n<e.length;n++)t.push(e[n].clone());return t}function lo(e){let t=e.getRenderTarget();return t===null?e.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:er.workingColorSpace}var uo={clone:ao,merge:oo},fo=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,po=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,mo=class extends Qi{constructor(e){super(),this.isShaderMaterial=!0,this.type=`ShaderMaterial`,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=fo,this.fragmentShader=po,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ao(e.uniforms),this.uniformsGroups=co(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let r=this.uniforms[n].value;r&&r.isTexture?t.uniforms[n]={type:`t`,value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[n]={type:`c`,value:r.getHex()}:r&&r.isVector2?t.uniforms[n]={type:`v2`,value:r.toArray()}:r&&r.isVector3?t.uniforms[n]={type:`v3`,value:r.toArray()}:r&&r.isVector4?t.uniforms[n]={type:`v4`,value:r.toArray()}:r&&r.isMatrix3?t.uniforms[n]={type:`m3`,value:r.toArray()}:r&&r.isMatrix4?t.uniforms[n]={type:`m4`,value:r.toArray()}:t.uniforms[n]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let e in this.extensions)this.extensions[e]===!0&&(n[e]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case`t`:this.uniforms[n].value=t[r.value]||null;break;case`c`:this.uniforms[n].value=new U().setHex(r.value);break;case`v2`:this.uniforms[n].value=new B().fromArray(r.value);break;case`v3`:this.uniforms[n].value=new V().fromArray(r.value);break;case`v4`:this.uniforms[n].value=new dr().fromArray(r.value);break;case`m3`:this.uniforms[n].value=new H().fromArray(r.value);break;case`m4`:this.uniforms[n].value=new gr().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let t in e.extensions)this.extensions[t]=e.extensions[t];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},ho=class extends mo{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type=`RawShaderMaterial`}},go=class extends Qi{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type=`MeshStandardMaterial`,this.defines={STANDARD:``},this.color=new U(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new U(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new B(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Er,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:``},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},_o=class extends Qi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type=`MeshDepthMaterial`,this.depthPacking=tn,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},vo=class extends Qi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type=`MeshDistanceMaterial`,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},yo=class extends wa{constructor(e){super(),this.isLineDashedMaterial=!0,this.type=`LineDashedMaterial`,this.scale=1,this.dashSize=3,this.gapSize=1,this.setValues(e)}copy(e){return super.copy(e),this.scale=e.scale,this.dashSize=e.dashSize,this.gapSize=e.gapSize,this}};function bo(e,t){return!e||e.constructor===t?e:typeof t.BYTES_PER_ELEMENT==`number`?new t(e):Array.prototype.slice.call(e)}function xo(e){return e!==void 0&&e.inTangents!==void 0&&e.outTangents!==void 0}var So=class{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r===void 0?new t.constructor(n):r,this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,r=t[n],i=t[n-1];validate_interval:{seek:{let a;linear_scan:{forward_scan:if(!(e<r)){for(let a=n+2;;){if(r===void 0){if(e<i)break forward_scan;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(i=r,r=t[++n],e<r)break seek}a=t.length;break linear_scan}if(!(e>=i)){let o=t[1];e<o&&(n=2,i=o);for(let a=n-2;;){if(i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(r=i,i=t[--n-1],e>=i)break seek}a=n,n=0;break linear_scan}break validate_interval}for(;n<a;){let r=n+a>>>1;e<t[r]?a=r:n=r+1}if(r=t[n],i=t[n-1],i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,i,r)}return this.interpolate_(n,i,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r;for(let e=0;e!==r;++e)t[e]=n[i+e];return t}interpolate_(){throw Error(`THREE.Interpolant: Call to abstract method.`)}intervalChanged_(){}},Co=class extends So{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Qt,endingEnd:Qt}}intervalChanged_(e,t,n){let r=this.parameterPositions,i=e-2,a=e+1,o=r[i],s=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case $t:i=e,o=2*t-n;break;case en:i=r.length-2,o=t+r[i]-r[i+1];break;default:i=e,o=n}if(s===void 0)switch(this.getSettings_().endingEnd){case $t:a=e,s=2*n-t;break;case en:a=1,s=n+r[1]-r[0];break;default:a=e-1,s=t}let c=(n-t)*.5,l=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(s-n),this._offsetPrev=i*l,this._offsetNext=a*l}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(r-t),m=p*p,h=m*p,g=-d*h+2*d*m-d*p,_=(1+d)*h+(-1.5-2*d)*m+(-.5+d)*p+1,v=(-1-f)*h+(1.5+f)*m+.5*p,y=f*h-f*m;for(let e=0;e!==o;++e)i[e]=g*a[l+e]+_*a[c+e]+v*a[s+e]+y*a[u+e];return i}},wo=class extends So{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=(n-t)/(r-t),u=1-l;for(let e=0;e!==o;++e)i[e]=a[c+e]*u+a[s+e]*l;return i}},To=class extends So{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}},Eo=class extends So{interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this.inTangents,u=this.outTangents;if(!l||!u){let e=(n-t)/(r-t),l=1-e;for(let t=0;t!==o;++t)i[t]=a[c+t]*l+a[s+t]*e;return i}let d=o*2,f=e-1;for(let p=0;p!==o;++p){let o=a[c+p],m=a[s+p],h=f*d+p*2,g=u[h],_=u[h+1],v=e*d+p*2,y=l[v],b=l[v+1],x=ko(n,t,g,y,r);i[p]=Do(x,o,_,b,m)}return i}};function Do(e,t,n,r,i){let a=1-e;return a*a*a*t+3*a*a*e*n+3*a*e*e*r+e*e*e*i}function Oo(e,t,n,r,i){let a=1-e;return 3*a*a*(n-t)+6*a*e*(r-n)+3*e*e*(i-r)}function ko(e,t,n,r,i){let a=(e-t)/(i-t);for(let o=0;o<8;o++){let o=Do(a,t,n,r,i)-e;if(Math.abs(o)<1e-10)break;let s=Oo(a,t,n,r,i);if(Math.abs(s)<1e-10)break;a=Math.max(0,Math.min(1,a-o/s))}return a}var Ao=class{constructor(e,t,n,r){if(e===void 0)throw Error(`THREE.KeyframeTrack: track name is undefined`);if(t===void 0||t.length===0)throw Error(`THREE.KeyframeTrack: no keyframes in track named `+e);this.name=e,this.times=bo(t,this.TimeBufferType),this.values=bo(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:bo(e.times,Array),values:bo(e.values,Array)};let t=e.getInterpolation();t!==e.DefaultInterpolation&&(n.interpolation=t),xo(e.settings)&&(n.settings={inTangents:bo(e.settings.inTangents,Array),outTangents:bo(e.settings.outTangents,Array)})}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new To(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new wo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Co(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new Eo(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case Jt:t=this.InterpolantFactoryMethodDiscrete;break;case Yt:t=this.InterpolantFactoryMethodLinear;break;case Xt:t=this.InterpolantFactoryMethodSmooth;break;case Zt:t=this.InterpolantFactoryMethodBezier}if(t===void 0){let t=`unsupported interpolation for `+this.ValueTypeName+` keyframe track named `+this.name;if(this.createInterpolant===void 0){if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(t)}return L(`KeyframeTrack:`,t),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Jt;case this.InterpolantFactoryMethodLinear:return Yt;case this.InterpolantFactoryMethodSmooth:return Xt;case this.InterpolantFactoryMethodBezier:return Zt}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e;xo(this.settings)&&(jo(this.settings.inTangents,e),jo(this.settings.outTangents,e))}return this}trim(e,t){let n=this.times,r=n.length,i=0,a=r-1;for(;i!==r&&n[i]<e;)++i;for(;a!==-1&&n[a]>t;)--a;if(++a,i!==0||a!==r){i>=a&&(a=Math.max(a,1),i=a-1);let e=this.getValueSize();this.times=n.slice(i,a),this.values=this.values.slice(i*e,a*e)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(R(`KeyframeTrack: Invalid value size in track.`,this),e=!1);let n=this.times,r=this.values,i=n.length;i===0&&(R(`KeyframeTrack: Track is empty.`,this),e=!1);let a=null;for(let t=0;t!==i;t++){let r=n[t];if(typeof r==`number`&&isNaN(r)){R(`KeyframeTrack: Time is not a valid number.`,this,t,r),e=!1;break}if(a!==null&&a>r){R(`KeyframeTrack: Out of order keys.`,this,t,r,a),e=!1;break}a=r}if(r!==void 0&&dn(r))for(let t=0,n=r.length;t!==n;++t){let n=r[t];if(isNaN(n)){R(`KeyframeTrack: Value is not a valid number.`,this,t,n),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===Xt,i=e.length-1,a=1;for(let o=1;o<i;++o){let i=!1,s=e[o];if(s!==e[o+1]&&(o!==1||s!==e[0])){if(r)i=!0;else{let e=o*n,r=e-n,a=e+n;for(let o=0;o!==n;++o){let n=t[e+o];if(n!==t[r+o]||n!==t[a+o]){i=!0;break}}}}if(i){if(o!==a){e[a]=e[o];let r=o*n,i=a*n;for(let e=0;e!==n;++e)t[i+e]=t[r+e]}++a}}if(i>0){e[a]=e[i];for(let e=i*n,r=a*n,o=0;o!==n;++o)t[r+o]=t[e+o];++a}return a===e.length?(this.times=e,this.values=t):(this.times=e.slice(0,a),this.values=t.slice(0,a*n)),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,xo(this.settings)&&(r.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),r}};function jo(e,t){for(let n=0,r=e.length;n!==r;n+=2)e[n]*=t}Ao.prototype.ValueTypeName=``,Ao.prototype.TimeBufferType=Float32Array,Ao.prototype.ValueBufferType=Float32Array,Ao.prototype.DefaultInterpolation=Yt;var Mo=class extends Ao{constructor(e,t,n){super(e,t,n)}};Mo.prototype.ValueTypeName=`bool`,Mo.prototype.ValueBufferType=Array,Mo.prototype.DefaultInterpolation=Jt,Mo.prototype.InterpolantFactoryMethodLinear=void 0,Mo.prototype.InterpolantFactoryMethodSmooth=void 0;var No=class extends Ao{constructor(e,t,n,r){super(e,t,n,r)}};No.prototype.ValueTypeName=`color`;var Po=class extends Ao{constructor(e,t,n,r){super(e,t,n,r)}};Po.prototype.ValueTypeName=`number`;var Fo=class extends So{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=(n-t)/(r-t),c=e*o;for(let e=c+o;c!==e;c+=4)qn.slerpFlat(i,0,a,c-o,a,c,s);return i}},Io=class extends Ao{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new Fo(this.times,this.values,this.getValueSize(),e)}};Io.prototype.ValueTypeName=`quaternion`,Io.prototype.InterpolantFactoryMethodSmooth=void 0;var Lo=class extends Ao{constructor(e,t,n){super(e,t,n)}};Lo.prototype.ValueTypeName=`string`,Lo.prototype.ValueBufferType=Array,Lo.prototype.DefaultInterpolation=Jt,Lo.prototype.InterpolantFactoryMethodLinear=void 0,Lo.prototype.InterpolantFactoryMethodSmooth=void 0;var Ro=class extends Ao{constructor(e,t,n,r){super(e,t,n,r)}};Ro.prototype.ValueTypeName=`vector`;var zo=class extends Ur{constructor(e,t=1){super(),this.isLight=!0,this.type=`Light`,this.color=new U(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},Bo=class extends zo{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type=`HemisphereLight`,this.position.copy(Ur.DEFAULT_UP),this.updateMatrix(),this.groundColor=new U(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){let t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}},Vo=new gr,Ho=new V,Uo=new V,Wo=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new B(512,512),this.mapType=Ue,this.map=null,this.mapPass=null,this.matrix=new gr,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ca,this._frameExtents=new B(1,1),this._viewportCount=1,this._viewports=[new dr(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;Ho.setFromMatrixPosition(e.matrixWorld),t.position.copy(Ho),Uo.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Uo),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,r){Vo.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(Vo,e.coordinateSystem,e.reversedDepth);let i=this._frameExtents,a=r?r.z/i.x:1,o=r?r.w/i.y:1,s=r?r.x/i.x:0,c=r?r.y/i.y:0;e.coordinateSystem===2001||e.reversedDepth?t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(Vo)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Go=new V,Ko=new qn,qo=new V,Jo=class extends Ur{constructor(){super(),this.isCamera=!0,this.type=`Camera`,this.matrixWorldInverse=new gr,this.projectionMatrix=new gr,this.projectionMatrixInverse=new gr,this.coordinateSystem=ln,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Go,Ko,qo),qo.x===1&&qo.y===1&&qo.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Go,Ko,qo.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Go,Ko,qo),qo.x===1&&qo.y===1&&qo.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Go,Ko,qo.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},Yo=new V,Xo=new B,Zo=new B,Qo=class extends Jo{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type=`PerspectiveCamera`,this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=wn*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Cn*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return wn*2*Math.atan(Math.tan(Cn*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Yo.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Yo.x,Yo.y).multiplyScalar(-e/Yo.z),Yo.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Yo.x,Yo.y).multiplyScalar(-e/Yo.z)}getViewSize(e,t){return this.getViewBounds(e,Xo,Zo),t.subVectors(Zo,Xo)}setViewOffset(e,t,n,r,i,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Cn*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,i=-.5*r,a=this.view;if(this.view!==null&&this.view.enabled){let e=a.fullWidth,o=a.fullHeight;i+=a.offsetX*r/e,t-=a.offsetY*n/o,r*=a.width/e,n*=a.height/o}let o=this.filmOffset;o!==0&&(i+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(i,i+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},$o=class extends Jo{constructor(e=-1,t=1,n=1,r=-1,i=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type=`OrthographicCamera`,this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=i,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,i,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2,i=n-e,a=n+e,o=r+t,s=r-t;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,t=(this.top-this.bottom)/this.view.fullHeight/this.zoom;i+=e*this.view.offsetX,a=i+e*this.view.width,o-=t*this.view.offsetY,s=o-t*this.view.height}this.projectionMatrix.makeOrthographic(i,a,o,s,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},es=class extends Wo{constructor(){super(new $o(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},ts=class extends zo{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type=`DirectionalLight`,this.position.copy(Ur.DEFAULT_UP),this.updateMatrix(),this.target=new Ur,this.shadow=new es}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}},ns=-90,rs=1,is=class extends Ur{constructor(e,t,n){super(),this.type=`CubeCamera`,this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let r=new Qo(ns,rs,e,t);r.layers=this.layers,this.add(r);let i=new Qo(ns,rs,e,t);i.layers=this.layers,this.add(i);let a=new Qo(ns,rs,e,t);a.layers=this.layers,this.add(a);let o=new Qo(ns,rs,e,t);o.layers=this.layers,this.add(o);let s=new Qo(ns,rs,e,t);s.layers=this.layers,this.add(s);let c=new Qo(ns,rs,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,r,i,a,o,s]=t;for(let e of t)this.remove(e);if(e===2e3)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),i.up.set(0,0,-1),i.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),s.up.set(0,1,0),s.lookAt(0,0,-1);else if(e===2001)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),i.up.set(0,0,1),i.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),s.up.set(0,-1,0),s.lookAt(0,0,-1);else throw Error(`THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: `+e);for(let e of t)this.add(e),e.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[i,a,o,s,c,l]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;let m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let h=!1;h=e.isWebGLRenderer===!0?e.state.buffers.depth.getReversed():e.reversedDepthBuffer,e.setRenderTarget(n,0,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,i),e.setRenderTarget(n,1,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,4,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(u,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}},as=class extends Qo{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}},os=`\\[\\]\\.:\\/`,ss=RegExp(`[\\[\\]\\.:\\/]`,`g`),cs=`[^\\[\\]\\.:\\/]`,ls=`[^`+os.replace(`\\.`,``)+`]`,us=`((?:WC+[\\/:])*)`.replace(`WC`,cs),ds=`(WCOD+)?`.replace(`WCOD`,ls),fs=`(?:\\.(WC+)(?:\\[(.+)\\])?)?`.replace(`WC`,cs),ps=`\\.(WC+)(?:\\[(.+)\\])?`.replace(`WC`,cs),ms=RegExp(`^`+us+ds+fs+ps+`$`),hs=[`material`,`materials`,`bones`,`map`],gs=class{constructor(e,t,n){let r=n||_s.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,i=n.length;r!==i;++r)n[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},_s=class e{constructor(t,n,r){this.path=n,this.parsedPath=r||e.parseTrackName(n),this.node=e.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,n,r){return t&&t.isAnimationObjectGroup?new e.Composite(t,n,r):new e(t,n,r)}static sanitizeNodeName(e){return e.replace(/\s/g,`_`).replace(ss,``)}static parseTrackName(e){let t=ms.exec(e);if(t===null)throw Error(`THREE.PropertyBinding: Cannot parse trackName: `+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(`.`);if(r!==void 0&&r!==-1){let e=n.nodeName.substring(r+1);hs.indexOf(e)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=e)}if(n.propertyName===null||n.propertyName.length===0)throw Error(`THREE.PropertyBinding: can not parse propertyName from trackName: `+e);return n}static findNode(e,t){if(t===void 0||t===``||t===`.`||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(e){for(let r=0;r<e.length;r++){let i=e[r];if(i.name===t||i.uuid===t)return i;let a=n(i.children);if(a)return a}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let t=this.node,n=this.parsedPath,r=n.objectName,i=n.propertyName,a=n.propertyIndex;if(t||(t=e.findNode(this.rootNode,n.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){L(`PropertyBinding: No target node found for track: `+this.path+`.`);return}if(r){let e=n.objectIndex;switch(r){case`materials`:if(!t.material){R(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.materials){R(`PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.`,this);return}t=t.material.materials;break;case`bones`:if(!t.skeleton){R(`PropertyBinding: Can not bind to bones as node does not have a skeleton.`,this);return}t=t.skeleton.bones;for(let n=0;n<t.length;n++)if(t[n].name===e){e=n;break}break;case`map`:if(`map`in t){t=t.map;break}if(!t.material){R(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.map){R(`PropertyBinding: Can not bind to material.map as node.material does not have a map.`,this);return}t=t.material.map;break;default:if(t[r]===void 0){R(`PropertyBinding: Can not bind to objectName of node undefined.`,this);return}t=t[r]}if(e!==void 0){if(t[e]===void 0){R(`PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.`,this,t);return}t=t[e]}}let o=t[i];if(o===void 0){let e=n.nodeName;R(`PropertyBinding: Trying to update property for track: `+e+`.`+i+` but it wasn't found.`,t);return}let s=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?s=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(s=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(a!==void 0){if(i===`morphTargetInfluences`){if(!t.geometry){R(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.`,this);return}if(!t.geometry.morphAttributes){R(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.`,this);return}t.morphTargetDictionary[a]!==void 0&&(a=t.morphTargetDictionary[a])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=a}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][s]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};_s.Composite=gs,_s.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},_s.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},_s.prototype.GetterByBindingType=[_s.prototype._getValue_direct,_s.prototype._getValue_array,_s.prototype._getValue_arrayElement,_s.prototype._getValue_toArray],_s.prototype.SetterByBindingTypeAndVersioning=[[_s.prototype._setValue_direct,_s.prototype._setValue_direct_setNeedsUpdate,_s.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[_s.prototype._setValue_array,_s.prototype._setValue_array_setNeedsUpdate,_s.prototype._setValue_array_setMatrixWorldNeedsUpdate],[_s.prototype._setValue_arrayElement,_s.prototype._setValue_arrayElement_setNeedsUpdate,_s.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[_s.prototype._setValue_fromArray,_s.prototype._setValue_fromArray_setNeedsUpdate,_s.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var vs=new gr,ys=class{constructor(e,t,n=0,r=1/0){this.ray=new ra(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new Dr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):R(`Raycaster: Unsupported camera type: `+t.type)}setFromXRController(e){return vs.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(vs),this}intersectObject(e,t=!0,n=[]){return xs(e,this,n,t),n.sort(bs),n}intersectObjects(e,t=!0,n=[]){for(let r=0,i=e.length;r<i;r++)xs(e[r],this,n,t);return n.sort(bs),n}};function bs(e,t){return e.distance-t.distance}function xs(e,t,n,r){let i=!0;if(e.layers.test(t.layers)&&e.raycast(t,n)===!1&&(i=!1),i===!0&&r===!0){let r=e.children;for(let e=0,i=r.length;e<i;e++)xs(r[e],t,n,!0)}}var Ss=class{constructor(e=1,t=0,n=0){this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){let e=1e-6;return this.phi=z(this.phi,e,Math.PI-e),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(z(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};(class e{static{e.prototype.isMatrix2=!0}constructor(e,t,n,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,r){let i=this.elements;return i[0]=e,i[2]=t,i[1]=n,i[3]=r,this}});var Cs=new V,ws=new V,Ts=new V,Es=new V,Ds=new V,Os=new V,ks=new V,As=class{constructor(e=new V,t=new V){this.start=e,this.end=t}set(e,t){return this.start.copy(e),this.end.copy(t),this}copy(e){return this.start.copy(e.start),this.end.copy(e.end),this}getCenter(e){return e.addVectors(this.start,this.end).multiplyScalar(.5)}delta(e){return e.subVectors(this.end,this.start)}distanceSq(){return this.start.distanceToSquared(this.end)}distance(){return this.start.distanceTo(this.end)}at(e,t){return this.delta(t).multiplyScalar(e).add(this.start)}closestPointToPointParameter(e,t){Cs.subVectors(e,this.start),ws.subVectors(this.end,this.start);let n=ws.dot(ws);if(n===0)return 0;let r=ws.dot(Cs)/n;return t&&(r=z(r,0,1)),r}closestPointToPoint(e,t,n){let r=this.closestPointToPointParameter(e,t);return this.delta(n).multiplyScalar(r).add(this.start)}distanceSqToLine3(e,t=Os,n=ks){let r=1e-8*1e-8,i,a,o=this.start,s=e.start,c=this.end,l=e.end;Ts.subVectors(c,o),Es.subVectors(l,s),Ds.subVectors(o,s);let u=Ts.dot(Ts),d=Es.dot(Es),f=Es.dot(Ds);if(u<=r&&d<=r)return t.copy(o),n.copy(s),t.sub(n),t.dot(t);if(u<=r)i=0,a=f/d,a=z(a,0,1);else{let e=Ts.dot(Ds);if(d<=r)a=0,i=z(-e/u,0,1);else{let t=Ts.dot(Es),n=u*d-t*t;i=n===0?0:z((t*f-e*d)/n,0,1),a=(t*i+f)/d,a<0?(a=0,i=z(-e/u,0,1)):a>1&&(a=1,i=z((t-e)/u,0,1))}}return t.copy(o).addScaledVector(Ts,i),n.copy(s).addScaledVector(Es,a),t.distanceToSquared(n)}applyMatrix4(e){return this.start.applyMatrix4(e),this.end.applyMatrix4(e),this}equals(e){return e.start.equals(this.start)&&e.end.equals(this.end)}clone(){return new this.constructor().copy(this)}},js=class extends Ia{constructor(e=10,t=10,n=4473924,r=8947848){n=new U(n),r=new U(r);let i=t/2,a=e/t,o=e/2,s=[],c=[];for(let e=0,l=0,u=-o;e<=t;e++,u+=a){s.push(-o,0,u,o,0,u),s.push(u,0,-o,u,0,o);let t=e===i?n:r;t.toArray(c,l),l+=3,t.toArray(c,l),l+=3,t.toArray(c,l),l+=3,t.toArray(c,l),l+=3}let l=new Ki;l.setAttribute(`position`,new Pi(s,3)),l.setAttribute(`color`,new Pi(c,3));let u=new wa({vertexColors:!0,toneMapped:!1});super(l,u),this.type=`GridHelper`}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},Ms=class extends Ia{constructor(e,t=16776960){let n=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),r=[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,-1],i=new Ki;i.setIndex(new ji(n,1)),i.setAttribute(`position`,new Pi(r,3)),super(i,new wa({color:t,toneMapped:!1})),this.box=e,this.type=`Box3Helper`,this.geometry.computeBoundingSphere()}updateMatrixWorld(e){let t=this.box;t.isEmpty()||(t.getCenter(this.position),t.getSize(this.scale),this.scale.multiplyScalar(.5),super.updateMatrixWorld(e))}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},Ns=class extends bn{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}};function Ps(e,t,n,r){let i=Fs(r);switch(n){case nt:return e*t;case st:return e*t/i.components*i.byteLength;case ct:return e*t/i.components*i.byteLength;case lt:return e*t*2/i.components*i.byteLength;case ut:return e*t*2/i.components*i.byteLength;case rt:return e*t*3/i.components*i.byteLength;case it:return e*t*4/i.components*i.byteLength;case dt:return e*t*4/i.components*i.byteLength;case ft:case pt:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case mt:case ht:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case _t:case yt:return Math.max(e,16)*Math.max(t,8)/4;case gt:case vt:return Math.max(e,8)*Math.max(t,8)/2;case bt:case xt:case Ct:case wt:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case St:case Tt:case Et:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case Dt:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case Ot:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case kt:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case At:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case jt:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case Mt:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case Nt:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case Pt:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case Ft:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case It:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case Lt:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case Rt:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case zt:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case Bt:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case Vt:case Ht:case Ut:return Math.ceil(e/4)*Math.ceil(t/4)*16;case Wt:case Gt:return Math.ceil(e/4)*Math.ceil(t/4)*8;case Kt:case qt:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw Error(`Unable to determine texture byte length for ${n} format.`)}function Fs(e){switch(e){case Ue:case We:return{byteLength:1,components:1};case Ke:case Ge:case Xe:return{byteLength:2,components:1};case Ze:case Qe:return{byteLength:2,components:4};case Je:case qe:case Ye:return{byteLength:4,components:1};case et:case tt:return{byteLength:4,components:3}}throw Error(`THREE.TextureUtils: Unknown texture type ${e}.`)}typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`register`,{detail:{revision:`186`}})),typeof window<`u`&&(window.__THREE__?L(`WARNING: Multiple instances of Three.js being imported.`):window.__THREE__=`186`);function Is(){let e=null,t=!1,n=null,r=null;function i(t,a){r=e.requestAnimationFrame(i),n(t,a)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function Ls(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var W={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},G={common:{diffuse:{value:new U(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new H},alphaMap:{value:null},alphaMapTransform:{value:new H},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new H}},envmap:{envMap:{value:null},envMapRotation:{value:new H},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new H}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new H}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new H},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new H},normalScale:{value:new B(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new H},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new H}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new H}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new H}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new U(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new V},probesMax:{value:new V},probesResolution:{value:new V}},points:{diffuse:{value:new U(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new H},alphaTest:{value:0},uvTransform:{value:new H}},sprite:{diffuse:{value:new U(16777215)},opacity:{value:1},center:{value:new B(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new H},alphaMap:{value:null},alphaMapTransform:{value:new H},alphaTest:{value:0}}},Rs={basic:{uniforms:oo([G.common,G.specularmap,G.envmap,G.aomap,G.lightmap,G.fog]),vertexShader:W.meshbasic_vert,fragmentShader:W.meshbasic_frag},lambert:{uniforms:oo([G.common,G.specularmap,G.envmap,G.aomap,G.lightmap,G.emissivemap,G.bumpmap,G.normalmap,G.displacementmap,G.fog,G.lights,{emissive:{value:new U(0)},envMapIntensity:{value:1}}]),vertexShader:W.meshlambert_vert,fragmentShader:W.meshlambert_frag},phong:{uniforms:oo([G.common,G.specularmap,G.envmap,G.aomap,G.lightmap,G.emissivemap,G.bumpmap,G.normalmap,G.displacementmap,G.fog,G.lights,{emissive:{value:new U(0)},specular:{value:new U(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:W.meshphong_vert,fragmentShader:W.meshphong_frag},standard:{uniforms:oo([G.common,G.envmap,G.aomap,G.lightmap,G.emissivemap,G.bumpmap,G.normalmap,G.displacementmap,G.roughnessmap,G.metalnessmap,G.fog,G.lights,{emissive:{value:new U(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:W.meshphysical_vert,fragmentShader:W.meshphysical_frag},toon:{uniforms:oo([G.common,G.aomap,G.lightmap,G.emissivemap,G.bumpmap,G.normalmap,G.displacementmap,G.gradientmap,G.fog,G.lights,{emissive:{value:new U(0)}}]),vertexShader:W.meshtoon_vert,fragmentShader:W.meshtoon_frag},matcap:{uniforms:oo([G.common,G.bumpmap,G.normalmap,G.displacementmap,G.fog,{matcap:{value:null}}]),vertexShader:W.meshmatcap_vert,fragmentShader:W.meshmatcap_frag},points:{uniforms:oo([G.points,G.fog]),vertexShader:W.points_vert,fragmentShader:W.points_frag},dashed:{uniforms:oo([G.common,G.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:W.linedashed_vert,fragmentShader:W.linedashed_frag},depth:{uniforms:oo([G.common,G.displacementmap]),vertexShader:W.depth_vert,fragmentShader:W.depth_frag},normal:{uniforms:oo([G.common,G.bumpmap,G.normalmap,G.displacementmap,{opacity:{value:1}}]),vertexShader:W.meshnormal_vert,fragmentShader:W.meshnormal_frag},sprite:{uniforms:oo([G.sprite,G.fog]),vertexShader:W.sprite_vert,fragmentShader:W.sprite_frag},background:{uniforms:{uvTransform:{value:new H},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:W.background_vert,fragmentShader:W.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new H}},vertexShader:W.backgroundCube_vert,fragmentShader:W.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:W.cube_vert,fragmentShader:W.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:W.equirect_vert,fragmentShader:W.equirect_frag},distance:{uniforms:oo([G.common,G.displacementmap,{referencePosition:{value:new V},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:W.distance_vert,fragmentShader:W.distance_frag},shadow:{uniforms:oo([G.lights,G.fog,{color:{value:new U(0)},opacity:{value:1}}]),vertexShader:W.shadow_vert,fragmentShader:W.shadow_frag}};Rs.physical={uniforms:oo([Rs.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new H},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new H},clearcoatNormalScale:{value:new B(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new H},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new H},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new H},sheen:{value:0},sheenColor:{value:new U(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new H},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new H},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new H},transmissionSamplerSize:{value:new B},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new H},attenuationDistance:{value:0},attenuationColor:{value:new U(0)},specularColor:{value:new U(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new H},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new H},anisotropyVector:{value:new B},anisotropyMap:{value:null},anisotropyMapTransform:{value:new H}}]),vertexShader:W.meshphysical_vert,fragmentShader:W.meshphysical_frag};var zs={r:0,b:0,g:0},Bs=new gr,Vs=new H;Vs.set(-1,0,0,0,1,0,0,0,1);function Hs(e,t,n,r,i,a){let o=new U(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&(i.isCubeTexture||i.mapping===306)?(l===void 0&&(l=new ga(new Ya(1,1,1),new mo({name:`BackgroundCubeMaterial`,uniforms:ao(Rs.backgroundCube.uniforms),vertexShader:Rs.backgroundCube.vertexShader,fragmentShader:Rs.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(Bs.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isCubeTexture&&i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(Vs),l.material.toneMapped=er.getTransfer(i.colorSpace)!==on,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new ga(new no(2,2),new mo({name:`BackgroundMaterial`,uniforms:ao(Rs.background.uniforms),vertexShader:Rs.background.vertexShader,fragmentShader:Rs.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=er.getTransfer(i.colorSpace)!==on,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(zs,lo(e)),n.buffers.color.setClear(zs.r,zs.g,zs.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function Us(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.stride,p=s.offset;if(t.isInstancedInterleavedBuffer){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function Ws(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function Gs(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return t===1023||r.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&n!==1015&&!i&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE))}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(L(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.logarithmicDepthBuffer===!0,f=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`);n.reversedDepthBuffer===!0&&f===!1&&L(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function Ks(e){let t=this,n=null,r=0,i=!1,a=!1,o=new Xi,s=new H,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var qs=4,Js=6,Ys=20,Xs=256,Zs=new $o,Qs=new U,$s=null,ec=0,tc=0,nc=!1,rc=new V,ic=new V,ac=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=rc}=i;$s=this._renderer.getRenderTarget(),ec=this._renderer.getActiveCubeFace(),tc=this._renderer.getActiveMipmapLevel(),nc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s,o),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=fc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=dc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=2**this._lodMax}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget($s,ec,tc),this._renderer.xr.enabled=nc,e.scissorTest=!1,cc(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),$s=this._renderer.getRenderTarget(),ec=this._renderer.getActiveCubeFace(),tc=this._renderer.getActiveMipmapLevel(),nc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Be,minFilter:Be,generateMipmaps:!1,type:Xe,format:it,colorSpace:rn,depthBuffer:!1},r=sc(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=sc(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=oc(r)),this._blurMaterial=uc(r,e,t),this._ggxMaterial=lc(r,e,t)}return r}_compileMaterial(e){let t=new ga(new Ki,e);this._renderer.compile(t,Zs)}_sceneToCubeUV(e,t,n,r,i){let a=new Qo(90,1,t,n),o=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,u=c.toneMapping;c.getClearColor(Qs),c.toneMapping=0,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(r),c.clearDepth(),c.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new ga(new Ya,new ia({name:`PMREM.Background`,side:1,depthWrite:!1,depthTest:!1})));let d=this._backgroundBox,f=d.material,p=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,p=!0):(f.color.copy(Qs),p=!0);for(let t=0;t<6;t++){let n=t%3;n===0?(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x+s[t],i.y,i.z)):n===1?(a.up.set(0,0,o[t]),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y+s[t],i.z)):(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y,i.z+s[t]));let l=this._cubeSize;cc(r,n*l,t>2?l:0,l,l),c.setRenderTarget(r),p&&c.render(d,a),c.render(e,a)}c.toneMapping=u,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,r=e.mapping===301||e.mapping===302;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=fc()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=dc());let i=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=i;let o=i.uniforms;o.envMap.value=e;let s=this._cubeSize;cc(t,0,0,3*s,2*s),n.setRenderTarget(t),n.render(a,Zs)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let t=1;t<r;t++)this._applyGGXFilter(e,t-1,t);t.autoClear=n}_applyGGXFilter(e,t,n){let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let s=a.uniforms,c=n/(this._lodMeshes.length-1),l=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-l*l)*(c*1.25),{_lodMax:d}=this,f=this._sizeLods[n],p=3*f*(n>d-qs?n-d+qs:0),m=4*(this._cubeSize-f);s.envMap.value=e.texture,s.roughness.value=u,s.mipInt.value=d-t,cc(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,Zs),s.envMap.value=i.texture,s.roughness.value=0,s.mipInt.value=d-n,cc(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,Zs)}_blur(e,t,n,r){let i=this._pingPongRenderTarget,a=Math.min(r,Math.PI)/Math.SQRT2;this._blurPass(e,i,t,n,a),this._blurPass(i,e,n,n,a)}_blurPass(e,t,n,r,i){let a=this._renderer,o=this._blurMaterial,s=this._lodMeshes[r];s.material=o;let c=o.uniforms;c.envMap.value=e.texture,c.sigma.value=i,c.mipInt.value=this._lodMax-n;let l=this._sizeLods[r];cc(t,3*l*(r>this._lodMax-qs?r-this._lodMax+qs:0),4*(this._cubeSize-l),3*l,2*l),a.setRenderTarget(t),a.render(s,Zs)}};function oc(e){let t=[],n=[],r=e,i=e-qs+1+Js;for(let e=0;e<i;e++){let e=2**r;t.push(e);let i=1/(e-2),a=-i,o=1+i,s=[a,a,o,a,o,o,a,a,o,o,a,o],c=new Float32Array(108),l=new Float32Array(108);for(let e=0;e<6;e++){let t=e%3*2/3-1,n=e>2?0:-1,r=[t,n,0,t+2/3,n,0,t+2/3,n+1,0,t,n,0,t+2/3,n+1,0,t,n+1,0];c.set(r,18*e);for(let t=0;t<6;t++){let n=s[t*2]*2-1,r=s[t*2+1]*2-1;e===0?ic.set(1,r,n):e===1?ic.set(-n,1,-r):e===2?ic.set(-n,r,1):e===3?ic.set(-1,r,-n):e===4?ic.set(-n,-1,r):ic.set(n,r,-1),ic.toArray(l,(e*6+t)*3)}}let u=new Ki;u.setAttribute(`position`,new ji(c,3)),u.setAttribute(`outputDirection`,new ji(l,3)),n.push(new ga(u,null)),r>qs&&r--}return{lodMeshes:n,sizeLods:t}}function sc(e,t,n){let r=new pr(e,t,n);return r.texture.mapping=306,r.texture.name=`PMREM.cubeUv`,r.scissorTest=!0,r}function cc(e,t,n,r,i){e.viewport.set(t,n,r,i),e.scissor.set(t,n,r,i)}function lc(e,t,n){return new mo({name:`PMREMGGXConvolution`,defines:{GGX_SAMPLES:Xs,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:pc(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function uc(e,t,n){return new mo({name:`SphericalGaussianBlur`,defines:{SAMPLES:Ys,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:pc(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function dc(){return new mo({name:`EquirectangularToCubeUV`,uniforms:{envMap:{value:null}},vertexShader:pc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function fc(){return new mo({name:`CubemapToCubeUV`,uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:pc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function pc(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var mc=class extends pr{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Wa(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Ya(5,5,5),i=new mo({name:`CubemapFromEquirect`,uniforms:ao(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new ga(r,i),o=t.minFilter;return t.minFilter===1008&&(t.minFilter=Be),new is(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}};function hc(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304){if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}{let r=n.image;if(r&&r.height>0){let i=new mc(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}return null}}}return n}function o(t){if(t&&t.isTexture){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new ac(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new ac(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function gc(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&_n(`WebGLRenderer: `+e+` extension not supported.`),t}}}function _c(e,t,n,r){let i={},a=new WeakMap;function o(e){let s=e.target;s.index!==null&&t.remove(s.index);for(let e in s.attributes)t.remove(s.attributes[e]);s.removeEventListener(`dispose`,o),delete i[s.id];let c=a.get(s);c&&(t.remove(c),a.delete(s)),r.releaseStatesOfGeometry(s),s.isInstancedBufferGeometry===!0&&delete s._maxInstanceCount,n.memory.geometries--}function s(e,t){return i[t.id]===!0||(t.addEventListener(`dispose`,o),i[t.id]=!0,n.memory.geometries++),t}function c(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function l(e){let n=[],r=e.index,i=e.attributes.position,o=0;if(i===void 0)return;if(r!==null){let e=r.array;o=r.version;for(let t=0,r=e.length;t<r;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];n.push(r,i,i,a,a,r)}}else{let e=i.array;o=i.version;for(let t=0,r=e.length/3-1;t<r;t+=3){let e=t+0,r=t+1,i=t+2;n.push(e,r,r,i,i,e)}}let s=new(i.count>=65535?Ni:Mi)(n,1);s.version=o;let c=a.get(e);c&&t.remove(c),a.set(e,s)}function u(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&l(e)}else l(e);return a.get(e)}return{get:s,update:c,getWireframeAttribute:u}}function vc(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function yc(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:R(`WebGLInfo: Unknown draw mode:`,r)}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function bc(e,t,n){let r=new WeakMap,i=new dr;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,m=1;p>t.maxTextureSize&&(m=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let h=new Float32Array(p*m*4*u),g=new mr(h,p,m,u);g.type=Ye,g.needsUpdate=!0;let _=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*m*4*t;for(let t=0;t<r.count;t++){let s=t*_;e===!0&&(i.fromBufferAttribute(r,t),h[d+s+0]=i.x,h[d+s+1]=i.y,h[d+s+2]=i.z,h[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),h[d+s+4]=i.x,h[d+s+5]=i.y,h[d+s+6]=i.z,h[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),h[d+s+8]=i.x,h[d+s+9]=i.y,h[d+s+10]=i.z,h[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:g,size:new B(p,m)},r.set(o,d);function v(){g.dispose(),r.delete(o),o.removeEventListener(`dispose`,v)}o.addEventListener(`dispose`,v)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function xc(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var Sc={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function Cc(e,t,n,r,i,a){let o=new pr(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),s=null,c=null,l=new Ki;l.setAttribute(`position`,new Pi([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute(`uv`,new Pi([0,2,0,0,2,0],2));let u=new ho({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new ga(l,u),f=new $o(-1,1,1,-1,0,1),p=null,m=null,h=!1,g,_=null,v=[],y=!1;this.setSize=function(e,t){o.setSize(e,t),s!==null&&s.setSize(e,t),c!==null&&c.setSize(e,t);for(let n=0;n<v.length;n++){let r=v[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){v=e,y=v.length>0&&v[0].isRenderPass===!0;let t=o.width,n=o.height;v.length>0&&s===null&&(s=new pr(t,n,{type:Xe,depthBuffer:!1,stencilBuffer:!1}),c=new pr(t,n,{type:Xe,depthBuffer:!1,stencilBuffer:!1}));for(let e=0;e<v.length;e++){let r=v[e];r.setSize&&r.setSize(t,n)}},this.begin=function(e,t){if(h||e.toneMapping===0&&v.length===0)return!1;if(_=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return y===!1&&e.setRenderTarget(o),g=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return y},this.end=function(e,t){e.toneMapping=g,h=!0;let n=o,r=s;for(let i=0;i<v.length;i++){let a=v[i];a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1&&(n=r,r=r===s?c:s))}if(p!==e.outputColorSpace||m!==e.toneMapping){p=e.outputColorSpace,m=e.toneMapping,u.defines={},er.getTransfer(p)===`srgb`&&(u.defines.SRGB_TRANSFER=``);let t=Sc[m];t&&(u.defines[t]=``),u.needsUpdate=!0}u.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(_),e.render(d,f),_=null,h=!1},this.isCompositing=function(){return h},this.dispose=function(){o.dispose(),s!==null&&s.dispose(),c!==null&&c.dispose(),l.dispose(),u.dispose()}}var wc=new ur,Tc=new Ka(1,1),Ec=new mr,Dc=new hr,Oc=new Wa,kc=[],Ac=[],jc=new Float32Array(16),Mc=new Float32Array(9),Nc=new Float32Array(4);function Pc(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=kc[i];if(a===void 0&&(a=new Float32Array(i),kc[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function Fc(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function Ic(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function Lc(e,t){let n=Ac[t];n===void 0&&(n=new Int32Array(t),Ac[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function Rc(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function zc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Fc(n,t))return;e.uniform2fv(this.addr,t),Ic(n,t)}}function Bc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(Fc(n,t))return;e.uniform3fv(this.addr,t),Ic(n,t)}}function Vc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Fc(n,t))return;e.uniform4fv(this.addr,t),Ic(n,t)}}function Hc(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Fc(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),Ic(n,t)}else{if(Fc(n,r))return;Nc.set(r),e.uniformMatrix2fv(this.addr,!1,Nc),Ic(n,r)}}function Uc(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Fc(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),Ic(n,t)}else{if(Fc(n,r))return;Mc.set(r),e.uniformMatrix3fv(this.addr,!1,Mc),Ic(n,r)}}function Wc(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(Fc(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),Ic(n,t)}else{if(Fc(n,r))return;jc.set(r),e.uniformMatrix4fv(this.addr,!1,jc),Ic(n,r)}}function Gc(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function Kc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Fc(n,t))return;e.uniform2iv(this.addr,t),Ic(n,t)}}function qc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Fc(n,t))return;e.uniform3iv(this.addr,t),Ic(n,t)}}function Jc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Fc(n,t))return;e.uniform4iv(this.addr,t),Ic(n,t)}}function Yc(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function Xc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Fc(n,t))return;e.uniform2uiv(this.addr,t),Ic(n,t)}}function Zc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Fc(n,t))return;e.uniform3uiv(this.addr,t),Ic(n,t)}}function Qc(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Fc(n,t))return;e.uniform4uiv(this.addr,t),Ic(n,t)}}function $c(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;this.type===e.SAMPLER_2D_SHADOW?(Tc.compareFunction=n.isReversedDepthBuffer()?518:515,a=Tc):a=wc,n.setTexture2D(t||a,i)}function el(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||Dc,i)}function tl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTextureCube(t||Oc,i)}function nl(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||Ec,i)}function rl(e){switch(e){case 5126:return Rc;case 35664:return zc;case 35665:return Bc;case 35666:return Vc;case 35674:return Hc;case 35675:return Uc;case 35676:return Wc;case 5124:case 35670:return Gc;case 35667:case 35671:return Kc;case 35668:case 35672:return qc;case 35669:case 35673:return Jc;case 5125:return Yc;case 36294:return Xc;case 36295:return Zc;case 36296:return Qc;case 35678:case 36198:case 36298:case 36306:case 35682:return $c;case 35679:case 36299:case 36307:return el;case 35680:case 36300:case 36308:case 36293:return tl;case 36289:case 36303:case 36311:case 36292:return nl}}function il(e,t){e.uniform1fv(this.addr,t)}function al(e,t){let n=Pc(t,this.size,2);e.uniform2fv(this.addr,n)}function ol(e,t){let n=Pc(t,this.size,3);e.uniform3fv(this.addr,n)}function sl(e,t){let n=Pc(t,this.size,4);e.uniform4fv(this.addr,n)}function cl(e,t){let n=Pc(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function ll(e,t){let n=Pc(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function ul(e,t){let n=Pc(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function dl(e,t){e.uniform1iv(this.addr,t)}function fl(e,t){e.uniform2iv(this.addr,t)}function pl(e,t){e.uniform3iv(this.addr,t)}function ml(e,t){e.uniform4iv(this.addr,t)}function hl(e,t){e.uniform1uiv(this.addr,t)}function gl(e,t){e.uniform2uiv(this.addr,t)}function _l(e,t){e.uniform3uiv(this.addr,t)}function vl(e,t){e.uniform4uiv(this.addr,t)}function yl(e,t,n){let r=this.cache,i=t.length,a=Lc(n,i);Fc(r,a)||(e.uniform1iv(this.addr,a),Ic(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?Tc:wc;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function bl(e,t,n){let r=this.cache,i=t.length,a=Lc(n,i);Fc(r,a)||(e.uniform1iv(this.addr,a),Ic(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||Dc,a[e])}function xl(e,t,n){let r=this.cache,i=t.length,a=Lc(n,i);Fc(r,a)||(e.uniform1iv(this.addr,a),Ic(r,a));for(let e=0;e!==i;++e)n.setTextureCube(t[e]||Oc,a[e])}function Sl(e,t,n){let r=this.cache,i=t.length,a=Lc(n,i);Fc(r,a)||(e.uniform1iv(this.addr,a),Ic(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||Ec,a[e])}function Cl(e){switch(e){case 5126:return il;case 35664:return al;case 35665:return ol;case 35666:return sl;case 35674:return cl;case 35675:return ll;case 35676:return ul;case 5124:case 35670:return dl;case 35667:case 35671:return fl;case 35668:case 35672:return pl;case 35669:case 35673:return ml;case 5125:return hl;case 36294:return gl;case 36295:return _l;case 36296:return vl;case 35678:case 36198:case 36298:case 36306:case 35682:return yl;case 35679:case 36299:case 36307:return bl;case 35680:case 36300:case 36308:case 36293:return xl;case 36289:case 36303:case 36311:case 36292:return Sl}}var wl=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=rl(t.type)}},Tl=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Cl(t.type)}},El=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},Dl=/(\w+)(\])?(\[|\.)?/g;function Ol(e,t){e.seq.push(t),e.map[t.id]=t}function kl(e,t,n){let r=e.name,i=r.length;for(Dl.lastIndex=0;;){let a=Dl.exec(r),o=Dl.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){Ol(n,l===void 0?new wl(s,e,t):new Tl(s,e,t));break}{let e=n.map[s];e===void 0&&(e=new El(s),Ol(n,e)),n=e}}}var Al=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);kl(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function jl(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var Ml=37297,Nl=0;function Pl(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var Fl=new H;function Il(e){er._getMatrix(Fl,er.workingColorSpace,e);let t=`mat3( ${Fl.elements.map(e=>e.toFixed(4))} )`;switch(er.getTransfer(e)){case an:return[t,`LinearTransferOETF`];case on:return[t,`sRGBTransferOETF`];default:return L(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function Ll(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+Pl(e.getShaderSource(t),r)}return i}function Rl(e,t){let n=Il(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,`}`].join(`
`)}var zl={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function Bl(e,t){let n=zl[t];return n===void 0?(L(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var Vl=new V;function Hl(){return er.getLuminanceCoefficients(Vl),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${Vl.x.toFixed(4)}, ${Vl.y.toFixed(4)}, ${Vl.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function Ul(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(Kl).join(`
`)}function Wl(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function Gl(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function Kl(e){return e!==``}function ql(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Jl(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var Yl=/^[ \t]*#include +<([\w\d./]+)>/gm;function Xl(e){return e.replace(Yl,Ql)}var Zl=new Map;function Ql(e,t){let n=W[t];if(n===void 0){let e=Zl.get(t);if(e!==void 0)n=W[e],L(`WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.`,t,e);else throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`)}return Xl(n)}var $l=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function eu(e){return e.replace($l,tu)}function tu(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function nu(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var ru={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function iu(e){return ru[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var au={301:`ENVMAP_TYPE_CUBE`,302:`ENVMAP_TYPE_CUBE`,306:`ENVMAP_TYPE_CUBE_UV`};function ou(e){return e.envMap===!1?`ENVMAP_TYPE_CUBE`:au[e.envMapMode]||`ENVMAP_TYPE_CUBE`}var su={302:`ENVMAP_MODE_REFRACTION`};function cu(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:su[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var lu={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function uu(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:lu[e.combine]||`ENVMAP_BLENDING_NONE`}function du(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let n=Math.log2(t)-2,r=1/t;return{texelWidth:1/(3*Math.max(2**n,112)),texelHeight:r,maxMip:n}}function fu(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=iu(n),l=ou(n),u=cu(n),d=uu(n),f=du(n),p=Ul(n),m=Wl(a),h=i.createProgram(),g,_,v=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(Kl).join(`
`),g.length>0&&(g+=`
`),_=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(Kl).join(`
`),_.length>0&&(_+=`
`)):(g=[nu(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(Kl).join(`
`),_=[nu(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,f?`#define CUBEUV_TEXEL_WIDTH `+f.texelWidth:``,f?`#define CUBEUV_TEXEL_HEIGHT `+f.texelHeight:``,f?`#define CUBEUV_MAX_MIP `+f.maxMip+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.retroreflection?`#define USE_RETROREFLECTION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.numLightProbeGrids>0?`#define USE_LIGHT_PROBES_GRID`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:W.tonemapping_pars_fragment,n.toneMapping===0?``:Bl(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,W.colorspace_pars_fragment,Rl(`linearToOutputTexel`,n.outputColorSpace),Hl(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(Kl).join(`
`)),o=Xl(o),o=ql(o,n),o=Jl(o,n),s=Xl(s),s=ql(s,n),s=Jl(s,n),o=eu(o),s=eu(s),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+g,_=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+_);let y=v+g+o,b=v+_+s,x=jl(i,i.VERTEX_SHADER,y),S=jl(i,i.FRAGMENT_SHADER,b);i.attachShader(h,x),i.attachShader(h,S),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(h,0,`position`):i.bindAttribLocation(h,0,n.index0AttributeName),i.linkProgram(h);function C(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(h)||``,r=i.getShaderInfoLog(x)||``,a=i.getShaderInfoLog(S)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(h,i.LINK_STATUS)===!1){if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,h,x,S);else{let e=Ll(i,x,`vertex`),n=Ll(i,S,`fragment`);R(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(h,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}}else o===``?(s===``||c===``)&&(u=!1):L(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:g},fragmentShader:{log:c,prefix:_}})}i.deleteShader(x),i.deleteShader(S),w=new Al(i,h),T=Gl(i,h)}let w;this.getUniforms=function(){return w===void 0&&C(this),w};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let E=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(h,Ml)),E},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(h),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=Nl++,this.cacheKey=t,this.usedTimes=1,this.program=h,this.vertexShader=x,this.fragmentShader=S,this}var pu=0,mu=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new hu(e),t.set(e,n)),n}},hu=class{constructor(e){this.id=pu++,this.code=e,this.usedTimes=0}};function gu(e){return e===1030||e===37490||e===36285}function _u(e,t,n,r,i,a){let o=new Dr,s=new mu,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f=r.precision,p={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function m(e){return c.add(e),e===0?`uv`:`uv${e}`}function h(i,o,l,u,h,g){let _=u.fog,v=h.geometry,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,b=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,x=t.get(i.envMap||y,b),S=x&&x.mapping===306?x.image.height:null,C=p[i.type];i.precision!==null&&(f=r.getMaxPrecision(i.precision),f!==i.precision&&L(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,f,`instead.`));let w=v.morphAttributes.position||v.morphAttributes.normal||v.morphAttributes.color,T=w===void 0?0:w.length,E=0;v.morphAttributes.position!==void 0&&(E=1),v.morphAttributes.normal!==void 0&&(E=2),v.morphAttributes.color!==void 0&&(E=3);let D,O,k,A;if(C){let e=Rs[C];D=e.vertexShader,O=e.fragmentShader}else{D=i.vertexShader,O=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),k=e.id,A=t.id}let j=e.getRenderTarget(),ee=e.state.buffers.depth.getReversed(),M=h.isInstancedMesh===!0,te=h.isBatchedMesh===!0,ne=!!i.map,re=!!i.matcap,ie=!!x,ae=!!i.aoMap,oe=!!i.lightMap,se=!!i.bumpMap&&i.wireframe===!1,N=!!i.normalMap,ce=!!i.displacementMap,le=!!i.emissiveMap,ue=!!i.metalnessMap,de=!!i.roughnessMap,fe=i.anisotropy>0,pe=i.clearcoat>0,me=i.dispersion>0,he=i.retroreflectivity>0,ge=i.iridescence>0,_e=i.sheen>0,ve=i.transmission>0,ye=fe&&!!i.anisotropyMap,be=pe&&!!i.clearcoatMap,xe=pe&&!!i.clearcoatNormalMap,Se=pe&&!!i.clearcoatRoughnessMap,Ce=ge&&!!i.iridescenceMap,P=ge&&!!i.iridescenceThicknessMap,we=_e&&!!i.sheenColorMap,Te=_e&&!!i.sheenRoughnessMap,Ee=!!i.specularMap,F=!!i.specularColorMap,De=!!i.specularIntensityMap,I=ve&&!!i.transmissionMap,Oe=ve&&!!i.thicknessMap,ke=!!i.gradientMap,Ae=!!i.alphaMap,je=i.alphaTest>0,Me=!!i.alphaHash,Ne=!!i.extensions,Pe=0;i.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Pe=e.toneMapping);let Fe={shaderID:C,shaderType:i.type,shaderName:i.name,vertexShader:D,fragmentShader:O,defines:i.defines,customVertexShaderID:k,customFragmentShaderID:A,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:f,batching:te,batchingColor:te&&h._colorsTexture!==null,instancing:M,instancingColor:M&&h.instanceColor!==null,instancingMorph:M&&h.morphTexture!==null,outputColorSpace:j===null?e.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:er.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:ne,matcap:re,envMap:ie,envMapMode:ie&&x.mapping,envMapCubeUVHeight:S,aoMap:ae,lightMap:oe,bumpMap:se,normalMap:N,displacementMap:ce,emissiveMap:le,normalMapObjectSpace:N&&i.normalMapType===1,normalMapTangentSpace:N&&i.normalMapType===0,packedNormalMap:N&&i.normalMapType===0&&gu(i.normalMap.format),metalnessMap:ue,roughnessMap:de,anisotropy:fe,anisotropyMap:ye,clearcoat:pe,clearcoatMap:be,clearcoatNormalMap:xe,clearcoatRoughnessMap:Se,dispersion:me,retroreflection:he,iridescence:ge,iridescenceMap:Ce,iridescenceThicknessMap:P,sheen:_e,sheenColorMap:we,sheenRoughnessMap:Te,specularMap:Ee,specularColorMap:F,specularIntensityMap:De,transmission:ve,transmissionMap:I,thicknessMap:Oe,gradientMap:ke,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:Ae,alphaTest:je,alphaHash:Me,combine:i.combine,mapUv:ne&&m(i.map.channel),aoMapUv:ae&&m(i.aoMap.channel),lightMapUv:oe&&m(i.lightMap.channel),bumpMapUv:se&&m(i.bumpMap.channel),normalMapUv:N&&m(i.normalMap.channel),displacementMapUv:ce&&m(i.displacementMap.channel),emissiveMapUv:le&&m(i.emissiveMap.channel),metalnessMapUv:ue&&m(i.metalnessMap.channel),roughnessMapUv:de&&m(i.roughnessMap.channel),anisotropyMapUv:ye&&m(i.anisotropyMap.channel),clearcoatMapUv:be&&m(i.clearcoatMap.channel),clearcoatNormalMapUv:xe&&m(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Se&&m(i.clearcoatRoughnessMap.channel),iridescenceMapUv:Ce&&m(i.iridescenceMap.channel),iridescenceThicknessMapUv:P&&m(i.iridescenceThicknessMap.channel),sheenColorMapUv:we&&m(i.sheenColorMap.channel),sheenRoughnessMapUv:Te&&m(i.sheenRoughnessMap.channel),specularMapUv:Ee&&m(i.specularMap.channel),specularColorMapUv:F&&m(i.specularColorMap.channel),specularIntensityMapUv:De&&m(i.specularIntensityMap.channel),transmissionMapUv:I&&m(i.transmissionMap.channel),thicknessMapUv:Oe&&m(i.thicknessMap.channel),alphaMapUv:Ae&&m(i.alphaMap.channel),vertexTangents:!!v.attributes.tangent&&(N||fe),vertexNormals:!!v.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!v.attributes.color&&v.attributes.color.itemSize===4,pointsUvs:h.isPoints===!0&&!!v.attributes.uv&&(ne||Ae),fog:!!_,useFog:i.fog===!0,fogExp2:!!_&&_.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||v.attributes.normal===void 0&&N===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:ee,skinning:h.isSkinnedMesh===!0,hasPositionAttribute:v.attributes.position!==void 0,morphTargets:v.morphAttributes.position!==void 0,morphNormals:v.morphAttributes.normal!==void 0,morphColors:v.morphAttributes.color!==void 0,morphTargetsCount:T,morphTextureStride:E,numSunLights:o.sun.length,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numSunLightShadows:o.sunShadowMap.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:g.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:Pe,decodeVideoTexture:ne&&i.map.isVideoTexture===!0&&er.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:le&&i.emissiveMap.isVideoTexture===!0&&er.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:Ne&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(Ne&&i.extensions.multiDraw===!0||te)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return Fe.vertexUv1s=c.has(1),Fe.vertexUv2s=c.has(2),Fe.vertexUv3s=c.has(3),c.clear(),Fe}function g(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(_(n,t),v(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function _(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapCubeUVHeight),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.morphAttributeCount),e.push(t.numSunLights),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numSunLightShadows),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function v(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.retroreflection&&o.enable(24),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function y(e){let t=p[e.type],n;if(t){let e=Rs[t];n=uo.clone(e.uniforms)}else n=e.uniforms;return n}function b(t,n){let r=u.get(n);return r===void 0?(r=new fu(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function x(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function S(e){s.remove(e)}function C(){s.dispose()}return{getParameters:h,getProgramCacheKey:g,getUniforms:y,acquireProgram:b,releaseProgram:x,releaseShaderCache:S,programs:l,dispose:C}}function vu(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function yu(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function bu(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function xu(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l,u){u.reversedDepth===!0&&(c=-c);let d=s(e,t,a,o,c,l);a.transmission>0?r.push(d):a.transparent===!0?i.push(d):n.push(d)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t){n.length>1&&n.sort(e||yu),r.length>1&&r.sort(t||bu),i.length>1&&i.sort(t||bu)}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function Su(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new xu,e.set(t,[i])):n>=r.length?(i=new xu,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function Cu(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={direction:new V,color:new U};break;case`SpotLight`:n={position:new V,direction:new V,color:new U,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new V,color:new U,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new V,skyColor:new U,groundColor:new U};break;case`RectAreaLight`:n={color:new U,position:new V,halfWidth:new V,halfHeight:new V}}return e[t.id]=n,n}}}function wu(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new B};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new B};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new B,shadowCameraNear:1,shadowCameraFar:1e3}}return e[t.id]=n,n}}}var Tu=0;function Eu(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function Du(e){let t=new Cu,n=wu(),r={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new V);let i=new V,a=new gr,o=new gr;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0,y=0,b=0,x=0;i.sort(Eu);for(let e=0,S=i.length;e<S;e++){let S=i[e],C=S.color,w=S.intensity,T=S.distance,E=null;if(S.shadow&&S.shadow.map&&(E=S.shadow.map.texture.format===1030?S.shadow.map.texture:S.shadow.map.depthTexture||S.shadow.map.texture),S.isAmbientLight)a+=C.r*w,o+=C.g*w,s+=C.b*w;else if(S.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(S.sh.coefficients[e],w);x++}else if(S.isSunLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()),r.sunShadow[l]=t,r.sunShadowMap[l]=E;let i=e.getViewportCount();for(let t=0;t<i;t++)r.sunShadowMatrix[u+t]=e.getMatrix(t),r.sunShadowCascade[u+t]=e._cascadeData[t];u+=i,l++}r.sun[c]=e,c++}else if(S.isDirectionalLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[d]=t,r.directionalShadowMap[d]=E,r.directionalShadowMatrix[d]=S.shadow.matrix,g++}r.directional[d]=e,d++}else if(S.isSpotLight){let e=t.get(S);e.position.setFromMatrixPosition(S.matrixWorld),e.color.copy(C).multiplyScalar(w),e.distance=T,e.coneCos=Math.cos(S.angle),e.penumbraCos=Math.cos(S.angle*(1-S.penumbra)),e.decay=S.decay,r.spot[p]=e;let i=S.shadow;if(S.map&&(r.spotLightMap[y]=S.map,y++,i.updateMatrices(S),S.castShadow&&b++),r.spotLightMatrix[p]=i.matrix,S.castShadow){let e=n.get(S);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[p]=e,r.spotShadowMap[p]=E,v++}p++}else if(S.isRectAreaLight){let e=t.get(S);e.color.copy(C).multiplyScalar(w),e.halfWidth.set(S.width*.5,0,0),e.halfHeight.set(0,S.height*.5,0),r.rectArea[m]=e,m++}else if(S.isPointLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),e.distance=S.distance,e.decay=S.decay,S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[f]=t,r.pointShadowMap[f]=E,r.pointShadowMatrix[f]=S.shadow.matrix,_++}r.point[f]=e,f++}else if(S.isHemisphereLight){let e=t.get(S);e.skyColor.copy(S.color).multiplyScalar(w),e.groundColor.copy(S.groundColor).multiplyScalar(w),r.hemi[h]=e,h++}}m>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=G.LTC_FLOAT_1,r.rectAreaLTC2=G.LTC_FLOAT_2):(r.rectAreaLTC1=G.LTC_HALF_1,r.rectAreaLTC2=G.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let S=r.hash;(S.sunLength!==c||S.directionalLength!==d||S.pointLength!==f||S.spotLength!==p||S.rectAreaLength!==m||S.hemiLength!==h||S.numSunShadows!==l||S.numDirectionalShadows!==g||S.numPointShadows!==_||S.numSpotShadows!==v||S.numSpotMaps!==y||S.numLightProbes!==x)&&(r.sun.length=c,r.directional.length=d,r.spot.length=p,r.rectArea.length=m,r.point.length=f,r.hemi.length=h,r.sunShadow.length=l,r.sunShadowMap.length=l,r.sunShadowMatrix.length=u,r.sunShadowCascade.length=u,r.directionalShadow.length=g,r.directionalShadowMap.length=g,r.directionalShadowMatrix.length=g,r.pointShadow.length=_,r.pointShadowMap.length=_,r.pointShadowMatrix.length=_,r.spotShadow.length=v,r.spotShadowMap.length=v,r.spotLightMatrix.length=v+y-b,r.spotLightMap.length=y,r.numSpotLightShadowsWithMaps=b,r.numLightProbes=x,S.sunLength=c,S.directionalLength=d,S.pointLength=f,S.spotLength=p,S.rectAreaLength=m,S.hemiLength=h,S.numSunShadows=l,S.numDirectionalShadows=g,S.numPointShadows=_,S.numSpotShadows=v,S.numSpotMaps=y,S.numLightProbes=x,r.version=Tu++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=0,f=t.matrixWorldInverse;for(let t=0,p=e.length;t<p;t++){let p=e[t];if(p.isSunLight){let e=r.sun[n];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),n++}else if(p.isDirectionalLight){let e=r.directional[s];e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),s++}else if(p.isSpotLight){let e=r.spot[l];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),l++}else if(p.isRectAreaLight){let e=r.rectArea[u];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),o.identity(),a.copy(p.matrixWorld),a.premultiply(f),o.extractRotation(a),e.halfWidth.set(p.width*.5,0,0),e.halfHeight.set(0,p.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),u++}else if(p.isPointLight){let e=r.point[c];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),c++}else if(p.isHemisphereLight){let e=r.hemi[d];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),d++}}}return{setup:s,setupView:c,state:r}}function Ou(e){let t=new Du(e),n=[],r=[],i=[];function a(e){d.camera=e,n.length=0,r.length=0,i.length=0}function o(e){n.push(e)}function s(e){r.push(e)}function c(e){i.push(e)}function l(){t.setup(n)}function u(e){t.setupView(n,e)}let d={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:s,pushLightProbeGrid:c}}function ku(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new Ou(e),t.set(n,[a])):r>=i.length?(a=new Ou(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var Au=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ju=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Mu=[new V(1,0,0),new V(-1,0,0),new V(0,1,0),new V(0,-1,0),new V(0,0,1),new V(0,0,-1)],Nu=[new V(0,-1,0),new V(0,-1,0),new V(0,0,1),new V(0,0,-1),new V(0,-1,0),new V(0,-1,0)],Pu=new gr,Fu=new V,Iu=new V;function Lu(e,t,n){let r=new Ca,i=new B,a=new B,o=new dr,s=new _o,c=new vo,l={},u=n.maxTextureSize,d={0:1,1:0,2:2},f=new mo({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new B},radius:{value:4}},vertexShader:Au,fragmentShader:ju}),p=f.clone();p.defines.HORIZONTAL_PASS=1;let m=new Ki;m.setAttribute(`position`,new ji(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let h=new ga(m,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let _=this.type;this.render=function(t,n,s){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||t.length===0)return;this.type===2&&(L(`WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead.`),this.type=1);let c=e.getRenderTarget(),l=e.getActiveCubeFace(),d=e.getActiveMipmapLevel(),f=e.state;f.setBlending(0),f.buffers.depth.getReversed()===!0?f.buffers.color.setClear(0,0,0,0):f.buffers.color.setClear(1,1,1,1),f.buffers.depth.setTest(!0),f.setScissorTest(!1);let p=_!==this.type;p&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let c=0,l=t.length;c<l;c++){let l=t[c],d=l.shadow;if(d===void 0){L(`WebGLShadowMap:`,l,`has no shadow.`);continue}if(d.autoUpdate===!1&&d.needsUpdate===!1)continue;i.copy(d.mapSize);let m=d.getFrameExtents();i.multiply(m),a.copy(d.mapSize),(i.x>u||i.y>u)&&(i.x>u&&(a.x=Math.floor(u/m.x),i.x=a.x*m.x,d.mapSize.x=a.x),i.y>u&&(a.y=Math.floor(u/m.y),i.y=a.y*m.y,d.mapSize.y=a.y));let h=e.state.buffers.depth.getReversed();if(d.camera._reversedDepth=h,d.map===null||p===!0){if(d.map!==null&&(d.map.depthTexture!==null&&(d.map.depthTexture.dispose(),d.map.depthTexture=null),d.map.dispose()),this.type===3){if(l.isPointLight){L(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}d.map=new pr(i.x,i.y,{format:lt,type:Xe,minFilter:Be,magFilter:Be,generateMipmaps:!1}),d.map.texture.name=l.name+`.shadowMap`,d.map.depthTexture=new Ka(i.x,i.y,Ye),d.map.depthTexture.name=l.name+`.shadowMapDepth`,d.map.depthTexture.format=at,d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=Le,d.map.depthTexture.magFilter=Le}else l.isPointLight?(d.map=new mc(i.x),d.map.depthTexture=new qa(i.x,Je)):(d.map=new pr(i.x,i.y),d.map.depthTexture=new Ka(i.x,i.y,Je)),d.map.depthTexture.name=l.name+`.shadowMap`,d.map.depthTexture.format=at,this.type===1?(d.map.depthTexture.compareFunction=h?518:515,d.map.depthTexture.minFilter=Be,d.map.depthTexture.magFilter=Be):(d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=Le,d.map.depthTexture.magFilter=Le);d.camera.updateProjectionMatrix()}d.map.isWebGLCubeRenderTarget!==!0&&(d.map.width!==i.x||d.map.height!==i.y)&&d.map.setSize(i.x,i.y);let g=d.map.isWebGLCubeRenderTarget?6:d.getViewportCount();l.isPointLight!==!0&&d.updateMatrices(l,s);for(let t=0;t<g;t++){let i=d.getCamera(t);if(l.isPointLight){let e=d.camera,n=d.matrix,r=l.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),Fu.setFromMatrixPosition(l.matrixWorld),e.position.copy(Fu),Iu.copy(e.position),Iu.add(Mu[t]),e.up.copy(Nu[t]),e.lookAt(Iu),e.updateMatrixWorld(),n.makeTranslation(-Fu.x,-Fu.y,-Fu.z),Pu.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),d._frustum.setFromProjectionMatrix(Pu,e.coordinateSystem,e.reversedDepth)}if(d.map.isWebGLCubeRenderTarget)e.setRenderTarget(d.map,t),e.clear();else{t===0&&(e.setRenderTarget(d.map),e.clear());let n=d.getViewport(t);o.set(a.x*n.x,a.y*n.y,a.x*n.z,a.y*n.w),f.viewport(o)}r=d.getFrustum(t),b(n,s,i,l,this.type)}d.isPointLightShadow!==!0&&this.type===3&&v(d,s),d.needsUpdate=!1}_=this.type,g.needsUpdate=!1,e.setRenderTarget(c,l,d)};function v(n,r){let a=t.update(h);f.defines.VSM_SAMPLES!==n.blurSamples&&(f.defines.VSM_SAMPLES=n.blurSamples,p.defines.VSM_SAMPLES=n.blurSamples,f.needsUpdate=!0,p.needsUpdate=!0),n.mapPass===null?n.mapPass=new pr(i.x,i.y,{format:lt,type:Xe}):(n.mapPass.width!==n.map.width||n.mapPass.height!==n.map.height)&&n.mapPass.setSize(n.map.width,n.map.height),f.uniforms.shadow_pass.value=n.map.depthTexture,f.uniforms.resolution.value.set(n.map.width,n.map.height),f.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,a,f,h,null),p.uniforms.shadow_pass.value=n.mapPass.texture,p.uniforms.resolution.value.set(n.map.width,n.map.height),p.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,a,p,h,null)}function y(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?c:s,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=l[e];r===void 0&&(r={},l[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,x)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?d[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function b(n,i,a,o,s){if(n.visible===!1)return;if(n.layers.test(i.layers)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&s===3)&&(!n.frustumCulled||n.intersectsFrustum(r))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let r=t.update(n),c=n.material;if(Array.isArray(c)){let t=r.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=c[u.materialIndex];if(d&&d.visible){let t=y(n,d,o,s);n.onBeforeShadow(e,n,i,a,r,t,u),e.renderBufferDirect(a,null,r,t,n,u),n.onAfterShadow(e,n,i,a,r,t,u)}}}else if(c.visible){let t=y(n,c,o,s);n.onBeforeShadow(e,n,i,a,r,t,null),e.renderBufferDirect(a,null,r,t,n,null),n.onAfterShadow(e,n,i,a,r,t,null)}}let c=n.children;for(let e=0,t=c.length;e<t;e++)b(c[e],i,a,o,s)}function x(e){e.target.removeEventListener(`dispose`,x);for(let t in l){let n=l[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function Ru(e,t){function n(){let t=!1,n=new dr,r=null,i=new dr(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?ue(e.DEPTH_TEST):de(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=yn[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?ue(e.STENCIL_TEST):de(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c=new WeakMap,l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new U(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,ee=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),M=!1,te=0,ne=e.getParameter(e.VERSION);ne.indexOf(`WebGL`)===-1?ne.indexOf(`OpenGL ES`)!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(ne)[1]),M=te>=2):(te=parseFloat(/^WebGL (\d)/.exec(ne)[1]),M=te>=1);let re=null,ie={},ae=e.getParameter(e.SCISSOR_BOX),oe=e.getParameter(e.VIEWPORT),se=new dr().fromArray(ae),N=new dr().fromArray(oe);function ce(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let le={};le[e.TEXTURE_2D]=ce(e.TEXTURE_2D,e.TEXTURE_2D,1),le[e.TEXTURE_CUBE_MAP]=ce(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),le[e.TEXTURE_2D_ARRAY]=ce(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),le[e.TEXTURE_3D]=ce(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),ue(e.DEPTH_TEST),o.setFunc(3),ye(!1),be(1),ue(e.CULL_FACE),_e(0);function ue(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function de(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function fe(t,n){return f[t]!==n&&(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function pe(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function me(t){return h!==t&&(e.useProgram(t),h=t,!0)}let he={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};he[103]=e.MIN,he[104]=e.MAX;let ge={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function _e(t,n,r,i,a,o,s,c,l,u){if(t===0)g===!0&&(de(e.BLEND),g=!1);else if(g===!1&&(ue(e.BLEND),g=!0),t!==5){if(t!==_||u!==E){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:R(`WebGLState: Invalid blending: `,t)}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:R(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:R(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:R(`WebGLState: Invalid blending: `,t)}y=null,b=null,S=null,C=null,w.set(0,0,0),T=0,_=t,E=u}}else a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(he[n],he[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==C)&&(e.blendFuncSeparate(ge[r],ge[i],ge[o],ge[s]),y=r,b=i,S=o,C=s),(c.equals(w)===!1||l!==T)&&(e.blendColor(c.r,c.g,c.b,l),w.copy(c),T=l),_=t,E=!1}function ve(t,n){t.side===2?de(e.CULL_FACE):ue(e.CULL_FACE);let r=t.side===1;n&&(r=!r),ye(r),t.blending===1&&t.transparent===!1?_e(0):_e(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),Se(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?ue(e.SAMPLE_ALPHA_TO_COVERAGE):de(e.SAMPLE_ALPHA_TO_COVERAGE)}function ye(t){D!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),D=t)}function be(t){t===0?de(e.CULL_FACE):(ue(e.CULL_FACE),t!==O&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),O=t}function xe(t){t!==k&&(M&&e.lineWidth(t),k=t)}function Se(t,n,r){t?(ue(e.POLYGON_OFFSET_FILL),(A!==n||j!==r)&&(A=n,j=r,o.getReversed()&&(n=-n),e.polygonOffset(n,r))):de(e.POLYGON_OFFSET_FILL)}function Ce(t){t?ue(e.SCISSOR_TEST):de(e.SCISSOR_TEST)}function P(t){t===void 0&&(t=e.TEXTURE0+ee-1),re!==t&&(e.activeTexture(t),re=t)}function we(t,n,r){r===void 0&&(r=re===null?e.TEXTURE0+ee-1:re);let i=ie[r];i===void 0&&(i={type:void 0,texture:void 0},ie[r]=i),(i.type!==t||i.texture!==n)&&(re!==r&&(e.activeTexture(r),re=r),e.bindTexture(t,n||le[t]),i.type=t,i.texture=n)}function Te(){let t=ie[re];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function Ee(){try{e.compressedTexImage2D(...arguments)}catch(e){R(`WebGLState:`,e)}}function F(){try{e.compressedTexImage3D(...arguments)}catch(e){R(`WebGLState:`,e)}}function De(){try{e.texSubImage2D(...arguments)}catch(e){R(`WebGLState:`,e)}}function I(){try{e.texSubImage3D(...arguments)}catch(e){R(`WebGLState:`,e)}}function Oe(){try{e.compressedTexSubImage2D(...arguments)}catch(e){R(`WebGLState:`,e)}}function ke(){try{e.compressedTexSubImage3D(...arguments)}catch(e){R(`WebGLState:`,e)}}function Ae(){try{e.texStorage2D(...arguments)}catch(e){R(`WebGLState:`,e)}}function je(){try{e.texStorage3D(...arguments)}catch(e){R(`WebGLState:`,e)}}function Me(){try{e.texImage2D(...arguments)}catch(e){R(`WebGLState:`,e)}}function Ne(){try{e.texImage3D(...arguments)}catch(e){R(`WebGLState:`,e)}}function Pe(t){return d[t]===void 0?e.getParameter(t):d[t]}function Fe(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function Ie(t){se.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),se.copy(t))}function Le(t){N.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),N.copy(t))}function Re(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),r.set(t,i))}function ze(t,n){let r=l.get(n).get(t);c.get(n)!==r&&(e.uniformBlockBinding(n,r,t.__bindingPointIndex),c.set(n,r))}function Be(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},re=null,ie={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new U(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,se.set(0,0,e.canvas.width,e.canvas.height),N.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:ue,disable:de,bindFramebuffer:fe,drawBuffers:pe,useProgram:me,setBlending:_e,setMaterial:ve,setFlipSided:ye,setCullFace:be,setLineWidth:xe,setPolygonOffset:Se,setScissorTest:Ce,activeTexture:P,bindTexture:we,unbindTexture:Te,compressedTexImage2D:Ee,compressedTexImage3D:F,texImage2D:Me,texImage3D:Ne,pixelStorei:Fe,getParameter:Pe,updateUBOMapping:Re,uniformBlockBinding:ze,texStorage2D:Ae,texStorage3D:je,texSubImage2D:De,texSubImage3D:I,compressedTexSubImage2D:Oe,compressedTexSubImage3D:ke,scissor:Ie,viewport:Le,reset:Be}}function zu(e,t,n,r,i,a,o){let s=t.has(`WEBGL_multisampled_render_to_texture`)?t.get(`WEBGL_multisampled_render_to_texture`):null,c=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),l=new B,u=new WeakMap,d=new Set,f,p=new WeakMap,m=!1;try{m=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function h(e,t){return m?new OffscreenCanvas(e,t):fn(`canvas`)}function g(e,t,n){let r=1,i=Ee(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);f===void 0&&(f=h(n,a));let o=t?h(n,a):f;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),L(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}return`data`in e&&L(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e}return e}function _(e){return e.generateMipmaps}function v(t){e.generateMipmap(t)}function y(t){return t.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:t.isWebGL3DRenderTarget?e.TEXTURE_3D:t.isWebGLArrayRenderTarget||t.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function b(n,r,i,a,o,s=!1){if(n!==null){if(e[n]!==void 0)return e[n];L(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+n+`'`)}let c;a&&(c=t.get(`EXT_texture_norm16`),c||L(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let l=r;if(r===e.RED&&(i===e.FLOAT&&(l=e.R32F),i===e.HALF_FLOAT&&(l=e.R16F),i===e.UNSIGNED_BYTE&&(l=e.R8),i===e.UNSIGNED_SHORT&&c&&(l=c.R16_EXT),i===e.SHORT&&c&&(l=c.R16_SNORM_EXT)),r===e.RED_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.R8UI),i===e.UNSIGNED_SHORT&&(l=e.R16UI),i===e.UNSIGNED_INT&&(l=e.R32UI),i===e.BYTE&&(l=e.R8I),i===e.SHORT&&(l=e.R16I),i===e.INT&&(l=e.R32I)),r===e.RG&&(i===e.FLOAT&&(l=e.RG32F),i===e.HALF_FLOAT&&(l=e.RG16F),i===e.UNSIGNED_BYTE&&(l=e.RG8),i===e.UNSIGNED_SHORT&&c&&(l=c.RG16_EXT),i===e.SHORT&&c&&(l=c.RG16_SNORM_EXT)),r===e.RG_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RG8UI),i===e.UNSIGNED_SHORT&&(l=e.RG16UI),i===e.UNSIGNED_INT&&(l=e.RG32UI),i===e.BYTE&&(l=e.RG8I),i===e.SHORT&&(l=e.RG16I),i===e.INT&&(l=e.RG32I)),r===e.RGB_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGB8UI),i===e.UNSIGNED_SHORT&&(l=e.RGB16UI),i===e.UNSIGNED_INT&&(l=e.RGB32UI),i===e.BYTE&&(l=e.RGB8I),i===e.SHORT&&(l=e.RGB16I),i===e.INT&&(l=e.RGB32I)),r===e.RGBA_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGBA8UI),i===e.UNSIGNED_SHORT&&(l=e.RGBA16UI),i===e.UNSIGNED_INT&&(l=e.RGBA32UI),i===e.BYTE&&(l=e.RGBA8I),i===e.SHORT&&(l=e.RGBA16I),i===e.INT&&(l=e.RGBA32I)),r===e.RGB&&(i===e.UNSIGNED_SHORT&&c&&(l=c.RGB16_EXT),i===e.SHORT&&c&&(l=c.RGB16_SNORM_EXT),i===e.UNSIGNED_INT_5_9_9_9_REV&&(l=e.RGB9_E5),i===e.UNSIGNED_INT_10F_11F_11F_REV&&(l=e.R11F_G11F_B10F)),r===e.RGBA){let t=s?an:er.getTransfer(o);i===e.FLOAT&&(l=e.RGBA32F),i===e.HALF_FLOAT&&(l=e.RGBA16F),i===e.UNSIGNED_BYTE&&(l=t===`srgb`?e.SRGB8_ALPHA8:e.RGBA8),i===e.UNSIGNED_SHORT&&c&&(l=c.RGBA16_EXT),i===e.SHORT&&c&&(l=c.RGBA16_SNORM_EXT),i===e.UNSIGNED_SHORT_4_4_4_4&&(l=e.RGBA4),i===e.UNSIGNED_SHORT_5_5_5_1&&(l=e.RGB5_A1)}return(l===e.R16F||l===e.R32F||l===e.RG16F||l===e.RG32F||l===e.RGBA16F||l===e.RGBA32F)&&t.get(`EXT_color_buffer_float`),l}function x(t,n){let r;return t?n===null||n===1014||n===1020?r=e.DEPTH24_STENCIL8:n===1015?r=e.DEPTH32F_STENCIL8:n===1012&&(r=e.DEPTH24_STENCIL8,L(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):n===null||n===1014||n===1020?r=e.DEPTH_COMPONENT24:n===1015?r=e.DEPTH_COMPONENT32F:n===1012&&(r=e.DEPTH_COMPONENT16),r}function S(e,t){return _(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps!==void 0&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function C(e){let t=e.target;t.removeEventListener(`dispose`,C),T(t),t.isVideoTexture&&u.delete(t),t.isHTMLTexture&&d.delete(t)}function w(e){let t=e.target;t.removeEventListener(`dispose`,w),D(t)}function T(e){let t=r.get(e);if(t.__webglInit===void 0)return;let n=e.source,i=p.get(n);if(i){let r=i[t.__cacheKey];r.usedTimes--,r.usedTimes===0&&E(e),Object.keys(i).length===0&&p.delete(n)}r.remove(e)}function E(t){let n=r.get(t);e.deleteTexture(n.__webglTexture);let i=t.source,a=p.get(i);delete a[n.__cacheKey],o.memory.textures--}function D(t){let n=r.get(t);if(t.depthTexture&&(t.depthTexture.dispose(),r.remove(t.depthTexture)),t.isWebGLCubeRenderTarget)for(let t=0;t<6;t++){if(Array.isArray(n.__webglFramebuffer[t]))for(let r=0;r<n.__webglFramebuffer[t].length;r++)e.deleteFramebuffer(n.__webglFramebuffer[t][r]);else e.deleteFramebuffer(n.__webglFramebuffer[t]);n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer[t])}else{if(Array.isArray(n.__webglFramebuffer))for(let t=0;t<n.__webglFramebuffer.length;t++)e.deleteFramebuffer(n.__webglFramebuffer[t]);else e.deleteFramebuffer(n.__webglFramebuffer);if(n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer),n.__webglMultisampledFramebuffer&&e.deleteFramebuffer(n.__webglMultisampledFramebuffer),n.__webglColorRenderbuffer)for(let t=0;t<n.__webglColorRenderbuffer.length;t++)n.__webglColorRenderbuffer[t]&&e.deleteRenderbuffer(n.__webglColorRenderbuffer[t]);n.__webglDepthRenderbuffer&&e.deleteRenderbuffer(n.__webglDepthRenderbuffer)}let i=t.textures;for(let t=0,n=i.length;t<n;t++){let n=r.get(i[t]);n.__webglTexture&&(e.deleteTexture(n.__webglTexture),o.memory.textures--),r.remove(i[t])}r.remove(t)}let O=0;function k(){O=0}function A(){return O}function j(e){O=e}function ee(){let e=O;return e>=i.maxTextures&&L(`WebGLTextures: Trying to use `+(e+1)+` texture units while this GPU supports only `+i.maxTextures),O+=1,e}function M(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function te(t,i){let a=r.get(t);if(t.isVideoTexture&&we(t),t.isRenderTargetTexture===!1&&t.isExternalTexture!==!0&&t.version>0&&a.__version!==t.version){let e=t.image;if(e===null)L(`WebGLRenderer: Texture marked for update but no image data found.`);else if(e.complete===!1)L(`WebGLRenderer: Texture marked for update but image is incomplete`);else{de(a,t,i);return}}else t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null);n.bindTexture(e.TEXTURE_2D,a.__webglTexture,e.TEXTURE0+i)}function ne(t,i){let a=r.get(t);t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version?de(a,t,i):(t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null),n.bindTexture(e.TEXTURE_2D_ARRAY,a.__webglTexture,e.TEXTURE0+i))}function re(t,i){let a=r.get(t);t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version?de(a,t,i):n.bindTexture(e.TEXTURE_3D,a.__webglTexture,e.TEXTURE0+i)}function ie(t,i){let a=r.get(t);t.isCubeDepthTexture!==!0&&t.version>0&&a.__version!==t.version?fe(a,t,i):n.bindTexture(e.TEXTURE_CUBE_MAP,a.__webglTexture,e.TEXTURE0+i)}let ae={[Pe]:e.REPEAT,[Fe]:e.CLAMP_TO_EDGE,[Ie]:e.MIRRORED_REPEAT},oe={[Le]:e.NEAREST,[Re]:e.NEAREST_MIPMAP_NEAREST,[ze]:e.NEAREST_MIPMAP_LINEAR,[Be]:e.LINEAR,[Ve]:e.LINEAR_MIPMAP_NEAREST,[He]:e.LINEAR_MIPMAP_LINEAR},se={512:e.NEVER,519:e.ALWAYS,513:e.LESS,515:e.LEQUAL,514:e.EQUAL,518:e.GEQUAL,516:e.GREATER,517:e.NOTEQUAL};function N(n,a){if(a.type===1015&&t.has(`OES_texture_float_linear`)===!1&&(a.magFilter===1006||a.magFilter===1007||a.magFilter===1005||a.magFilter===1008||a.minFilter===1006||a.minFilter===1007||a.minFilter===1005||a.minFilter===1008)&&L(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),e.texParameteri(n,e.TEXTURE_WRAP_S,ae[a.wrapS]),e.texParameteri(n,e.TEXTURE_WRAP_T,ae[a.wrapT]),(n===e.TEXTURE_3D||n===e.TEXTURE_2D_ARRAY)&&e.texParameteri(n,e.TEXTURE_WRAP_R,ae[a.wrapR]),e.texParameteri(n,e.TEXTURE_MAG_FILTER,oe[a.magFilter]),e.texParameteri(n,e.TEXTURE_MIN_FILTER,oe[a.minFilter]),a.compareFunction&&(e.texParameteri(n,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(n,e.TEXTURE_COMPARE_FUNC,se[a.compareFunction])),t.has(`EXT_texture_filter_anisotropic`)===!0){if(a.magFilter===1003||a.minFilter!==1005&&a.minFilter!==1008||a.type===1015&&t.has(`OES_texture_float_linear`)===!1)return;if(a.anisotropy>1||r.get(a).__currentAnisotropy){let o=t.get(`EXT_texture_filter_anisotropic`);e.texParameterf(n,o.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,i.getMaxAnisotropy())),r.get(a).__currentAnisotropy=a.anisotropy}}}function ce(t,n){let r=!1;t.__webglInit===void 0&&(t.__webglInit=!0,n.addEventListener(`dispose`,C));let i=n.source,a=p.get(i);a===void 0&&(a={},p.set(i,a));let s=M(n);if(s!==t.__cacheKey){a[s]===void 0&&(a[s]={texture:e.createTexture(),usedTimes:0},o.memory.textures++,r=!0),a[s].usedTimes++;let i=a[t.__cacheKey];i!==void 0&&(a[t.__cacheKey].usedTimes--,i.usedTimes===0&&E(n)),t.__cacheKey=s,t.__webglTexture=a[s].texture}return r}function le(e,t,n){return Math.floor(Math.floor(e/n)/t)}function ue(t,r,i,a){let o=t.updateRanges;if(o.length===0)n.texSubImage2D(e.TEXTURE_2D,0,0,0,r.width,r.height,i,a,r.data);else{o.sort((e,t)=>e.start-t.start);let s=0;for(let e=1;e<o.length;e++){let t=o[s],n=o[e],i=t.start+t.count,a=le(n.start,r.width,4),c=le(t.start,r.width,4);n.start<=i+1&&a===c&&le(n.start+n.count-1,r.width,4)===a?t.count=Math.max(t.count,n.start+n.count-t.start):(++s,o[s]=n)}o.length=s+1;let c=n.getParameter(e.UNPACK_ROW_LENGTH),l=n.getParameter(e.UNPACK_SKIP_PIXELS),u=n.getParameter(e.UNPACK_SKIP_ROWS);n.pixelStorei(e.UNPACK_ROW_LENGTH,r.width);for(let t=0,s=o.length;t<s;t++){let s=o[t],c=Math.floor(s.start/4),l=Math.ceil(s.count/4),u=c%r.width,d=Math.floor(c/r.width),f=l;n.pixelStorei(e.UNPACK_SKIP_PIXELS,u),n.pixelStorei(e.UNPACK_SKIP_ROWS,d),n.texSubImage2D(e.TEXTURE_2D,0,u,d,f,1,i,a,r.data)}t.clearUpdateRanges(),n.pixelStorei(e.UNPACK_ROW_LENGTH,c),n.pixelStorei(e.UNPACK_SKIP_PIXELS,l),n.pixelStorei(e.UNPACK_SKIP_ROWS,u)}}function de(t,o,s){let c=e.TEXTURE_2D;(o.isDataArrayTexture||o.isCompressedArrayTexture)&&(c=e.TEXTURE_2D_ARRAY),o.isData3DTexture&&(c=e.TEXTURE_3D);let l=ce(t,o),u=o.source;n.bindTexture(c,t.__webglTexture,e.TEXTURE0+s);let f=r.get(u);if(u.version!==f.__version||l===!0){if(n.activeTexture(e.TEXTURE0+s),!(typeof ImageBitmap<`u`&&o.image instanceof ImageBitmap)){let t=er.getPrimaries(er.workingColorSpace),r=o.colorSpace===``?null:er.getPrimaries(o.colorSpace),i=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,i)}n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment);let t=g(o.image,!1,i.maxTextureSize);t=Te(o,t);let r=a.convert(o.format,o.colorSpace),p=a.convert(o.type),m=b(o.internalFormat,r,p,o.normalized,o.colorSpace,o.isVideoTexture);N(c,o);let h,y=o.mipmaps,C=o.isVideoTexture!==!0,w=f.__version===void 0||l===!0,T=u.dataReady,E=S(o,t);if(o.isDepthTexture)m=x(o.format===ot,o.type),w&&(C?n.texStorage2D(e.TEXTURE_2D,1,m,t.width,t.height):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,null));else if(o.isDataTexture){if(y.length>0){C&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,y[0].width,y[0].height);for(let t=0,i=y.length;t<i;t++)h=y[t],C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data);o.generateMipmaps=!1}else C?(w&&n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height),T&&ue(o,t,r,p)):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,t.data)}else if(o.isCompressedTexture){if(o.isCompressedArrayTexture){C&&w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,y[0].width,y[0].height,t.depth);for(let i=0,a=y.length;i<a;i++)if(h=y[i],o.format!==1023){if(r!==null){if(C){if(T){if(o.layerUpdates.size>0){let t=Ps(h.width,h.height,o.format,o.type);for(let a of o.layerUpdates){let o=h.data.subarray(a*t/h.data.BYTES_PER_ELEMENT,(a+1)*t/h.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,a,h.width,h.height,1,r,o)}}else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,h.data)}}else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,h.data,0,0)}else L(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`)}else C?T&&n.texSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,p,h.data):n.texImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,r,p,h.data);o.layerUpdates.size>0&&o.clearLayerUpdates()}else{C&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,y[0].width,y[0].height);for(let t=0,i=y.length;t<i;t++)h=y[t],o.format===1023?C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data):r===null?L(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):C?T&&n.compressedTexSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,h.data):n.compressedTexImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,h.data)}}else if(o.isDataArrayTexture){if(C){if(w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,t.width,t.height,t.depth),T){if(o.layerUpdates.size>0){let i=Ps(t.width,t.height,o.format,o.type);for(let a of o.layerUpdates){let o=t.data.subarray(a*i/t.data.BYTES_PER_ELEMENT,(a+1)*i/t.data.BYTES_PER_ELEMENT);n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,a,t.width,t.height,1,r,p,o)}o.clearLayerUpdates()}else n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)}}else n.texImage3D(e.TEXTURE_2D_ARRAY,0,m,t.width,t.height,t.depth,0,r,p,t.data)}else if(o.isData3DTexture)C?(w&&n.texStorage3D(e.TEXTURE_3D,E,m,t.width,t.height,t.depth),T&&n.texSubImage3D(e.TEXTURE_3D,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)):n.texImage3D(e.TEXTURE_3D,0,m,t.width,t.height,t.depth,0,r,p,t.data);else if(o.isFramebufferTexture){if(w){if(C)n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height);else{let i=t.width,a=t.height;for(let t=0;t<E;t++)n.texImage2D(e.TEXTURE_2D,t,m,i,a,0,r,p,null),i>>=1,a>>=1}}}else if(o.isHTMLTexture){if(`texElementImage2D`in e){let n=e.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),t.parentNode!==n){n.appendChild(t),d.add(o),n.onpaint=e=>{let t=e.changedElements;for(let e of d)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,t);else{let n=e.RGBA,r=e.RGBA,i=e.UNSIGNED_BYTE;e.texElementImage2D(e.TEXTURE_2D,0,n,r,i,t)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(y.length>0){if(C&&w){let t=Ee(y[0]);n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height)}for(let t=0,i=y.length;t<i;t++)h=y[t],C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,r,p,h):n.texImage2D(e.TEXTURE_2D,t,m,r,p,h);o.generateMipmaps=!1}else if(C){if(w){let r=Ee(t);n.texStorage2D(e.TEXTURE_2D,E,m,r.width,r.height)}T&&n.texSubImage2D(e.TEXTURE_2D,0,0,0,r,p,t)}else n.texImage2D(e.TEXTURE_2D,0,m,r,p,t);_(o)&&v(c),f.__version=u.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function fe(t,o,s){if(o.image.length!==6)return;let c=ce(t,o),l=o.source;n.bindTexture(e.TEXTURE_CUBE_MAP,t.__webglTexture,e.TEXTURE0+s);let u=r.get(l);if(l.version!==u.__version||c===!0){n.activeTexture(e.TEXTURE0+s);let t=er.getPrimaries(er.workingColorSpace),r=o.colorSpace===``?null:er.getPrimaries(o.colorSpace),d=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,d);let f=o.isCompressedTexture||o.image[0].isCompressedTexture,p=o.image[0]&&o.image[0].isDataTexture,m=[];for(let e=0;e<6;e++)!f&&!p?m[e]=g(o.image[e],!0,i.maxCubemapSize):m[e]=p?o.image[e].image:o.image[e],m[e]=Te(o,m[e]);let h=m[0],y=a.convert(o.format,o.colorSpace),x=a.convert(o.type),C=b(o.internalFormat,y,x,o.normalized,o.colorSpace),w=o.isVideoTexture!==!0,T=u.__version===void 0||c===!0,E=l.dataReady,D=S(o,h);N(e.TEXTURE_CUBE_MAP,o);let O;if(f){w&&T&&n.texStorage2D(e.TEXTURE_CUBE_MAP,D,C,h.width,h.height);for(let t=0;t<6;t++){O=m[t].mipmaps;for(let r=0;r<O.length;r++){let i=O[r];o.format===1023?w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,y,x,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,C,i.width,i.height,0,y,x,i.data):y===null?L(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):w?E&&n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,y,i.data):n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,C,i.width,i.height,0,i.data)}}}else{if(O=o.mipmaps,w&&T){O.length>0&&D++;let t=Ee(m[0]);n.texStorage2D(e.TEXTURE_CUBE_MAP,D,C,t.width,t.height)}for(let t=0;t<6;t++)if(p){w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,m[t].width,m[t].height,y,x,m[t].data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,C,m[t].width,m[t].height,0,y,x,m[t].data);for(let r=0;r<O.length;r++){let i=O[r].image[t].image;w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,i.width,i.height,y,x,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,C,i.width,i.height,0,y,x,i.data)}}else{w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,y,x,m[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,C,y,x,m[t]);for(let r=0;r<O.length;r++){let i=O[r];w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,y,x,i.image[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,C,y,x,i.image[t])}}}_(o)&&v(e.TEXTURE_CUBE_MAP),u.__version=l.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function pe(t,i,o,c,l,u){let d=a.convert(o.format,o.colorSpace),f=a.convert(o.type),p=b(o.internalFormat,d,f,o.normalized,o.colorSpace),m=r.get(i),h=r.get(o);if(h.__renderTarget=i,!m.__hasExternalTextures){let t=Math.max(1,i.width>>u),r=Math.max(1,i.height>>u);l===e.TEXTURE_3D||l===e.TEXTURE_2D_ARRAY?n.texImage3D(l,u,p,t,r,i.depth,0,d,f,null):n.texImage2D(l,u,p,t,r,0,d,f,null)}n.bindFramebuffer(e.FRAMEBUFFER,t),P(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,c,l,h.__webglTexture,0,Ce(i)):(l===e.TEXTURE_2D||l>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&l<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,c,l,h.__webglTexture,u),n.bindFramebuffer(e.FRAMEBUFFER,null)}function me(t,n,r){if(e.bindRenderbuffer(e.RENDERBUFFER,t),n.depthBuffer){let i=n.depthTexture,a=i&&i.isDepthTexture?i.type:null,o=x(n.stencilBuffer,a),c=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;P(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,Ce(n),o,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,Ce(n),o,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,o,n.width,n.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,c,e.RENDERBUFFER,t)}else{let t=n.textures;for(let i=0;i<t.length;i++){let o=t[i],c=a.convert(o.format,o.colorSpace),l=a.convert(o.type),u=b(o.internalFormat,c,l,o.normalized,o.colorSpace);P(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,Ce(n),u,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,Ce(n),u,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,u,n.width,n.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function he(t,i,o){let c=i.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(e.FRAMEBUFFER,t),!(i.depthTexture&&i.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let l=r.get(i.depthTexture);if(l.__renderTarget=i,(!l.__webglTexture||i.depthTexture.image.width!==i.width||i.depthTexture.image.height!==i.height)&&(i.depthTexture.image.width=i.width,i.depthTexture.image.height=i.height,i.depthTexture.needsUpdate=!0),c){if(l.__webglInit===void 0&&(l.__webglInit=!0,i.depthTexture.addEventListener(`dispose`,C)),l.__webglTexture===void 0){l.__webglTexture=e.createTexture(),n.bindTexture(e.TEXTURE_CUBE_MAP,l.__webglTexture),N(e.TEXTURE_CUBE_MAP,i.depthTexture);let t=a.convert(i.depthTexture.format),r=a.convert(i.depthTexture.type),o;i.depthTexture.format===1026?o=e.DEPTH_COMPONENT24:i.depthTexture.format===1027&&(o=e.DEPTH24_STENCIL8);for(let n=0;n<6;n++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,o,i.width,i.height,0,t,r,null)}}else te(i.depthTexture,0);let u=l.__webglTexture,d=Ce(i),f=c?e.TEXTURE_CUBE_MAP_POSITIVE_X+o:e.TEXTURE_2D,p=i.depthTexture.format===1027?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(i.depthTexture.format===1026)P(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else if(i.depthTexture.format===1027)P(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function ge(t){let i=r.get(t),a=t.isWebGLCubeRenderTarget===!0;if(i.__boundDepthTexture!==t.depthTexture){let e=t.depthTexture;if(i.__depthDisposeCallback&&i.__depthDisposeCallback(),e){let t=()=>{delete i.__boundDepthTexture,delete i.__depthDisposeCallback,e.removeEventListener(`dispose`,t)};e.addEventListener(`dispose`,t),i.__depthDisposeCallback=t}i.__boundDepthTexture=e}if(t.depthTexture&&!i.__autoAllocateDepthBuffer){if(a)for(let e=0;e<6;e++)he(i.__webglFramebuffer[e],t,e);else{let e=t.texture.mipmaps;e&&e.length>0?he(i.__webglFramebuffer[0],t,0):he(i.__webglFramebuffer,t,0)}}else if(a){i.__webglDepthbuffer=[];for(let r=0;r<6;r++)if(n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[r]),i.__webglDepthbuffer[r]===void 0)i.__webglDepthbuffer[r]=e.createRenderbuffer(),me(i.__webglDepthbuffer[r],t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,a=i.__webglDepthbuffer[r];e.bindRenderbuffer(e.RENDERBUFFER,a),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,a)}}else{let r=t.texture.mipmaps;if(r&&r.length>0?n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[0]):n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer),i.__webglDepthbuffer===void 0)i.__webglDepthbuffer=e.createRenderbuffer(),me(i.__webglDepthbuffer,t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,r=i.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,r),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,r)}}n.bindFramebuffer(e.FRAMEBUFFER,null)}function _e(t,n,i){let a=r.get(t);n!==void 0&&pe(a.__webglFramebuffer,t,t.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),i!==void 0&&ge(t)}function ve(t){let i=t.texture,s=r.get(t),c=r.get(i);t.addEventListener(`dispose`,w);let l=t.textures,u=t.isWebGLCubeRenderTarget===!0,d=l.length>1;if(d||(c.__webglTexture===void 0&&(c.__webglTexture=e.createTexture()),c.__version=i.version,o.memory.textures++),u){s.__webglFramebuffer=[];for(let t=0;t<6;t++)if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer[t]=[];for(let n=0;n<i.mipmaps.length;n++)s.__webglFramebuffer[t][n]=e.createFramebuffer()}else s.__webglFramebuffer[t]=e.createFramebuffer()}else{if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer=[];for(let t=0;t<i.mipmaps.length;t++)s.__webglFramebuffer[t]=e.createFramebuffer()}else s.__webglFramebuffer=e.createFramebuffer();if(d)for(let t=0,n=l.length;t<n;t++){let n=r.get(l[t]);n.__webglTexture===void 0&&(n.__webglTexture=e.createTexture(),o.memory.textures++)}if(t.samples>0&&P(t)===!1){s.__webglMultisampledFramebuffer=e.createFramebuffer(),s.__webglColorRenderbuffer=[],n.bindFramebuffer(e.FRAMEBUFFER,s.__webglMultisampledFramebuffer);for(let n=0;n<l.length;n++){let r=l[n];s.__webglColorRenderbuffer[n]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,s.__webglColorRenderbuffer[n]);let i=a.convert(r.format,r.colorSpace),o=a.convert(r.type),c=b(r.internalFormat,i,o,r.normalized,r.colorSpace,t.isXRRenderTarget===!0),u=Ce(t);e.renderbufferStorageMultisample(e.RENDERBUFFER,u,c,t.width,t.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,s.__webglColorRenderbuffer[n])}e.bindRenderbuffer(e.RENDERBUFFER,null),t.depthBuffer&&(s.__webglDepthRenderbuffer=e.createRenderbuffer(),me(s.__webglDepthRenderbuffer,t,!0)),n.bindFramebuffer(e.FRAMEBUFFER,null)}}if(u){n.bindTexture(e.TEXTURE_CUBE_MAP,c.__webglTexture),N(e.TEXTURE_CUBE_MAP,i);for(let n=0;n<6;n++)if(i.mipmaps&&i.mipmaps.length>0)for(let r=0;r<i.mipmaps.length;r++)pe(s.__webglFramebuffer[n][r],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,r);else pe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0);_(i)&&v(e.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(d){for(let i=0,a=l.length;i<a;i++){let a=l[i],o=r.get(a),c=e.TEXTURE_2D;(t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(c=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(c,o.__webglTexture),N(c,a),pe(s.__webglFramebuffer,t,a,e.COLOR_ATTACHMENT0+i,c,0),_(a)&&v(c)}n.unbindTexture()}else{let r=e.TEXTURE_2D;if((t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(r=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(r,c.__webglTexture),N(r,i),i.mipmaps&&i.mipmaps.length>0)for(let n=0;n<i.mipmaps.length;n++)pe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,r,n);else pe(s.__webglFramebuffer,t,i,e.COLOR_ATTACHMENT0,r,0);_(i)&&v(r),n.unbindTexture()}t.depthBuffer&&ge(t)}function ye(e){let t=e.textures;for(let i=0,a=t.length;i<a;i++){let a=t[i];if(_(a)){let t=y(e),i=r.get(a).__webglTexture;n.bindTexture(t,i),v(t),n.unbindTexture()}}}let be=[],xe=[];function Se(t){if(t.samples>0){if(P(t)===!1){let i=t.textures,a=t.width,o=t.height,s=e.COLOR_BUFFER_BIT,l=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,u=r.get(t),d=i.length>1;if(d)for(let t=0;t<i.length;t++)n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,null),n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,null,0);n.bindFramebuffer(e.READ_FRAMEBUFFER,u.__webglMultisampledFramebuffer);let f=t.texture.mipmaps;f&&f.length>0?n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer[0]):n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer);for(let n=0;n<i.length;n++){if(t.resolveDepthBuffer&&(t.depthBuffer&&(s|=e.DEPTH_BUFFER_BIT),t.stencilBuffer&&t.resolveStencilBuffer&&(s|=e.STENCIL_BUFFER_BIT)),d){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,u.__webglColorRenderbuffer[n]);let t=r.get(i[n]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0)}e.blitFramebuffer(0,0,a,o,0,0,a,o,s,e.NEAREST),c===!0&&(be.length=0,xe.length=0,be.push(e.COLOR_ATTACHMENT0+n),t.depthBuffer&&t.storeMultisampledDepthBuffer===!1&&(be.push(l),xe.push(l),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,xe)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,be))}if(n.bindFramebuffer(e.READ_FRAMEBUFFER,null),n.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),d)for(let t=0;t<i.length;t++){n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,u.__webglColorRenderbuffer[t]);let a=r.get(i[t]).__webglTexture;n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,a,0)}n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglMultisampledFramebuffer)}else if(t.depthBuffer&&t.storeMultisampledDepthBuffer===!1&&c){let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[n])}}}function Ce(e){return Math.min(i.maxSamples,e.samples)}function P(e){let n=r.get(e);return e.samples>0&&t.has(`WEBGL_multisampled_render_to_texture`)===!0&&n.__useRenderToTexture!==!1}function we(e){let t=o.render.frame;u.get(e)!==t&&(u.set(e,t),e.update())}function Te(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(er.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&L(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):R(`WebGLTextures: Unsupported texture color space:`,n)),t}function Ee(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(l.width=e.naturalWidth||e.width,l.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(l.width=e.displayWidth,l.height=e.displayHeight):(l.width=e.width,l.height=e.height),l}this.allocateTextureUnit=ee,this.resetTextureUnits=k,this.getTextureUnits=A,this.setTextureUnits=j,this.setTexture2D=te,this.setTexture2DArray=ne,this.setTexture3D=re,this.setTextureCube=ie,this.rebindTextures=_e,this.setupRenderTarget=ve,this.updateRenderTargetMipmap=ye,this.updateMultisampleRenderTarget=Se,this.setupDepthRenderbuffer=ge,this.setupFrameBufferTexture=pe,this.useMultisampledRTT=P,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function Bu(e,t){function n(n,r=``){let i,a=er.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779){if(a===`srgb`){if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null}else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null}if(n===35840||n===35841||n===35842||n===35843){if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null}if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491){if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null}if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821){if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null}if(n===36492||n===36494||n===36495){if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null}if(n===36283||n===36284||n===36285||n===36286){if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null}return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var Vu=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Hu=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Uu=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new Ja(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new mo({vertexShader:Vu,fragmentShader:Hu,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ga(new no(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Wu=class extends bn{constructor(e,t){super();let n=this,r=null,i=1,a=null,o=`local-floor`,s=1,c=null,l=null,u=null,d=null,f=null,p=null,m=typeof XRWebGLBinding<`u`,h=new Uu,g={},_=t.getContextAttributes(),v=null,y=null,b=[],x=[],S=new B,C=null,w=null,T=new Qo;T.viewport=new dr;let E=new Qo;E.viewport=new dr;let D=[T,E],O=new as,k=null,A=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=b[e];return t===void 0&&(t=new Kr,b[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=b[e];return t===void 0&&(t=new Kr,b[e]=t),t.getGripSpace()},this.getHand=function(e){let t=b[e];return t===void 0&&(t=new Kr,b[e]=t),t.getHandSpace()};function j(e){let t=x.indexOf(e.inputSource);if(t===-1)return;let n=b[t];n!==void 0&&(n.update(e.inputSource,e.frame,c||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function ee(){r.removeEventListener(`select`,j),r.removeEventListener(`selectstart`,j),r.removeEventListener(`selectend`,j),r.removeEventListener(`squeeze`,j),r.removeEventListener(`squeezestart`,j),r.removeEventListener(`squeezeend`,j),r.removeEventListener(`end`,ee),r.removeEventListener(`inputsourceschange`,M);for(let e=0;e<b.length;e++){let t=x[e];t!==null&&(x[e]=null,b[e].disconnect(t))}k=null,A=null,h.reset();for(let e in g)delete g[e];if(e.setRenderTarget(v),f=null,d=null,u=null,r=null,y=null,N.stop(),n.isPresenting=!1,e.setPixelRatio(C),e.setSize(S.width,S.height,!1),w!==null){let e=w.camera;e.fov=w.fov,e.zoom=w.zoom,e.updateProjectionMatrix(),w=null}n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&L(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){o=e,n.isPresenting===!0&&L(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(e){c=e},this.getBaseLayer=function(){return d===null?f:d},this.getBinding=function(){return u===null&&m&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return p},this.getSession=function(){return r},this.setSession=async function(l){if(r=l,r!==null){if(v=e.getRenderTarget(),r.addEventListener(`select`,j),r.addEventListener(`selectstart`,j),r.addEventListener(`selectend`,j),r.addEventListener(`squeeze`,j),r.addEventListener(`squeezestart`,j),r.addEventListener(`squeezeend`,j),r.addEventListener(`end`,ee),r.addEventListener(`inputsourceschange`,M),_.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(S),m&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;_.depth&&(o=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=_.stencil?ot:at,a=_.stencil?$e:Je);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};u=this.getBinding(),d=u.createProjectionLayer(s),r.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),y=new pr(d.textureWidth,d.textureHeight,{format:it,type:Ue,depthTexture:new Ka(d.textureWidth,d.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{let n={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:i};f=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new pr(f.framebufferWidth,f.framebufferHeight,{format:it,type:Ue,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(s),c=null,a=await r.requestReferenceSpace(o),N.setContext(r),N.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return h.getDepthTexture()};function M(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=x.indexOf(n);r>=0&&(x[r]=null,b[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=x.indexOf(n);if(r===-1){for(let e=0;e<b.length;e++)if(e>=x.length){x.push(n),r=e;break}else if(x[e]===null){x[e]=n,r=e;break}if(r===-1)break}let i=b[r];i&&i.connect(n)}}let te=new V,ne=new V;function re(e,t,n){te.setFromMatrixPosition(t.matrixWorld),ne.setFromMatrixPosition(n.matrixWorld);let r=te.distanceTo(ne),i=t.projectionMatrix.elements,a=n.projectionMatrix.elements,o=i[14]/(i[10]-1),s=i[14]/(i[10]+1),c=(i[9]+1)/i[5],l=(i[9]-1)/i[5],u=(i[8]-1)/i[0],d=(a[8]+1)/a[0],f=o*u,p=o*d,m=r/(-u+d),h=m*-u;if(t.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(h),e.translateZ(m),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),i[10]===-1)e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse);else{let t=o+m,n=s+m,i=f-h,a=p+(r-h),u=c*s/n*t,d=l*s/n*t;e.projectionMatrix.makePerspective(i,a,u,d,t,n),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()}}function ie(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;h.texture!==null&&(h.depthNear>0&&(t=h.depthNear),h.depthFar>0&&(n=h.depthFar)),O.near=E.near=T.near=t,O.far=E.far=T.far=n,(k!==O.near||A!==O.far)&&(r.updateRenderState({depthNear:O.near,depthFar:O.far}),k=O.near,A=O.far),O.layers.mask=e.layers.mask|6,T.layers.mask=O.layers.mask&-5,E.layers.mask=O.layers.mask&-3;let i=e.parent,a=O.cameras;ie(O,i);for(let e=0;e<a.length;e++)ie(a[e],i);a.length===2?re(O,T,E):O.projectionMatrix.copy(T.projectionMatrix),w===null&&e.isPerspectiveCamera&&(w={camera:e,fov:e.fov,zoom:e.zoom}),ae(e,O,i)};function ae(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=wn*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return O},this.getFoveation=function(){if(d!==null||f!==null)return s},this.setFoveation=function(e){s=e,d!==null&&(d.fixedFoveation=e),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=e)},this.hasDepthSensing=function(){return h.texture!==null},this.getDepthSensingMesh=function(){return h.getMesh(O)},this.getCameraTexture=function(e){return g[e]};let oe=null;function se(t,i){if(l=i.getViewerPose(c||a),p=i,l!==null){let t=l.views;f!==null&&(e.setRenderTargetFramebuffer(y,f.framebuffer),e.setRenderTarget(y));let i=!1;t.length!==O.cameras.length&&(O.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(f!==null)a=f.getViewport(r);else{let t=u.getViewSubImage(d,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(y,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(y))}let o=D[n];o===void 0&&(o=new Qo,o.layers.enable(n),o.viewport=new dr,D[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(O.matrix.copy(o.matrix),O.matrix.decompose(O.position,O.quaternion,O.scale)),i===!0&&O.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&m){u=n.getBinding();let e=u.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&h.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&m){e.state.unbindTexture(),u=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=g[n];e||(e=new Ja,g[n]=e);let t=u.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<b.length;e++){let t=x[e],n=b[e];t!==null&&n!==void 0&&n.update(t,i,c||a)}oe&&oe(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),p=null}let N=new Is;N.setAnimationLoop(se),this.setAnimationLoop=function(e){oe=e},this.dispose=function(){}}},Gu=new gr,Ku=new H;Ku.set(-1,0,0,0,1,0,0,0,1);function qu(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,lo(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4(Gu.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(Ku),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.retroreflectivity>0&&(e.retroreflectivity.value=t.retroreflectivity),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessRange[0],e.iridescenceThicknessMaximum.value=t.iridescenceThicknessRange[1],t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function Ju(e,t,n,r){let i={},a={},o=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function c(e,t){let n=t.program;r.uniformBlockBinding(e,n)}function l(e,n){let o=i[e.id];o===void 0&&(g(e),o=u(e),i[e.id]=o,e.addEventListener(`dispose`,v));let s=n.program;r.updateUBOMapping(e,s);let c=t.render.frame;a[e.id]!==c&&(f(e),a[e.id]=c)}function u(t){let n=d();t.__bindingPointIndex=n;let r=e.createBuffer(),i=t.__size,a=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,r),e.bufferData(e.UNIFORM_BUFFER,i,a),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,n,r),r}function d(){for(let e=0;e<s;e++)if(o.indexOf(e)===-1)return o.push(e),e;return R(`WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached.`),0}function f(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)p(t[n],e,n,a);else p(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function p(t,n,r,i){if(h(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=_(i);m(i,t.__data,e),typeof i!=`number`&&typeof i!=`boolean`&&!i.isMatrix3&&!ArrayBuffer.isView(i)&&(e+=a.storage/Float32Array.BYTES_PER_ELEMENT)}}else m(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function m(e,t,n){typeof e==`number`||typeof e==`boolean`?t[0]=e:e.isMatrix3?(t[0]=e.elements[0],t[1]=e.elements[1],t[2]=e.elements[2],t[3]=0,t[4]=e.elements[3],t[5]=e.elements[4],t[6]=e.elements[5],t[7]=0,t[8]=e.elements[6],t[9]=e.elements[7],t[10]=e.elements[8],t[11]=0):ArrayBuffer.isView(e)?t.set(new e.constructor(e.buffer,e.byteOffset,t.length)):e.toArray(t,n)}function h(e,t,n,r){let i=e.value,a=t+`_`+n;if(r[a]===void 0)return r[a]=typeof i==`number`||typeof i==`boolean`?i:ArrayBuffer.isView(i)?i.slice():i.clone(),!0;{let e=r[a];if(typeof i==`number`||typeof i==`boolean`){if(e!==i)return r[a]=i,!0}else if(ArrayBuffer.isView(i))return!0;else if(e.equals(i)===!1)return e.copy(i),!0}return!1}function g(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let e=0,t=r.length;e<t;e++){let t=r[e],i=Array.isArray(t.value)?t.value:[t.value];for(let e=0,r=i.length;e<r;e++){let r=i[e],a=_(r),o=n%16,s=o%a.boundary,c=o+s;n+=s,c!==0&&16-c<a.storage&&(n+=16-c),t.__data=new Float32Array(a.storage/Float32Array.BYTES_PER_ELEMENT),t.__offset=n,n+=a.storage}}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function _(e){let t={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?L(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):L(`WebGLRenderer: Unsupported uniform value type.`,e),t}function v(t){let n=t.target;n.removeEventListener(`dispose`,v);let r=o.indexOf(n.__bindingPointIndex);o.splice(r,1),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function y(){for(let t in i)e.deleteBuffer(i[t]);o=[],i={},a={}}return{bind:c,update:l,dispose:y}}var Yu=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),Xu=null;function Zu(){return Xu===null&&(Xu=new ya(Yu,16,16,lt,Xe),Xu.name=`DFG_LUT`,Xu.minFilter=Be,Xu.magFilter=Be,Xu.wrapS=Fe,Xu.wrapT=Fe,Xu.generateMipmaps=!1,Xu.needsUpdate=!0),Xu}var Qu=class{constructor(e={}){let{canvas:t=pn(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:c=!1,powerPreference:l=`default`,failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=Ue}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);p=n.getContextAttributes().alpha}else p=a;let m=f,h=new Set([dt,ut,ct]),g=new Set([Ue,Je,Ke,$e,Ze,Qe]),_=new Uint32Array(4),v=new Int32Array(4),y=new V,b=null,x=null,S=[],C=[],w=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let T=this,E=!1,D=null,O=null,k=null,A=null;this._outputColorSpace=nn;let j=0,ee=0,M=null,te=-1,ne=null,re=new dr,ie=new dr,ae=null,oe=new U(0),se=0,N=t.width,ce=t.height,le=1,ue=null,de=null,fe=new dr(0,0,N,ce),pe=new dr(0,0,N,ce),me=!1,he=new Ca,ge=!1,_e=!1,ve=new gr,ye=new V,be=new dr,xe={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},Se=!1;function Ce(){return M===null?le:1}let P=n;function we(e,n){return t.getContext(e,n)}let Te,Ee,F,De,I,Oe,ke,Ae,je,Me,Ne,Pe,Fe,Ie,Le,Re,ze,Be,Ve,We,Ge,qe,Ye;try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:c,powerPreference:l,failIfMajorPerformanceCaveat:u};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r186`),t.addEventListener(`webglcontextlost`,nt,!1),t.addEventListener(`webglcontextrestored`,rt,!1),t.addEventListener(`webglcontextcreationerror`,it,!1),P===null){let t=`webgl2`;if(P=we(t,e),P===null)throw we(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}et()}catch(e){throw t.removeEventListener(`webglcontextlost`,nt,!1),t.removeEventListener(`webglcontextrestored`,rt,!1),t.removeEventListener(`webglcontextcreationerror`,it,!1),R(`WebGLRenderer: `+e.message),e}function et(){Te=new gc(P),Te.init(),Ge=new Bu(P,Te),Ee=new Gs(P,Te,e,Ge),F=new Ru(P,Te),Ee.reversedDepthBuffer&&d&&F.buffers.depth.setReversed(!0),O=P.createFramebuffer(),k=P.createFramebuffer(),A=P.createFramebuffer(),De=new yc(P),I=new vu,Oe=new zu(P,Te,F,I,Ee,Ge,De),ke=new hc(T),Ae=new Ls(P),qe=new Us(P,Ae),je=new _c(P,Ae,De,qe),Me=new xc(P,je,Ae,qe,De),Be=new bc(P,Ee,Oe),Le=new Ks(I),Ne=new _u(T,ke,Te,Ee,qe,Le),Pe=new qu(T,I),Fe=new Su,Ie=new ku(Te),ze=new Hs(T,ke,F,Me,p,s),Re=new Lu(T,Me,Ee),Ye=new Ju(P,De,Ee,F),Ve=new Ws(P,Te,De),We=new vc(P,Te,De),De.programs=Ne.programs,T.capabilities=Ee,T.extensions=Te,T.properties=I,T.renderLists=Fe,T.shadowMap=Re,T.state=F,T.info=De}m!==1009&&(w=new Cc(m,t.width,t.height,o,r,i));let tt=new Wu(T,P);this.xr=tt,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){let e=Te.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=Te.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return le},this.setPixelRatio=function(e){e!==void 0&&(le=e,this.setSize(N,ce,!1))},this.getSize=function(e){return e.set(N,ce)},this.setSize=function(e,n,r=!0){tt.isPresenting?L(`WebGLRenderer: Can't change size while VR device is presenting.`):(N=e,ce=n,t.width=Math.floor(e*le),t.height=Math.floor(n*le),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),w!==null&&w.setSize(t.width,t.height),this.setViewport(0,0,e,n))},this.getDrawingBufferSize=function(e){return e.set(N*le,ce*le).floor()},this.setDrawingBufferSize=function(e,n,r){N=e,ce=n,le=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(m===1009)R(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);else{if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){L(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}w.setEffects(e||[])}},this.getCurrentViewport=function(e){return e.copy(re)},this.getViewport=function(e){return e.copy(fe)},this.setViewport=function(e,t,n,r){e.isVector4?fe.set(e.x,e.y,e.z,e.w):fe.set(e,t,n,r),F.viewport(re.copy(fe).multiplyScalar(le).round())},this.getScissor=function(e){return e.copy(pe)},this.setScissor=function(e,t,n,r){e.isVector4?pe.set(e.x,e.y,e.z,e.w):pe.set(e,t,n,r),F.scissor(ie.copy(pe).multiplyScalar(le).round())},this.getScissorTest=function(){return me},this.setScissorTest=function(e){F.setScissorTest(me=e)},this.setOpaqueSort=function(e){ue=e},this.setTransparentSort=function(e){de=e},this.getClearColor=function(e){return e.copy(ze.getClearColor())},this.setClearColor=function(){ze.setClearColor(...arguments)},this.getClearAlpha=function(){return ze.getClearAlpha()},this.setClearAlpha=function(){ze.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(M!==null){let t=M.texture.format;e=h.has(t)}if(e){let e=M.texture.type,t=g.has(e),n=ze.getClearColor(),r=ze.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(_[0]=i,_[1]=a,_[2]=o,_[3]=r,P.clearBufferuiv(P.COLOR,0,_)):(v[0]=i,v[1]=a,v[2]=o,v[3]=r,P.clearBufferiv(P.COLOR,0,v))}else r|=P.COLOR_BUFFER_BIT}t&&(r|=P.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&P.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),D=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,nt,!1),t.removeEventListener(`webglcontextrestored`,rt,!1),t.removeEventListener(`webglcontextcreationerror`,it,!1),ze.dispose(),Fe.dispose(),Ie.dispose(),I.dispose(),ke.dispose(),Me.dispose(),qe.dispose(),Ye.dispose(),Ne.dispose(),tt.dispose(),tt.removeEventListener(`sessionstart`,mt),tt.removeEventListener(`sessionend`,ht),gt.stop()};function nt(e){e.preventDefault(),hn(`WebGLRenderer: Context Lost.`),E=!0}function rt(){hn(`WebGLRenderer: Context Restored.`),E=!1;let e=De.autoReset,t=Re.enabled,n=Re.autoUpdate,r=Re.needsUpdate,i=Re.type;et(),De.autoReset=e,Re.enabled=t,Re.autoUpdate=n,Re.needsUpdate=r,Re.type=i}function it(e){R(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function at(e){let t=e.target;t.removeEventListener(`dispose`,at),ot(t)}function ot(e){st(e),I.remove(e)}function st(e){let t=I.get(e).programs;t!==void 0&&(t.forEach(function(e){Ne.releaseProgram(e)}),e.isShaderMaterial&&Ne.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=xe);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=Et(e,t,n,r,i);F.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=je.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;qe.setup(i,r,s,n,c);let h,g=Ve;if(c!==null&&(h=Ae.get(c),g=We,g.setIndex(h)),i.isMesh)r.wireframe===!0?(F.setLineWidth(r.wireframeLinewidth*Ce()),g.setMode(P.LINES)):g.setMode(P.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),F.setLineWidth(e*Ce()),i.isLineSegments?g.setMode(P.LINES):i.isLineLoop?g.setMode(P.LINE_LOOP):g.setMode(P.LINE_STRIP)}else i.isPoints?g.setMode(P.POINTS):i.isSprite&&g.setMode(P.TRIANGLES);if(i.isBatchedMesh){if(Te.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?Ae.get(c).bytesPerElement:1,o=I.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(P,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function lt(e,t,n,r){D!==null&&e.isNodeMaterial&&D.setObject(r,e),ge===!0&&Le.setState(e,n,!1),e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,St(e,t,r),e.side=0,e.needsUpdate=!0,St(e,t,r),e.side=2):St(e,t,r)}this.compile=function(e,t,n=null){n===null&&(n=e),D!==null&&D.renderStart(e,t,n),x=Ie.get(n),x.init(t),C.push(x),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),x.setupLights(),D!==null&&D.updateLights(x.state.lightsArray),_e=this.localClippingEnabled,ge=Le.init(this.clippingPlanes,_e),ge===!0&&Le.setGlobalState(this.clippingPlanes,t),D!==null&&Re.render(x.state.shadowsArray,n,t);let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let i=e.material;if(i){if(Array.isArray(i))for(let a=0;a<i.length;a++){let o=i[a];lt(o,n,t,e),r.add(o)}else lt(i,n,t,e),r.add(i)}}),x=C.pop(),D!==null&&D.renderEnd(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){r.forEach(function(e){let t=I.get(e).currentProgram;(t===void 0||t.isReady())&&r.delete(e)}),r.size===0?t(e):setTimeout(n,10)}Te.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let ft=null;function pt(e){ft&&ft(e)}function mt(){gt.stop()}function ht(){gt.start()}let gt=new Is;gt.setAnimationLoop(pt),typeof self<`u`&&gt.setContext(self),this.setAnimationLoop=function(e){ft=e,tt.setAnimationLoop(e),e===null?gt.stop():gt.start()},tt.addEventListener(`sessionstart`,mt),tt.addEventListener(`sessionend`,ht),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){R(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(E===!0)return;D!==null&&D.renderStart(e,t);let n=tt.enabled===!0&&tt.isPresenting===!0,r=w!==null&&(M===null||n)&&w.begin(T,M);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),tt.enabled===!0&&tt.isPresenting===!0&&(w===null||w.isCompositing()===!1)&&(tt.cameraAutoUpdate===!0&&tt.updateCamera(t),t=tt.getCamera()),e.isScene===!0&&e.onBeforeRender(T,e,t,M),x=Ie.get(e,C.length),x.init(t),x.state.textureUnits=Oe.getTextureUnits(),C.push(x),ve.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),he.setFromProjectionMatrix(ve,ln,t.reversedDepth),_e=this.localClippingEnabled,ge=Le.init(this.clippingPlanes,_e),b=Fe.get(e,S.length),b.init(),S.push(b),tt.enabled===!0&&tt.isPresenting===!0){let e=T.xr.getDepthSensingMesh();e!==null&&_t(e,t,-1/0,T.sortObjects)}_t(e,t,0,T.sortObjects),b.finish(),D!==null&&D.updateLights(x.state.lightsArray),T.sortObjects===!0&&b.sort(ue,de),Se=tt.enabled===!1||tt.isPresenting===!1||tt.hasDepthSensing()===!1,Se&&ze.addToRenderList(b,e),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),ge===!0&&Le.beginShadows();let i=x.state.shadowsArray;if(Re.render(i,e,t),ge===!0&&Le.endShadows(),(r&&w.hasRenderPass())===!1){let n=b.opaque,r=b.transmissive;if(x.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];yt(n,r,e,a)}Se&&ze.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];vt(b,e,n,n.viewport)}}else r.length>0&&yt(n,r,e,t),Se&&ze.render(e),vt(b,e,t)}M!==null&&ee===0&&(Oe.updateMultisampleRenderTarget(M),Oe.updateRenderTargetMipmap(M)),r&&w.end(T),e.isScene===!0&&e.onAfterRender(T,e,t),qe.resetDefaultState(),te=-1,ne=null,C.pop(),C.length>0?(x=C[C.length-1],Oe.setTextureUnits(x.state.textureUnits),ge===!0&&Le.setGlobalState(T.clippingPlanes,x.state.camera)):x=null,S.pop(),b=S.length>0?S[S.length-1]:null,D!==null&&D.renderEnd()};function _t(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLightProbeGrid)x.pushLightProbeGrid(e);else if(e.isLight)x.pushLight(e),e.castShadow&&x.pushShadow(e);else if(e.isSprite){if(!e.frustumCulled||e.intersectsFrustum(he)){r&&be.setFromMatrixPosition(e.matrixWorld).applyMatrix4(ve);let i=Me.update(e),a=e.material;a.visible&&b.push(e,i,a,n,be.z,null,t)}}else if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||e.intersectsFrustum(he))){let i=Me.update(e),a=e.material;if(r&&(e.boundingSphere===void 0?(i.boundingSphere===null&&i.computeBoundingSphere(),be.copy(i.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),be.copy(e.boundingSphere.center)),be.applyMatrix4(e.matrixWorld).applyMatrix4(ve)),Array.isArray(a)){let r=i.groups;for(let o=0,s=r.length;o<s;o++){let s=r[o],c=a[s.materialIndex];c&&c.visible&&b.push(e,i,c,n,be.z,s,t)}}else a.visible&&b.push(e,i,a,n,be.z,null,t)}}let i=e.children;for(let e=0,a=i.length;e<a;e++)_t(i[e],t,n,r)}function vt(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;x.setupLightsView(n),ge===!0&&Le.setGlobalState(T.clippingPlanes,n),r&&F.viewport(re.copy(r)),i.length>0&&bt(i,t,n),a.length>0&&bt(a,t,n),o.length>0&&bt(o,t,n),F.buffers.depth.setTest(!0),F.buffers.depth.setMask(!0),F.buffers.color.setMask(!0),F.setPolygonOffset(!1)}function yt(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(x.state.transmissionRenderTarget[r.id]===void 0){let e=Te.has(`EXT_color_buffer_half_float`)||Te.has(`EXT_color_buffer_float`);x.state.transmissionRenderTarget[r.id]=new pr(1,1,{generateMipmaps:!0,type:e?Xe:Ue,minFilter:He,samples:Math.max(4,Ee.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:er.workingColorSpace})}let a=x.state.transmissionRenderTarget[r.id],o=r.viewport||re;a.setSize(o.z*T.transmissionResolutionScale,o.w*T.transmissionResolutionScale);let s=T.getRenderTarget(),c=T.getActiveCubeFace(),l=T.getActiveMipmapLevel();T.setRenderTarget(a),T.getClearColor(oe),se=T.getClearAlpha(),se<1&&T.setClearColor(16777215,.5),T.clear(),Se&&ze.render(n);let u=T.toneMapping;T.toneMapping=0;let d=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),x.setupLightsView(r),ge===!0&&Le.setGlobalState(T.clippingPlanes,r),bt(e,n,r),Oe.updateMultisampleRenderTarget(a),Oe.updateRenderTargetMipmap(a),Te.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,xt(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(Oe.updateMultisampleRenderTarget(a),Oe.updateRenderTargetMipmap(a))}T.setRenderTarget(s,c,l),T.setClearColor(oe,se),d!==void 0&&(r.viewport=d),T.toneMapping=u}function bt(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&xt(o,t,n,s,l,c)}}function xt(e,t,n,r,i,a){D!==null&&i.isNodeMaterial&&D.setObject(e,i),e.onBeforeRender(T,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(T,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=2):T.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(T,t,n,r,i,a)}function St(e,t,n){t.isScene!==!0&&(t=xe);let r=I.get(e),i=x.state.lights,a=x.state.shadowsArray,o=i.state.version,s=Ne.getParameters(e,i.state,a,t,n,x.state.lightProbeGridArray),c=Ne.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=ke.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,at),l=new Map,r.programs=l);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return wt(e,s),d}else s.uniforms=Ne.getUniforms(e),D!==null&&e.isNodeMaterial&&D.build(e,n,s),e.onBeforeCompile(s,T),d=Ne.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=Le.uniform),wt(e,s),r.needsLights=Ot(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.sunLights.value=i.state.sun,f.sunLightShadows.value=i.state.sunShadow,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.sunShadowMatrix.value=i.state.sunShadowMatrix,f.sunShadowCascade.value=i.state.sunShadowCascade,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.lightProbeGrid=x.state.lightProbeGridArray.length>0,r.currentProgram=d,r.uniformsList=null,d}function Ct(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=Al.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function wt(e,t){let n=I.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function Tt(e,t){if(e.length===0)return null;if(e.length===1)return e[0].texture===null?null:e[0];y.setFromMatrixPosition(t.matrixWorld);for(let t=0,n=e.length;t<n;t++){let n=e[t];if(n.texture!==null&&n.boundingBox.containsPoint(y))return n}return null}function Et(e,t,n,r,i){t.isScene!==!0&&(t=xe),Oe.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=M===null?T.outputColorSpace:M.isXRRenderTarget===!0?M.texture.colorSpace:er.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=ke.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(M===null||M.isXRRenderTarget===!0)&&(h=T.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=I.get(r),y=x.state.lights;if(ge===!0&&(_e===!0||e!==ne)){let t=e===ne&&r.id===te;Le.setState(r,e,t)}let b=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version?b=!0:v.outputColorSpace===s?i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i._colorsTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i._colorsTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==Le.numPlanes||v.numIntersection!==Le.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.toneMapping===h&&v.morphTargetsCount===_?!!v.lightProbeGrid!=x.state.lightProbeGridArray.length>0&&(b=!0):b=!0:b=!0:b=!0:(b=!0,v.__version=r.version);let S=v.currentProgram;b===!0&&(S=St(r,t,i),D&&r.isNodeMaterial&&D.onUpdateProgram(r,S,v));let C=!1,w=!1,E=!1,O=S.getUniforms(),k=v.uniforms;if(F.useProgram(S.program)&&(C=!0,w=!0,E=!0),r.id!==te&&(te=r.id,w=!0),v.needsLights){let e=Tt(x.state.lightProbeGridArray,i);v.lightProbeGrid!==e&&(v.lightProbeGrid=e,w=!0)}if(C||ne!==e){F.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),O.setValue(P,`projectionMatrix`,e.projectionMatrix),O.setValue(P,`viewMatrix`,e.matrixWorldInverse);let t=O.map.cameraPosition;t!==void 0&&t.setValue(P,ye.setFromMatrixPosition(e.matrixWorld)),Ee.logarithmicDepthBuffer&&O.setValue(P,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&O.setValue(P,`isOrthographic`,e.isOrthographicCamera===!0),ne!==e&&(ne=e,w=!0,E=!0)}if(v.needsLights&&(y.state.sunShadowMap.length>0&&O.setValue(P,`sunShadowMap`,y.state.sunShadowMap,Oe),y.state.directionalShadowMap.length>0&&O.setValue(P,`directionalShadowMap`,y.state.directionalShadowMap,Oe),y.state.spotShadowMap.length>0&&O.setValue(P,`spotShadowMap`,y.state.spotShadowMap,Oe),y.state.pointShadowMap.length>0&&O.setValue(P,`pointShadowMap`,y.state.pointShadowMap,Oe)),i.isSkinnedMesh){O.setOptional(P,i,`bindMatrix`),O.setOptional(P,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),O.setValue(P,`boneTexture`,e.boneTexture,Oe))}i.isBatchedMesh&&(O.setOptional(P,i,`batchingTexture`),O.setValue(P,`batchingTexture`,i._matricesTexture,Oe),O.setOptional(P,i,`batchingIdTexture`),O.setValue(P,`batchingIdTexture`,i._indirectTexture,Oe),O.setOptional(P,i,`batchingColorTexture`),i._colorsTexture!==null&&O.setValue(P,`batchingColorTexture`,i._colorsTexture,Oe));let A=n.morphAttributes;if((A.position!==void 0||A.normal!==void 0||A.color!==void 0)&&Be.update(i,n,S),(w||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,O.setValue(P,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(k.envMapIntensity.value=t.environmentIntensity),k.dfgLUT!==void 0&&(k.dfgLUT.value=Zu()),w){if(O.setValue(P,`toneMappingExposure`,T.toneMappingExposure),v.needsLights&&Dt(k,E),a&&r.fog===!0&&Pe.refreshFogUniforms(k,a),Pe.refreshMaterialUniforms(k,r,le,ce,x.state.transmissionRenderTarget[e.id]),v.needsLights&&v.lightProbeGrid){let e=v.lightProbeGrid;k.probesSH.value=e.texture,k.probesMin.value.copy(e.boundingBox.min),k.probesMax.value.copy(e.boundingBox.max),k.probesResolution.value.copy(e.resolution)}Al.upload(P,Ct(v),k,Oe)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&(Al.upload(P,Ct(v),k,Oe),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&O.setValue(P,`center`,i.center),O.setValue(P,`modelViewMatrix`,i.modelViewMatrix),O.setValue(P,`normalMatrix`,i.normalMatrix),O.setValue(P,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];Ye.update(n,S),Ye.bind(n,S)}}return S}function Dt(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.sunLights.needsUpdate=t,e.sunLightShadows.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function Ot(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return j},this.getActiveMipmapLevel=function(){return ee},this.getRenderTarget=function(){return M},this.setRenderTargetTextures=function(e,t,n){let r=I.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),I.get(e.texture).__webglTexture=t,I.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=I.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){M=e,j=t,ee=n;let r=null,i=!1,a=!1;if(e){let o=I.get(e);if(o.__useDefaultFramebuffer!==void 0){F.bindFramebuffer(P.FRAMEBUFFER,o.__webglFramebuffer),re.copy(e.viewport),ie.copy(e.scissor),ae=e.scissorTest,F.viewport(re),F.scissor(ie),F.setScissorTest(ae),te=-1;return}if(o.__webglFramebuffer===void 0)Oe.setupRenderTarget(e);else if(o.__hasExternalTextures)Oe.rebindTextures(e,I.get(e.texture).__webglTexture,I.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&I.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);Oe.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=I.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&Oe.useMultisampledRTT(e)===!1?I.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,re.copy(e.viewport),ie.copy(e.scissor),ae=e.scissorTest}else re.copy(fe).multiplyScalar(le).floor(),ie.copy(pe).multiplyScalar(le).floor(),ae=me;if(n!==0&&(r=O),F.bindFramebuffer(P.FRAMEBUFFER,r)&&F.drawBuffers(e,r),F.viewport(re),F.scissor(ie),F.setScissorTest(ae),i){let r=I.get(e.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=I.get(e.textures[t]);P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=I.get(e.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,t.__webglTexture,n)}te=-1};function kt(e){let t=I.get(e);return(t.__readFormat!==e.format||t.__readType!==e.type)&&(t.__readFormat=e.format,t.__readType=e.type,t.__formatReadable=Ee.textureFormatReadable(e.format),t.__typeReadable=Ee.textureTypeReadable(e.type)),t}this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){R(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=I.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){F.bindFramebuffer(P.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;e.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+s);let u=kt(o);if(u.__formatReadable===!1){R(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(u.__typeReadable===!1){R(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&P.readPixels(t,n,r,i,Ge.convert(c),Ge.convert(l),a)}finally{let e=M===null?null:I.get(M).__webglFramebuffer;F.bindFramebuffer(P.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=I.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){F.bindFramebuffer(P.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;e.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+s);let d=kt(o);if(d.__formatReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(d.__typeReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let f=P.createBuffer();P.bindBuffer(P.PIXEL_PACK_BUFFER,f),P.bufferData(P.PIXEL_PACK_BUFFER,a.byteLength,P.STREAM_READ),P.readPixels(t,n,r,i,Ge.convert(l),Ge.convert(u),0),P.bindBuffer(P.PIXEL_PACK_BUFFER,null);let p=M===null?null:I.get(M).__webglFramebuffer;F.bindFramebuffer(P.FRAMEBUFFER,p);let m=P.fenceSync(P.SYNC_GPU_COMMANDS_COMPLETE,0);return P.flush(),await vn(P,m,4),P.bindBuffer(P.PIXEL_PACK_BUFFER,f),P.getBufferSubData(P.PIXEL_PACK_BUFFER,0,a),P.bindBuffer(P.PIXEL_PACK_BUFFER,null),P.deleteBuffer(f),P.deleteSync(m),a}throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)}},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;Oe.setTexture2D(e,0),P.copyTexSubImage2D(P.TEXTURE_2D,n,0,0,o,s,i,a),F.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=Ge.convert(t.format),_=Ge.convert(t.type),v;t.isData3DTexture?(Oe.setTexture3D(t,0),v=P.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(Oe.setTexture2DArray(t,0),v=P.TEXTURE_2D_ARRAY):(Oe.setTexture2D(t,0),v=P.TEXTURE_2D),F.activeTexture(P.TEXTURE0),F.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,t.flipY),F.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),F.pixelStorei(P.UNPACK_ALIGNMENT,t.unpackAlignment);let y=F.getParameter(P.UNPACK_ROW_LENGTH),b=F.getParameter(P.UNPACK_IMAGE_HEIGHT),x=F.getParameter(P.UNPACK_SKIP_PIXELS),S=F.getParameter(P.UNPACK_SKIP_ROWS),C=F.getParameter(P.UNPACK_SKIP_IMAGES);F.pixelStorei(P.UNPACK_ROW_LENGTH,h.width),F.pixelStorei(P.UNPACK_IMAGE_HEIGHT,h.height),F.pixelStorei(P.UNPACK_SKIP_PIXELS,l),F.pixelStorei(P.UNPACK_SKIP_ROWS,u),F.pixelStorei(P.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=I.get(e),r=I.get(t),h=I.get(n.__renderTarget),g=I.get(r.__renderTarget);F.bindFramebuffer(P.READ_FRAMEBUFFER,h.__webglFramebuffer),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,I.get(e).__webglTexture,i,d+n),P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,I.get(t).__webglTexture,a,m+n)),P.blitFramebuffer(l,u,o,s,f,p,o,s,P.DEPTH_BUFFER_BIT,P.NEAREST);F.bindFramebuffer(P.READ_FRAMEBUFFER,null),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||I.has(e)){let n=I.get(e),r=I.get(t);F.bindFramebuffer(P.READ_FRAMEBUFFER,k),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,A);for(let e=0;e<c;e++)w?P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):P.framebufferTexture2D(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,n.__webglTexture,i),T?P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):P.framebufferTexture2D(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,r.__webglTexture,a),i===0?T?P.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):P.copyTexSubImage2D(v,a,f,p,l,u,o,s):P.blitFramebuffer(l,u,o,s,f,p,o,s,P.COLOR_BUFFER_BIT,P.NEAREST);F.bindFramebuffer(P.READ_FRAMEBUFFER,null),F.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?P.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?P.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):P.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):P.texSubImage2D(P.TEXTURE_2D,a,f,p,o,s,g,_,h);F.pixelStorei(P.UNPACK_ROW_LENGTH,y),F.pixelStorei(P.UNPACK_IMAGE_HEIGHT,b),F.pixelStorei(P.UNPACK_SKIP_PIXELS,x),F.pixelStorei(P.UNPACK_SKIP_ROWS,S),F.pixelStorei(P.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps&&P.generateMipmap(v),F.unbindTexture()},this.initRenderTarget=function(e){I.get(e).__webglFramebuffer===void 0&&Oe.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?Oe.setTextureCube(e,0):e.isData3DTexture?Oe.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?Oe.setTexture2DArray(e,0):Oe.setTexture2D(e,0),F.unbindTexture()},this.resetState=function(){j=0,ee=0,M=null,F.reset(),qe.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return ln}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=er._getDrawingBufferColorSpace(e),t.unpackColorSpace=er._getUnpackColorSpace()}};function $u(e,t=.001){if(e.length<3||!e.flat().every(Number.isFinite))throw Error(`Нужно не менее трёх конечных точек`);let n=e.map(e=>new V(...e)),r=n[0],i=new V;for(let e=1;e<n.length-1&&i.lengthSq()<1e-16;e++)i.crossVectors(n[e].clone().sub(r),n[e+1].clone().sub(r));if(i.lengthSq()<1e-16)throw Error(`Точки лежат на одной прямой`);if(i.normalize(),n.some(e=>Math.abs(e.clone().sub(r).dot(i))>t))throw Error(`Контур не плоский: отклонение больше 1 мм`);let a=n[1].clone().sub(r).normalize(),o=new V().crossVectors(i,a),s=n.map(e=>{let t=e.clone().sub(r);return[t.dot(a),t.dot(o)]}),c=(e,t,n)=>(t[0]-e[0])*(n[1]-e[1])-(t[1]-e[1])*(n[0]-e[0]);for(let e=0;e<s.length;e++)for(let t=e+1;t<s.length;t++){if(t===e+1||e===0&&t===s.length-1)continue;let n=s[e],r=s[(e+1)%s.length],i=s[t],a=s[(t+1)%s.length],o=[c(n,r,i),c(n,r,a)],l=[c(i,a,n),c(i,a,r)];if(o[0]*o[1]<=0&&l[0]*l[1]<=0&&Math.max(Math.min(n[0],r[0]),Math.min(i[0],a[0]))<=Math.min(Math.max(n[0],r[0]),Math.max(i[0],a[0]))&&Math.max(Math.min(n[1],r[1]),Math.min(i[1],a[1]))<=Math.min(Math.max(n[1],r[1]),Math.max(i[1],a[1])))throw Error(`Контур самопересекается или касается себя`)}let l=Math.abs(s.reduce((e,t,n)=>{let r=s[(n+1)%s.length];return e+t[0]*r[1]-r[0]*t[1]},0))/2;if(l<=1e-12)throw Error(`Площадь контура не определена`);return l}function ed(e,t,n,r){let i=t.clone().sub(e),a=r.clone().sub(n),o=e.clone().sub(n),s=i.dot(i),c=i.dot(a),l=a.dot(a),u=i.dot(o),d=a.dot(o),f=s*l-c*c,p=f>1e-20?Math.max(0,Math.min(1,(c*d-l*u)/f)):0,m=l>1e-20?(c*p+d)/l:0;return m<0?(m=0,p=s>1e-20?Math.max(0,Math.min(1,-u/s)):0):m>1&&(m=1,p=s>1e-20?Math.max(0,Math.min(1,(c-u)/s)):0),[e.clone().addScaledVector(i,p),n.clone().addScaledVector(a,m)]}function td(e,t){let n=[e.a,e.b,e.c],r=[t.a,t.b,t.c],i=1/0,a=new V,o=new V,s=(e,t)=>{let n=e.distanceToSquared(t);n<i&&(i=n,a=e.clone(),o=t.clone())};for(let e of n)s(e,t.closestPointToPoint(e,new V));for(let t of r)s(e.closestPointToPoint(t,new V),t);for(let e=0;e<3;e++)for(let t=0;t<3;t++)s(...ed(n[e],n[(e+1)%3],r[t],r[(t+1)%3]));for(let[i,a]of[[n,t],[r,e]])for(let e=0;e<3;e++){let t=i[(e+1)%3].clone().sub(i[e]),n=t.length();if(!n)continue;let r=new ra(i[e],t.normalize()).intersectTriangle(a.a,a.b,a.c,!1,new V);r&&r.distanceTo(i[e])<=n+1e-9&&s(r,r)}return{distance_m:Math.sqrt(i),a:a.toArray(),b:o.toArray()}}async function nd(e,t,n,r,i=2e5){if(n.mesh?.primitive===`lines`||r.mesh?.primitive===`lines`)throw Error(`Зазор между линейными примитивами пока не поддержан`);if(!n.mesh||!r.mesh)throw Error(`Для обоих элементов нужна геометрия`);if(n.id===r.id)throw Error(`Выберите два разных элемента`);let a=n.mesh.index_count/3*r.mesh.index_count/3;if(a>i)throw Error(`Зазор не рассчитан: ${a} пар треугольников превышают лимит ${i}.`);let o=n=>{let r=n.mesh,i=new Float32Array(t,r.position_byte_offset,r.vertex_count*3),a=new Uint32Array(t,r.index_byte_offset,r.index_count),o=e.coordinate_system.render_origin_m;return Array.from({length:a.length/3},(e,t)=>new fi(...[0,1,2].map(e=>{let n=a[t*3+e]*3;return new V(i[n]+o[0],i[n+1]+o[1],i[n+2]+o[2])})))},s=null,c=0,l=o(n),u=o(r);for(let e of l)for(let t of u){let n=td(e,t);if((!s||n.distance_m<s.distance_m)&&(s=n),s.distance_m<1e-9)return s;++c%2e3==0&&await new Promise(e=>setTimeout(e,0))}if(!s)throw Error(`В сетке нет треугольников`);return s}function rd(e,t,n,r,i=()=>[],a=()=>null){let o=document.getElementById(`measure`),s=document.getElementById(`measure-controls`);s.innerHTML=`<strong>Измерения модели</strong><p id="measure-message" role="status">Выберите две точки на модели.</p><label>Результат<select id="measure-axis"><option value="distance">Расстояние 3D</option><option>X</option><option>Y</option><option>Z</option><option value="area">Площадь плоского контура</option></select></label><label class="check"><input id="measure-snap" type="checkbox" checked>Привязки: вершины и рёбра треугольной сетки</label><div class="measure-actions"><button id="measure-next">Новый замер</button><button id="measure-area">Замкнуть контур</button><button id="measure-gap">Зазор двух выбранных</button><button id="measure-history">Журнал</button><button id="measure-close">Закрыть</button></div><small>Ctrl + щелчок — выбрать второй элемент. Зазор измеряется между поверхностями сеток; вложение тел и точность исходной геометрии требуют проверки.</small>`;let c=s.querySelector(`#measure-message`),l=s.querySelector(`#measure-axis`),u=[],d=!1,f=``;function p(){let e=JSON.parse(localStorage.getItem(Te(n()))??`[]`);if(!Array.isArray(e))throw Error(`Повреждён журнал замеров`);return e}function m(e,t){try{let r=p();r.push(e),localStorage.setItem(Te(n()),JSON.stringify(r)),c.textContent=t+` · сохранено в журнале браузера`,document.dispatchEvent(new Event(`spatial-measurement-saved`))}catch(e){c.textContent=t+` · НЕ сохранено`,r(e)}}function h(){u=[],f=t()?.model_id??``,e?.showMeasurement([]),c.textContent=l.value===`area`?`Укажите точки контура по порядку, затем замкните.`:`Выберите две точки на модели.`}function g(){d=!1,s.hidden=!0,o.setAttribute(`aria-pressed`,`false`),e?.setMeasureHandler(null),h()}o.onclick=()=>{d?g():!t()||!e?r(`Сначала откройте модель с геометрией`):(d=!0,s.hidden=!1,o.setAttribute(`aria-pressed`,`true`),h(),e.setMeasureHandler(r=>{let i=t();if(!i)return;if((f!==i.model_id||l.value!==`area`&&u.length===2)&&h(),u.push(r),e.showMeasurement(u.map(e=>e.point_m)),l.value===`area`){c.textContent=`Точек контура: ${u.length} · ${r.snap??`surface`}`;return}if(u.length===1){c.textContent=`Первая точка: ${r.snap??`surface`}. Укажите вторую.`;return}let a=we(n(),i,u[0],u[1],l.value);m(a,`${a.value_m.toFixed(3)} м · ΔX ${a.delta_m[0].toFixed(3)} · ΔY ${a.delta_m[1].toFixed(3)} · ΔZ ${a.delta_m[2].toFixed(3)}`)}))},s.querySelector(`#measure-next`).onclick=h,s.querySelector(`#measure-close`).onclick=g,s.querySelector(`#measure-snap`).onchange=t=>{e&&(e.measureSnap=t.target.checked)},s.querySelector(`#measure-area`).onclick=()=>{try{let r=t();if(!r||l.value!==`area`)throw Error(`Выберите измерение площади`);let i=$u(u.map(e=>e.point_m)),a={...we(n(),r,u[0],u[1],`distance`),method:`planar_mesh_polygon`,axis:`area`,value_m2:i,points:u.map(e=>P(r,e)),note:`Плоский контур по сетке; допуск плоскостности 1 мм. Не площадь исходной BIM-поверхности.`};delete a.value_m,m(a,`${i.toFixed(3)} м²`),e?.showMeasurement([...u.map(e=>e.point_m),u[0].point_m])}catch(e){r(e)}};let _=s.querySelector(`#measure-gap`);_.onclick=async()=>{let o=t(),s=a(),l=i();if(!o||!s||l.length!==2)r(`Выберите ровно два элемента через Ctrl + щелчок`);else{_.disabled=!0,c.textContent=`Расчёт минимального расстояния между поверхностями…`;try{let r=l.map(e=>o.elements.find(t=>t.id===e)),i=await nd(o,s,r[0],r[1]);if(t()!==o)throw Error(`Модель сменилась во время расчёта`);let a=[{element_id:l[0],point_m:i.a,triangle_index:null},{element_id:l[1],point_m:i.b,triangle_index:null}];e?.showMeasurement(a.map(e=>e.point_m)),m({...we(n(),o,a[0],a[1],`distance`),method:`exhaustive_triangle_surface_distance`,note:`Минимум между треугольными поверхностями. Положительное расстояние не доказывает отсутствие вложения одного тела в другое.`},`${i.distance_m.toFixed(4)} м · между поверхностями`)}catch(e){c.textContent=`Зазор не рассчитан`,r(e)}finally{_.disabled=!1}}},l.onchange=h,document.getElementById(`canvas`).addEventListener(`measurement-cancel`,g);let v=document.createElement(`dialog`);return v.setAttribute(`aria-label`,`Журнал пространственных замеров`),document.body.append(v),s.querySelector(`#measure-history`).onclick=()=>{let i;try{i=p()}catch(e){r(e);return}v.replaceChildren();let a=document.createElement(`div`);a.className=`dialog-content`,v.append(a);let o=document.createElement(`h2`);o.textContent=`Замеры проекта`,a.append(o);let s=document.createElement(`p`);s.textContent=`Журнал хранится в браузере. Сохранение рабочего места переносит его в общую базу проекта вместе с источниками и состоянием сцены.`,a.append(s);for(let n of i.slice().reverse()){let r=document.createElement(`p`);r.textContent=`${n.value_m2===void 0?n.value_m?.toFixed(3)+` м`:n.value_m2.toFixed(3)+` м²`} (${n.axis}) · ${n.filename} · ${n.model_id===t()?.model_id?`текущая модель`:`другая модель / ревизия`} · ${new Date(n.created_at).toLocaleString()}`,a.append(r);let i=document.createElement(`button`);i.textContent=`Показать точки`,i.disabled=n.model_id!==t()?.model_id,i.onclick=()=>{e?.showMeasurement(n.points.map(e=>e.point_m)),e?.focusTargets(n.points.map(e=>e.element_id)),v.close()},a.append(i)}if(!i.length){let e=document.createElement(`p`);e.textContent=`Замеров пока нет`,a.append(e)}let c=document.createElement(`button`);c.textContent=`Скачать JSON`,c.onclick=()=>{let e=URL.createObjectURL(new Blob([JSON.stringify({project_id:n(),measurements:i},null,2)],{type:`application/json`})),t=document.createElement(`a`);t.href=e,t.download=`uvyazka-spatial-measurements.json`,t.click(),setTimeout(()=>URL.revokeObjectURL(e),1e3)},a.append(c);let l=document.createElement(`button`);l.textContent=`Закрыть журнал`,l.onclick=()=>v.close(),a.append(l),v.showModal()},{reset:g}}var id={cube:`<path d="m12 3 9 5v8l-9 5-9-5V8zM3 8l9 5 9-5M12 13v8"/>`,layers:`<path d="m12 3 10 5-10 5L2 8zM2 12l10 5 10-5M2 16l10 5 10-5"/>`,open:`<path d="M3 7V5h6l2 2h10v13H3zM3 11h18"/>`,sliders:`<path d="M4 7h16M4 17h16M8 4v6M16 14v6"/>`,close:`<path d="m6 6 12 12M18 6 6 18"/>`,fit:`<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>`,ruler:`<path d="m3 16 13-13 5 5L8 21zM7 12l2 2M10 9l2 2M13 6l2 2"/>`,cut:`<path d="M4 4h16v16H4zM2 15 22 9"/>`,info:`<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7v1"/>`,list:`<path d="M9 5h12M9 12h12M9 19h12M3 5h1M3 12h1M3 19h1"/>`,top:`<path d="M4 4h16v16H4zM4 10h16M10 4v16"/>`,play:`<path d="m9 5 11 7-11 7z"/>`,search:`<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>`},ad=e=>`<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${id[e]||id.cube}</svg>`,od=`
<header class="app-header">
 <a class="brand" id="memory-link" href="/" aria-label="Увязка — база проекта">увязка</a>
 <div class="file-heading"><h1 id="file-title">Загрузка модели…</h1><span id="geometry-kind"></span></div>
 <nav class="mode-switch" aria-label="Режим работы"><button id="mode-view" aria-pressed="true">Модель</button><button id="mode-simulate" aria-pressed="false">Симуляция</button><a id="measurement-link" href="/measurements/" hidden>Лист и измерения ↗</a></nav>
 <div class="header-actions"><button id="open-workspace" title="Сохранение сцены, подборки и ревизии">Рабочее место</button><button id="theme-toggle" title="Переключить тему">Тёмная тема</button><a id="back" href="/">База проекта</a><button id="replace-model" title="Открыть файл вместо текущей сцены">Заменить сцену</button><button id="open-file" class="add-model-primary" aria-label="Добавить модель" title="Добавить RVT, IFC или NWD к сцене">${ad(`open`)}<span>Добавить модель</span></button></div>
</header>
<main>
 <nav class="tool-rail" aria-label="Инструменты модели">
  <button id="toggle-tree" aria-label="Структура модели" aria-expanded="true" aria-controls="model-panel">${ad(`layers`)}<span>Модель</span></button>
  <button id="iso" title="Аксонометрия">${ad(`cube`)}<span>3D</span></button>
  <button id="top" title="Вид сверху">${ad(`top`)}<span>План</span></button>
  <button id="cut" aria-pressed="false" aria-label="Разрез модели">${ad(`cut`)}<span>Разрез</span></button>
  <button id="measure" aria-pressed="false" aria-label="Измерить расстояние">${ad(`ruler`)}<span>Замер</span></button>
  <button id="toggle-inspector" aria-label="Свойства модели" aria-expanded="true" aria-controls="properties-panel">${ad(`list`)}<span>Свойства</span></button>
  <button id="open-network" aria-label="Инженерные связи">${ad(`layers`)}<span>Связи</span></button><div class="rail-spacer"></div>
  <button id="file-settings" aria-label="Модель и параметры расчёта" title="Модель и параметры расчёта">${ad(`sliders`)}<span>Параметры</span></button>
  <button id="help" aria-label="Справка" title="Справка">${ad(`info`)}<span>Справка</span></button>
 </nav>
 <div class="workarea">
  <div class="error" id="error" role="alert" hidden></div>
  <div class="workspace">
   <aside class="model-tree" id="model-panel">
    <div class="panel-head"><h2>Дерево модели</h2><button id="close-tree" class="icon-button" aria-label="Скрыть структуру">${ad(`close`)}</button></div>
    <div id="scene-members"></div><div class="tree-tools"><label class="search-field">${ad(`search`)}<input id="element-search" aria-label="Найти элемент или документ модели" type="search" placeholder="Элемент, вид, лист: имя, ID…" title="Название, семейство, тип, Revit ID, IFC ID или GlobalId"></label><details class="compact-filters"><summary>Фильтры и параметры</summary><details id="parameter-search-details" class="parameter-search"><summary>Поиск по параметрам</summary><label>Параметр<input id="parameter-name" list="parameter-names" placeholder="Например, FireRating или Мощность" autocomplete="off"></label><datalist id="parameter-names"></datalist><div class="parameter-condition"><select id="parameter-operator" aria-label="Условие параметра"><option value="contains">Содержит</option><option value="equals">Равно</option><option value="exists">Заполнен</option><option value="missing">Не заполнен / отсутствует</option><option value="gt">Больше</option><option value="gte">Не меньше</option><option value="lt">Меньше</option><option value="lte">Не больше</option></select><input id="parameter-value" aria-label="Значение параметра" placeholder="Значение"></div><small>Числа — в единицах источника, без пересчёта.</small><button id="add-parameter">Добавить условие</button><select id="parameter-combine" aria-label="Объединение условий"><option value="all">Все условия (И)</option><option value="any">Любое условие (ИЛИ)</option></select><div id="parameter-active"></div><button id="clear-parameter">Сбросить параметры</button></details><details id="level-filter" class="facet-filter"></details><details id="category-filter" class="facet-filter"></details><label class="storey-picker">Система<select id="system-filter"><option value="">Все системы</option></select></label><label class="system-only-toggle"><input id="visibility-filter" type="checkbox" checked><span>Применять фильтры к 3D</span></label><div id="system-summary" aria-live="polite"></div></details><label class="storey-picker">Дерево<select id="tree-grouping"><option value="categories">По категориям</option><option value="levels">По уровням</option></select></label><div class="selection-toolbar"><span id="selection-count">Выбрано 0</span><button id="undo-visibility" disabled title="Отменить последнее изменение видимости">↶ Видимость</button></div></div>
    <div class="tree-match-actions" aria-label="Действия с результатами поиска"><button id="hide-matches" disabled>Скрыть найденные</button><button id="show-matches" disabled>Показать</button><button id="isolate-matches" disabled>Только найденные</button></div><div id="element-tree"></div><button id="reset-visibility" class="reset-tree">${ad(`fit`)}Показать всю модель</button>
   </aside>
   <section class="scene" aria-label="Рабочая область модели">
    <div id="canvas"></div><div id="cad-host" hidden></div><div id="no-model"><strong>Добавьте модель проекта</strong><p>RVT / IFC — модель, системы и свойства; NWD — геометрия.<br>DWG / DXF — просмотр чертежа.</p><button id="empty-add-model" class="add-model-primary">${ad(`open`)}Добавить модель</button><small>Файл обрабатывается на вашем устройстве</small></div>
    <div class="scene-tools"><button id="fit" title="Вписать модель · F" aria-label="Вписать модель">${ad(`fit`)}</button><button id="xray" aria-pressed="false" title="Прозрачная модель" aria-label="Прозрачная модель">${ad(`layers`)}</button></div>
    <div id="cut-controls" hidden><label>Ось сечения<select id="cut-axis" aria-label="Ось сечения"><option>Z</option><option>X</option><option>Y</option></select><output id="cut-height"></output><input id="cut-position" type="range" min="0" max="100" value="50" aria-label="Положение сечения"></label><label class="check"><input id="cut-reverse" type="checkbox">Обратная сторона</label><button id="cut-box">Область выбранного элемента</button></div><div id="measure-controls" hidden></div>
    <div class="scene-caption simulation-only"><span>Последовательность строительства</span><strong id="active-stage">Сценарий не выбран</strong></div>
    <div class="canvas-hint">Мышь — вращение <span>Правая кнопка — перемещение</span> · F — вписать</div>
   </section>
   <aside class="properties-panel" id="properties-panel"><div class="panel-head"><h2 id="inspector-title">Свойства модели</h2><button id="close-inspector" class="icon-button" aria-label="Скрыть свойства">${ad(`close`)}</button></div><div id="selected-visibility-actions" class="selected-visibility-actions" hidden><button id="hide-selected">Скрыть</button><button id="show-selected">Показать</button><button id="isolate-selected">Только выбранные</button></div><div class="inspector-tabs" role="group" aria-label="Содержимое инспектора"><button id="properties-tab" aria-pressed="true">Свойства</button><button id="network-tab" aria-pressed="false">Связи</button></div><div class="properties-scroll"><div id="property-content"><div class="inspector" id="inspector"></div><div class="inspector" id="resources"></div></div><div class="inspector" id="engineering-panel" hidden></div></div></aside>
  </div>
  <section class="simulation-dock simulation-only" aria-label="Управление симуляцией">
   <div class="playback">
    <span class="dock-label">4D<span>Ход строительства</span></span>
    <button id="calculate-current" class="primary" hidden>Рассчитать график</button><button id="play" aria-label="Воспроизвести" class="primary" disabled>▶</button><button id="rewind" aria-label="В начало" disabled>↶</button>
    <select id="rate" aria-label="Скорость"><option value="1">1×</option><option value="10">10×</option><option value="60" selected>60×</option><option value="240">240×</option></select>
    <select id="scenes" aria-label="Сцена работ"><option value="">Выберите этап</option></select>
    <span id="clock">0 мин</span><input id="time" type="range" min="0" max="1" value="0" aria-label="Виртуальное время" disabled>
    <details class="view-options"><summary title="Отображение и обход модели">${ad(`sliders`)}</summary><div><button id="tour" aria-pressed="false">Автопоказ</button><button id="worker-route">Путь бригады</button><label class="check"><input id="site" type="checkbox" checked>Площадка</label><label class="check"><input id="show-complete" type="checkbox" checked>Будущие элементы</label></div></details>
    <select id="time-unit" aria-label="Единицы шкалы"><option value="days">Сутки</option><option value="hours">Часы</option><option value="minutes">Минуты</option></select>
    <select id="timeline-zoom" aria-label="Масштаб графика"><option value="1">1:1</option><option value="2">2×</option><option value="4">4×</option></select>
    <button id="toggle-schedule" aria-label="Показать график" aria-expanded="true" aria-controls="schedule-panel">${ad(`list`)}</button>
   </div>
   <section class="schedule-panel" id="schedule-panel">
    <div class="gantt-scroll"><div id="gantt" aria-label="Расчётный график работ"><div id="gantt-ruler"></div><div id="gantt-body"></div></div></div>
    <div class="export-actions"><span id="schedule-summary">Нет выбранного расчёта</span><a id="csv" hidden>CSV</a><a id="journal" hidden>JSON</a><button id="schedule-details-toggle" aria-expanded="false" aria-controls="schedule-details">Основания и длительности</button></div>
    <div id="schedule-details" hidden><div class="metrics" id="metrics"></div><div class="schedule-wrap"><table><thead><tr><th>Работа</th><th>Начало / конец, мин</th><th>Ход работ</th><th>Основание</th></tr></thead><tbody id="schedule"></tbody></table></div></div>
   </section>
  </section>
 </div>
</main>
<footer class="status-bar"><span class="status-indicator" aria-hidden="true"></span><span id="workspace-status" role="status">Загрузка</span><button id="status-details">Подробности</button><span class="privacy-label">Обработка на устройстве</span><span class="formats">DWG / RVT / IFC / NWD</span></footer>
<dialog id="file-dialog" aria-labelledby="file-dialog-title"><div class="panel-head"><h2 id="file-dialog-title">Файл и параметры</h2><button id="close-file" class="icon-button" aria-label="Закрыть параметры">${ad(`close`)}</button></div><div class="dialog-content"><button id="workspace-settings">Рабочее место: сцены, подборки и ревизии</button><label>Проект<select id="projects" aria-label="Проект"></select></label><label>Сохранённый сценарий<select id="runs" aria-label="Рассчитанный сценарий"></select></label><label>Сохранённая модель<select id="models" aria-label="Пространственная модель"></select></label><div id="import-host"></div><details class="notes simulation-only"><summary>Допущения и покрытие</summary><div id="assumptions">Нет выбранного расчёта.</div></details></div></dialog>
<dialog id="help-dialog" aria-labelledby="help-title"><div class="panel-head"><h2 id="help-title">Работа с моделью</h2><button id="close-help" class="icon-button" aria-label="Закрыть справку">${ad(`close`)}</button></div><div class="dialog-content"><p>Откройте DWG, DXF, RVT, IFC или NWD. Выберите элемент на модели или в структуре — его свойства появятся справа.</p><dl><dt>Вращение</dt><dd>Левая кнопка мыши</dd><dt>Перемещение</dt><dd>Правая кнопка или стрелки</dd><dt>Масштаб</dt><dd>Колесо мыши</dd><dt>Вписать модель</dt><dd>F при фокусе на холсте</dd><dt>Дерево и видимость</dt><dd>Модель → категория → элементы; переключатель «По уровням» добавляет уровень перед категорией. RVT использует категории Revit, IFC — классы IFC, DWG/DXF — слои. Галочка показывает или скрывает ветку, «Только» оставляет её в сцене. Скрытые элементы остаются в дереве. «Показать всю модель» сбрасывает скрытие и фильтры.</dd><dt>Поиск</dt><dd>Строка поиска ищет элементы по названию, семейству, типу, Revit ID, IFC ID и GlobalId, а документы — по имени и Revit ID. Под RVT-моделью доступны листы, виды, спецификации и размещения; выбор открывает исходную запись. #123 — точный IFC ID; revit:123 — точный Revit ID. В «Поиск по параметрам» добавляйте условия и объединяйте их через «И» или «ИЛИ». Уровни и категории можно выбирать по несколько. Галочка «Применять фильтры к 3D» управляет видимостью результатов; без неё фильтруется только дерево. Если «Показать» возвращает выбранный элемент вне текущей выборки, эта галочка отключается, а условия поиска сохраняются. «Только найденные» изолирует результаты в 3D.</dd><dt>Снять выделение</dt><dd>Escape при фокусе на холсте</dd></dl><div class="notice">Расчётный сценарий содержит допущения и не заменяет ПОС/ППР.</div><p>RVT читается частично. DWG/DXF доступны для просмотра чертежей; симуляция рассчитывается по IFC/RVT.</p></div></dialog>`,sd=(e,t=`days`)=>{let n=t===`days`?1440:t===`hours`?60:1;return new Intl.NumberFormat(`ru-RU`,{maximumFractionDigits:1}).format(e/n)};function cd(e){let t=new Set(e.scenario.operations.map(e=>e.id)),n=new Set,r=e.scenario.units.map(e=>({id:e.id,name:e.name,ids:e.operation_ids.filter(e=>!t.has(e)||n.has(e)?!1:(n.add(e),!0))})).filter(e=>e.ids.length);for(let t of e.scenario.operations)n.has(t.id)||r.push({id:t.id,name:t.name,ids:[t.id]});let i=new Map(e.scenario.operations.map(e=>[e.id,e])),a=Math.max(1,e.duration);return r.map(t=>({...t,bars:t.ids.map(t=>{let n=i.get(t),r=e.operation_states[t],o=Number.isFinite(r?.start)&&Number.isFinite(r?.finish)&&r.start!==null&&r.finish!==null&&r.finish>=r.start;return{id:t,name:n.name,start:o?r.start:null,finish:o?r.finish:null,left:o?Math.max(0,Math.min(100,r.start/a*100)):null,width:o?Math.max(0,Math.min(a,r.finish-r.start)/a*100):null,evidence:n.evidence.kind}})}))}function ld(e){return new Promise(t=>{let n=document.createElement(`dialog`);n.className=`nwd-unit-dialog`,n.innerHTML=`<div class="panel-head"><h2>Масштаб NWD</h2></div><div class="dialog-content"><p data-file></p><p>Исходные единицы пока не прочитаны. Укажите их для пересчёта координат в метры. Этот выбор сохранится как допущение пользователя.</p><label>Единицы исходного файла<select aria-label="Единицы NWD"><option value="">Выберите единицы</option><option value="m">Метры</option><option value="mm">Миллиметры</option><option value="cm">Сантиметры</option><option value="ft">Футы</option></select></label><p>Если единицы неизвестны, отмените открытие и уточните их в источнике.</p><div class="row"><button data-cancel>Отмена</button><button data-open disabled>Открыть с этим масштабом</button></div></div>`,n.querySelector(`[data-file]`).textContent=e,document.body.append(n);let r=n.querySelector(`select`),i=n.querySelector(`[data-open]`),a=e=>{n.close(),n.remove(),t(e)};r.onchange=()=>i.disabled=!r.value,i.onclick=()=>a(r.value),n.querySelector(`[data-cancel]`).onclick=()=>a(null),n.oncancel=e=>{e.preventDefault(),a(null)},n.showModal()})}var ud=(e,t=!1)=>t?[`Подготовка`,`Расчёт`,`Отображение`]:/\.(dwg|dxf)$/i.test(e)?[`Чтение файла`,`CAD`]:/\.nwd$/i.test(e)?[`Чтение файла`,`Хеширование`,`NWD-движок`,`Данные NWD`,`Геометрия`,`Отображение`]:[`Чтение файла`,`Хеширование`,.../\.rvt$/i.test(e)?[`RVT-движок`,`Документ RVT`,`Параметры RVT`,`Связи RVT`,`RVT → IFC`,`IFC-буфер`]:[],`IFC-движок`,`Структура IFC`,`Свойства IFC`,`Геометрия`,`Отображение`],dd=class{startedAt=0;stageAt=0;lastReply=0;lastUpdate=0;stage=``;message=``;filename=``;size=0;state=`running`;steps=[];begin(e,t,n,r=!1){this.filename=e,this.size=t,this.startedAt=this.stageAt=this.lastUpdate=n,this.lastReply=0,this.stage=`Подготовка`,this.message=`Подготовка файла`,this.state=`running`,this.steps=ud(e,r).map(e=>({name:e,state:`waiting`}))}update(e,t,n){if(this.state!==`running`)return;if(e!==this.stage){for(let e of this.steps)e.state===`active`&&(e.state=`done`);this.stage=e,this.stageAt=n}let r=this.steps.findIndex(t=>t.name===e);r>=0&&(this.steps.forEach((e,t)=>{t<r&&e.state===`waiting`&&(e.state=`skipped`)}),this.steps[r].state=`active`),this.message=t,this.lastUpdate=n}reply(e){this.state===`running`&&(this.lastReply=e)}finish(e,t,n){if(this.state===`running`){this.state=e,this.message=t,this.lastUpdate=n;for(let t of this.steps)t.state===`active`&&(t.state=e===`completed`?`done`:`stopped`)}}snapshot(e){let t=this.state===`running`?e:this.lastUpdate,n=Math.max(0,e-Math.max(this.lastReply,this.lastUpdate));return{elapsed:Math.max(0,t-this.startedAt),stageElapsed:Math.max(0,t-this.stageAt),silent:n>=15e3,replyAge:this.lastReply?Math.max(0,e-this.lastReply):null}}};function fd(e){let t=Math.floor(e/1e3);return`${Math.floor(t/60)}:${String(t%60).padStart(2,`0`)}`}var pd={running:`Обработка файла`,completed:`Готово`,partial:`Открыто частично`,failed:`Не удалось обработать`,cancelled:`Отменено`,interrupted:`Прервано`},md={waiting:`Ожидает`,active:`В работе`,done:`Завершён`,skipped:`Пропущен`,stopped:`Остановлен`};function hd(e,t){let n=new dd,r=!1,i=document.createElement(`dialog`);i.id=`conversion-dialog`,i.className=`conversion-dialog`,i.setAttribute(`aria-labelledby`,`conversion-title`),i.innerHTML=`<header class="panel-head"><h2 id="conversion-title">Обработка файла</h2><button id="conversion-close" aria-label="Свернуть окно обработки">Свернуть</button></header><div class="conversion-body"><p id="conversion-source"></p><div class="conversion-stage" role="status" aria-live="polite"><span id="conversion-badge"></span><strong id="conversion-stage"></strong><p id="conversion-message"></p></div><progress id="conversion-progress" aria-label="Выполняется текущий этап"></progress><div class="conversion-timers"><span>Всего <b id="conversion-total">0:00</b></span><span>Текущий этап <b id="conversion-time">0:00</b></span></div><p id="conversion-activity"></p><ol id="conversion-steps" aria-label="Этапы обработки"></ol><p class="conversion-privacy">Файл обрабатывается на вашем устройстве. Время завершения заранее неизвестно.</p><div class="conversion-actions"><button id="conversion-log">Открыть журнал</button><button id="conversion-cancel">Отменить обработку</button><button id="conversion-done" hidden>К модели</button></div></div>`,document.body.append(i);let a=e=>i.querySelector(`#`+e),o=document.createElement(`button`);o.id=`open-processing`,o.textContent=`Обработка`,o.hidden=!0,document.getElementById(`status-details`).after(o);let s=()=>{i.open||i.showModal()};o.onclick=s,a(`conversion-close`).onclick=()=>i.close(),a(`conversion-cancel`).onclick=e,a(`conversion-done`).onclick=()=>i.close(),a(`conversion-log`).onclick=()=>{i.close(),t()};function c(){if(!r)return;let e=n.snapshot(Date.now()),t=n.state===`running`;i.dataset.state=n.state,a(`conversion-title`).textContent=pd[n.state],a(`conversion-badge`).textContent=t?`Выполняется`:pd[n.state],a(`conversion-source`).textContent=n.filename+` · `+(n.size/1024**2).toFixed(1)+` MiB`,a(`conversion-stage`).textContent=n.stage,a(`conversion-message`).textContent=n.message,a(`conversion-total`).textContent=fd(e.elapsed),a(`conversion-time`).textContent=fd(e.stageElapsed);let s=a(`conversion-activity`);s.dataset.silent=String(e.silent),s.textContent=t?e.silent?`Новых ответов движка нет `+fd(Math.max(0,Date.now()-Math.max(n.lastReply,n.lastUpdate)))+`. Тяжёлый этап может выполняться без промежуточных сообщений. Зависание не исключено; можно подождать или отменить.`:e.replyAge===null?`Ожидаем первый ответ движка. Таймер показывает время ожидания.`:`Последний ответ движка `+fd(e.replyAge)+` назад.`:`Результат и события сохранены в журнале.`,a(`conversion-progress`).hidden=!t,a(`conversion-cancel`).hidden=!t,a(`conversion-done`).hidden=t,o.textContent=t?`Обработка · `+fd(e.elapsed):pd[n.state],a(`conversion-steps`).replaceChildren(...n.steps.map(e=>{let t=document.createElement(`li`);t.dataset.state=e.state;let n=document.createElement(`span`);n.textContent=e.name;let r=document.createElement(`small`);return r.textContent=md[e.state],t.append(n,r),e.state===`active`&&t.setAttribute(`aria-current`,`step`),t}))}let l=setInterval(()=>{n.state===`running`&&(i.open||r)&&c()},1e3);return addEventListener(`pagehide`,()=>clearInterval(l)),{begin(e,t,i=!1){n.begin(e,t,Date.now(),i),r=!0,o.hidden=!1,c(),s()},update(e,t){n.update(e,t,Date.now()),c()},reply(){n.reply(Date.now())},finish(e,t){n.finish(e,t,Date.now()),c()},open:s}}var gd=`web-ifc-0.0.78/uvyazka-2/cache-4-network`,_d=e=>`${gd}:${e}`;function vd(e,t){if(e.model.source.sha256!==t||e.model.model_id!==t||e.model.importer_version!==`web-ifc-0.0.78/uvyazka-2`)throw Error(`Кеш относится к другой модели или версии обработчика`);return De(e.model,e.binary),e}async function yd(){let e=await new Promise((e,t)=>{let n=indexedDB.open(`uvyazka-ifc-geometry`,1);n.onupgradeneeded=()=>n.result.createObjectStore(`models`),n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error),n.onblocked=()=>t(Error(`Кеш занят другой вкладкой`))}),t=t=>new Promise((n,r)=>{let i=e.transaction(`models`,`readwrite`);t(i.objectStore(`models`)),i.oncomplete=()=>n(),i.onerror=()=>r(i.error),i.onabort=()=>r(i.error??Error(`Запись кеша отменена`))});return{async get(t){let n=await new Promise((n,r)=>{let i=e.transaction(`models`).objectStore(`models`).get(_d(t));i.onsuccess=()=>n(i.result),i.onerror=()=>r(i.error)});return n&&vd(n,t),n},async put(e,n,r){await t(t=>{let i=t.getAllKeys(),a=t.getAll();a.onsuccess=()=>{for(let e of i.result)String(e).startsWith(`web-ifc-0.0.78/uvyazka-2/cache-4-network:`)||t.delete(e);let o=a.result.filter(t=>_d(t.model.source.sha256)!==_d(e)).sort((e,t)=>t.accessed-e.accessed);for(let e of o.slice(2))t.delete(_d(e.model.source.sha256));t.put({model:n,binary:r,accessed:Date.now()},_d(e))}})},clear:()=>t(e=>e.clear()),close:()=>e.close()}}var bd=1e3;function xd(e){if(e===void 0)return;let t=JSON.stringify(e);return t.length<=65536?e:{truncated:!0,original_characters:t.length,preview:t.slice(0,65536)}}function Sd(e,t){return!/\.(ifc|rvt|nwd|dwg|dxf)$/i.test(e)||!Number.isSafeInteger(t)||t<=0?{error:`Нужен непустой RVT, IFC, NWD, DWG или DXF.`}:/\.nwd$/i.test(e)&&t>512*1024**2?{error:`NWD: технический бюджет экспериментального читателя — 512 MiB.`}:/\.(dwg|dxf)$/i.test(e)&&t>67108864?{error:`CAD-движок поддерживает DWG/DXF до 64 MiB.`}:/\.rvt$/i.test(e)&&t>2*1024**3?{error:`Размер RVT превышает технический предел текущего читателя: 2 GiB.`}:t>64*1024**2?{warning:`Большой файл: обработка может потребовать значительно больше памяти, чем размер файла. Отмена доступна; длительность заранее неизвестна.`}:{}}var Cd=class{runs=[];storageError=``;pending=Promise.resolve();dirty=new Map;saving=!1;storage;owner;changed;clock;constructor(e,t,n=()=>{},r=Date.now){this.storage=e,this.owner=t,this.changed=n,this.clock=r}async restore(){try{this.runs=await this.storage.load();for(let e of this.runs)e.owner===this.owner&&e.state===`running`&&this.finish(e,`interrupted`,`Предыдущая сессия завершилась без результата. Причина неизвестна: вкладка могла быть закрыта или перезапущена.`)}catch(e){this.storageError=`История недоступна: `+String(e)}this.changed()}begin(e,t,n){let r=new Date(this.clock()).toISOString(),i={id:crypto.randomUUID(),owner:this.owner,operation:e,filename:t,size_bytes:n,started_at:r,state:`running`,stage:`Подготовка`,stage_started_at:r,events:[],omitted_events:0,warnings:0,errors:0};return this.runs.unshift(i),this.event(i,`info`,`Запуск обработки`,{size_bytes:n}),i}event(e,t,n,r){if(e.state!==`running`)return;let i=this.clock();e.events.push({at:new Date(i).toISOString(),elapsed_ms:Math.max(0,i-Date.parse(e.started_at)),level:t,stage:e.stage,message:n,details:xd(r)}),t===`warning`&&e.warnings++,t===`error`&&e.errors++,e.events.length>bd&&(e.events.splice(1,1),e.omitted_events++),this.persist(e)}progress(e,t,n,r){e.state===`running`&&(t!==e.stage&&(this.event(e,`info`,`Этап завершён`,{stage:e.stage,duration_ms:Math.max(0,this.clock()-Date.parse(e.stage_started_at))}),e.stage=t,e.stage_started_at=new Date(this.clock()).toISOString()),this.event(e,`info`,n,r))}source(e,t){e.sha256=t,this.event(e,`info`,`Контрольная сумма исходного файла`,{sha256:t})}finish(e,t,n,r){e.state===`running`&&(this.event(e,t===`failed`?`error`:t===`completed`?`info`:`warning`,n,{stage_duration_ms:Math.max(0,this.clock()-Date.parse(e.stage_started_at)),result:r}),e.state=t,e.ended_at=new Date(this.clock()).toISOString(),this.persist(e))}persist(e){this.dirty.set(e.id,e),this.saving||(this.saving=!0,this.pending=this.pending.then(async()=>{for(;this.dirty.size;){let[e,t]=this.dirty.entries().next().value;this.dirty.delete(e);try{await this.storage.save(structuredClone(t))}catch(e){this.storageError=`Журнал не сохранён на диск браузера: `+String(e)+`. Скачайте JSON или TXT.`,this.changed()}}}).finally(()=>{this.saving=!1})),this.changed()}flush(){return this.pending}};function wd(e){return[`${e.filename} · ${e.operation} · ${e.state}`,`ID: ${e.id}`,`Размер: ${e.size_bytes} bytes`,`SHA-256: ${e.sha256||`не вычислен`}`,`Начало: ${e.started_at}`,`Конец: ${e.ended_at||`в процессе`}`,`Предупреждения: ${e.warnings}; ошибки: ${e.errors}; вытеснено событий: ${e.omitted_events}`,...e.events.map(e=>`${e.at} +${(e.elapsed_ms/1e3).toFixed(2)}s [${e.level}] ${e.stage}: ${e.message}${e.details===void 0?``:`
`+JSON.stringify(e.details,null,2)}`)].join(`
`)}function Td(){let e=new Promise((e,t)=>{let n=indexedDB.open(`uvyazka-processing-journal`,1);n.onupgradeneeded=()=>{n.result.createObjectStore(`runs`,{keyPath:`id`}).createIndex(`started_at`,`started_at`)},n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error),n.onblocked=()=>t(Error(`Хранилище заблокировано другой вкладкой`))});return{async load(){let t=await e;return new Promise((e,n)=>{let r=[],i=t.transaction(`runs`).objectStore(`runs`).index(`started_at`).openCursor(null,`prev`);i.onsuccess=()=>{let t=i.result;t&&r.length<30?(r.push(t.value),t.continue()):e(r)},i.onerror=()=>n(i.error)})},async save(t){let n=await e;await new Promise((e,r)=>{let i=n.transaction(`runs`,`readwrite`);i.objectStore(`runs`).put(t),i.oncomplete=()=>e(),i.onerror=()=>r(i.error),i.onabort=()=>r(i.error||Error(`Запись отменена`))})}}}var Ed={running:`В работе`,completed:`Завершено`,partial:`Открыто частично`,failed:`Ошибка`,cancelled:`Отменено`,interrupted:`Прервано`};function Dd(){let e=document.createElement(`dialog`);e.className=`processing-journal`,e.id=`processing-journal`,e.setAttribute(`aria-labelledby`,`processing-title`),e.innerHTML=`<div class="panel-head"><h2 id="processing-title">Журнал обработки</h2><button id="processing-close" aria-label="Закрыть журнал">✕</button></div>
<div class="journal-controls"><label>Запуск<select id="processing-runs"></select></label><label>События<select id="processing-filter"><option value="all">Все</option><option value="warning">Предупреждения и ошибки</option><option value="error">Ошибки</option></select></label><button id="processing-json">JSON</button><button id="processing-text">TXT</button></div>
<p id="processing-storage" class="journal-storage">История хранится в этом браузере. Показаны последние 30 запусков; геометрия не входит в журнал. Кеш IFC хранится отдельно.</p>
<div id="processing-summary" class="journal-summary" aria-live="polite"></div><div id="processing-events" class="journal-events" role="log" aria-label="События обработки"></div>`,document.body.append(e);let t=t=>e.querySelector(`#`+t),n=t(`processing-runs`),r=t(`processing-filter`),i=``,a=crypto.randomUUID(),o=``;try{a=sessionStorage.getItem(`uvyazka-journal-owner`)||a,sessionStorage.setItem(`uvyazka-journal-owner`,a)}catch{o=`Хранилище сессии недоступно: восстановление прерванных запусков ограничено.`}let s;try{s=Td()}catch(e){s={load:async()=>[],save:async()=>{throw e}}}let c=new Cd(s,a,()=>{e.open&&d()}),l=()=>c.runs.find(e=>e.id===i)||c.runs[0];function u(e){let n=t(`processing-summary`);if(n.replaceChildren(),!e){n.textContent=`Загрузите модель — здесь появятся этапы, время и результат.`;return}let r=e.ended_at?Date.parse(e.ended_at):Date.now(),i=document.createElement(`strong`);i.dataset.state=e.state,i.textContent=Ed[e.state]+(e.warnings?` · предупреждений: ${e.warnings}`:``);let a=document.createElement(`span`);a.textContent=`${e.stage} · всего ${((r-Date.parse(e.started_at))/1e3).toFixed(1)} с · этап ${((r-Date.parse(e.stage_started_at))/1e3).toFixed(1)} с`;let o=document.createElement(`small`);if(o.textContent=`${(e.size_bytes/1024**2).toFixed(1)} MiB · ${e.sha256?`SHA-256 `+e.sha256:`SHA-256 ещё не вычислен`}`,n.append(i,a,o),e.state===`running`){let e=document.createElement(`small`);e.textContent=`Показывается прошедшее время. Это не оценка процента готовности и не подтверждение, что worker отвечает.`,n.append(e)}if(e.omitted_events){let t=document.createElement(`small`);t.textContent=`Вытеснено старых событий: ${e.omitted_events}. Сохранены первое и последние 999 событий.`,n.append(t)}}function d(){let e=l();i=e?.id||``,n.replaceChildren(...c.runs.slice(0,30).map(e=>{let t=document.createElement(`option`);return t.value=e.id,t.textContent=`${new Date(e.started_at).toLocaleString()} · ${e.filename} · ${Ed[e.state]}`,t})),n.value=i,t(`processing-storage`).textContent=c.storageError||o||`История хранится в этом браузере. Показаны последние 30 запусков; геометрия не входит в журнал. Кеш IFC хранится отдельно.`,t(`processing-storage`).classList.toggle(`journal-warning`,!!c.storageError||!!o),u(e);let a=t(`processing-events`),s=a.scrollHeight-a.scrollTop-a.clientHeight<50;a.replaceChildren();let d=(e?.events||[]).filter(e=>r.value===`all`||r.value===`warning`&&e.level!==`info`||r.value===`error`&&e.level===`error`);for(let e of d){let t=document.createElement(`article`);t.className=`journal-event`,t.dataset.level=e.level;let n=document.createElement(`time`);n.dateTime=e.at,n.textContent=new Date(e.at).toLocaleTimeString(),n.title=e.at;let r=document.createElement(`span`);r.className=`journal-elapsed`,r.textContent=`+${(e.elapsed_ms/1e3).toFixed(1)} с`;let i=document.createElement(`div`),o=document.createElement(`small`),s=document.createElement(`p`);if(o.textContent=e.stage+` · `+{info:`Информация`,warning:`Предупреждение`,error:`Ошибка`}[e.level],s.textContent=e.message,i.append(o,s),e.details!==void 0){let t=document.createElement(`details`),n=document.createElement(`summary`),r=document.createElement(`pre`);n.textContent=`Подробности`,r.textContent=JSON.stringify(e.details,null,2),t.append(n,r),i.append(t)}t.append(n,r,i),a.append(t)}d.length||(a.textContent=e?`Событий по этому фильтру нет.`:`Журнал пока пуст.`),s&&(a.scrollTop=a.scrollHeight);for(let n of[`processing-json`,`processing-text`])t(n).disabled=!e}let f=c.restore(),p=()=>{d(),e.open||e.showModal()};t(`processing-close`).onclick=()=>e.close(),n.onchange=()=>{i=n.value,d()},r.onchange=d;for(let[e,n]of[[`processing-json`,!0],[`processing-text`,!1]])t(e).onclick=()=>{let e=l();if(!e)return;let t=new Blob([n?JSON.stringify({schema_version:1,run:e},null,2):wd(e)],{type:n?`application/json`:`text/plain;charset=utf-8`}),r=URL.createObjectURL(t),i=document.createElement(`a`);i.href=r,i.download=`uvyazka-${e.id}.${n?`json`:`txt`}`,i.click(),setTimeout(()=>URL.revokeObjectURL(r),1e3)};let m=setInterval(()=>{e.open&&u(l())},1e3);return addEventListener(`pagehide`,()=>clearInterval(m)),{journal:c,ready:f,open:p,select:t=>{i=t.id,e.open&&d()}}}function Od(e){return!!e?.records.some(e=>!!e.graph?.objects.length)}function kd(e){let t=/native record framing is unvalidated for Revit (\d{4})/.exec(e)?.[1];return t?`Чтение записей RVT ${t} текущим декодером не поддерживается.`:e}function Ad(e){let t=document.createElement(`section`);t.className=`panel browser-import`,t.innerHTML=`
<h2>Открыть файл</h2>
<p>Файл остаётся на вашем устройстве. Для RVT и IFC прежний порог размера снят; большие модели требуют больше памяти. DWG/DXF до 64 MiB. Чтение RVT экспериментальное; Revit и агент не нужны.</p>
<div class="browser-actions"><label>DWG / RVT / IFC / NWD<input id="browser-file" type="file" accept=".dwg,.dxf,.rvt,.ifc,.nwd"></label><button id="browser-cancel" disabled>Отменить</button><button id="browser-demo">Учебный пример</button><button id="browser-log">Журнал обработки</button><button id="browser-document">Виды и таблицы</button></div>
<label class="check"><input id="browser-append" type="checkbox">Добавить IFC / RVT / NWD к открытой сцене</label><button id="browser-clear-cache">Очистить кеш IFC</button>
<p id="browser-status" role="status" aria-live="polite">Выберите файл или изучите готовый пример ниже.</p>
<details><summary>Память и большие модели</summary><label>Бюджет IFC-декодера<select id="browser-memory"><option value="512">512 MiB</option><option value="1024" selected>1 GiB</option><option value="2048">2 GiB</option></select></label><p>Это бюджет IFC-движка, а не всей вкладки. RVT, промежуточный IFC и 3D требуют дополнительной памяти. Технический предел RVT-читателя — 2 GiB входного файла; успешное чтение такого размера не гарантируется.</p></details>
<div class="browser-actions simulation-only"><label>Ресурсы<select id="browser-variant"><option value="base">Базовые</option><option value="reinforced">Усиленные</option></select></label><label>Доступность ресурсов<select id="browser-capacity"><option value="1">1×</option><option value="2">2×</option><option value="3">3×</option><option value="4">4×</option></select></label><label>Выдержка бетона, суток<input id="browser-curing" type="number" min="1" max="365" value="28"></label><button id="browser-plan" disabled>Рассчитать сценарий</button></div>
<p class="simulation-only">Работы, технология, выработка и связи — предварительные допущения IFCCS. Стадии RVT в браузере пока не читаются; существующие и демонтируемые элементы автоматически не исключаются.</p>
<div class="browser-actions"><a id="browser-ifc" hidden>Скачать IFC</a><a id="browser-report" hidden>Диагностика JSON</a></div><details id="browser-diagnostics" hidden><summary>Покрытие и вопросы</summary><pre></pre></details>`,document.getElementById(`import-host`).append(t);let n=e=>t.querySelector(`#`+e),r=Dd(),i=r.journal;n(`browser-clear-cache`).onclick=async()=>{let e;try{e=await yd(),await e.clear(),v(`Кеш IFC очищен. При следующем открытии файл будет прочитан заново.`)}catch(e){v(`Кеш не очищен: `+String(e))}finally{e?.close()}},n(`browser-log`).onclick=r.open,n(`browser-document`).onclick=e.openDocument;let a=document.createElement(`button`);a.id=`open-import-log`,a.textContent=`Журнал`,a.onclick=r.open,document.getElementById(`status-details`).after(a);let o=new URL(`.`,location.href).href,s=0,c=null,l=null,u=null,d=null,f=null,p=new Map,m=hd(()=>n(`browser-cancel`).click(),r.open),h=(e,t,n,r)=>{i.finish(e,t,n,r),e===f&&m.finish(t,n)},g=(e,t,n,r)=>{i.progress(e,t,n,r),e===f&&m.update(t,n)},_=setInterval(()=>{f?.state===`running`&&(c?.postMessage({kind:`ping`,job:s}),l?.postMessage({kind:`ping`,job:s}))},2e3);addEventListener(`pagehide`,()=>clearInterval(_));let v=e=>{n(`browser-status`).textContent=e;let t=document.getElementById(`workspace-status`);t.textContent=e,t.title=e},y=e=>{document.body.classList.toggle(`is-busy`,e),n(`browser-cancel`).disabled=!e,n(`browser-plan`).disabled=e||!u||u.source.format===`nwd`;for(let t of[`open-file`,`empty-add-model`,`replace-model`]){let n=document.getElementById(t);n&&(n.disabled=e)}},b=(e=`Обработка отменена: выбран другой файл или режим.`,t=!1)=>{f?.state===`running`&&h(f,`cancelled`,e),s++,c?.terminate(),c=null,t||(l?.terminate(),l=null),y(!1)},x=(e,t)=>{u=d,f&&h(f,`failed`,e,t),b(),v(e+` · подробности в журнале`)},S=(e,t,r)=>{let i=p.get(e);i&&URL.revokeObjectURL(i);let a=URL.createObjectURL(t);p.set(e,a);let o=n(e);o.href=a,o.download=r,o.hidden=!1},C=e=>{n(`browser-diagnostics`).hidden=!1,t.querySelector(`pre`).textContent=JSON.stringify(e,null,2),S(`browser-report`,new Blob([JSON.stringify(e,null,2)],{type:`application/json`}),`uvyazka-diagnostics.json`)};n(`browser-cancel`).onclick=()=>{u=d,e.cancelDrawing(),b(`Отменено пользователем.`),v(`Обработка отменена. События сохранены в журнале.`)},n(`browser-demo`).onclick=async()=>{b(`Переход к учебному примеру.`),await i.flush(),location.href=o};let w=async(a,l)=>{document.querySelector(`#file-dialog`).close();let _=/\.nwd$/i.test(a.name)?await ld(a.name):null;if(/\.nwd$/i.test(a.name)&&!_)return;b();let w=s;if(await r.ready,w!==s)return;f=i.begin(`import`,a.name,a.size);let T=f;r.select(f),m.begin(a.name,a.size),d=u;let E=Sd(a.name,a.size);if(E.error){x(E.error);return}E.warning&&i.event(f,`warning`,E.warning);let D=Number(n(`browser-memory`).value);i.event(f,`info`,`Настройки обработки`,{ifc_memory_budget_mib:D,rvt_reader_max_bytes:2*1024**3,processing:`browser-local`});let O=(l??n(`browser-append`).checked)&&!/\.(dwg|dxf)$/i.test(a.name);d=O?u:null,u=null,e.reset(O),y(!0),v(`Чтение `+a.name);for(let[e,t]of p)URL.revokeObjectURL(t),n(e).hidden=!0;p.clear(),n(`browser-diagnostics`).hidden=!0;try{if(/\.(dwg|dxf)$/i.test(a.name)){g(f,`CAD`,`Чтение чертежа`),await e.drawing(a),w===s&&(document.querySelector(`#file-dialog`).close(),h(T,`completed`,`Чертёж открыт.`),v(a.name+` открыт. Масштаб и слои — над чертежом.`),y(!1));return}g(f,`Чтение файла`,`Загрузка байтов с локального диска`);let r=await a.arrayBuffer();if(w!==s)return;c=new Worker(new URL(`/uvyazka/assets/import.worker-L0dE-A6S.js`,``+import.meta.url),{type:`module`}),c.onerror=e=>{w===s&&x(`Worker остановился: `+(e.message||`причина недоступна; возможна нехватка памяти`),{filename:e.filename,line:e.lineno})},c.onmessageerror=()=>{w===s&&x(`Не удалось получить данные от worker.`)},c.onmessage=async({data:r})=>{if(r.job===s&&(m.reply(),r.kind!==`pong`)){if(r.kind===`document`)e.document(r.document),i.event(T,r.document.status===`partial`||r.document.schedule_data?.status===`partial`?`warning`:`info`,Od(r.document)?`Каталог видов и таблиц прочитан`:`Читаемые записи каталога не получены`,{cached:!!r.cached,records:r.document.records.length,status:r.document.status,error:r.document.error,clipped_records:r.document.clipped_records,schedule_parameters:r.document.schedule_data?{records:r.document.schedule_data.records.length,status:r.document.schedule_data.status,error:r.document.schedule_data.error}:void 0});else if(r.kind===`document-cache-error`)i.event(T,`warning`,`Кеш каталога недоступен; прочитанные данные можно скачать JSON`,{message:r.message});else if(r.kind===`document-error`)e.document(null,`Каталог RVT не прочитан: `+r.message),i.event(T,`warning`,`Не удалось прочитать каталог RVT; геометрия обрабатывается отдельно`,{message:r.message});else if(r.kind===`source`)i.source(T,r.sha256);else if(r.kind===`progress`)r.details?.warning&&i.event(T,`warning`,r.text,r.details),g(T,r.stage||`Импорт`,r.text,r.details),v(r.text);else if(r.kind===`error`)C({filename:a.name,sha256:T.sha256,outcome:`failed`,message:r.message,...r.details}),!O&&/\.rvt$/i.test(a.name)&&e.noGeometry(a.name,r.message),x(/\.rvt$/i.test(a.name)?r.message:`Не удалось открыть: `+r.message,r.details);else if(r.kind===`partial`)C({filename:a.name,sha256:T.sha256,outcome:`partial`,message:r.message,...r.details}),h(T,`partial`,r.message,r.details),u=d,b(),v(r.message),O||e.noGeometry(a.name,r.message),document.querySelector(`#file-dialog`).close(),e.openDocument();else if(r.kind===`imported`){c?.terminate(),c=null;let o=r.model.statistics,l={source:r.model.source,statistics:o,systems:r.model.systems,diagnostics:r.model.diagnostics,conversion:r.conversion};i.event(T,`info`,`Результат извлечения`,{source:r.model.source,statistics:o,cached:!!r.cached}),(r.model.diagnostics.length||o.geometry_errors||r.conversion?.diagnostics?.warnings?.length||r.conversion?.diagnostics?.unsupported_features?.length||r.conversion?.saved_mesh_error)&&i.event(T,`warning`,`Есть пропуски геометрии или предупреждения декодера. Проверьте покрытие.`,l),n(`browser-diagnostics`).hidden=!1,t.querySelector(`pre`).textContent=JSON.stringify(l,null,2),S(`browser-report`,new Blob([JSON.stringify(l,null,2)],{type:`application/json`}),`uvyazka-diagnostics.json`),r.convertedIfc&&S(`browser-ifc`,new Blob([r.convertedIfc],{type:`application/x-step`}),a.name.replace(/\.rvt$/i,`.ifc`)),g(T,`Отображение`,`Создание 3D-сцены`),v(`Отображение модели`);try{let t=await e.model(r.model,r.binary,O);if(w!==s)return;u=t,d=null}catch(e){w===s&&x(`Не удалось отобразить модель: `+String(e));return}let f=`${a.name}: ${r.model.source.format===`nwd`?r.model.elements.length+` геометрических экземпляров`:o.physical_elements+` физических элементов`}, ${o.meshes} сеток, ${o.geometry_errors} без геометрии.`;h(T,`completed`,f),v(f+(r.model.source.format===`nwd`?` Семантика BIM и исходные единицы не прочитаны.`:` Можно рассчитать сценарий.`)),y(!1)}}},c.postMessage({job:w,buffer:r,filename:a.name,base:o,memoryMiB:D,nwdUnit:_},[r])}catch(e){w===s&&x(String(e),{stack:e instanceof Error?e.stack:void 0})}};return n(`browser-file`).onchange=()=>{let e=n(`browser-file`),t=e.files?.[0];e.value=``,t&&w(t)},n(`browser-plan`).onclick=async()=>{if(!u)return;if(u.elements.some(e=>e.semantic_kind===`geometry_fragment`)){v(`Сценарий для геометрических фрагментов NWD не рассчитывается: семантика объектов не прочитана.`);return}let t=Number(n(`browser-curing`).value);if(!Number.isInteger(t)||t<1||t>365){v(`Выдержка бетона: целое число от 1 до 365 суток`);return}await r.ready,b(`Запущен новый расчёт.`,!0);let a=s;d=u,f=i.begin(`simulation`,u.source.filename,u.source.size_bytes);let c=f;r.select(f),i.source(f,u.source.sha256),document.querySelector(`#file-dialog`).close(),m.begin(u.source.filename,u.source.size_bytes,!0),y(!0),v(`Подготовка расчёта`),m.update(`Подготовка`,`Загрузка расчётного движка`),l??=new Worker(new URL(`/uvyazka/assets/planner.worker-CGYnfsgD.js`,``+import.meta.url),{type:`module`}),l.onerror=e=>{a===s&&x(`Ошибка расчёта: `+e.message)},l.onmessage=async({data:t})=>{if(t.job===s&&(m.reply(),t.kind!==`pong`)){if(t.kind===`progress`)g(c,/Загрузка Python/.test(t.text)?`Подготовка`:`Расчёт`,t.text),v(t.text);else if(t.kind===`error`)x(`Не удалось рассчитать: `+t.message);else if(t.kind===`planned`){try{if(g(c,`Отображение`,`Подготовка результата расчёта`),await e.run(t.run),a!==s)return;let n=`Рассчитано: ${t.run.scenario.operations.length} работ, ${t.run.duration} минут. Вне графика: ${t.run.scenario.unplanned_element_ids.length} элементов.`;t.run.scenario.unplanned_element_ids.length&&i.event(c,`warning`,`Часть элементов осталась вне графика`,{element_ids:t.run.scenario.unplanned_element_ids}),h(c,`completed`,n),v(n)}catch(e){a===s&&x(String(e))}a===s&&y(!1)}}};let p={variant:n(`browser-variant`).value,curingDays:t,capacityFactor:Number(n(`browser-capacity`).value)};i.event(f,`info`,`Параметры расчёта`,p),l.postMessage({job:a,base:o,model:u,...p})},document.addEventListener(`scene-model-changed`,(e=>{b(`Изменён состав или размещение сцены.`),u=e.detail,y(!1)})),addEventListener(`pagehide`,()=>{f?.state===`running`&&h(f,`interrupted`,`Вкладка закрыта или перезагружена до завершения.`),b();for(let e of p.values())URL.revokeObjectURL(e)}),{openFile:w,stop:b}}function jd(e,t){let n=new Map;for(let t of e.scenario.operations){let e=n.get(t.kind)??[];e.push(t),n.set(t.kind,e)}let r=[];for(let[i,a]of n){let n=a.length>8?[a[0],a[Math.floor(a.length/2)]]:[a[0]];for(let a of n){let n=e.operation_states[a.id],o=e.scenario.temporary_assets?.find(e=>e.install_id===a.id||e.check_id===a.id||e.remove_id===a.id),s=a.target_ids.length?a.target_ids:o?.unit_id?e.scenario.units.find(e=>e.id===o.unit_id)?.target_ids??[]:[],c=t.elements.filter(e=>s.includes(e.id)&&e.mesh),l=i.startsWith(`mep_`)||[`duct_install`,`pipe_install`,`cable_install`,`commissioning`].includes(i);r.push({title:a.name+(i===`curing`?` · календарное ожидание сжато`:``),kind:i,start:n.start+a.duration*.18,end:n.start+a.duration*.82,operationId:a.id,targetIds:s,cut:l&&c.length?Math.max(...c.map(e=>e.mesh.bbox_max_m[2]))-t.coordinate_system.render_origin_m[2]+.5:void 0})}}r.sort((e,t)=>e.start-t.start||e.end-t.end);for(let e=0;e<r.length-1;e++)r[e].end=Math.min(r[e].end,r[e+1].start);r.push({title:`Полная сводная модель · включая объекты вне графика`,kind:`reference`,start:e.duration,end:e.duration,targetIds:[],reference:!0});let i=new Set(t.elements.filter(e=>e.hierarchy.includes(`IfcFurnishingElement`)).map(e=>e.storey_id)),a=t.storeys.filter(e=>i.has(e.id)&&e.elevation_m!==null).sort((e,t)=>t.elevation_m-e.elevation_m);for(let n of a.slice(0,3))r.push({title:`Интерьер · `+n.name+` · исходные элементы`,kind:`interior`,start:e.duration,end:e.duration,targetIds:[],reference:!0,cut:n.elevation_m-t.coordinate_system.render_origin_m[2]+1.25});return r}var Md=(e,t)=>{let n=document.createElement(e);return t!==void 0&&(n.textContent=t),n};function Nd(e,t,n,r){let i=Md(`label`,`Группировка `),a=Md(`select`);a.setAttribute(`aria-label`,`Группировка ведомости`);for(let[e,t]of[[`schedule`,`По ключам из RVT (требует сверки)`],[`instances`,`Каждый экземпляр`],[`type`,`По ID типа`]]){let n=Md(`option`,t);n.value=e,a.append(n)}a.value=n.grouping,a.onchange=()=>{n.grouping=a.value,r()},i.append(a),e.append(i);let o=Md(`details`);o.id=`rvt-review-rules`,o.append(Md(`summary`,`Фильтры сверки и суммы (${n.filters.length})`)),o.append(Md(`p`,`Это ваши правила сверки, отдельно от фильтров RVT. Условия соединены И. Текст сравнивается с учётом регистра. Для ширины и высоты можно вводить миллиметры; правило сохраняет порог в исходных футах. Неизвестные значения не отбрасываются.`));let s=Md(`select`);s.setAttribute(`aria-label`,`Поле фильтра`);for(let e of t.all_columns){if(e.id===null)continue;let t=Md(`option`,`${e.properties.m_columnHeading??`Поле`} · ID ${e.id}${e.properties.m_hidden?` · скрытое`:``}`);t.value=e.id,s.append(t)}o.append(s);let c=Md(`select`);c.setAttribute(`aria-label`,`Условие фильтра`);for(let[e,t]of[[`equal`,`Равно`],[`not_equal`,`Не равно`],[`greater`,`Больше`],[`greater_equal`,`Не меньше`],[`less`,`Меньше`],[`less_equal`,`Не больше`],[`contains`,`Содержит`],[`not_contains`,`Не содержит`],[`begins`,`Начинается с`],[`ends`,`Заканчивается на`],[`has_value`,`Значение прочитано`]]){let n=Md(`option`,t);n.value=e,c.append(n)}o.append(c);let l=Md(`select`);l.setAttribute(`aria-label`,`Тип порога`);for(let[e,t]of[[`text`,`Текст`],[`number`,`Число / ID (без единиц)`],[`mm`,`Миллиметры → исходные футы`],[`ft`,`Число в футах`],[`native`,`Число в исходных единицах`]]){let n=Md(`option`,t);n.value=e,l.append(n)}o.append(l);let u=Md(`input`);u.type=`text`,u.placeholder=`Порог`,u.setAttribute(`aria-label`,`Значение порога`),o.append(u);let d=Md(`p`);d.setAttribute(`role`,`status`),o.append(d);let f=Md(`button`,`Добавить фильтр`);f.disabled=!s.options.length,f.onclick=()=>{let t={field_id:s.value,operator:c.value};if(t.operator!==`has_value`){if(l.value===`text`)t.value=u.value;else{let e=u.value.trim().replace(`,`,`.`);if(!e||!Number.isFinite(Number(e))){d.textContent=`Введите конечное число; пустое значение не равно нулю.`;return}t.value=l.value===`mm`?Number(e)/304.8:Number(e),l.value!==`number`&&(t.unit=l.value===`mm`?`ft`:l.value)}}n.filters.push(t),r(),e.querySelector(`#rvt-review-rules`).open=!0},o.append(f),n.filters.forEach((e,t)=>{let i=Md(`p`,`Поле ${e.field_id}: ${e.operator} ${e.value??``} ${e.unit??``} `),a=Md(`button`,`Убрать фильтр ${t+1}`);a.onclick=()=>{n.filters.splice(t,1),r()},i.append(a),o.append(i)});let p=Md(`button`,`Добавить контрольную сумму выбранного поля`);if(p.disabled=!s.options.length,p.onclick=()=>{n.sum_fields.includes(s.value)||n.sum_fields.push(s.value),r()},o.append(p),e.append(o),t.totals.length){let i=Md(`details`);i.append(Md(`summary`,`Контрольные суммы прошедших условия экземпляров`)),i.append(Md(`p`,`Суммы считаются до группировки. Исключённые и неопределённые строки не входят; это не итоги Revit.`));for(let e of t.totals){let t=Md(`p`,`Поле ${e.field_id}: ${D(e.cell)} · ${e.instance_count} экз. `),a=Md(`details`);a.append(Md(`summary`,`Источники суммы`),Md(`pre`,JSON.stringify(e,null,2)));let o=Md(`button`,`Убрать сумму ${e.field_id}`);o.onclick=()=>{n.sum_fields=n.sum_fields.filter(t=>t!==e.field_id),r()},t.append(o),i.append(t,a)}e.append(i)}let m=Md(`details`);m.append(Md(`summary`,`Журнал отбора и исходные правила`));let h=Md(`pre`);m.append(h),m.ontoggle=()=>{m.open&&(h.textContent=JSON.stringify({rules:t.rule_audit,selection:t.selection.slice(0,100),display_limit:100,total:t.selection.length},null,2))},e.append(m)}var Pd=new Set([`equal`,`not_equal`,`greater`,`greater_equal`,`less`,`less_equal`,`contains`,`not_contains`,`begins`,`ends`,`has_value`]);function Fd(e,t,n){if(e===null)return{grouping:`schedule`,filters:[],sum_fields:[]};let r=JSON.parse(e),i=r.settings;if(r.version!==1||r.source_sha256!==t||r.schedule_id!==n||!i||![`schedule`,`instances`,`type`].includes(i.grouping)||!Array.isArray(i.filters)||!Array.isArray(i.sum_fields))throw Error(`Настройки не соответствуют модели или версии формата.`);if(i.filters.some(e=>!e||typeof e.field_id!=`string`||!Pd.has(e.operator)||e.operator!==`has_value`&&!(typeof e.value==`string`||typeof e.value==`number`&&Number.isFinite(e.value))||e.unit!==void 0&&![`ft`,`native`].includes(e.unit))||i.sum_fields.some(e=>typeof e!=`string`))throw Error(`Повреждены правила сверки.`);return i}function Id(e,t,n){return JSON.stringify({version:1,source_sha256:t,schedule_id:n,updated_at:new Date().toISOString(),settings:e})}var Ld=(e,t)=>{let n=document.createElement(e);return t!==void 0&&(n.textContent=t),n};function Rd(e,t,n,r){let i=Ld(`details`);i.id=`rvt-preview`,i.append(Ld(`summary`,`Сверочная ведомость по элементам`)),e.append(i),i.append(Ld(`p`,`Строки строятся по параметрам экземпляров и типов с совпадением ID категории. Длины из подтверждённых слотов показаны в мм; CSV сохраняет исходные значения и единицы. Это предварительная выборка, а не пересчитанная спецификация Revit.`));let a=Ld(`button`,`Построить сверочную ведомость`);i.append(a),a.disabled=!n.schedule_data,n.schedule_data||i.append(Ld(`p`,`Параметры ещё не прочитаны или недоступны.`));let o=Ld(`div`);i.append(o);let s=n.source?.sha256??``,c=String(t.identity.element_id),l=`uvyazka-schedule-review-v1:${s}:${c}`,u={grouping:`schedule`,filters:[],sum_fields:[]},d=``,f=0,p=0;try{s&&(u=Fd(localStorage.getItem(l),s,c))}catch(e){d=`Не удалось восстановить настройки: ${String(e)}`}let m=()=>{let e=E(t,n,u);o.replaceChildren(),o.append(Ld(`h3`,`Прошли условия: ${e.passed_instances} · неизвестно: ${e.unknown_instances} · исключено: ${e.excluded_instances}`)),o.append(Ld(`p`,`Экземпляров: ${e.instance_count} · строк: ${e.rows.length}. Полнота модели не подтверждена.`));let i=Ld(`details`);i.className=`rvt-notice`,i.append(Ld(`summary`,`Частичная ведомость · ограничения (${e.issues.length})`)),i.open=e.unknown_instances>0||!e.rows.length;for(let t of e.issues)i.append(Ld(`p`,t));o.append(i),o.append(Ld(`p`,d||`Настройки сохраняются локально для этой модели и таблицы; синхронизации с базой проекта пока нет.`)),Nd(o,e,u,()=>{f=0;try{if(!s)throw Error(`Нет SHA-256 модели`);localStorage.setItem(l,Id(u,s,c)),d=``}catch(e){d=`Настройки действуют до закрытия окна; сохранение не удалось: ${String(e)}`}m()});let a=Ld(`button`,`Ведомость CSV`),h=Ld(`button`,`Ведомость JSON`);a.disabled=!e.rows.length,h.disabled=!n.schedule_data,a.onclick=()=>r(O(e),`text/csv`,`rvt-preview-${t.identity.element_id}.csv`),h.onclick=()=>r(JSON.stringify(e,null,2),`application/json`,`rvt-preview-${t.identity.element_id}.json`),o.append(a,h);let g=Ld(`div`);g.className=`rvt-grid-controls`,o.append(g),g.append(Ld(`small`,`Строки ${e.rows.length?f+1:0}–${Math.min(f+50,e.rows.length)} из ${e.rows.length}; поля ${e.columns.length?p+1:0}–${Math.min(p+8,e.columns.length)} из ${e.columns.length}`));for(let[t,n,r]of[[`← Строки`,f===0,()=>{f=Math.max(0,f-50),m()}],[`Строки →`,f+50>=e.rows.length,()=>{f+=50,m()}],[`← Поля`,p===0,()=>{p=Math.max(0,p-8),m()}],[`Поля →`,p+8>=e.columns.length,()=>{p+=8,m()}]]){let e=Ld(`button`,t);e.disabled=n,e.onclick=r,g.append(e)}let _=Ld(`div`);_.className=`rvt-table-scroll`;let v=Ld(`table`),y=Ld(`thead`),b=Ld(`tr`),x=Ld(`tbody`);b.append(Ld(`th`,`Экземпляры / тип`),Ld(`th`,`Отбор`));let S=e.columns.slice(p,p+8);for(let e of S)b.append(Ld(`th`,String(e.properties.m_columnHeading??e.id??e.order)));y.append(b);let C=Ld(`details`),w=Ld(`summary`,`Источник выбранного значения`),T=Ld(`pre`);C.append(w,T);for(let t of e.rows.slice(f,f+50)){let n=Ld(`tr`),r=Ld(`td`,`${t.element_ids.length===1?`#`+t.element_ids[0]:t.element_ids.length+` экз.`} / тип #${t.type_id??`разные / не прочитан`}`);n.append(r,Ld(`td`,t.membership===`pass`?`Прошёл условия`:`Неизвестно`)),t.cells.slice(p,p+8).forEach((r,i)=>{let a=Ld(`td`),o=Ld(`button`,D(r));o.className=`rvt-cell`,o.dataset.state=r.state,o.setAttribute(`aria-label`,`${S[i].properties.m_columnHeading??S[i].id}; ${t.element_ids.length===1?`экземпляр #`+t.element_ids[0]:`тип #`+t.type_id+`, `+t.element_ids.length+` экз.`}: ${D(r)}`),o.onclick=()=>{w.textContent=`Источник: ${S[i].properties.m_columnHeading??S[i].id}`,T.textContent=JSON.stringify({source:e.source,schedule_id:e.schedule_id,field:S[i],element_ids:t.element_ids,type_id:t.type_id,cell:r},null,2),C.open=!0},a.append(o),n.append(a)}),x.append(n)}v.append(y,x),_.append(v),o.append(_,C)};a.onclick=()=>{a.hidden=!0,m()}}var zd={all:`Всё содержимое`,views:`Планы и разрезы`,"3d":`3D-виды`,sheets:`Листы`,schedules:`Спецификации`,templates:`Шаблоны`,placements:`Размещения`,other:`Другие виды`},K=(e,t)=>{let n=document.createElement(e);return t!==void 0&&(n.textContent=t),n};function Bd(i,c,f={}){let p=K(`dialog`);p.id=`rvt-document`,p.className=`rvt-document`,p.setAttribute(`aria-labelledby`,`rvt-document-title`),p.innerHTML=`<div class="panel-head"><div><small>СОДЕРЖИМОЕ RVT</small><h2 id="rvt-document-title">Виды и таблицы</h2></div><button id="rvt-document-close" aria-label="Закрыть виды и таблицы">✕</button></div><p id="rvt-document-status" role="status"></p><div class="rvt-document-tools"><button id="rvt-whole">Вся прочитанная модель</button><button id="rvt-export">Скачать каталог JSON</button></div><div class="rvt-document-layout"><nav aria-label="Каталог RVT"><label>Раздел<select id="rvt-kind"></select></label><label>Поиск<input id="rvt-search" type="search" placeholder="Имя или ElementId"></label><div id="rvt-records"></div><button id="rvt-more" hidden>Показать ещё 100</button></nav><article id="rvt-record-detail"></article></div>`,document.body.append(p);let m=e=>p.querySelector(`#`+e),h=K(`button`,`Виды и таблицы`);h.id=`open-rvt-document`,h.onclick=()=>p.showModal(),document.getElementById(`reset-visibility`).after(h);let g=null,_=null,v=100,y=!1,b=``,x=0,S=K(`p`);S.id=`rvt-catalog-storage`,S.className=`rvt-notice`,m(`rvt-document-status`).after(S);let C=K(`select`),w=K(`button`,`Ещё снимки`),T=K(`button`,`Каталоги базы проекта`);C.setAttribute(`aria-label`,`Снимок каталога базы проекта`);let E=0;if(f.listCatalogs){let e=K(`div`);e.className=`project-catalog-picker`,e.append(T,C,w),S.after(e),C.hidden=!0,w.hidden=!0;let t=async e=>{if(e&&(E=0,C.replaceChildren(new Option(`Выберите снимок`,``))),E===null)return;T.disabled=!0,w.disabled=!0;let t=x;try{let e=await f.listCatalogs(E);if(t!==x)return;for(let t of e.items)C.add(new Option(`${t.source.filename||t.source.sha256.slice(0,12)} · ${t.record_count} записей · ${t.profile} · ${t.created_at}`,t.extraction_id));E=e.next_offset,C.hidden=!1,w.hidden=E===null}catch(e){S.textContent=`База недоступна: `+String(e)}finally{T.disabled=!1,w.disabled=!1}};T.onclick=()=>void t(!0),w.onclick=()=>void t(!1),C.onchange=async()=>{if(C.value){C.disabled=!0;try{await f.loadCatalog?.(C.value)}catch(e){S.textContent=`Каталог не открыт: `+String(e)}finally{C.disabled=!1}}}}if(f.importCatalog){let e=K(`label`,`Импорт каталога JSON в проект`),t=K(`input`);t.type=`file`,t.accept=`.json,application/json`,e.className=`catalogue-import`,e.append(t),m(`rvt-whole`).after(e),t.onchange=async()=>{let e=t.files?.[0];if(t.value=``,!e)return;let n=f.context?.();t.disabled=!0;try{if(e.size>128*1024**2)throw Error(`Каталог больше 128 MiB`);let t=JSON.parse(await e.text());if(f.context?.()!==n)throw Error(`Проект сменился; повторите импорт в выбранном проекте`);await f.importCatalog(t)}catch(e){S.textContent=`НЕ сохранено в проект: `+String(e)}finally{t.disabled=!1}}}for(let[e,t]of Object.entries(zd))m(`rvt-kind`).add(new Option(t,e));m(`rvt-document-close`).onclick=()=>p.close(),m(`rvt-whole`).onclick=()=>{c(),p.close()};let D=(e,t,n)=>{b&&URL.revokeObjectURL(b),b=URL.createObjectURL(new Blob([e],{type:t}));let r=K(`a`);r.href=b,r.download=n,r.click()};m(`rvt-export`).onclick=()=>{g&&D(JSON.stringify(g,null,2),`application/json`,`uvyazka-rvt-document.json`)};function O(e,t,n){let r=K(`details`),i=K(`summary`,t),a=K(`pre`,JSON.stringify(n,null,2));r.append(i,a),e.append(r)}function k(e,t,n){let r=K(`div`),i=K(`table`),a=K(`thead`),o=K(`tr`),s=K(`tbody`);r.className=`rvt-table-scroll`,t.forEach(e=>o.append(K(`th`,e))),a.append(o);for(let e of n){let t=K(`tr`);e.forEach(e=>t.append(K(`td`,e==null?`Не прочитано`:typeof e==`object`?JSON.stringify(e):String(e)))),s.append(t)}i.append(a,s),r.append(i),e.append(r)}function A(c){_=c,j();let f=m(`rvt-record-detail`);f.replaceChildren();let h=e(c),v=r(c);f.append(K(`small`,`${zd[v]} · #${c.identity.element_id}`),K(`h2`,n(c))),f.append(K(`p`,c.graph?`Сохранённая запись прочитана`:`Данные записи недоступны`)),c.diagnostic&&f.append(K(`p`,c.diagnostic)),c.graph||f.append(K(`p`,`Граф этой записи не прочитан. Пустое содержимое не означает отсутствие данных в RVT.`));let b=K(`button`,`Запись JSON`);b.onclick=()=>D(JSON.stringify({source:g?.source,record:c},null,2),`application/json`,`rvt-${c.identity.element_id}.json`),f.append(b);let x=K(`button`,`Копировать запись`);if(x.dataset.copy=JSON.stringify({source:g?.source,record:c},null,2),f.append(x),c.kind===`schedule`){g&&Rd(f,c,g,D);let e=a(c),n=K(`p`,`Ниже — сохранённые ячейки RVT, без пересчёта. Сверочная ведомость выше строится отдельно; формулы, нативные фильтры и точное оформление Revit пока не воспроизводятся.`);n.className=`rvt-notice`,f.append(n);let r=K(`button`,`Ячейки CSV`);r.disabled=!e.cells.length,r.onclick=()=>D(l(c),`text/csv`,`rvt-schedule-${c.identity.element_id}.csv`),f.append(r);let i=K(`details`),o=K(`summary`,`Поля спецификации · ${e.columns.length}`);i.append(o),f.append(i),e.columns.length&&k(i,[`Порядок в RVT`,`ID`,`Заголовок`,`Скрыто`,`Параметр`],e.columns.map(e=>[e.order,e.id,e.properties.m_columnHeading,typeof e.properties.m_hidden==`boolean`?e.properties.m_hidden?`Да`:`Нет`:null,t(e.properties.m_paramElemId)]));for(let t of e.issues)f.append(K(`p`,t));f.append(K(`h3`,`Сохранённые ячейки · ${e.cells.length}`)),e.cells.length||f.append(K(`p`,`Сохранённых ячеек не получено. Это не пустая спецификация и не нулевые количества.`)),e.cells.length&&f.append(K(`p`,`Номера строк и колонок — исходные. «Пустая» — сохранён пустой текст; «Нет данных» — записи в этой позиции нет среди прочитанных. Нажмите ячейку для проверки источника. Объединение и оформление не реконструируются.`));for(let t of u(e.cells)){let e=K(`section`);e.className=`rvt-schedule-grid`,e.append(K(`h4`,`Секция ${JSON.stringify(t.section)??`неизвестна`}`)),f.append(e);let n=K(`div`);n.className=`rvt-grid-controls`;let r=K(`div`);r.className=`rvt-table-scroll`;let i=K(`details`),a=K(`summary`,`Источник выбранной ячейки`),o=K(`pre`,`Выберите ячейку таблицы.`);i.append(a,o),e.append(n,r,i);let s=0,l=0,u=()=>{n.replaceChildren(),n.append(K(`small`,`Строки ${t.rows.length?s+1:0}–${Math.min(s+50,t.rows.length)} из ${t.rows.length}; колонки ${t.columns.length?l+1:0}–${Math.min(l+12,t.columns.length)} из ${t.columns.length}`));for(let[e,r,i]of[[`← Строки`,s===0,()=>{s=Math.max(0,s-50),p()}],[`Строки →`,s+50>=t.rows.length,()=>{s+=50,p()}],[`← Колонки`,l===0,()=>{l=Math.max(0,l-12),p()}],[`Колонки →`,l+12>=t.columns.length,()=>{l+=12,p()}]]){let t=K(`button`,e);t.disabled=r,t.onclick=i,n.append(t)}},p=()=>{u(),r.replaceChildren();let e=K(`table`),n=K(`thead`),f=K(`tr`),p=K(`tbody`);f.append(K(`th`,`Строка / колонка`));let m=t.columns.slice(l,l+12);for(let e of m)f.append(K(`th`,String(e)));n.append(f);for(let e of t.rows.slice(s,s+50)){let n=K(`tr`),r=K(`th`,String(e));r.scope=`row`,n.append(r);for(let r of m){let s=t.cells.get(`${e}:${r}`)??[],l=d(s),u=K(`td`),f=l===`text`?s[0].text:{missing:`Нет данных`,conflict:`Конфликт: ${s.length} записей`,unreadable:`Текст не прочитан`,empty:`Пустая`}[l],p=K(`button`,f);p.className=`rvt-cell`,p.dataset.state=l,p.setAttribute(`aria-label`,`Строка ${e}, колонка ${r}: ${f}`),p.onclick=()=>{a.textContent=`Источник: строка ${e}, колонка ${r}`,o.textContent=JSON.stringify({source:g?.source,element_id:c.identity.element_id,section:t.section,row:e,column:r,status:l,cells:s},null,2),i.open=!0},u.append(p),n.append(u)}p.append(n)}e.append(n,p),r.append(e)};p(),t.unpositioned.length&&(e.append(K(`p`,`${t.unpositioned.length} ячеек без достоверных координат — сохранены отдельно.`)),O(e,`Ячейки с неизвестным положением`,t.unpositioned))}O(f,`Определение, фильтры и сортировка (исходные поля)`,{definition:e.schema,resolved_rules:e.rules}),O(f,`Поля и ячейки с адресами источников`,e)}else if(v===`sheets`){f.append(K(`p`,`Номер листа: ${h.m_sheetNumber}`),K(`p`,`Состав листа по сохранённым размещениям. Рамка, аннотации и графика листа пока не отрисовываются.`));let r=s(c,g?.records??[]);f.append(K(`h3`,`Размещения · ${r.length}`)),r.length||f.append(K(`p`,`Явные связи размещений не найдены; полнота листа неизвестна.`));for(let i of r){let r=e(i),a=t(r.m_dbViewId??r.m_scheduleId??r.m_internalScheduleId),o=g?.records.find(e=>String(e.identity.element_id)===a),s=K(`button`,o?`${n(o)} · размещение #${i.identity.element_id}`:`Размещение #${i.identity.element_id} · вид ${a??`не прочитан`}`);s.onclick=()=>A(o??i),f.append(s)}}else{if(o(c)){let e=K(`button`,`Показать ориентацию на модели`);e.disabled=!y,e.onclick=()=>{i(c),p.close()},f.append(e),f.append(K(`p`,`Реконструкция ориентации по направлениям вида. Обрезка, масштаб листа, фильтры видимости, шаблон и аннотации не применяются.`))}let e={m_viewName:`Имя`,m_viewDescription:`Описание`,m_scale:`Масштаб (исходный коэффициент)`,m_isTemplate:`Шаблон`,m_viewTemplateId:`ID шаблона`,m_origin:`Начало координат (исходные единицы)`,m_viewDir:`Направление взгляда`,m_horzDir:`Горизонталь вида`,m_vertDir:`Вертикаль вида`,m_cutPlaneElev:`Высота сечения (исходные единицы)`,m_topClipElev:`Верхняя граница`,m_bottomClipElev:`Нижняя граница`,m_dbViewId:`ID вида`,m_dbDrawingId:`ID чертежа`,m_scheduleId:`ID спецификации`,m_sheetNumber:`Номер листа`};k(f,[`Свойство`,`Сохранённое значение`],Object.entries(h).filter(([e])=>/^m_(viewName|viewDescription|scale|isTemplate|viewTemplateId|origin|viewDir|horzDir|vertDir|cutPlaneElev|topClipElev|bottomClipElev|dbViewId|dbDrawingId|scheduleId|sheetNumber)$/.test(e)).map(([n,r])=>[e[n]||n,typeof r==`boolean`?r?`Да`:`Нет`:/Id$/.test(n)?t(r):r]))}O(f,`Происхождение записи`,{source:g?.source,identity:c.identity,location:c.source,schema_sha256:g?.schema_sha256}),O(f,`Все сохранённые поля и связи`,c.graph)}function j(){let e=m(`rvt-records`);e.replaceChildren();let t=m(`rvt-search`).value.toLocaleLowerCase(),i=m(`rvt-kind`).value,a=(g?.records??[]).filter(e=>(i===`all`||r(e)===i)&&`${n(e)} ${e.identity.element_id} ${e.class_name}`.toLocaleLowerCase().includes(t));e.append(K(`small`,`Найдено: ${a.length}`));for(let t of a.slice(0,v)){let i=K(`button`);i.setAttribute(`aria-pressed`,String(t===_)),i.append(K(`span`,n(t)),K(`small`,`${zd[r(t)]} · #${t.identity.element_id}`)),i.onclick=()=>A(t),e.append(i)}m(`rvt-more`).hidden=a.length<=v}m(`rvt-more`).onclick=()=>{v+=100,j()};for(let e of[`rvt-search`,`rvt-kind`])m(e).oninput=()=>{v=100,_=null,m(`rvt-record-detail`).replaceChildren(K(`p`,`Выберите запись в каталоге.`)),j()};function ee(e,t=`Загрузите RVT, чтобы прочитать виды, листы и таблицы.`){e||(x++,C.replaceChildren(),C.hidden=!0,w.hidden=!0,E=0),g=e,_=null,y=!1,m(`rvt-whole`).disabled=!0,m(`rvt-export`).disabled=!g,m(`rvt-record-detail`).replaceChildren(K(`p`,Od(g)?`Выберите запись в каталоге.`:`Читаемые записи не получены. Это не подтверждение отсутствия видов и таблиц в файле.`)),m(`rvt-document-status`).textContent=g?`${g.source?.filename??`RVT`} · ${g.records.length} записей · ${Od(g)?g.status===`partial`?`Прочитано частично`:`Каталог прочитан`:`Каталог недоступен`}${g.error?` · `+kd(g.error):``} · Полнота документа не подтверждена.`:t,j()}let M=()=>{S.textContent=g?.shared_store?`Общая база проекта · ${g.shared_store.project_id} · снимок ${g.shared_store.extraction_id.slice(0,12)} · ${g.shared_store.source_verification===`declared_sha256_not_reopened`?`Хеш RVT заявлен в каталоге; исходный файл не перепроверен.`:`Источник зарегистрирован при извлечении; актуальность файла требует отдельной проверки.`}`:f.importCatalog?`Каталог ещё не сохранён в базу проекта. Импортируйте JSON или откройте подготовленную RVT-модель.`:`Каталог в этом браузере. Для продолжения в MCP скачайте JSON и импортируйте в локальный проект Увязки.`},te=(e,t)=>{ee(e,t),M()};return te(null),{set:te,geometryReady:e=>{y=e,m(`rvt-whole`).disabled=!e,_&&A(_)},open:()=>p.showModal(),openRecord:(e,t,n)=>{m(`rvt-kind`).value=`all`,m(`rvt-search`).value=``,te(e),y=n,m(`rvt-whole`).disabled=!n,A(t),p.showModal()}}}function Vd(e){let t=[],n=(e,r=``)=>{if(!e||typeof e!=`object`||Array.isArray(e))return;let i=e;if(`value`in i&&typeof i.unit==`string`&&i.kind===`explicit`)t.push(`${r}: ${i.value} ${i.unit}`);else if(`value_si`in i&&typeof i.value_si==`number`&&typeof i.unit==`string`)t.push(`${r}: ${i.value_si} ${i.unit}`);else for(let[e,t]of Object.entries(i))n(t,e)};return n(e.record.source_quantities??e.record.quantity_sets),t.length||n(e.record.quantities),t.slice(0,3).join(` · `)||`Явные величины с единицами не прочитаны`}function Hd(e,t){if(t===`storeys`)return e.storeys.map(e=>({id:e.id,name:e.name,type:`IfcBuildingStorey`,level:e.elevation_m===null?`Не прочитана`:e.elevation_m+` м`,record:{...e}}));if(t===`systems`)return(e.systems??[]).map(e=>({id:e.id,name:e.name||e.class,type:e.class,level:`Участников: `+e.member_ids.length,record:{...e}}));let n=new Map(e.storeys.map(e=>[e.id,e.name]));return e.elements.filter(e=>t===`rooms`?e.role===`space`:e.role===`element`).map(e=>{let{mesh:t,...r}=e;return{id:e.id,name:e.long_name?e.name+` · `+e.long_name:e.name,type:e.class,level:n.get(e.storey_id||``)||`Не прочитан`,record:{...r,revit_identity:f(e),geometry_available:!!t}}})}function Ud(e,t,n){return{contract:`UvyazkaModelData`,version:1,model_id:e.model_id,source:e.source,attribution:e.attribution??null,section:t,coverage:{products:e.statistics.products,physical_elements:e.statistics.physical_elements,rooms:e.elements.filter(e=>e.role===`space`).length,storeys:e.storeys.length,systems:e.systems?.length??0,geometry_errors:e.statistics.geometry_errors,exported_rows:n.length},interpretation:`Extracted records, not an accepted project passport or verified connections. Explicit quantities and derived mesh measurements remain separate. Missing values are not zero. Raw property-set units may be unavailable.`,records:n.map(e=>e.record)}}function Wd(e){let t=e===null?`null`:typeof e==`object`?JSON.stringify(e):String(e??``);return/^[\s]*[=+@-]/.test(t)&&(t=`'`+t),`"`+t.replaceAll(`"`,`""`)+`"`}function Gd(e,t){let n=[[`Model ID`,`Source SHA-256`,`Entity ID`,`GlobalId`,`Name`,`Path`,`Value`,`Unit`,`Evidence kind`]];for(let r of t){let t=r.record.source?.file_sha256||e.source.sha256,i=(i,a,o=``,s=`raw_unreviewed`)=>n.push([e.model_id,t,r.id,r.record.global_id??``,r.name,i,a,o,s]),a=(e,t)=>{if(t&&typeof t==`object`&&!Array.isArray(t)){let n=t;if(`value`in n&&`unit`in n){i(e,n.value,n.unit==null?``:String(n.unit),String(n.kind??`raw_unreviewed`));return}for(let[t,r]of Object.entries(n))a(e?e+`.`+t:t,r)}else i(e,t)};a(``,r.record)}return`﻿`+n.map(e=>e.map(Wd).join(`,`)).join(`\r
`)}var Kd=e=>e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),qd=e=>e==null?`Не прочитано`:typeof e==`object`?JSON.stringify(e):String(e);function Jd(e){let t=qd(e);return`<span class="property-value">${Kd(t)}</span><button class="copy-property" data-copy="${Kd(t)}" aria-label="Копировать значение" title="Копировать значение"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="8" y="8" width="12" height="13" rx="1"/><path d="M16 8V3H3v13h5"/></svg></button>`}function Yd(){let e=document.createElement(`span`);e.className=`copy-status`,e.setAttribute(`role`,`status`),document.body.append(e),document.addEventListener(`click`,async t=>{let n=t.target.closest(`button[data-copy]`);if(!n)return;let r=n.dataset.copy??``;try{try{await navigator.clipboard.writeText(r)}catch{let e=document.createElement(`textarea`);e.value=r,e.className=`clipboard-fallback`,(n.closest(`dialog`)||document.body).append(e),e.select();let t=document.execCommand(`copy`);if(e.remove(),n.focus({preventScroll:!0}),!t)throw Error(`Clipboard unavailable`)}e.textContent=`Скопировано`,n.dataset.copied=`true`,setTimeout(()=>{delete n.dataset.copied,e.textContent=``},1200)}catch{e.textContent=`Не удалось скопировать. Выделите значение и нажмите Ctrl+C.`}})}function Xd(e,t){let n=document.createElement(`dialog`);n.className=`model-data`,n.setAttribute(`aria-labelledby`,`model-data-title`),n.innerHTML=`<div class="panel-head"><h2 id="model-data-title">Данные модели</h2><button data-close aria-label="Закрыть данные">✕</button></div>
  <div class="model-data-summary" role="status"></div><div class="model-data-controls"><label>Таблица<select data-section><option value="elements">Элементы</option><option value="rooms">Помещения</option><option value="storeys">Этажи</option><option value="systems">Системы</option></select></label><label class="model-data-query">Поиск по именам, ID и параметрам<input data-query type="search" placeholder="Revit ID, марка, материал, мощность…"></label><button data-json>JSON данных</button><button data-csv>CSV параметров</button></div>
  <p class="model-data-note">Данные из файла. Единицы сырых свойств могут быть не прочитаны; явные количества и измерения геометрии разделены. Экспликация и спецификация проекта требуют проверки состава и версий.</p>
  <div class="model-data-layout"><div class="model-data-table"></div><div class="model-data-detail"><p>Выберите строку, чтобы прочитать все её параметры и источник.</p></div></div><div class="model-data-footer"><span></span><button data-prev>Назад</button><button data-next>Далее</button></div>`,document.body.append(n);let r=document.createElement(`button`);r.id=`open-model-data`,r.textContent=`Данные модели`,document.getElementById(`theme-toggle`).before(r);let i=e=>n.querySelector(e),a=[],o=[],s=0,c,l=new WeakMap,u=()=>i(`[data-section]`).value,d=e=>{let t=document.createElement(`td`);return t.textContent=String(e??`—`),t},f=()=>{let e=i(`[data-query]`).value.trim().toLocaleLowerCase();o=e?a.filter(t=>h(t.record,e)):a,s=Math.min(s,Math.max(0,Math.floor((o.length-1)/50)*50));let r=document.createElement(`table`);r.innerHTML=`<thead><tr><th>Наименование / ID</th><th>Revit ElementId</th><th>Класс</th><th>Этаж / состав</th><th>Величины из источника</th></tr></thead>`;let c=document.createElement(`tbody`);for(let e of o.slice(s,s+50)){let r=document.createElement(`tr`),a=document.createElement(`td`),o=document.createElement(`button`);o.textContent=e.name+` · #`+e.id,o.onclick=()=>{let r=i(`.model-data-detail`);r.replaceChildren();let a=document.createElement(`h3`);a.textContent=e.name,r.append(a);let o=document.createElement(`button`);if(o.textContent=`Копировать все свойства`,o.dataset.copy=JSON.stringify(e.record,null,2),r.append(o),u()===`elements`||u()===`rooms`){let i=document.createElement(`button`);i.textContent=`Свойства в модели`,i.onclick=()=>{n.close(),t(e.id)},r.append(i)}let s=document.createElement(`pre`);s.textContent=JSON.stringify(e.record,null,2),r.append(s)};let s=e.record.revit_identity?.element_id,l=d(`Не прочитан`);s&&(l.innerHTML=Jd(s)),a.append(o),r.append(a,l,d(e.type),d(e.level),d(Vd(e))),c.append(r)}r.append(c);let l=i(`.model-data-table`);if(l.replaceChildren(r),!o.length){let e=document.createElement(`p`);e.textContent=u()===`systems`?`Системы в этой выгрузке не прочитаны. Это не доказывает их отсутствие в исходном проекте.`:`В этой выборке записей нет. Отсутствие записи не равно нулевому значению.`,l.append(e)}i(`.model-data-footer span`).textContent=`${o.length} записей · показаны ${o.length?s+1:0}–${Math.min(s+50,o.length)}`,i(`[data-prev]`).disabled=s===0,i(`[data-next]`).disabled=s+50>=o.length},p=()=>{let t=e();if(a=[],t){let e=l.get(t);e||(e=new Map,l.set(t,e));let n=e.get(u());n||(n=Hd(t,u()),e.set(u(),n)),a=n}s=0,i(`.model-data-summary`).textContent=t?.source.format===`nwd`?`${t.source.filename} · ${t.elements.length} геометрических фрагментов. BIM-объекты, уровни и системы не прочитаны.`:t?`${t.source.filename} · ${t.statistics.physical_elements} элементов · ${t.elements.filter(e=>e.role===`space`).length} помещений · ${t.storeys.length} уровней · ${t.systems?.length??0} систем в выгрузке`:`Модель ещё не прочитана. Для RVT без геометрии откройте «Виды и таблицы».`,i(`.model-data-detail`).replaceChildren(),f()},m=t=>{let n=e();if(!n)return;let r=new Blob([t===`json`?JSON.stringify(Ud(n,u(),o),null,2):Gd(n,o)],{type:t===`json`?`application/json`:`text/csv;charset=utf-8`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=`uvyazka-${u()}.${t}`,a.click(),setTimeout(()=>URL.revokeObjectURL(i),1e3)};r.onclick=()=>{p(),n.showModal()},i(`[data-close]`).onclick=()=>n.close(),i(`[data-section]`).onchange=p,i(`[data-query]`).oninput=()=>{clearTimeout(c),s=0,c=setTimeout(f,200)},i(`[data-prev]`).onclick=()=>{s=Math.max(0,s-50),f()},i(`[data-next]`).onclick=()=>{s+=50,f()},i(`[data-json]`).onclick=()=>m(`json`),i(`[data-csv]`).onclick=()=>m(`csv`),document.addEventListener(`model-data-changed`,()=>{n.open&&p()})}var Zd=class{hidden=new Set;visible(e){return!this.hidden.has(e)}set(e,t){for(let n of e)t?this.hidden.delete(n):this.hidden.add(n)}isolate(e,t){let n=new Set(e);this.hidden=new Set([...t].filter(e=>!n.has(e)))}reset(){this.hidden.clear()}snapshot(){return[...this.hidden]}restore(e){this.hidden=new Set(e)}count(e){let t=0,n=0;for(let r of e)t++,this.visible(r)&&n++;return{total:t,shown:n,checked:t>0&&n===t,mixed:n>0&&n<t}}},Qd={sheets:`Листы`,views:`Планы и разрезы`,"3d":`3D-виды`,schedules:`Спецификации`,templates:`Шаблоны видов`,placements:`Размещения`,other:`Другие виды`};function $d(e,t){let i=t.trim().toLocaleLowerCase();return/^(?:revit:|#)\d+$/.test(i)?String(e.identity.element_id)===i.replace(/^(?:revit:|#)/,``):i.split(/\s+/).filter(Boolean).every(t=>`${n(e)} ${e.identity.element_id} ${e.class_name} ${Qd[r(e)]}`.toLocaleLowerCase().includes(t))}function ef(e,t,i,a,o){let s=new Map;for(let e of t.records){if(!$d(e,i))continue;let t=r(e);s.has(t)||s.set(t,[]),s.get(t).push(e)}let c=document.createElement(`p`);c.className=`document-tree-note`,c.textContent=`Документ RVT · ${t.records.length} записей · ${t.status===`partial`?`прочитано частично`:`полнота не подтверждена`}`,e.append(c);for(let[r,c]of s){let s=document.createElement(`details`);s.className=`model-branch branch-document`;let l=t.source?.sha256+`:`+r;s.open=o.has(l)||!!i.trim();let u=document.createElement(`summary`),d=document.createElement(`span`),f=document.createElement(`small`);d.className=`tree-node-name`,d.textContent=Qd[r],f.textContent=String(c.length),u.append(d,f),s.append(u),e.append(s);let p=!1,m=()=>{if(p)return;p=!0;let e=document.createElement(`div`);e.className=`tree-document-list`,s.append(e);let r=50,i=()=>{e.replaceChildren();for(let i of c.slice(0,r)){let r=document.createElement(`button`);r.className=`document-item`,r.dataset.documentHash=t.source?.sha256,r.dataset.recordId=String(i.identity.element_id);let o=document.createElement(`strong`),s=document.createElement(`small`);o.textContent=n(i),s.textContent=`Revit ${i.identity.element_id}${i.diagnostic||!i.graph?` · есть пропуски`:``}`,r.append(o,s),r.onclick=()=>a(t,i),e.append(r)}if(c.length>r){let t=document.createElement(`button`);t.className=`tree-more`,t.textContent=`Ещё ${Math.min(50,c.length-r)}`,t.onclick=()=>{r+=50,i()},e.append(t)}};i()};s.addEventListener(`toggle`,e=>{e.target===s&&s.isConnected&&(s.open?(o.add(l),m()):o.delete(l))}),s.open&&m()}if(!s.size){let n=document.createElement(`p`);n.className=`document-tree-note`,n.textContent=t.records.length?`Документы не совпали с поиском по имени или ID.`:`Читаемые записи не получены; отсутствие видов и таблиц не подтверждено.`,e.append(n)}}function tf(e,t,n=`categories`){let r=[],i=new Map,a=new Map,o=new Map,s=new Map(e.storeys.map(e=>[e.id,e.name]));for(let c of t){let t=c.source_instance_id??``,l=c.storey_id??``,u=i.get(t);u||(u={key:JSON.stringify([`model`,t]),name:e.federation?.members.find(e=>e.instance_id===t)?.label??(e.federation?t?`Источник `+t:`Источник не прочитан`:e.source.filename),kind:`model`,items:[],children:[]},i.set(t,u),r.push(u)),u.items.push(c);let d=u;if(n===`levels`){let e=JSON.stringify([`storey`,t,l]),n=a.get(e);n||(n={key:e,name:s.get(l)||`Без уровня`,kind:`storey`,items:[],children:[]},a.set(e,n),u.children.push(n)),n.items.push(c),d=n}let f=v(c,e),p=JSON.stringify([`category`,t,n===`levels`?l:``,f.key]),m=o.get(p);m||(m={key:p,name:f.name,kind:`class`,items:[],children:[]},o.set(p,m),d.children.push(m)),m.items.push(c)}return r}function nf(e,t,n){let r=null,i=new Map,a=new Map,o=new Map,s=[],c=!1,l=``,u=`categories`,d=[],p=``,m=new Set;function h(h,g,_,v,y=String(v),b=`categories`,x=d,S=p){if(d=x,p=S,r!==h&&(r=h,i.clear(),a.clear(),o.clear()),l!==y&&(i.clear(),a.clear(),o.clear(),l=y),u!==b&&(i.clear(),a.clear(),o.clear(),u=b),s=g,c=v,e.replaceChildren(),!h&&!x.length)return;let C=document.createElement(`p`);C.className=`tree-results`;let w=t.count(g.map(e=>e.id));if(C.textContent=`Элементов найдено ${g.length} · включено ${w.shown}`,e.append(C),!g.length&&!x.length){let t=document.createElement(`p`);t.textContent=`Совпадений нет. Измените поиск или фильтры.`,e.append(t);return}let T=new Set,E=h?tf(h,g,b):[],D=h?.federation?.members.map(e=>({key:JSON.stringify([`model`,e.instance_id]),name:e.label,hash:e.source_sha256}))??(h?[{key:JSON.stringify([`model`,``]),name:h.source.filename,hash:h.source.sha256}]:[]),O=new Map;for(let e of D){let t=x.find(t=>t.source?.sha256===e.hash);t&&(T.add(t),O.set(e.key,t),E.some(t=>t.key===e.key)||E.push({key:e.key,name:e.name,kind:`model`,items:[],children:[]}))}let k=e=>{let r=document.createElement(`details`);r.className=`model-branch branch-`+e.kind,r.open=i.get(e.key)??(e.kind!==`class`||v||e.items.some(e=>e.id===_));let s=document.createElement(`summary`),c=document.createElement(`input`);c.type=`checkbox`;let l=e.items.map(e=>e.id),u=t.count(l);c.checked=u.checked,c.indeterminate=u.mixed,c.disabled=!l.length,c.setAttribute(`aria-label`,`Показывать `+e.name),c.onclick=e=>e.stopPropagation(),c.onchange=()=>n.show(l,c.checked);let d=document.createElement(`span`);d.textContent=e.name,d.className=`tree-node-name`;let h=document.createElement(`small`);h.textContent=String(e.items.length),h.title=`Включено ${u.shown} из ${u.total}`;let g=document.createElement(`button`);g.className=`tree-isolate`,g.textContent=`Только`,g.title=`Оставить только `+e.name,g.setAttribute(`aria-label`,g.title),g.onclick=e=>{e.stopPropagation(),n.isolate(l)},g.disabled=!l.length,s.append(c,d,h,g),r.append(s);let y=!1,b=()=>{if(y)return;if(y=!0,e.children.length)for(let t of e.children)r.append(k(t));if(e.kind===`model`&&O.has(e.key)&&ef(r,O.get(e.key),p,(e,t)=>n.document?.(e,t),m),e.children.length||e.kind===`model`&&O.has(e.key))return;let i=document.createElement(`div`);i.className=`tree-element-list`,r.append(i);let s=()=>{i.replaceChildren();let r=a.get(e.key)??50,c=o.get(e.key)??0;if(c){let t=document.createElement(`button`);t.className=`tree-more`,t.textContent=`Предыдущие 50`,t.onclick=()=>{o.set(e.key,Math.max(0,c-50)),a.set(e.key,50),s()},i.append(t)}for(let a of e.items.slice(c,c+r)){let e=document.createElement(`div`);e.className=`tree-element-row`,e.dataset.visible=String(t.visible(a.id));let r=document.createElement(`input`);r.type=`checkbox`,r.checked=t.visible(a.id),r.disabled=!a.mesh,r.setAttribute(`aria-label`,`Показывать `+(a.name||a.id)),r.title=a.mesh?`Показать / скрыть элемент`:`Геометрия не прочитана`,r.onchange=()=>n.show([a.id],r.checked);let o=document.createElement(`button`);o.className=`element-item`,o.dataset.id=a.id,o.setAttribute(`aria-pressed`,String(_===a.id));let s=document.createElement(`span`),c=document.createElement(`strong`),l=document.createElement(`small`);c.textContent=a.name||a.id;let u=f(a).element_id;l.textContent=(u?`Revit `+u:`#`+a.id)+(a.mesh?``:` · без геометрии`),s.append(c,l),o.append(s),o.onclick=e=>n.select(a.id,e.ctrlKey||e.metaKey||e.shiftKey),e.append(r,o),i.append(e)}if(e.items.length>c+r){let t=document.createElement(`button`);t.className=`tree-more`,t.textContent=`Ещё ${Math.min(50,e.items.length-c-r)} · осталось ${e.items.length-c-r}`,t.onclick=()=>{a.set(e.key,r+50),s()},i.append(t)}};s()};return r.addEventListener(`toggle`,t=>{t.target===r&&r.isConnected&&(i.set(e.key,r.open),r.open&&b())}),r.open&&b(),r};for(let t of E)e.append(k(t));for(let t of x)if(!T.has(t)){let r=document.createElement(`details`);r.className=`model-branch branch-model document-only`,r.open=!0;let i=document.createElement(`summary`);i.textContent=(t.source?.filename??`RVT`)+` · каталог без привязки к геометрии этой сцены`,r.append(i),ef(r,t,p,(e,t)=>n.document?.(e,t),m),e.append(r)}}function g(t){if(!r||!s.some(e=>e.id===t)||[...e.querySelectorAll(`.element-item`)].some(e=>e.dataset.id===t))return;let n=tf(r,s,u);for(;n.length;){let e=n.find(e=>e.items.some(e=>e.id===t));if(!e)break;i.set(e.key,!0),e.kind===`class`&&(o.set(e.key,Math.floor(e.items.findIndex(e=>e.id===t)/50)*50),a.set(e.key,50)),n=e.children}h(r,s,t,c,l,u)}return{render:h,reveal:g}}var rf=new WeakMap,af=new WeakMap;function of(e){let t=rf.get(e);if(t)return t;t=[];let n=(e,n)=>t.push({name:e,value:n}),r=(e,t)=>{if(typeof e==`object`&&e&&!Array.isArray(e))for(let[n,i]of Object.entries(e))r(i,[...t,n]);else n(t.join(` · `),e)};return r(e.property_sets??{},[`Свойства`]),r(e.quantity_sets??{},[`Количества`]),r(e.source_quantities??{},[`Величины из источника`]),n(`Revit ElementId`,f(e).element_id),n(`IFC GlobalId`,e.global_id),n(`ID сцены`,e.id),n(`Наименование`,e.name),n(`Класс IFC`,e.class),n(`Материалы`,e.materials),rf.set(e,t),t}function sf(e){let t=af.get(e);return t||(t=[...new Set(e.elements.filter(e=>e.role===`element`).flatMap(e=>of(e).map(e=>e.name)))].sort((e,t)=>e.localeCompare(t,`ru`)),af.set(e,t)),t}function cf(e,t){let n=t.name.trim().toLocaleLowerCase();if(!n)return!0;let r=of(e).filter(e=>e.name.toLocaleLowerCase().includes(n)).filter(e=>e.value!==null&&e.value!==void 0&&(typeof e.value!=`string`||e.value.trim()!==``));if(t.operator===`exists`)return r.length>0;if(t.operator===`missing`)return r.length===0;let i=t.value.trim().toLocaleLowerCase();if([`gt`,`gte`,`lt`,`lte`].includes(t.operator)){if(!/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)$/.test(i))return!1;let e=Number(i.replace(`,`,`.`));return!Number.isFinite(e)||Number.isInteger(e)&&!Number.isSafeInteger(e)?!1:r.some(n=>{let r=typeof n.value==`number`?n.value:typeof n.value==`string`&&/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)$/.test(n.value.trim())?Number(n.value.replace(`,`,`.`)):NaN;return Number.isFinite(r)&&(!Number.isInteger(r)||Number.isSafeInteger(r))&&(t.operator===`gt`?r>e:t.operator===`gte`?r>=e:t.operator===`lt`?r<e:r<=e)})}return r.some(e=>{let n=(typeof e.value==`string`?e.value:JSON.stringify(e.value)).toLocaleLowerCase();return t.operator===`equals`?n===i:n.includes(i)})}function lf(e,t,n=`all`){let r=t.filter(e=>e.name.trim());return!r.length||(n===`any`?r.some(t=>cf(e,t)):r.every(t=>cf(e,t)))}function uf(e,t,n){let r=[],i=new Set,a=document.createElement(`summary`),o=document.createElement(`div`),s=document.createElement(`button`);o.className=`facet-options`,s.textContent=`Все / сбросить`,s.type=`button`,e.replaceChildren(a,o,s);let c=()=>a.textContent=t+` · `+(i.size?i.size:`все`),l=()=>{o.replaceChildren();for(let e of r){let t=document.createElement(`label`),r=document.createElement(`input`);r.type=`checkbox`,r.checked=i.has(e.id),r.value=e.id,r.onchange=()=>{r.checked?i.add(e.id):i.delete(e.id),c(),n()},t.append(r,document.createTextNode(e.name)),o.append(t)}c()};return s.onclick=()=>{i.clear(),l(),n()},{setChoices:e=>{r=e,i.clear(),l()},selected:()=>new Set(i),restore:e=>{i=new Set(e.filter(e=>r.some(t=>t.id===e))),l()},reset:()=>{i.clear(),l()}}}function df(e,t){let n=null,r=new Set,i=new Map;e.replaceChildren();let a=document.createElement(`input`);a.type=`search`,a.placeholder=`Найти объект: слой, тип, ID…`,a.setAttribute(`aria-label`,`Найти объект DWG / DXF`),a.className=`cad-tree-search`;let o=document.createElement(`button`);o.textContent=`Показать все слои и объекты`,o.onclick=()=>t({kind:`reset-visibility`});let s=document.createElement(`p`),c=document.createElement(`div`);e.append(a,o,s,c);let l=()=>{if(c.replaceChildren(),!n)return;let e=a.value.trim().toLocaleLowerCase(),o=e.split(/\s+/).filter(Boolean),l=n.entities.filter(e=>o.every(t=>`${e.id} ${e.type} ${e.layer}`.toLocaleLowerCase().includes(t)));s.textContent=`${n.filename} · найдено ${l.length} из ${n.entities.length} объектов`;let u=document.createElement(`details`);u.className=`model-branch branch-model`,u.open=!0;let d=document.createElement(`summary`),f=document.createElement(`input`);f.type=`checkbox`,f.checked=n.layers.length>0&&n.layers.every(e=>e.visible),f.indeterminate=n.layers.some(e=>e.visible)&&!f.checked,f.setAttribute(`aria-label`,`Показывать чертёж`),f.onclick=e=>e.stopPropagation(),f.onchange=()=>t({kind:`all-layer-visibility`,visible:f.checked});let p=document.createElement(`span`);p.className=`tree-node-name`,p.textContent=n.filename,d.append(f,p),u.append(d),c.append(u);for(let a of n.layers){let n=l.filter(e=>e.layer===a.name);if(e&&!n.length&&!a.name.toLocaleLowerCase().includes(e))continue;let o=document.createElement(`details`);o.className=`model-branch branch-class`,o.open=r.has(a.name)||!!e;let s=document.createElement(`summary`),c=document.createElement(`input`);c.type=`checkbox`,c.checked=a.visible,c.setAttribute(`aria-label`,`Показывать слой `+a.name),c.onclick=e=>e.stopPropagation(),c.onchange=()=>t({kind:`layer-visibility`,layer:a.name,visible:c.checked});let d=document.createElement(`span`);d.className=`tree-node-name`,d.textContent=a.name;let f=document.createElement(`small`);f.textContent=String(n.length);let p=document.createElement(`button`);p.className=`tree-isolate`,p.textContent=`Только`,p.onclick=e=>{e.stopPropagation(),t({kind:`isolate-layer`,layer:a.name})},s.append(c,d,f,p),o.append(s);let m=!1,h=()=>{if(m)return;m=!0;let e=document.createElement(`div`);e.className=`tree-element-list`,o.append(e);let r=()=>{e.replaceChildren();let o=i.get(a.name)??50;for(let r of n.slice(0,o)){let n=document.createElement(`div`);n.className=`tree-element-row`,n.dataset.visible=String(r.visible===!0&&a.visible);let i=document.createElement(`input`);i.type=`checkbox`,i.checked=r.visible===!0&&a.visible,i.disabled=r.visible===null,i.setAttribute(`aria-label`,`Показывать объект `+r.id),i.onchange=()=>t({kind:`entity-visibility`,id:r.id,visible:i.checked});let o=document.createElement(`button`);o.className=`element-item`,o.textContent=r.type+` · #`+r.id,o.onclick=()=>t({kind:`select-entity`,id:r.id}),n.append(i,o),e.append(n)}if(n.length>o){let t=document.createElement(`button`);t.className=`tree-more`,t.textContent=`Ещё `+Math.min(50,n.length-o),t.onclick=()=>{i.set(a.name,o+50),r()},e.append(t)}};r()};o.ontoggle=()=>{o.isConnected&&(o.open?(r.add(a.name),h()):r.delete(a.name))},o.open&&h(),u.append(o)}};return a.oninput=l,{update:e=>{n=e,l()}}}function ff(e,t,n,r=!1){let i={X:0,Y:1,Z:2}[t];if(!Number.isFinite(n))throw Error(`Неверное положение сечения`);let a=e.bounds_min_m[i]+(e.bounds_max_m[i]-e.bounds_min_m[i])*Math.max(0,Math.min(1,n));return{value:a,normal:{X:[-1,0,0],Y:[0,0,1],Z:[0,-1,0]}[t].map(e=>e*(r?-1:1)),constant:(a-e.render_origin_m[i])*(r?-1:1)}}var pf={type:`change`},mf={type:`start`},hf={type:`end`},gf=new ra,_f=new Xi,vf=Math.cos(70*Kn.DEG2RAD),yf=new V,bf=2*Math.PI,xf={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},Sf=1e-6,Cf=class extends Ns{constructor(e,t=null){super(e,t),this.state=xf.NONE,this.target=new V,this.cursor=new V,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:`ArrowLeft`,UP:`ArrowUp`,RIGHT:`ArrowRight`,BOTTOM:`ArrowDown`},this.mouseButtons={LEFT:Me.ROTATE,MIDDLE:Me.DOLLY,RIGHT:Me.PAN},this.touches={ONE:Ne.ROTATE,TWO:Ne.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle=`auto`,this._domElementKeyEvents=null,this._lastPosition=new V,this._lastQuaternion=new qn,this._lastTargetPosition=new V,this._quat=new qn().setFromUnitVectors(e.up,new V(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Ss,this._sphericalDelta=new Ss,this._scale=1,this._panOffset=new V,this._rotateStart=new B,this._rotateEnd=new B,this._rotateDelta=new B,this._panStart=new B,this._panEnd=new B,this._panDelta=new B,this._dollyStart=new B,this._dollyEnd=new B,this._dollyDelta=new B,this._dollyDirection=new V,this._mouse=new B,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=Tf.bind(this),this._onPointerDown=wf.bind(this),this._onPointerUp=Ef.bind(this),this._onContextMenu=Nf.bind(this),this._onMouseWheel=kf.bind(this),this._onKeyDown=Af.bind(this),this._onTouchStart=jf.bind(this),this._onTouchMove=Mf.bind(this),this._onMouseDown=Df.bind(this),this._onMouseMove=Of.bind(this),this._interceptControlDown=Pf.bind(this),this._interceptControlUp=Ff.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e===`grab`?this.domElement.style.cursor=`grab`:this.domElement.style.cursor=`auto`}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener(`pointerdown`,this._onPointerDown),this.domElement.addEventListener(`pointercancel`,this._onPointerUp),this.domElement.addEventListener(`contextmenu`,this._onContextMenu),this.domElement.addEventListener(`wheel`,this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener(`keydown`,this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction=`none`}disconnect(){this.state=xf.NONE,this.domElement.removeEventListener(`pointerdown`,this._onPointerDown),this.domElement.ownerDocument.removeEventListener(`pointermove`,this._onPointerMove),this.domElement.ownerDocument.removeEventListener(`pointerup`,this._onPointerUp),this.domElement.removeEventListener(`pointercancel`,this._onPointerUp),this.domElement.removeEventListener(`wheel`,this._onMouseWheel),this.domElement.removeEventListener(`contextmenu`,this._onContextMenu),this.stopListenToKeyEvents();let e=this.domElement.getRootNode();e.removeEventListener(`keydown`,this._interceptControlDown,{capture:!0}),e.removeEventListener(`keyup`,this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction=``,this.domElement.style.cursor=`auto`}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener(`keydown`,this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener(`keydown`,this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(pf),this.update(),this.state=xf.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){let t=this.object.position;yf.copy(t).sub(this.target),yf.applyQuaternion(this._quat),this._spherical.setFromVector3(yf),this.autoRotate&&this.state===xf.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,r=this.maxAzimuthAngle;isFinite(n)&&isFinite(r)&&(n<-Math.PI?n+=bf:n>Math.PI&&(n-=bf),r<-Math.PI?r+=bf:r>Math.PI&&(r-=bf),n<=r?this._spherical.theta=Math.max(n,Math.min(r,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+r)/2?Math.max(n,this._spherical.theta):Math.min(r,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let i=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{let e=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),i=e!=this._spherical.radius}if(yf.setFromSpherical(this._spherical),yf.applyQuaternion(this._quatInverse),t.copy(this.target).add(yf),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let e=null;if(this.object.isPerspectiveCamera){let t=yf.length();e=this._clampDistance(t*this._scale);let n=t-e;this.object.position.addScaledVector(this._dollyDirection,n),this.object.updateMatrixWorld(),i=!!n}else if(this.object.isOrthographicCamera){let t=new V(this._mouse.x,this._mouse.y,0);t.unproject(this.object);let n=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),i=n!==this.object.zoom;let r=new V(this._mouse.x,this._mouse.y,0);r.unproject(this.object),this.object.position.sub(r).add(t),this.object.updateMatrixWorld(),e=yf.length()}else console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled.`),this.zoomToCursor=!1;e!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(e).add(this.object.position):(gf.origin.copy(this.object.position),gf.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(gf.direction))<vf?this.object.lookAt(this.target):(_f.setFromNormalAndCoplanarPoint(this.object.up,this.target),gf.intersectPlane(_f,this.target))))}else if(this.object.isOrthographicCamera){let e=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),e!==this.object.zoom&&(this.object.updateProjectionMatrix(),i=!0)}return this._scale=1,this._performCursorZoom=!1,i||this._lastPosition.distanceToSquared(this.object.position)>Sf||8*(1-this._lastQuaternion.dot(this.object.quaternion))>Sf||this._lastTargetPosition.distanceToSquared(this.target)>Sf?(this.dispatchEvent(pf),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e===null?bf/60/60*this.autoRotateSpeed:bf/60*this.autoRotateSpeed*e}_getZoomScale(e){let t=Math.abs(e*.01);return .95**(this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){yf.setFromMatrixColumn(t,0),yf.multiplyScalar(-e),this._panOffset.add(yf)}_panUp(e,t){this.screenSpacePanning===!0?yf.setFromMatrixColumn(t,1):(yf.setFromMatrixColumn(t,0),yf.crossVectors(this.object.up,yf)),yf.multiplyScalar(e),this._panOffset.add(yf)}_pan(e,t){let n=this.domElement;if(this.object.isPerspectiveCamera){let r=this.object.position;yf.copy(r).sub(this.target);let i=yf.length();i*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*i/n.clientHeight,this.object.matrix),this._panUp(2*t*i/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - pan disabled.`),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled.`),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled.`),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;let n=this.domElement.getBoundingClientRect(),r=e-n.left,i=t-n.top,a=n.width,o=n.height;this._mouse.x=r/a*2-1,this._mouse.y=-(i/o)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(bf*this._rotateDelta.x/t.clientHeight),this._rotateUp(bf*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(bf*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-bf*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(bf*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-bf*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._rotateStart.set(n,r)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._panStart.set(n,r)}}_handleTouchStartDolly(e){let t=this._getSecondPointerPosition(e),n=e.pageX-t.x,r=e.pageY-t.y,i=Math.sqrt(n*n+r*r);this._dollyStart.set(0,i)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._rotateEnd.set(n,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(bf*this._rotateDelta.x/t.clientHeight),this._rotateUp(bf*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._panEnd.set(n,r)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){let t=this._getSecondPointerPosition(e),n=e.pageX-t.x,r=e.pageY-t.y,i=Math.sqrt(n*n+r*r);this._dollyEnd.set(0,i),this._dollyDelta.set(0,(this._dollyEnd.y/this._dollyStart.y)**+this.zoomSpeed),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);let a=(e.pageX+t.x)*.5,o=(e.pageY+t.y)*.5;this._updateZoomParameters(a,o)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new B,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){let t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){let t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100}return e.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}};function wf(e){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(e.pointerId),this.domElement.ownerDocument.addEventListener(`pointermove`,this._onPointerMove),this.domElement.ownerDocument.addEventListener(`pointerup`,this._onPointerUp)),!this._isTrackingPointer(e)&&(this._addPointer(e),e.pointerType===`touch`?this._onTouchStart(e):this._onMouseDown(e),this._cursorStyle===`grab`&&(this.domElement.style.cursor=`grabbing`)))}function Tf(e){this.enabled!==!1&&(e.pointerType===`touch`?this._onTouchMove(e):this._onMouseMove(e))}function Ef(e){switch(this._removePointer(e),this._pointers.length){case 0:this.domElement.releasePointerCapture(e.pointerId),this.domElement.ownerDocument.removeEventListener(`pointermove`,this._onPointerMove),this.domElement.ownerDocument.removeEventListener(`pointerup`,this._onPointerUp),this.dispatchEvent(hf),this.state=xf.NONE,this._cursorStyle===`grab`&&(this.domElement.style.cursor=`grab`);break;case 1:let t=this._pointers[0],n=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:n.x,pageY:n.y})}}function Df(e){let t;switch(e.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Me.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(e),this.state=xf.DOLLY;break;case Me.ROTATE:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(e),this.state=xf.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(e),this.state=xf.ROTATE}break;case Me.PAN:if(e.ctrlKey||e.metaKey||e.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(e),this.state=xf.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(e),this.state=xf.PAN}break;default:this.state=xf.NONE}this.state!==xf.NONE&&this.dispatchEvent(mf)}function Of(e){switch(this.state){case xf.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(e);break;case xf.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(e);break;case xf.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(e)}}function kf(e){this.enabled!==!1&&this.enableZoom!==!1&&this.state===xf.NONE&&(e.preventDefault(),this.dispatchEvent(mf),this._handleMouseWheel(this._customWheelEvent(e)),this.dispatchEvent(hf))}function Af(e){this.enabled!==!1&&this._handleKeyDown(e)}function jf(e){switch(this._trackPointer(e),this._pointers.length){case 1:switch(this.touches.ONE){case Ne.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(e),this.state=xf.TOUCH_ROTATE;break;case Ne.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(e),this.state=xf.TOUCH_PAN;break;default:this.state=xf.NONE}break;case 2:switch(this.touches.TWO){case Ne.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(e),this.state=xf.TOUCH_DOLLY_PAN;break;case Ne.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(e),this.state=xf.TOUCH_DOLLY_ROTATE;break;default:this.state=xf.NONE}break;default:this.state=xf.NONE}this.state!==xf.NONE&&this.dispatchEvent(mf)}function Mf(e){switch(this._trackPointer(e),this.state){case xf.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(e),this.update();break;case xf.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(e),this.update();break;case xf.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(e),this.update();break;case xf.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(e),this.update();break;default:this.state=xf.NONE}}function Nf(e){this.enabled!==!1&&e.preventDefault()}function Pf(e){e.key===`Control`&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener(`keyup`,this._interceptControlUp,{passive:!0,capture:!0}))}function Ff(e){e.key===`Control`&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener(`keyup`,this._interceptControlUp,{passive:!0,capture:!0}))}var If=e=>Math.max(0,Math.min(1,e)),Lf=e=>{let t=If(e);return t*t*(3-2*t)},Rf=(e,t,n)=>e.map((e,r)=>e+(t[r]-e)*Lf(n)),zf=(e,t)=>If((t-e.start)/(e.end-e.start));function Bf(e){let t=new Map(e.scenario.operations.map(e=>[e.id,e])),n=new Map(e.scenario.resources.map(e=>[e.id,Array(e.capacity).fill(null)])),r=new Map,i=[];for(let a of e.events){if(!a.resource_id||!a.operation_id)continue;let e=`${a.resource_id}/${a.operation_id}`,o=n.get(a.resource_id);if(!o)throw Error(`Неизвестный ресурс ${a.resource_id}`);if(a.kind===`resource_acquired`){let n=a.amount,s=t.get(a.operation_id),c=r.get(e)??[];for(let e=0;e<n;e++){let e=o.indexOf(null);if(e<0)throw Error(`Двойное назначение ${a.resource_id}`);o[e]=s.id;let t={resource:a.resource_id,slot:e,operation:s,start:a.time,end:1/0};c.push(t),i.push(t)}r.set(e,c)}if(a.kind===`resource_released`){for(let t of r.get(e)??[])t.end=a.time,o[t.slot]=null;r.delete(e)}}if(r.size)throw Error(`Журнал содержит незавершённые назначения ресурсов`);return i}function Vf(e,t,n,r){return e.find(e=>e.resource===t&&e.slot===n&&e.start<=r&&r<e.end)}function Hf(e,t,n,r){if(!e)return{position:n,moving:!1,unloading:!1,phase:`стоянка`,travel:0};let i=zf(e,t);return i<.28?{position:Rf(n,r,i/.28),moving:!0,unloading:!1,phase:`въезд`,travel:i/.28}:i<.72?{position:r,moving:!1,unloading:!0,phase:`разгрузка`,travel:1}:{position:Rf(r,n,(i-.72)/.28),moving:!0,unloading:!1,phase:`выезд`,travel:(1-i)/.28}}function Uf(e,t,n,r){let i=Math.atan2(e[2]-n[2],e[0]-n[0]),a=Math.atan2(t[2]-n[2],t[0]-n[0]),o=Math.atan2(Math.sin(a-i),Math.cos(a-i)),s=Math.hypot(e[0]-n[0],e[2]-n[2]),c=s+(Math.hypot(t[0]-n[0],t[2]-n[2])-s)*Lf(r),l=i+o*Lf(r);return[n[0]+Math.cos(l)*c,e[1]+(t[1]-e[1])*Lf(r),n[2]+Math.sin(l)*c]}function Wf(e,t,n,r,i,a,o){let s=[n[0],a,n[2]],c=[r[0],a,r[2]],l=[r[0],r[1]+o*2+.18,r[2]],u,d,f=!0,p=!1,m=1,h;return e<.12?(u=n,d=Uf(i,s,t,e/.12),h=`подача крюка`):e<.22?(u=n,d=Rf(s,n,(e-.12)/.1),h=`строповка`):e<.28?(u=n,d=n,h=`строповка`):e<.42?(u=Rf(n,s,(e-.28)/.14),d=u,p=!0,h=`подъём`):e<.68?(u=Uf(s,c,t,(e-.42)/.26),d=u,p=!0,h=`перенос`):e<.84?(u=Rf(c,l,(e-.68)/.16),d=u,p=!0,h=`подача к месту монтажа`):e<.9?(u=l,d=l,p=!0,m=1-(e-.84)/.06,h=`передача монтажникам`):(u=l,d=Rf(l,c,(e-.9)/.1),f=!1,h=`подъём пустого крюка`),{position:u,hook:d,phase:h,attached:p,loadVisible:f,opacity:m,installed:e>=.9}}var Gf={type:`mobile_crane`,name:`Компактный автокран`,retractedLength:6.2,maxBoomLength:28,pivotHeight:2.2,outriggerWidth:6.5,evidence:`simulation_assumption`,loadMassKg:null,ratedCapacityKg:null,reason:`Предварительный тип для малоэтажной демонстрации; масса груза, грузовая характеристика и грунт не подтверждены.`};function Kf(e,t,n=[],r=.6){let i=t[0]-e[0],a=t[2]-e[2],o=Math.hypot(i,a),s=Math.max(e[1]+1.3,t[1]+.8);for(let i of n){let n=0,a=1;for(let r of[0,2]){let o=t[r]-e[r];if(Math.abs(o)<1e-9){if(e[r]<i.min[r]-.35||e[r]>i.max[r]+.35){a=-1;break}}else{let t=(i.min[r]-.35-e[r])/o,s=(i.max[r]+.35-e[r])/o;n=Math.max(n,Math.min(t,s)),a=Math.min(a,Math.max(t,s))}}if(!(n>a||a<0||n>1)){if(n<1e-6&&i.max[1]+r>=e[1])return{head:t,radius:o,angle:0,length:1/0,reachable:!1};n>1e-6&&(s=Math.max(s,e[1]+(i.max[1]+r-e[1])/n))}}let c=s-e[1],l=Math.hypot(o,c);return l<Gf.retractedLength&&(c=Math.sqrt(Gf.retractedLength**2-o**2),s=e[1]+c,l=Gf.retractedLength),{head:[t[0],s,t[2]],radius:o,angle:Math.atan2(c,o),length:l,reachable:l<=Gf.maxBoomLength}}var qf=class{model;run;occupied;group=new Wr;objects=[];states=[];geometries=[];frame=new wa({color:4225164});deck=new go({color:13019252,roughness:.9});constructor(e,t,n){this.model=e,this.run=t,this.occupied=n;let r=e.coordinate_system.render_origin_m,i=e=>new V(e[0]-r[0],e[2]-r[2],-(e[1]-r[1]));for(let r of t.scenario.temporary_assets??[]){let a=i(r.bounds_m[0]),o=i(r.bounds_m[1]),s=new pi().setFromPoints([a,o]),c=new Wr;this.group.add(c);let l=null,u=!0;if(r.kind===`facade_scaffold`){let e=s.min,t=s.max,n=[[[e.x-.8,e.z-.8],[t.x+.8,e.z-.8]],[[t.x+.8,e.z-.8],[t.x+.8,t.z+.8]],[[t.x+.8,t.z+.8],[e.x-.8,t.z+.8]],[[e.x-.8,t.z+.8],[e.x-.8,e.z-.8]]];for(let r=e.y;r<t.y;r+=2)for(let[e,i]of n){let n=Math.hypot(i[0]-e[0],i[1]-e[1]),a=Math.max(1,Math.ceil(n/2.5));for(let n=0;n<a;n++){let o=e[0]+(i[0]-e[0])*n/a,s=e[1]+(i[1]-e[1])*n/a,l=e[0]+(i[0]-e[0])*(n+1)/a,u=e[1]+(i[1]-e[1])*(n+1)/a,d=Math.min(r+2,t.y),f=new Wr;c.add(f),this.lines(f,[[o,r,s,o,d,s],[l,r,u,l,d,u],[o,d,s,l,d,u],[o,r,s,l,d,u],[o,d+.6,s,l,d+.6,u]]);let p=new Ya(Math.abs(l-o)>.01?Math.abs(l-o):.65,.06,Math.abs(u-s)>.01?Math.abs(u-s):.65);this.geometries.push(p);let m=new ga(p,this.deck);m.position.set((o+l)/2,d,(s+u)/2),f.add(m)}}}else{let i=s.getCenter(new V),a=s.getSize(new V),o=t.scenario.units.find(e=>e.id===r.unit_id),d=new pi;for(let e of o?.target_ids??[]){let t=n.get(e);t&&d.union(t)}let f=(d.isEmpty()?[i.clone()]:[new V(d.min.x-.9,i.y,d.getCenter(new V).z),new V(d.max.x+.9,i.y,d.getCenter(new V).z),new V(d.getCenter(new V).x,i.y,d.min.z-.8),new V(d.getCenter(new V).x,i.y,d.max.z+.8)]).flatMap(e=>[e,...[-1.5,-.75,.75,1.5].flatMap(t=>[new V(e.x+t,e.y,e.z),new V(e.x,e.y,e.z+t)])]),p=t.operation_states[r.install_id].start,m=new Set(t.scenario.initial_element_ids??[]);for(let e of t.scenario.units)if(t.operation_states[e.operation_ids.at(-1)].finish<=p)for(let t of e.target_ids)m.add(t);let h=f.find(t=>{let r=new pi(new V(t.x-.65,s.min.y+.1,t.z-.45),new V(t.x+.65,s.max.y+1.5,t.z+.45));return(Math.abs(s.min.y)<.05||e.elements.some(e=>e.hierarchy.includes(`IfcSlab`)&&m.has(e.id)&&(()=>{let r=n.get(e.id);return r&&Math.abs(r.max.y-s.min.y)<.2&&t.x-.65>=r.min.x&&t.x+.65<=r.max.x&&t.z-.45>=r.min.z&&t.z+.45<=r.max.z})()))&&![...m,...o?.target_ids??[]].some(e=>{let t=n.get(e);return t&&t.max.y>s.min.y+.2&&t.intersectsBox(r)})});u=!!h;let g=h??i;c.position.set(g.x,s.min.y,g.z);let _=Math.max(1,a.y),v=[];for(let e of[-.65,.65])for(let t of[-.45,.45])v.push([e,0,t,e,_+1,t]);for(let e=0;e<=_+.01;e+=.5)v.push([-.65,e,-.45,.65,e,-.45],[-.65,e,.45,.65,e,.45]);v.push([.65,0,.45,-.65,_,.45],[-.65,_+1,-.45,-.25,_+1,-.45],[.25,_+1,-.45,.65,_+1,-.45],[-.65,_+1,.45,.65,_+1,.45]);for(let e of[-.22,.22])v.push([e,0,-.8,e,_+.8,-.8]);for(let e=.2;e<_+.5;e+=.28)v.push([-.22,e,-.8,.22,e,-.8]);this.lines(c,v);let y=new Ya(1.3,.07,.9);this.geometries.push(y);let b=new ga(y,this.deck);b.position.y=_,c.add(b),l=new V(g.x,s.min.y+_+.04,g.z)}this.objects.push({asset:r,root:c,platform:l,valid:u,box:s})}}lines(e,t){let n=new Ki;n.setAttribute(`position`,new Pi(t.flat(),3)),this.geometries.push(n),e.add(new Ia(n,this.frame))}update(e){this.states.length=0;for(let t of this.objects){let{asset:n,root:r,valid:i}=t,a=this.run.operation_states[n.install_id],o=this.run.operation_states[n.check_id],s=this.run.operation_states[n.remove_id],c=e<a.start||e>=s.finish?0:e<a.finish?(e-a.start)/(a.finish-a.start):e>=s.start?1-(e-s.start)/(s.finish-s.start):1;r.visible=i&&c>0,n.kind===`facade_scaffold`&&r.children.forEach((e,t)=>e.visible=t<Math.ceil(r.children.length*c)),c>0&&this.states.push({id:n.id,kind:n.kind,fraction:c,placementValid:i,phase:e<a.finish?`сборка`:e<o.finish?`ожидание приёмки`:e>=s.start?`разборка`:`готово к работе`})}}platformFor(e,t){let n=this.objects.find(n=>n.valid&&n.asset.work_operation_ids.includes(e)&&this.run.operation_states[n.asset.check_id].finish<=t&&t<this.run.operation_states[n.asset.remove_id].start);if(!n)return null;if(n.platform)return n.platform;let r=this.run.scenario.operations.find(t=>t.id===e),i=new pi;for(let e of r?.target_ids??[]){let t=this.occupied.get(e);t&&i.union(t)}if(i.isEmpty())return null;let a=i.getCenter(new V),o=n.box.min,s=n.box.max,c=[new V(o.x-.8,0,a.z),new V(s.x+.8,0,a.z),new V(a.x,0,o.z-.8),new V(a.x,0,s.z+.8)].sort((e,t)=>e.distanceToSquared(a)-t.distanceToSquared(a))[0];return c.y=Math.min(s.y,o.y+Math.max(2,Math.round((a.y-o.y)/2)*2))+.04,c}accessFor(e,t,n){let r=this.objects.find(n=>n.valid&&n.platform&&n.asset.work_operation_ids.includes(e)&&this.run.operation_states[n.asset.check_id].finish<=t&&t<this.run.operation_states[n.asset.remove_id].start);if(!r||n>1)return null;let i=r.platform,a=r.root.position;return{id:r.asset.id,base:new V(i.x,a.y,i.z-.8),top:new V(i.x,i.y,i.z-.8),entry:new V(i.x,i.y,i.z-.25),position:new V(i.x+(n?.3:-.3),i.y,i.z+.12),availableUntil:this.run.operation_states[r.asset.remove_id].start,basis:`assumed_external_tower_ladder`}}dispose(){this.group.removeFromParent(),this.geometries.forEach(e=>e.dispose()),this.frame.dispose(),this.deck.dispose()}},Jf=[`crew`,`concrete_crew`,`inspector`,`surveyor`,`hvac_crew`,`pipe_crew`,`electrical_crew`,`scaffold_crew`,`commissioning_crew`];function Yf(e,t,n){let r=e=>t.find(t=>t.id===e)?.capacity??0,i=new Map,a=[],o=[],s=(e.minZ+e.maxZ)/2,c=Math.max(13,2*n+4);for(let t=0;t<r(`crane`);t++){let r=t%2?1:-1,l=s+Math.floor(t/2)*c,u=r<0?e.minX-5:e.maxX+5;a.push([u,0,l]),o.push([u+r*(n+5),.6,l]),i.set(`crane:${t}`,{id:`crane:${t}`,park:[u,0,l],dock:[u,0,l],envelope:{minX:u-3.9,maxX:u+3.9,minZ:l-7,maxZ:l+4}})}let l=Math.max(15,2*n+12),u=e.minX-l,d=e.maxX+l,f=e.minZ-12,p=s;for(let[e,t,n]of[[`truck`,3.4,3.7],[`mixer`,3.4,3],[`concrete_pump`,6.8,3.3],[`excavator`,10,5],[`dump_truck`,3.6,3.4],[`compactor`,3.6,3.2],[`vibrator`,1.8,1]])for(let a=0;a<r(e);a++){let r=e===`truck`?u-t/2:d+t/2;e===`truck`?u-=t+.3:d+=t+.3,i.set(`${e}:${a}`,{id:`${e}:${a}`,park:[r,0,f],dock:[r,0,p],envelope:{minX:r-t/2,maxX:r+t/2,minZ:f-n,maxZ:p+n}})}let m=Math.max(e.maxZ+4,...[...i.values()].map(e=>e.envelope.maxZ+3)),h=Jf.reduce((e,t)=>e+r(t),0),g=Math.max(4,...t.map(e=>(e.people_per_slot??2)*1.3)),_=new Map,v=0;for(let t of Jf)for(let n=0;n<r(t);n++)_.set(`${t}:${n}`,[e.maxX+2+v++%4*g,0,m+Math.floor((v-1)/4)*1.8]);let y=[e.minX-6,0,m],b=[e.maxX+4,0,m+Math.ceil(h/4)*1.8+5];return{bays:i,cranes:a,pickups:o,staging:_,stock:y,cabin:b,bounds:{minX:u-3,maxX:Math.max(d+3,e.maxX+2+g*4+2),minZ:f-7,maxZ:b[2]+5}}}var Xf=(e,t)=>Math.hypot(...e.map((e,n)=>e-t[n])),Zf=(e,t,n)=>e.map((e,r)=>e+(t[r]-e)*n);function Qf(e){return/concret|blinding/.test(e)?{tool:`hose`,action:`укладка и уплотнение смеси`}:/reinforc/.test(e)?{tool:`pliers`,action:`вязка арматуры`}:/formwork|stripping/.test(e)?{tool:`hammer`,action:e===`stripping`?`разборка опалубки`:`крепление опалубки`}:/masonry|waterproof/.test(e)?{tool:`trowel`,action:`нанесение и разравнивание слоя`}:/inspect|check|survey|setting_out|as_built|commission/.test(e)?{tool:`meter`,action:`осмотр и замер`}:/duct|pipe|mep|lifting|install|scaffold/.test(e)?{tool:`wrench`,action:`установка и крепление элемента`}:{tool:`probe`,action:`подготовка рабочего участка`}}function $f(e){return e.modes.map((t,n)=>Xf(e.points[n],e.points[n+1])/(t===`climb`?8:60))}function ep(e,t,n,r,i,a,o,s=null){let c=$f(o).reduce((e,t)=>e+t,0),l=s??(c*2+.1>e.end-e.start?`В интервале назначения не хватает времени на подход, работу и возвращение.`:null);return{operationId:e.operation.id,targetId:i,targetName:a,home:t,destination:n,contact:r,route:o,start:e.start,end:e.end,approachMinutes:c,approachStart:e.start,workStart:e.start+c,workEnd:e.end-c,...Qf(e.operation.kind),blocked:l}}function tp(e,t,n=0){let r=`idle`,i=e.home,a=[0,0,1],o=0;if(t>=e.start&&t<e.end){if(e.blocked)r=`blocked`;else if(t<e.approachStart)r=`waiting`;else if(t>=e.workStart&&t<e.workEnd)r=`work`,i=e.destination,a=e.contact.map((e,t)=>e-i[t]);else{let n=t>=e.workEnd,s=n?e.end-t:t-e.approachStart,c=$f(e.route);for(let t=0;t<c.length;t++){let l=e.route.points[t],u=e.route.points[t+1];if(s<=c[t]+1e-9||t===c.length-1){let d=Math.min(1,s/Math.max(c[t],1e-9));i=Zf(l,u,d),o+=Xf(l,u)*d,a=n?l.map((e,t)=>e-u[t]):u.map((e,t)=>e-l[t]),r=e.route.modes[t]===`climb`?`climb`:n?`depart`:`approach`;break}s-=c[t],o+=Xf(l,u)}}}let s=r===`work`,c=[`approach`,`depart`,`climb`].includes(r),l=s?(t-e.workStart)/Math.min(.6,Math.max(.025,(e.workEnd-e.workStart)/4))+n*.3:o/.7,u=Math.sin(l*Math.PI*2),d=s?e.tool===`meter`?-.85+u*.12:e.tool===`hose`?-.8+u*.15:e.tool===`hammer`?-.9+u*.6:-.9+u*.25:c?u*.5:0;return{phase:r,position:i,direction:a,travelled:o,arm:d,walk:c?u*.45:0,lean:s?e.tool===`trowel`||e.tool===`pliers`?.35:.1:0,action:r===`work`?e.action:{idle:`нет назначения`,waiting:`ожидание свободного прохода`,approach:`подход к месту`,climb:`подъём / спуск по лестнице`,depart:`возвращение`,blocked:`доступ заблокирован`}[r],progress:s?(t-e.workStart)/(e.workEnd-e.workStart):+(t>=e.workEnd&&!e.blocked)}}function np(e){let t=[];if(e.blocked)return[{start:e.start,end:e.end,a:e.home,b:e.home}];e.approachStart>e.start&&t.push({start:e.start,end:e.approachStart,a:e.home,b:e.home});let n=$f(e.route),r=e.approachStart;n.forEach((n,i)=>{t.push({start:r,end:r+n,a:e.route.points[i],b:e.route.points[i+1]}),r+=n}),t.push({start:e.workStart,end:e.workEnd,a:e.destination,b:e.destination}),r=e.workEnd;for(let i=n.length-1;i>=0;i--)t.push({start:r,end:r+n[i],a:e.route.points[i+1],b:e.route.points[i]}),r+=n[i];return t.filter(e=>e.end>e.start)}function rp(e,t){if(e.start>=t.end||t.start>=e.end)return!1;for(let n of np(e))for(let e of np(t)){let t=Math.max(n.start,e.start),r=Math.min(n.end,e.end);if(t>=r)continue;let i=n.b.map((t,r)=>(t-n.a[r])/(n.end-n.start)-(e.b[r]-e.a[r])/(e.end-e.start)),a=t=>n.a.map((r,i)=>r+(n.b[i]-r)*(t-n.start)/(n.end-n.start)-(e.a[i]+(e.b[i]-e.a[i])*(t-e.start)/(e.end-e.start))),o=a(t);if(Math.abs(i[1])<1e-9){if(Math.abs(o[1])>=1.75)continue}else{let e=t+(-1.75-o[1])/i[1],n=t+(1.75-o[1])/i[1];if(t=Math.max(t,Math.min(e,n)),r=Math.min(r,Math.max(e,n)),t>=r)continue}let s=a(t),c=i[0]**2+i[2]**2,l=a(c<1e-12?t:Math.max(t,Math.min(r,t-(s[0]*i[0]+s[2]*i[2])/c)));if(Math.hypot(l[0],l[2])<.58)return!0}return!1}function ip(e,t){if(e.blocked)return e;for(let n of[0,.1,.25,.5,1,2,4]){let r={...e,approachStart:e.start+n,workStart:e.workStart+n};if(!(r.workStart+.1>r.workEnd)&&!t.some(e=>rp(r,e)))return r}return null}function ap(e,t,n){let r=Math.max(1,Math.ceil(Xf(e,t)/.15)),i=e[1];for(let a=0;a<=r;a++){let o=Zf(e,t,a/r),s=n.surface(o[0],o[2]);if(s===null||Math.abs(s-i)>.2||Math.abs(s-o[1])>.2||!n.clear([o[0],s,o[2]]))return!1;i=s}return!0}function op(e,t,n,r=.6,i=12e3){if(!ap(e,e,n)||!ap(t,t,n))return null;if(ap(e,t,n))return[e,t];let a=[{x:0,z:0,p:e,g:0,f:Xf(e,t),parent:null}],o=new Map([[`0,0`,0]]),s=0;for(;a.length&&s++<i;){let i=0;for(let e=1;e<a.length;e++)a[e].f<a[i].f&&(i=e);let s=a.splice(i,1)[0];if(!(s.g>o.get(`${s.x},${s.z}`)+1e-8)){if(Xf(s.p,t)<r*1.5&&ap(s.p,t,n)){let e=[t],r=s;for(;r;)e.push(r.p),r=r.parent;e.reverse();let i=[e[0]],a=0;for(;a<e.length-1;){let t=e.length-1;for(;t>a+1&&!ap(e[a],e[t],n);)t--;i.push(e[t]),a=t}return i}for(let[i,c]of[[1,0],[0,1],[-1,0],[0,-1],[1,1],[-1,1],[-1,-1],[1,-1]]){let l=s.x+i,u=s.z+c,d=e[0]+l*r,f=e[2]+u*r;if(d<n.minX||d>n.maxX||f<n.minZ||f>n.maxZ)continue;let p=n.surface(d,f);if(p===null)continue;let m=[d,p,f],h=s.g+Xf(s.p,m),g=`${l},${u}`;h>=(o.get(g)??1/0)-1e-8||!ap(s.p,m,n)||(o.set(g,h),a.push({x:l,z:u,p:m,g:h,f:h+Xf(m,t),parent:s}))}}}return null}var sp={c:null,u:[new V,new V,new V],e:[]},cp={c:null,u:[new V,new V,new V],e:[]},lp=[[],[],[]],q=[[],[],[]],up=[],dp=new V,fp=new V,pp=new V,mp=new V,hp=new V,gp=new V,_p=new H,vp=new pi,yp=new gr,bp=new gr,xp=new ra,Sp=class{constructor(e=new V,t=new V,n=new H){this.center=e,this.halfSize=t,this.rotation=n}set(e,t,n){return this.center=e,this.halfSize=t,this.rotation=n,this}copy(e){return this.center.copy(e.center),this.halfSize.copy(e.halfSize),this.rotation.copy(e.rotation),this}clone(){return new this.constructor().copy(this)}getSize(e){return e.copy(this.halfSize).multiplyScalar(2)}clampPoint(e,t){let n=this.halfSize;mp.subVectors(e,this.center),this.rotation.extractBasis(dp,fp,pp),t.copy(this.center);let r=Kn.clamp(mp.dot(dp),-n.x,n.x);t.add(dp.multiplyScalar(r));let i=Kn.clamp(mp.dot(fp),-n.y,n.y);t.add(fp.multiplyScalar(i));let a=Kn.clamp(mp.dot(pp),-n.z,n.z);return t.add(pp.multiplyScalar(a)),t}containsPoint(e){return mp.subVectors(e,this.center),this.rotation.extractBasis(dp,fp,pp),Math.abs(mp.dot(dp))<=this.halfSize.x&&Math.abs(mp.dot(fp))<=this.halfSize.y&&Math.abs(mp.dot(pp))<=this.halfSize.z}intersectsBox3(e){return this.intersectsOBB(Cp.fromBox3(e))}intersectsSphere(e){return this.clampPoint(e.center,gp),gp.distanceToSquared(e.center)<=e.radius*e.radius}intersectsOBB(e,t=2**-52){sp.c=this.center,sp.e[0]=this.halfSize.x,sp.e[1]=this.halfSize.y,sp.e[2]=this.halfSize.z,this.rotation.extractBasis(sp.u[0],sp.u[1],sp.u[2]),cp.c=e.center,cp.e[0]=e.halfSize.x,cp.e[1]=e.halfSize.y,cp.e[2]=e.halfSize.z,e.rotation.extractBasis(cp.u[0],cp.u[1],cp.u[2]);for(let e=0;e<3;e++)for(let t=0;t<3;t++)lp[e][t]=sp.u[e].dot(cp.u[t]);mp.subVectors(cp.c,sp.c),up[0]=mp.dot(sp.u[0]),up[1]=mp.dot(sp.u[1]),up[2]=mp.dot(sp.u[2]);for(let e=0;e<3;e++)for(let n=0;n<3;n++)q[e][n]=Math.abs(lp[e][n])+t;let n,r;for(let e=0;e<3;e++)if(n=sp.e[e],r=cp.e[0]*q[e][0]+cp.e[1]*q[e][1]+cp.e[2]*q[e][2],Math.abs(up[e])>n+r)return!1;for(let e=0;e<3;e++)if(n=sp.e[0]*q[0][e]+sp.e[1]*q[1][e]+sp.e[2]*q[2][e],r=cp.e[e],Math.abs(up[0]*lp[0][e]+up[1]*lp[1][e]+up[2]*lp[2][e])>n+r)return!1;return n=sp.e[1]*q[2][0]+sp.e[2]*q[1][0],r=cp.e[1]*q[0][2]+cp.e[2]*q[0][1],!(Math.abs(up[2]*lp[1][0]-up[1]*lp[2][0])>n+r||(n=sp.e[1]*q[2][1]+sp.e[2]*q[1][1],r=cp.e[0]*q[0][2]+cp.e[2]*q[0][0],Math.abs(up[2]*lp[1][1]-up[1]*lp[2][1])>n+r)||(n=sp.e[1]*q[2][2]+sp.e[2]*q[1][2],r=cp.e[0]*q[0][1]+cp.e[1]*q[0][0],Math.abs(up[2]*lp[1][2]-up[1]*lp[2][2])>n+r)||(n=sp.e[0]*q[2][0]+sp.e[2]*q[0][0],r=cp.e[1]*q[1][2]+cp.e[2]*q[1][1],Math.abs(up[0]*lp[2][0]-up[2]*lp[0][0])>n+r)||(n=sp.e[0]*q[2][1]+sp.e[2]*q[0][1],r=cp.e[0]*q[1][2]+cp.e[2]*q[1][0],Math.abs(up[0]*lp[2][1]-up[2]*lp[0][1])>n+r)||(n=sp.e[0]*q[2][2]+sp.e[2]*q[0][2],r=cp.e[0]*q[1][1]+cp.e[1]*q[1][0],Math.abs(up[0]*lp[2][2]-up[2]*lp[0][2])>n+r)||(n=sp.e[0]*q[1][0]+sp.e[1]*q[0][0],r=cp.e[1]*q[2][2]+cp.e[2]*q[2][1],Math.abs(up[1]*lp[0][0]-up[0]*lp[1][0])>n+r)||(n=sp.e[0]*q[1][1]+sp.e[1]*q[0][1],r=cp.e[0]*q[2][2]+cp.e[2]*q[2][0],Math.abs(up[1]*lp[0][1]-up[0]*lp[1][1])>n+r)||(n=sp.e[0]*q[1][2]+sp.e[1]*q[0][2],r=cp.e[0]*q[2][1]+cp.e[1]*q[2][0],Math.abs(up[1]*lp[0][2]-up[0]*lp[1][2])>n+r))}intersectsPlane(e){this.rotation.extractBasis(dp,fp,pp);let t=this.halfSize.x*Math.abs(e.normal.dot(dp))+this.halfSize.y*Math.abs(e.normal.dot(fp))+this.halfSize.z*Math.abs(e.normal.dot(pp)),n=e.normal.dot(this.center)-e.constant;return Math.abs(n)<=t}intersectRay(e,t){return this.getSize(hp),vp.setFromCenterAndSize(mp.set(0,0,0),hp),yp.setFromMatrix3(this.rotation),yp.setPosition(this.center),bp.copy(yp).invert(),xp.copy(e).applyMatrix4(bp),xp.intersectBox(vp,t)?t.applyMatrix4(yp):null}intersectsRay(e){return this.intersectRay(e,mp)!==null}fromBox3(e){return e.getCenter(this.center),e.getSize(this.halfSize).multiplyScalar(.5),this.rotation.identity(),this}equals(e){return e.center.equals(this.center)&&e.halfSize.equals(this.halfSize)&&e.rotation.equals(this.rotation)}applyMatrix4(e){let t=e.elements,n=mp.set(t[0],t[1],t[2]).length(),r=mp.set(t[4],t[5],t[6]).length(),i=mp.set(t[8],t[9],t[10]).length();e.determinant()<0&&(n=-n),_p.setFromMatrix4(e);let a=1/n,o=1/r,s=1/i;return _p.elements[0]*=a,_p.elements[1]*=a,_p.elements[2]*=a,_p.elements[3]*=o,_p.elements[4]*=o,_p.elements[5]*=o,_p.elements[6]*=s,_p.elements[7]*=s,_p.elements[8]*=s,this.rotation.multiply(_p),this.halfSize.x*=n,this.halfSize.y*=r,this.halfSize.z*=i,mp.setFromMatrixPosition(e),this.center.add(mp),this}},Cp=new Sp,wp=class{model;run;meshes;temporary;group=new Wr;bounds;siteBounds;leases;states=[];warnings=new Map;hiddenTargets=new Set;geom=new Set;materials=new Set;cube=this.ownGeometry(new Ya(1,1,1));cylinder=this.ownGeometry(new Xa(1,1,1,7));sphere=this.ownGeometry(new ro(1,9,6));yellow=this.material(14068796);dark=this.material(2571587);white=this.material(15329498);orange=this.material(14514235);blue=this.material(5536656);wood=this.material(10191195);metal=this.material(8688526);skin=this.material(12819835);black=this.material(2502700);window=this.material(7773085);cranes=[];trucks=[];crews=new Map;mixers=[];machines=new Map;forms=[];formStates=[];pit;cargo=new Map;boxes=new Map;completion=new Map;ray=new ys;floorMeshes;transitY;cargoMaxHalf=.3;roadX;stock=[];layout;spatialIssues=[];workerTasks=new Map;workerLeases=[];plannedWorkerLeases=0;workerPaths=new Map;accessRamps=[];constructor(e,t,n){this.model=e,this.run=t,this.meshes=n,this.group.name=`Event-driven construction site`,this.leases=Bf(t);for(let[e,t]of n)this.boxes.set(e,new pi().setFromObject(t));this.temporary=new qf(e,t,this.boxes),this.group.add(this.temporary.group),this.bounds=new pi;for(let t of e.elements)t.role===`element`&&this.boxes.has(t.id)&&this.bounds.union(this.boxes.get(t.id));this.bounds.isEmpty()&&this.bounds.set(new V(-1,0,-1),new V(1,1,1));for(let e of t.scenario.units)for(let n of e.target_ids)this.completion.set(n,t.operation_states[e.operation_ids.at(-1)].finish);this.floorMeshes=e.elements.filter(e=>e.hierarchy.includes(`IfcSlab`)&&n.has(e.id)).map(e=>n.get(e.id));let r=this.bounds.getSize(new V),i=1;for(let e of this.leases.filter(e=>e.resource===`crane`)){let t=this.targetBox(e).getSize(new V);this.cargoMaxHalf=Math.max(this.cargoMaxHalf,t.y/2),i=Math.max(i,Math.hypot(t.x,t.z)/2)}this.transitY=this.bounds.max.y+this.cargoMaxHalf+2.2,this.layout=Yf({minX:this.bounds.min.x,maxX:this.bounds.max.x,minZ:this.bounds.min.z,maxZ:this.bounds.max.z},t.scenario.resources,i),this.roadX=this.layout.bays.get(`truck:0`)?.park[0]??this.layout.bounds.minX+3;let a=e=>t.scenario.resources.find(t=>t.id===e)?.capacity??0,o=this.layout.bounds;this.siteBounds=new pi(new V(o.minX,0,o.minZ),new V(o.maxX,this.transitY+3,o.maxZ)),this.makeEnvironment(r);for(let e=0;e<a(`crane`);e++){let t=this.layout.cranes[e];this.cranes.push(this.makeCrane(t))}for(let e=0;e<a(`truck`);e++)this.trucks.push(this.makeTruck());for(let e of Jf){if(!t.scenario.operations.some(t=>t.demands[e]))continue;let n=[];for(let r=0;r<a(e);r++){let r=t.scenario.resources.find(t=>t.id===e)?.people_per_slot??(e===`inspector`?1:2),i=Array.from({length:r},()=>this.makePerson(e===`concrete_crew`?this.blue:e===`inspector`||e===`surveyor`?this.white:this.orange));if(e===`surveyor`){let e=i[0].root;for(let t of[0,Math.PI*2/3,Math.PI*4/3])this.rod(e,[.7,1.35,0],[.7+Math.cos(t)*.4,0,Math.sin(t)*.4],.025,this.yellow);this.box(e,[.24,.3,.26],[.7,1.5,0],this.yellow),this.box(e,[.1,.1,.3],[.7,1.52,.12],this.dark)}n.push(i)}this.crews.set(e,n)}for(let e=0;e<a(`mixer`);e++)this.mixers.push(this.makeMixer(e));for(let e of[`concrete_pump`,`excavator`,`dump_truck`,`compactor`,`vibrator`])this.machines.set(e,Array.from({length:a(e)},(t,n)=>this.makeMachine(e,n)));this.makeFormwork();let s=t.scenario.work_packages?.find(e=>e.pit_bounds_m);if(s?.pit_bounds_m){let[t,n]=s.pit_bounds_m,r=e.coordinate_system.render_origin_m;this.pit=this.box(this.group,[n[0]-t[0],.05,n[1]-t[1]],[(t[0]+n[0])/2-r[0],.005,-(t[1]+n[1])/2+r[1]],this.material(9401940)),this.pit.visible=!1}for(let e=0;e<10;e++){let t=new Wr;this.box(t,[.9,.12,.8],[0,.08,0],this.wood);for(let e=0;e<3;e++)this.box(t,[.85,.17,.72],[0,.24+e*.18,0],e===2?this.white:this.wood);t.position.set(this.layout.stock[0]+e%2*1.2,0,this.layout.stock[2]+Math.floor(e/2)*1.1),this.group.add(t),this.stock.push(t)}this.makePedestrianAccess(),this.workerLeases=this.leases.filter(e=>this.crews.has(e.resource)).sort((e,t)=>e.start-t.start||e.resource.localeCompare(t.resource)||e.slot-t.slot),this.update(0)}ownGeometry(e){return this.geom.add(e),e}material(e){let t=new go({color:e,roughness:.85,flatShading:!0});return this.materials.add(t),t}mesh(e,t,n){let r=new ga(t,n);return r.castShadow=!0,r.receiveShadow=!0,e.add(r),r}box(e,t,n,r){let i=this.mesh(e,this.cube,r);return i.scale.set(...t),i.position.set(...n),i}rod(e,t,n,r,i){let a=this.mesh(e,this.cylinder,i);return this.moveRod(a,t,n,r),a}moveRod(e,t,n,r){let i=new V(...t),a=new V(...n).sub(i);e.position.copy(i).addScaledVector(a,.5),e.scale.set(r,Math.max(.001,a.length()),r),e.quaternion.setFromUnitVectors(new V(0,1,0),a.normalize())}makeEnvironment(e){let t=this.siteBounds.min,n=this.siteBounds.max;this.box(this.group,[n.x-t.x,.08,n.z-t.z],[(n.x+t.x)/2,-.09,(n.z+t.z)/2],this.material(14342602));for(let e of this.layout.bays.values())if(!e.id.startsWith(`crane:`)&&!e.id.startsWith(`vibrator:`)){let t=e.envelope;this.box(this.group,[t.maxX-t.minX-.3,.025,t.maxZ-t.minZ],[e.park[0],-.025,(t.minZ+t.maxZ)/2],this.material(11580844))}let r=this.material(7505019),i=(e,t)=>{this.rod(this.group,[e[0],.05,e[2]],[e[0],1.3,e[2]],.035,r),this.rod(this.group,[e[0],1.2,e[2]],[t[0],1.2,t[2]],.025,r),this.rod(this.group,[e[0],.4,e[2]],[t[0],.4,t[2]],.018,r)};for(let e of[t.z,n.z])for(let r=t.x;r<n.x;r+=2.5)e===t.z&&Math.abs(r-this.roadX)<3.5||i([r,0,e],[Math.min(r+2.5,n.x),0,e]);for(let e of[t.x,n.x])for(let r=t.z;r<n.z;r+=2.5)i([e,0,r],[e,0,Math.min(r+2.5,n.z)]);let a=new Wr;this.box(a,[2.5,2.1,4],[0,1.05,0],this.material(7968139)),this.box(a,[2.7,.16,4.2],[0,2.16,0],this.white),this.box(a,[.04,.8,1],[1.26,1.3,-.8],this.window),this.box(a,[.04,1.7,.75],[1.26,.85,.8],this.white),a.position.set(...this.layout.cabin),this.group.add(a),this.sign(`IFC / CS`,[this.layout.cabin[0]+1.3,2,this.layout.cabin[2]],2.3),this.sign(`СКЛАД`,[this.layout.stock[0],1.7,this.layout.stock[2]+5],2.3),this.sign(`УСЛОВНАЯ ПЛОЩАДКА`,[(t.x+n.x)/2,.03,n.z-1.5],5,!0)}sign(e,t,n,r=!1){let i=document.createElement(`canvas`);i.width=512,i.height=96;let a=i.getContext(`2d`);a.fillStyle=`#e6e6d6`,a.fillRect(0,0,512,96),a.font=`600 32px Segoe UI`,a.fillStyle=`#435950`,a.textAlign=`center`,a.fillText(e,256,60);let o=new Ga(i),s=new ia({map:o,side:2});this.materials.add(s);let c=this.mesh(this.group,this.ownGeometry(new no(n,n*96/512)),s);c.position.set(...t),r&&(c.rotation.x=-Math.PI/2),c.userData.ownedTexture=o}makeCrane(e){let t=new Wr;t.position.set(...e),this.group.add(t),t.name=`Mobile telescopic crane`,this.box(t,[2.4,.4,7.2],[0,.85,0],this.dark),this.box(t,[2.35,.35,6.7],[0,1.2,0],this.yellow),this.box(t,[2.3,1.45,1.65],[0,1.85,2.65],this.yellow),this.box(t,[2.05,.7,.035],[0,2.05,3.49],this.window);for(let e of[-1,1]){this.box(t,[.035,.65,1.1],[e*1.16,2.05,2.6],this.window),this.box(t,[.3,.2,.08],[e*.8,1.4,3.5],this.white);for(let n of[-2.5,-1.25,1.5,2.8]){let r=this.mesh(t,this.cylinder,this.black);r.scale.set(.46,.25,.46),r.rotation.z=Math.PI/2,r.position.set(e*1.15,.48,n);let i=this.mesh(t,this.cylinder,this.metal);i.scale.set(.2,.27,.2),i.rotation.z=Math.PI/2,i.position.copy(r.position)}}let n=[];for(let e of[-1,1])for(let r of[-2,1.4]){let i=this.box(t,[1.3,.23,.3],[e*1.1,.65,r],this.yellow),a=new Wr;t.add(a),this.box(a,[1,.1,1],[0,.08,0],this.wood),this.rod(a,[0,.15,0],[0,.72,0],.07,this.metal),n.push({beam:i,foot:a,side:e,z:r})}let r=new Wr;r.position.y=Gf.pivotHeight,t.add(r),this.box(r,[1.6,.7,2.1],[-.5,-.25,0],this.yellow),this.box(r,[.9,1.2,1.15],[.05,.25,1.1],this.yellow),this.box(r,[.04,.75,.9],[.52,.4,1.1],this.window),this.box(r,[.7,.6,1.8],[-1.25,-.05,0],this.dark);let i=new Wr;r.add(i);let a=[.6,.5,.4,.3,.2].map((e,t)=>this.box(i,[Gf.retractedLength,e,e],[Gf.retractedLength/2,0,0],t===4?this.dark:this.yellow));this.rod(r,[.4,-.45,0],[2.4,.45,0],.09,this.metal);let o=this.rod(this.group,[e[0],3,e[2]],[e[0],2,e[2]],.018,this.dark),s=new Wr;return this.group.add(s),this.box(s,[.24,.35,.18],[0,-.1,0],this.yellow),this.rod(s,[0,-.2,0],[0,-.47,0],.035,this.dark),{root:t,slew:r,boom:i,sections:a,outriggers:n,rope:o,hook:s,slings:Array.from({length:4},()=>this.rod(this.group,[0,0,0],[0,1,0],.012,this.dark)),mast:e}}makeTruck(){let e=new Wr;this.group.add(e),this.box(e,[2.05,.28,5.5],[0,.68,0],this.dark),this.box(e,[2,1.35,1.45],[0,1.5,1.85],this.orange),this.box(e,[1.7,.65,.035],[0,1.75,2.59],this.window),this.box(e,[2.05,.2,3.75],[0,.94,-.75],this.wood),this.box(e,[2.08,.27,.16],[0,.55,2.7],this.white);let t=[];for(let n of[-1.02,1.02])for(let r of[-1.9,-.65,1.9]){let i=this.mesh(e,this.cylinder,this.black);i.scale.set(.36,.22,.36),i.rotation.z=Math.PI/2,i.position.set(n,.4,r),t.push(i)}let n=new Wr;e.add(n);for(let e=0;e<3;e++)this.box(n,[1.65,.45,.9],[0,1.27,-1.8+e*1.15],e===1?this.wood:this.white);return{root:e,wheels:t,load:n,gate:this.box(e,[1.9,.08,.95],[0,.9,-3.05],this.dark)}}makeMixer(e){let t=new Wr;this.group.add(t),this.box(t,[2,.3,4.8],[0,.7,0],this.dark),this.box(t,[1.9,1.4,1.35],[0,1.5,1.7],this.white),this.box(t,[1.65,.6,.04],[0,1.7,2.4],this.window);for(let e of[-1,1])for(let n of[-1.5,1.6]){let r=this.mesh(t,this.cylinder,this.black);r.scale.set(.36,.2,.36),r.rotation.z=Math.PI/2,r.position.set(e,.4,n)}let n=new Wr;n.position.set(0,1.65,-.5),t.add(n);let r=this.mesh(n,this.cylinder,this.white);return r.scale.set(.9,2.5,.9),r.rotation.x=Math.PI/2,this.box(n,[1.6,.1,.16],[0,.5,0],this.blue),t.position.set(...this.layout.bays.get(`mixer:${e}`).park),{root:t,drum:n}}makePerson(e){let t=new Wr;this.group.add(t),this.box(t,[.38,.52,.23],[0,1.06,0],e);for(let e of[-.12,.12])this.box(t,[.055,.45,.245],[e,1.06,.005],this.yellow);let n=this.mesh(t,this.sphere,this.skin);n.position.y=1.48,n.scale.set(.15,.18,.15);let r=this.mesh(t,this.sphere,this.yellow);r.position.y=1.62,r.scale.set(.19,.1,.19);let i=[],a=[-1,1].map(n=>{let r=new Wr;r.position.set(n*.25,1.26,0),t.add(r),this.box(r,[.12,.28,.14],[0,-.14,0],e);let a=new Wr;a.position.y=-.28,r.add(a),i.push(a),this.box(a,[.1,.26,.12],[0,-.13,0],e);let o=this.mesh(a,this.sphere,this.skin);return o.scale.set(.075,.09,.075),o.position.set(0,-.28,0),r}),o=[-1,1].map(e=>{let n=new Wr;return n.position.set(e*.105,.8,0),t.add(n),this.box(n,[.16,.68,.18],[0,-.35,0],this.dark),this.box(n,[.18,.12,.29],[0,-.73,.045],this.black),n}),s=new Wr;s.position.y=.8,t.add(s);for(let e of[...t.children])e!==s&&!o.includes(e)&&(t.updateMatrixWorld(!0),s.attach(e));let c=new Map;for(let e of[`hammer`,`trowel`,`wrench`,`pliers`,`hose`,`meter`,`probe`]){let t=new Wr;i[0].add(t),t.position.y=-.28,t.visible=!1,c.set(e,t),e===`meter`?this.box(t,[.18,.08,.27],[0,-.08,0],this.blue):e===`hose`?this.rod(t,[0,.1,0],[0,-.23,0],.04,this.black):e===`trowel`?(this.box(t,[.05,.17,.06],[0,-.06,0],this.wood),this.box(t,[.18,.025,.25],[0,-.15,0],this.metal)):(this.box(t,[.045,.22,.05],[0,-.07,0],e===`hammer`?this.wood:this.metal),this.box(t,[e===`probe`?.05:.16,.06,.065],[0,-.17,0],this.metal))}let l=this.mesh(this.group,this.sphere,this.orange);return l.scale.setScalar(.055),l.visible=!1,{root:t,body:s,tools:c,arms:a,forearms:i,legs:o,marker:l}}makeFormwork(){for(let e of this.run.scenario.units.filter(e=>e.kind===`concrete`)){let t=this.run.operation_states[`${e.id}:formwork`],n=this.run.operation_states[`${e.id}:stripping`];if(!t||!n)continue;let r=[],i=new V,a=new V,o=new V,s=new V;for(let t of e.target_ids){let n=this.meshes.get(t);if(!n)continue;let c=n.geometry,l=c.getAttribute(`position`),u=c.index;if(u)for(let t=0;t<u.count;t+=3){i.fromBufferAttribute(l,u.getX(t)).applyMatrix4(n.matrixWorld),a.fromBufferAttribute(l,u.getX(t+1)).applyMatrix4(n.matrixWorld),o.fromBufferAttribute(l,u.getX(t+2)).applyMatrix4(n.matrixWorld),s.crossVectors(a.clone().sub(i),o.clone().sub(i)).normalize();let c=e.lower[2]>(this.run.scenario.work_packages?.[0]?.ground_level_m??0)+.1;if(Math.abs(s.y)<.5||c&&s.y<-.5)for(let e of[i,a,o])r.push(...e.clone().addScaledVector(s,.045).toArray())}}if(!r.length)continue;let c=this.ownGeometry(new Ki);c.setAttribute(`position`,new Pi(r,3)),c.computeVertexNormals();let l=new Wr;this.group.add(l);let u=this.material(12752209);u.side=2;let d=this.mesh(l,c,u),f=new Ia(this.ownGeometry(new to(c,25)),new wa({color:4538162}));this.materials.add(f.material),l.add(f);let p=new pi().setFromBufferAttribute(c.getAttribute(`position`));for(let e of[p.min.x,p.max.x])for(let t of[p.min.z,p.max.z])this.rod(l,[e,p.min.y,t],[e,p.max.y,t],.04,this.dark);this.forms.push({unitId:e.id,root:l,mesh:d,triangles:r.length/9,install:t,strip:n,pour:this.run.operation_states[`${e.id}:concreting`].start})}}makeMachine(e,t){let n=new Wr;this.group.add(n);let r=[],i=[];if(e===`vibrator`)this.box(n,[.5,.45,.5],[0,.25,0],this.yellow),r.push(this.rod(n,[0,.4,0],[.5,.4,.5],.025,this.black));else if(e===`excavator`){for(let e of[-.95,.95])this.box(n,[3.5,.6,.5],[0,.4,e],this.dark);let e=new Wr;n.add(e),r.push(e),this.box(e,[2.4,.65,1.8],[0,.95,0],this.yellow),this.box(e,[1.1,1.4,.9],[-.3,1.9,.5],this.yellow),this.box(e,[1.12,.8,.04],[-.3,2.1,1],this.window),this.rod(e,[.7,1.3,0],[2.2,3.4,0],.16,this.yellow),this.rod(e,[2.2,3.4,0],[3.7,.8,0],.12,this.yellow),this.box(e,[.8,.55,1],[3.8,.55,0],this.dark)}else{this.box(n,[2.2,.3,e===`compactor`?3.2:5.8],[0,.75,0],this.dark),this.box(n,[2,1.5,1.5],[0,1.6,1.8],e===`concrete_pump`?this.white:this.yellow),this.box(n,[1.7,.7,.04],[0,1.9,2.57],this.window);for(let e of[-1,1])for(let t of[-1.6,1.7]){let r=this.mesh(n,this.cylinder,this.black);r.scale.set(.4,.23,.4),r.rotation.z=Math.PI/2,r.position.set(e,.45,t)}if(e===`concrete_pump`){this.box(n,[2.2,.7,3.4],[0,1.2,-.8],this.white);for(let e of[-1.7,1.7])this.box(n,[2.2,.12,.18],[e,.55,-.4],this.dark);for(let e=0;e<4;e++)i.push(this.rod(this.group,[0,0,0],[0,1,0],e===3?.045:.09,e===3?this.black:this.orange))}else if(e===`dump_truck`){let e=new Wr;n.add(e),r.push(e),this.box(e,[2.15,.25,3.4],[0,1.1,-.65],this.orange);for(let t of[-1,1])this.box(e,[.14,1.1,3.4],[t,1.7,-.65],this.yellow);this.box(e,[1.8,.8,3],[0,1.6,-.65],this.wood)}else this.box(n,[2.1,.8,1],[0,.5,-1.5],this.metal)}return n.position.set(...this.layout.bays.get(`${e}:${t}`).park),{root:n,moving:r,hose:i}}targetBox(e){let t=new pi;for(let n of e.operation.target_ids)this.boxes.has(n)&&t.union(this.boxes.get(n));return t.isEmpty()&&t.setFromCenterAndSize(new V((this.bounds.min.x+this.bounds.max.x)/2,.2,this.bounds.min.z-2),new V(2,.4,1)),t}completedAt(e){let t=new Set([...this.run.scenario.initial_element_ids??[],...[...this.completion].filter(([,t])=>t<=e).map(([e])=>e)]);for(let n of this.run.scenario.units)if((n.kind===`demolition`||this.run.scenario.element_phase_states?.[n.id]===`temporary`)&&this.run.operation_states[n.operation_ids.at(-1)].finish<=e)for(let e of n.target_ids)t.delete(e);return t}support(e,t,n,r){this.ray.set(new V(e,n+.15,t),new V(0,-1,0));for(let e of this.ray.intersectObjects(this.floorMeshes.filter(e=>r.has(String(e.userData.elementId))),!1)){let t=e.face?.normal.clone().transformDirection(e.object.matrixWorld);if(t&&Math.abs(t.y)>.8)return{y:e.point.y,id:String(e.object.userData.elementId)}}return e<this.bounds.min.x-.3||e>this.bounds.max.x+.3||t<this.bounds.min.z-.3||t>this.bounds.max.z+.3?{y:0,id:null}:null}stagingPoint(e,t,n){let r=this.layout.staging.get(`${e}:${t}`)??this.layout.cabin;return[r[0]+n*1.3,0,r[2]]}makePedestrianAccess(){if(this.model.source?.schema===`SyntheticDemo`)for(let e of this.floorMeshes){let t=String(e.userData.elementId),n=this.boxes.get(t);if(n.max.y<.2||n.max.y>.8||n.max.x-n.min.x<2)continue;let r=(n.min.x+n.max.x)/2+this.accessRamps.length*1.2,i=[r,0,n.max.z+2.5],a=[r,n.max.y,n.max.z+.05],o=[r,n.max.y,n.max.z-.4],s=new Wr;this.group.add(s);let c=Math.ceil(n.max.y/.16),l=(i[2]-a[2])/c;for(let e=0;e<c;e++)this.box(s,[.95,n.max.y*(e+1)/c,l],[r,n.max.y*(e+1)/c/2,i[2]-(e+.5)*l],this.wood);this.accessRamps.push({base:i,landing:a,top:o,floorId:t,root:s,ready:this.completion.get(t)??0})}}navigationWorld(e,t,n,r=e){let i=new Map,a=this.floorMeshes.filter(e=>r.has(String(e.userData.elementId))).map(e=>({mesh:e,box:this.boxes.get(String(e.userData.elementId))}));return{minX:this.siteBounds.min.x+.5,maxX:this.siteBounds.max.x-.5,minZ:this.siteBounds.min.z+.5,maxZ:this.siteBounds.max.z-.5,surface:(e,n)=>{let r=`${e.toFixed(4)},${n.toFixed(4)}`;if(i.has(r))return i.get(r);let o=null;for(let r of a)Math.abs(r.box.max.y-t)<=.2&&e-.23>=r.box.min.x&&e+.23<=r.box.max.x&&n-.23>=r.box.min.z&&n+.23<=r.box.max.z&&[[0,0],[-.23,-.23],[.23,-.23],[-.23,.23],[.23,.23]].every(([t,i])=>{this.ray.set(new V(e+t,r.box.max.y+.1,n+i),new V(0,-1,0));let a=this.ray.intersectObject(r.mesh,!1)[0];return a&&Math.abs(a.point.y-r.box.max.y)<.04})&&(o=Math.max(o??-1/0,r.box.max.y));return o===null&&Math.abs(t)<.2&&(e<this.bounds.min.x-.25||e>this.bounds.max.x+.25||n<this.bounds.min.z-.25||n>this.bounds.max.z+.25)&&(o=0),i.set(r,o),o},clear:t=>this.routeBodyClear(t,e)&&![...this.crews].some(([e,r])=>r.some((r,i)=>r.some((r,a)=>{let o=this.stagingPoint(e,i,a);return Xf(o,n)>.1&&Math.abs(t[1]-o[1])<1.75&&Math.hypot(t[0]-o[0],t[2]-o[2])<.6})))}}routeBodyClear(e,t){let n=new pi(new V(e[0]-.28,e[1]+.16,e[2]-.28),new V(e[0]+.28,e[1]+1.8,e[2]+.28));if([...t].some(e=>this.boxes.get(e)?.intersectsBox(n))||e[1]<3&&[...this.layout.bays.values()].some(t=>e[0]-.3<t.envelope.maxX&&e[0]+.3>t.envelope.minX&&e[2]-.3<t.envelope.maxZ&&e[2]+.3>t.envelope.minZ))return!1;let r=this.layout.cabin,i=this.layout.stock;return!(Math.abs(e[0]-r[0])<1.7&&Math.abs(e[2]-r[2])<2.5||e[0]>i[0]-.8&&e[0]<i[0]+2&&e[2]>i[2]-.8&&e[2]<i[2]+5.4)}contactAt(e,t,n){let r=new V(e[0],e[1]+1,e[2]),i=n.clampPoint(r,new V).lerp(n.getCenter(new V),.002);if(r.distanceTo(i)>1.3)return null;if(!t)return i.toArray();let a=this.meshes.get(t);if(!a)return null;this.ray.set(r,i.clone().sub(r).normalize());let o=this.ray.intersectObject(a,!1)[0];return o&&o.distance<1.3?o.point.toArray():null}routeTo(e,t,n,r){let i=this.completedAt(r),a=this.navigationWorld(n,0,e,i);if(Math.abs(t[1])<.2){let n=op(e,t,a);if(n)return{points:n,modes:n.slice(1).map(()=>`walk`),basis:[`mesh_support_and_body_clearance`]}}for(let o of this.accessRamps)if(o.ready<=r&&Math.abs(o.top[1]-t[1])<=.2){let r=op(e,o.base,a);if(!r)continue;let s=op(o.top,t,this.navigationWorld(n,o.top[1],e,i));if(!s||!Array.from({length:30},(e,t)=>t/29).every(e=>this.routeBodyClear(o.base.map((t,n)=>t+(o.landing[n]-t)*e),n)))continue;let c=[...r,o.landing,...s];return{points:c,modes:c.slice(1).map(()=>`walk`),basis:[`mesh_support_and_body_clearance`,`synthetic_demo_proposed_access_steps`]}}return null}planWorker(e,t){let n=this.stagingPoint(e.resource,e.slot,t),r=this.completedAt(e.start),i=new Set([...r,...this.completedAt(e.end),...[...this.completion].filter(([,t])=>t>=e.start&&t<=e.end).map(([e])=>e),...e.operation.target_ids]),a=e.operation.target_ids.filter(e=>this.boxes.has(e)),o=a.length?a[t%a.length]:null,s=o?this.boxes.get(o):this.targetBox(e),c=o?this.model.elements.find(e=>e.id===o)?.name??o:`Условный участок подготовительных работ`,l=[],u=this.temporary?.accessFor(e.operation.id,e.start,t);u&&l.push({position:u.position.toArray(),base:u.base.toArray(),top:u.top.toArray(),entry:u.entry.toArray(),basis:u.basis,until:u.availableUntil});let d=s.getCenter(new V),f=(t%2?1:-1)*(.4+Math.floor(t/2)*.7);for(let[e,t]of[[s.min.x-.55,d.z+f],[s.max.x+.55,d.z+f],[d.x+f,s.min.z-.55],[d.x+f,s.max.z+.55]]){let n=this.support(e,t,s.max.y,r);n&&l.push({position:[e,n.y,t]})}let p=`Не найден непрерывный маршрут с опорой от места сбора до рабочего места и обратно.`;for(let t of l){let r=this.contactAt(t.position,o,s);if(!r){p=`Элемент вне досягаемости инструмента с доступной опоры.`;continue}if(!this.reachableContact(t.position,r,Qf(e.operation.kind).tool)){p=`Инструмент не достаёт до поверхности из доступной рабочей позы.`;continue}if(!this.routeBodyClear(t.position,i))continue;let a=this.routeTo(n,t.base??t.position,i,e.start);if(!a)continue;if(t.base&&t.top&&t.entry){if(t.until<e.end){p=`Подмости разбираются до возвращения работника.`;continue}let n=[t.base,t.top,t.entry,t.position];if(!n.slice(1).every((e,t)=>Array.from({length:Math.ceil(Xf(n[t],e)/.12)+1},(r,i)=>i/Math.max(1,Math.ceil(Xf(n[t],e)/.12))).every(r=>this.routeBodyClear(n[t].map((t,n)=>t+(e[n]-t)*r),i)))){p=`Лестница или выход с неё пересекает конструкцию.`;continue}a.points.push(t.top,t.entry,t.position),a.modes.push(`climb`,`walk`,`walk`),a.basis.push(t.basis)}let l=ip(ep(e,n,t.position,r,o,c,a),[...this.workerTasks.values()]);if(l)return l;p=`Маршрут или рабочая позиция конфликтует с другой назначенной бригадой; свободное окно не найдено.`}return ep(e,n,n,s.getCenter(new V).toArray(),o,c,{points:[n],modes:[],basis:[]},p)}ensureWorkerPlans(e){for(;this.plannedWorkerLeases<this.workerLeases.length&&this.workerLeases[this.plannedWorkerLeases].start<=e;){let e=this.workerLeases[this.plannedWorkerLeases++],t=this.crews.get(e.resource)[e.slot];for(let n=0;n<t.length;n++){let t=`${e.resource}/${e.slot}/${e.operation.id}/${n}`,r=this.planWorker(e,n);if(this.workerTasks.set(t,r),!r.blocked){let e=this.ownGeometry(new Ki().setFromPoints(r.route.points.map(e=>new V(e[0],e[1]+.06,e[2])))),n=new yo({color:2263949,dashSize:.3,gapSize:.2,transparent:!0,opacity:.65});this.materials.add(n);let i=new Ma(e,n);i.computeLineDistances(),i.visible=!1,this.group.add(i),this.workerPaths.set(t,i)}}}}reachableContact(e,t,n){let r=Math.max(.05,Math.min(1.2,(1.15-(t[1]-e[1]))*1.1)),i=Math.atan2(t[0]-e[0],t[2]-e[2]),a=new V(-.25,.46,0).applyAxisAngle(new V(1,0,0),r);a.y+=.8-r*.35,a.applyAxisAngle(new V(0,1,0),i).add(new V(e[0],e[1]+.035,e[2]));let o=n===`meter`?.08:n===`trowel`?.15:n===`hose`?.23:.17,s=a.distanceTo(new V(...t))-o;return s>=.12&&s<=.56}aimWorkingHand(e,t,n,r){e.root.updateMatrixWorld(!0);let i=e.arms[0].getWorldPosition(new V),a=new V(...t).sub(i).normalize(),o=n===`meter`?.08:n===`trowel`?.15:n===`hose`?.23:.17,s=n===`hammer`?Math.max(0,Math.min(1,(r+1.5)/1.2))*.11:0,c=new V(...t).addScaledVector(a,-o-s),l=e.body.worldToLocal(c.clone()),u=e.arms[0].position,d=l.clone().sub(u),f=d.length(),p=d.normalize(),m=new V(0,-1,0).addScaledVector(p,p.y).normalize(),h=Math.min(1,f/.56),g=Math.sqrt(Math.max(0,1-h*h)),_=p.clone().multiplyScalar(h).addScaledVector(m,g);e.arms[0].quaternion.setFromUnitVectors(new V(0,-1,0),_);let v=l.clone().sub(u).addScaledVector(_,-.28).normalize().applyQuaternion(e.arms[0].quaternion.clone().invert());e.forearms[0].quaternion.setFromUnitVectors(new V(0,-1,0),v),e.root.updateMatrixWorld(!0);let y=e.tools.get(n),b=a.applyQuaternion(e.forearms[0].getWorldQuaternion(new qn).invert());y.quaternion.setFromUnitVectors(new V(0,-1,0),b)}getCargo(e){if(this.cargo.has(e.operation.id))return this.cargo.get(e.operation.id);let t=new Wr,n=new Wr;n.rotation.x=-Math.PI/2,t.add(n);let r=this.targetBox(e).getCenter(new V);for(let t of e.operation.target_ids){let e=this.meshes.get(t);if(!e)continue;let i=e.clone(!1);i.material=e.material.map(e=>{let t=e.clone();return t.clippingPlanes=[],t.color.set(14988892),this.materials.add(t),t}),i.visible=!0,i.position.set(-r.x,r.z,-r.y),n.add(i)}return this.group.add(t),this.cargo.set(e.operation.id,t),t}safeLift(e,t,n){let r=t[1]+n.y+.18,i=new pi(new V(t[0]-n.x,r,t[2]-n.z),new V(t[0]+n.x,this.transitY+n.y,t[2]+n.z));for(let t of this.completedAt(e.start))if(!e.operation.target_ids.includes(t)&&this.boxes.get(t)?.intersectsBox(i))return!1;return!0}equipmentObjects(){return[...this.cranes.map((e,t)=>({id:`crane:${t}`,roots:[e.root,e.rope,e.hook,...e.slings,...this.states.find(e=>e.id===`crane:${t}`)?.operationId?[this.cargo.get(this.states.find(e=>e.id===`crane:${t}`).operationId)].filter(e=>!!e):[]]})),...this.trucks.map((e,t)=>({id:`truck:${t}`,roots:[e.root]})),...this.mixers.map((e,t)=>({id:`mixer:${t}`,roots:[e.root]})),...[...this.machines].flatMap(([e,t])=>t.map((t,n)=>({id:`${e}:${n}`,roots:[t.root,...t.hose??[]]})))]}parts(e){let t=[];for(let n of e)n.traverseVisible(e=>{if(!(e instanceof ga))return;e.geometry.computeBoundingBox();let n=e.geometry.boundingBox;n&&!n.isEmpty()&&t.push({box:n.clone().applyMatrix4(e.matrixWorld),obb:new Sp().fromBox3(n).applyMatrix4(e.matrixWorld)})});return t}equipmentContacts(e){this.group.updateMatrixWorld(!0);let t=this.equipmentObjects().map(e=>({...e,parts:this.parts(e.roots)})),n=[...[...e].filter(e=>this.boxes.has(e)).map(e=>({id:`element:${e}`,box:this.boxes.get(e)})),...this.temporary.objects.filter(e=>e.root.visible).map(e=>({id:`temporary:${e.asset.id}`,box:new pi().setFromObject(e.root)}))],r=[];for(let e=0;e<t.length;e++){let i=t[e];for(let e of n)if(i.parts.some(t=>t.box.intersectsBox(e.box)&&t.obb.intersectsOBB(new Sp().fromBox3(e.box)))){r.push({actor:i.id,obstacle:e.id});break}for(let n of t.slice(e+1))i.parts.some(e=>n.parts.some(t=>e.box.intersectsBox(t.box)&&e.obb.intersectsOBB(t.obb)))&&r.push({actor:i.id,obstacle:n.id})}return r}enforceEquipmentClearance(e){let t=this.equipmentContacts(e);this.spatialIssues=t;let n=new Set(t.flatMap(e=>[e.actor,e.obstacle]));for(let e of n){let t=this.states.find(t=>t.id===e);if(!t)continue;let{resource:n,slot:r}=t;if(n===`crane`){let e=this.cranes[r],n=[e.mast[0],Gf.pivotHeight,e.mast[2]],i=[n[0],n[1]+Math.sin(.22)*Gf.retractedLength-.8,n[2]-Math.cos(.22)*Gf.retractedLength],a=Kf(n,i);e.slew.rotation.y=Math.PI/2,e.boom.rotation.z=a.angle,e.sections.forEach(e=>e.position.x=Gf.retractedLength/2),e.outriggers.forEach(e=>{e.beam.scale.x=1.3,e.beam.position.x=e.side*1.1,e.foot.position.set(e.side*1.65,.3,e.z)}),this.moveRod(e.rope,a.head,i,.018),e.hook.position.set(...i),e.slings.forEach(e=>e.visible=!1);let o=t.operationId?this.cargo.get(t.operationId):void 0;o&&(o.visible=!1),t.position=i,t.equipment&&Object.assign(t.equipment,{boomLength:a.length,boomAngle:a.angle,deployed:0,tip:a.head})}else{let i=n===`truck`?this.trucks[r]:n===`mixer`?this.mixers[r]:this.machines.get(n)?.[r];i&&(i.root.position.set(...this.layout.bays.get(e).park),t.position=i.root.position.toArray()),this.machines.get(n)?.[r].hose?.forEach(e=>e.visible=!1)}t.phase=`ожидание · пространственный конфликт`,this.warnings.set(`collision:${e}`,`${e}: движение или рабочая зона пересекает препятствие. Визуальное действие остановлено; требуется изменить размещение/очерёдность. Расчётный график не пересчитан.`)}}update(e){this.temporary?.update(e),this.states.length=0,this.hiddenTargets.clear(),this.warnings.clear(),this.spatialIssues=[];for(let e of this.temporary?.states??[])e.placementValid||this.warnings.set(e.id,`Для вышки-туры не найдено свободное место с опорой в предварительной геометрической проверке. Требуется уточнить размещение; показано сопровождение с площадки.`);this.formStates.length=0;for(let t of this.forms){let n=e<t.install.start||e>=t.strip.finish?0:e<t.install.finish?(e-t.install.start)/(t.install.finish-t.install.start):e>=t.strip.start?1-(e-t.strip.start)/(t.strip.finish-t.strip.start):1;if(t.root.visible=n>0,t.mesh.geometry.setDrawRange(0,Math.floor(t.triangles*n)*3),t.root.children.forEach(e=>{e!==t.mesh&&(e.visible=n>.25)}),n>0&&this.formStates.push({unitId:t.unitId,fraction:n,phase:e<t.install.finish?`монтаж опалубки`:e>=t.strip.start?`распалубка`:`опалубка установлена`}),e<t.pour)for(let e of this.run.scenario.units.find(e=>e.id===t.unitId).target_ids)this.hiddenTargets.add(e)}let t=this.run.operation_states[`site:excavation`],n=this.run.operation_states[`site:compaction`];this.pit&&(this.pit.visible=!!(t&&e>=t.start&&(!n||e<n.finish)));for(let e of this.cargo.values())e.visible=!1;let r=this.completedAt(e);for(let[t,n]of this.cranes.entries()){let i=Vf(this.leases,`crane`,t,e),a=[n.mast[0],Gf.pivotHeight,n.mast[2]],o=[a[0],a[1]+Math.sin(.22)*Gf.retractedLength-.8,a[2]-Math.cos(.22)*Gf.retractedLength],s=o,c=`стоянка · стрела сложена`,l=0,u=[...r].map(e=>this.boxes.get(e)).filter(e=>!!e).map(e=>({min:e.min.toArray(),max:e.max.toArray()}));if(i){let r=this.targetBox(i),d=r.getCenter(new V),f=r.getSize(new V).multiplyScalar(.5),p=[d.x,d.y,d.z],m=this.layout.pickups[t],h=[m[0],.35+f.y,m[2]],g=zf(i,e);l=Math.min(Lf(g/.05),Lf((1-g)/.02));let _=[h[0],this.transitY,h[2]],v=Wf(Math.max(0,Math.min(1,(g-.08)/.84)),n.mast,h,p,_,this.transitY,f.y),y=[v.hook[0],v.hook[1]+f.y+.55,v.hook[2]];if(g<.08)s=Rf(o,y,g/.08),c=`развёртывание автокрана`;else if(g>=.92){let e=[o[0],y[1],o[2]];s=g<.96?Rf(y,e,(g-.92)/.04):Rf(e,o,(g-.96)/.04),c=`складывание стрелы`}else s=y,c=v.phase;let b=Kf(a,s,u);if(this.safeLift(i,p,f)&&b.reachable){let e=this.getCargo(i);e.visible=v.loadVisible,e.position.set(...v.position),e.traverse(e=>{if(e instanceof ga)for(let t of e.material)t.transparent=v.opacity<1,t.opacity=v.opacity});for(let e of i.operation.target_ids)v.installed||this.hiddenTargets.add(e);for(let e=0;e<n.slings.length;e++){let t=n.slings[e];t.visible=v.attached&&v.loadVisible,this.moveRod(t,s,[v.position[0]+(e%2?1:-1)*f.x*.7,v.position[1]+f.y,v.position[2]+(e<2?1:-1)*f.z*.7],.012)}}else s=o,l=0,c=`траектория не подтверждена`,this.warnings.set(i.operation.id,`Подъём выходит за условный вылет стрелы или пересекает завершённую конструкцию; требуется уточнение техники и позиции.`),n.slings.forEach(e=>{e.visible=!1})}else n.slings.forEach(e=>{e.visible=!1});let d=Kf(a,s,u);n.slew.rotation.y=-Math.atan2(s[2]-a[2],s[0]-a[0]),n.boom.rotation.z=d.angle,n.sections.forEach((e,t)=>{e.position.x=Gf.retractedLength/2+t*(d.length-Gf.retractedLength)/(n.sections.length-1)});for(let e of n.outriggers){let t=.2+(Gf.outriggerWidth/2-1.2)*l;e.beam.scale.x=t,e.beam.position.x=e.side*(1+t/2),e.foot.visible=l>.05,e.foot.position.set(e.side*(1+t),0,e.z)}this.moveRod(n.rope,d.head,s,.018),n.hook.position.set(...s),this.states.push({id:`crane:${t}`,resource:`crane`,slot:t,operationId:i?.operation.id??null,active:!!i,phase:c,position:s,equipment:{type:Gf.type,boomLength:d.length,boomAngle:d.angle,deployed:l,tip:d.head,loadMassKg:null,status:Gf.evidence}})}for(let[t,n]of this.trucks.entries()){let r=Vf(this.leases,`truck`,t,e),{park:i,dock:a}=this.layout.bays.get(`truck:${t}`),o=Hf(r,e,i,a);n.root.position.set(...o.position),n.root.rotation.y=0,n.wheels.forEach(e=>{e.rotation.x=o.moving?o.travel*34:0});let s=r?zf(r,e):0;n.load.visible=!!r&&s<.63,n.load.position.y=o.unloading?-.35*Lf((s-.42)/.2):0,n.gate.scale.y=.08,this.states.push({id:`truck:${t}`,resource:`truck`,slot:t,operationId:r?.operation.id??null,active:!!r,phase:o.phase,position:o.position})}this.ensureWorkerPlans(e);for(let e of this.workerPaths.values())e.visible=!1;for(let t of this.accessRamps)t.root.visible=t.ready<=e;for(let[t,n]of this.crews)for(let[r,i]of n.entries()){let n=Vf(this.leases,t,r,e),a=[];for(let[o,s]of i.entries()){let i=n?this.workerTasks.get(`${t}/${r}/${n.operation.id}/${o}`):void 0;s.root.visible=!!i,s.marker.visible=!1;for(let e of s.tools.values())e.visible=!1,e.quaternion.identity();if(s.forearms.forEach(e=>e.quaternion.identity()),!i)continue;let c=this.workerPaths.get(`${t}/${r}/${n.operation.id}/${o}`);c&&(c.visible=!0);let l=tp(i,e,o),u=l.position;s.root.position.set(u[0],u[1]+.035,u[2]);let d=l.phase===`climb`?[0,0,1]:l.direction;s.root.rotation.y=Math.atan2(d[0],d[2]),s.body.rotation.x=l.phase===`work`?Math.max(.05,Math.min(1.2,(1.15-(i.contact[1]-u[1]))*1.1)):0,s.body.position.y=.8-s.body.rotation.x*.35,s.legs.forEach((e,t)=>e.rotation.x=l.walk*(t?-1:1)),s.arms.forEach((e,t)=>{e.quaternion.identity(),e.rotation.x=l.phase===`climb`?-2+l.walk*(t?-1:1):l.arm*(t&&l.phase!==`work`?-1:1)});let f=s.tools.get(i.tool);f.visible=l.phase!==`blocked`,l.phase===`work`&&(this.aimWorkingHand(s,i.contact,i.tool,l.arm),s.marker.visible=!0,s.marker.position.set(...i.contact)),i.blocked&&this.warnings.set(`worker:${t}:${r}:${o}`,`${i.targetName}: ${i.blocked} Назначение по графику не подтверждает выполнение работы.`),a.push({position:u,supportId:i.route.basis.includes(`assumed_external_tower_ladder`)?`temporary-access`:null,supported:!i.blocked,fallback:!!i.blocked,visible:!0,action:l.action,arm:l.arm,phase:l.phase,targetId:i.targetId,targetName:i.targetName,tool:i.tool,route:i.route.points,routeBasis:i.route.basis,reason:i.blocked,contact:i.contact,workProgress:l.progress})}this.states.push({id:`${t}:${r}`,resource:t,slot:r,operationId:n?.operation.id??null,active:!!n,phase:a.map(e=>e.action).filter((e,t,n)=>n.indexOf(e)===t).join(` / `)||`нет назначения`,position:i[0].root.position.toArray(),workers:a})}for(let[t,n]of this.mixers.entries()){let r=Vf(this.leases,`mixer`,t,e),{park:i,dock:a}=this.layout.bays.get(`mixer:${t}`),o=Hf(r,e,i,a);n.root.position.set(...o.position),n.root.visible=!!r,n.drum.rotation.z=r?zf(r,e)*18:0,this.states.push({id:`mixer:${t}`,resource:`mixer`,slot:t,operationId:r?.operation.id??null,active:!!r,phase:r?`доставка и подача бетонной смеси`:`ожидание назначения`,position:o.position})}for(let[t,n]of this.machines)for(let[r,i]of n.entries()){let n=Vf(this.leases,t,r,e),a=n?zf(n,e):0,o=this.layout.bays.get(`${t}:${r}`),s=[...o.dock];if(i.root.visible=!!n,n){if(t===`excavator`&&(i.root.rotation.y=Math.PI),(t===`dump_truck`||t===`compactor`)&&(s[2]=Hf(n,e,o.park,o.dock).position[2]),t===`vibrator`){let e=this.targetBox(n);s[0]=e.getCenter(new V).x+.8+r*.85,s[1]=e.max.y+.05,s[2]=e.getCenter(new V).z}i.moving.forEach(e=>{t===`excavator`&&(e.rotation.y=Math.sin(a*30)*.6),t===`dump_truck`&&(e.rotation.x=a>.65&&a<.85?-.3:0)})}if(i.root.position.set(...s),i.hose?.length&&(i.hose.forEach(e=>{e.visible=!!n}),n)){let e=this.targetBox(n).getCenter(new V),t=Math.max(this.bounds.max.y+3,5),r=e.x-s[0],a=e.z-s[2],o=[[s[0],1.8,s[2]],[s[0],t,s[2]],[s[0]+r*.5,t+1,s[2]+a*.5],[e.x,t,e.z],[e.x,e.y+.3,e.z]];i.hose.forEach((e,t)=>this.moveRod(e,o[t],o[t+1],t===3?.045:.09))}this.states.push({id:`${t}:${r}`,resource:t,slot:r,operationId:n?.operation.id??null,active:!!n,phase:n?{concrete_pump:`подача бетонной смеси к фронту`,excavator:`разработка / перемещение грунта`,dump_truck:`погрузка и вывоз / подвоз грунта`,compactor:`уплотнение слоя`,vibrator:`виброуплотнение бетона`}[t]:`ожидание назначения`,position:s})}let i=this.run.scenario.units.filter(t=>{let n=this.run.scenario.operations.find(e=>e.unit_id===t.id&&e.kind===`delivery`);if(!n||this.run.operation_states[n.id].finish>e)return!1;let r=t.operation_ids.find(e=>this.run.scenario.operations.find(t=>t.id===e)?.visual_phase===`work`);return r&&this.run.operation_states[r].start>e}).length;this.stock.forEach((e,t)=>{e.visible=t<Math.min(this.stock.length,i)}),this.enforceEquipmentClearance(r)}snapshot(){return{actors:structuredClone(this.states),warnings:[...this.warnings].map(([e,t])=>({operationId:e,message:t})),hiddenTargets:[...this.hiddenTargets],formwork:structuredClone(this.formStates),equipmentProfile:Gf,temporaryAccess:structuredClone(this.temporary?.states??[]),excavationProxyVisible:!!this.pit?.visible,spatialConflicts:structuredClone(this.spatialIssues),layoutBasis:`expandable_visual_site_not_surveyed`,truckRoadClearance:this.bounds.min.x-this.roadX,animationVersion:`0.6.0`}}dispose(){this.temporary?.dispose(),this.group.removeFromParent(),this.group.traverse(e=>{e.userData.ownedTexture?.dispose()}),this.geom.forEach(e=>e.dispose()),this.materials.forEach(e=>e.dispose()),this.group.clear()}};function Tp(e,t){let n=e>2e3;return{shadows:!n,pixelRatio:Math.min(t,n?1.25:2),edgeBudget:n?1e5:6e5}}var Ep=class{host;renderer;scene=new Qr;camera=new Qo(40,1,.01,1e4);controls;root=new Wr;meshes=new Map;raycaster=new ys;bounds=new pi;grid;lightTheme=()=>document.documentElement.dataset.theme!==`dark`;themeChanged=()=>{this.updateGridColors(),this.refreshPresentation()};updateGridColors(){if(!this.grid)return;let e=this.grid.geometry.getAttribute(`color`),t=new U(this.lightTheme()?11188421:3621709),n=new U(this.lightTheme()?13884644:2437177);for(let r=0;r<e.count;r++){let i=r>=56&&r<60?t:n;e.setXYZ(r,i.r,i.g,i.b)}e.needsUpdate=!0,this.invalidate()}ground;selected;highlightedElements=new Set;highlight;edges=new Map;xray=!1;sourceColors=!1;construction=null;showFuture=!1;site;model;clipPlanes=[];measureHandler=null;measurementOverlay;measureSnap=!0;captureView(){return{position:this.camera.position.toArray(),target:this.controls.target.toArray(),up:this.camera.up.toArray(),planes:this.clipPlanes.map(e=>({normal:e.normal.toArray(),constant:e.constant})),xray:this.xray}}restoreView(e){if([e.position,e.target,e.up].some(e=>e.length!==3||!e.every(Number.isFinite))||e.up.every(e=>e===0)||e.planes.length>6||e.planes.some(e=>e.normal.length!==3||!e.normal.every(Number.isFinite)||!Number.isFinite(e.constant)||Math.abs(Math.hypot(...e.normal)-1)>1e-5))throw Error(`Неверное состояние камеры или сечений`);this.camera.position.fromArray(e.position),this.controls.target.fromArray(e.target),this.camera.up.fromArray(e.up),this.xray=e.xray,this.applyClip(e.planes.map(e=>new Xi(new V(...e.normal),e.constant))),this.controls.update(),this.refreshPresentation()}setMeasureHandler(e){this.measureHandler=e,this.renderer.domElement.style.cursor=e?`crosshair`:``}showMeasurement(e){if(this.measurementOverlay){this.scene.remove(this.measurementOverlay);for(let e of this.measurementOverlay.children)e instanceof Ha&&e.material.dispose();this.measurementOverlay.geometry.dispose(),this.measurementOverlay.material.dispose(),this.measurementOverlay=void 0}if(e.length&&this.model){let t=this.model.coordinate_system.render_origin_m,n=e.map(e=>new V(e[0]-t[0],e[2]-t[2],-(e[1]-t[1])));n.length===1&&n.push(n[0].clone().add(new V(0,.04,0))),this.measurementOverlay=new Ma(new Ki().setFromPoints(n),new wa({color:15709790,depthTest:!1})),this.measurementOverlay.renderOrder=100;let r=new Ha(this.measurementOverlay.geometry,new La({color:16766082,size:7,sizeAttenuation:!1,depthTest:!1}));r.renderOrder=101,this.measurementOverlay.add(r),this.scene.add(this.measurementOverlay)}this.invalidate()}currentElements=[];observer;frame=0;pointerStart={x:0,y:0};onPick;constructor(e,t){this.host=e,this.onPick=t,this.renderer=new Qu({antialias:!0,alpha:!0}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,2)),this.renderer.setClearColor(1185821,0),document.addEventListener(`theme-change`,this.themeChanged),this.renderer.outputColorSpace=nn,this.renderer.toneMapping=4,this.renderer.toneMappingExposure=1.05,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=1,this.renderer.localClippingEnabled=!0;let n=this.renderer.domElement;n.setAttribute(`aria-label`,`3D-модель. Мышь: вращение, правая кнопка: перемещение, колесо: масштаб. Стрелки: перемещение. F: вся модель. Escape: снять выделение.`),n.tabIndex=0,this.host.append(n),this.controls=new Cf(this.camera,n),this.controls.enableDamping=!1,this.controls.screenSpacePanning=!0,this.controls.listenToKeyEvents(n),this.controls.addEventListener(`change`,this.invalidate),this.root.rotation.x=-Math.PI/2,this.scene.add(this.root),this.scene.add(new Bo(15199732,5464173,2.1));let r=new ts(16774623,3);r.position.set(18,28,18),r.castShadow=!0,r.shadow.mapSize.set(2048,2048),r.shadow.bias=-2e-4,r.shadow.normalBias=.035,this.scene.add(r);let i=new ts(14280695,1.3);i.position.set(-15,10,-10),this.scene.add(i),this.observer=new ResizeObserver(()=>{let{width:e,height:t}=this.host.getBoundingClientRect();this.renderer.setSize(e,t),this.camera.aspect=e/Math.max(t,1),this.camera.updateProjectionMatrix(),this.invalidate()}),this.observer.observe(e),n.addEventListener(`pointerdown`,e=>{this.pointerStart={x:e.clientX,y:e.clientY}}),n.addEventListener(`pointerup`,e=>{if(e.button!==0||Math.hypot(e.clientX-this.pointerStart.x,e.clientY-this.pointerStart.y)>4)return;let t=n.getBoundingClientRect();this.raycaster.setFromCamera(new B((e.clientX-t.left)/t.width*2-1,-(e.clientY-t.top)/t.height*2+1),this.camera);let r=[...this.meshes.values()].filter(e=>e.visible);for(let e of this.edges.values())e.userData.sourceLines&&e.parent?.visible&&r.push(e);this.raycaster.params.Line.threshold=Math.max(.001,this.bounds.getSize(new V).length()*.001);let i=this.raycaster.intersectObjects(r,!1).find(e=>this.clipPlanes.every(t=>t.distanceToPoint(e.point)>=-1e-7));if(this.measureHandler){if(i&&this.model){let n=this.model.coordinate_system.render_origin_m,r=i.point.clone(),a=`surface`,o=[];if(this.measureSnap&&i.face){let n=i.object,s=n.geometry.getAttribute(`position`),c=[i.face.a,i.face.b,i.face.c],l=c.map(e=>new V().fromBufferAttribute(s,e).applyMatrix4(n.matrixWorld)),u=e=>{let n=e.clone().project(this.camera);return new B((n.x+1)*t.width/2,(1-n.y)*t.height/2)},d=new B(e.clientX-t.left,e.clientY-t.top),f=12;for(let e=0;e<3;e++){let t=u(l[e]).distanceTo(d);t<f&&(f=t,r=l[e],a=`vertex`,o=[c[e]])}if(a===`surface`)for(let e=0;e<3;e++){let t=new As(l[e],l[(e+1)%3]).closestPointToPoint(i.point,!0,new V),n=u(t).distanceTo(d);n<f&&(f=n,r=t,a=`edge`,o=[c[e],c[(e+1)%3]])}this.clipPlanes.some(e=>e.distanceToPoint(r)<-1e-7)&&(r=i.point,a=`surface`,o=[])}this.measureHandler({element_id:String(i.object.userData.elementId),point_m:[r.x+n[0],-r.z+n[1],r.y+n[2]],triangle_index:i.faceIndex??null,snap:a,vertex_indices:o})}}else this.onPick(i?String(i.object.userData.elementId):null,e.ctrlKey||e.metaKey||e.shiftKey)}),n.addEventListener(`keydown`,e=>{e.key.toLowerCase()===`f`&&(e.preventDefault(),this.fit()),e.key===`Escape`&&(this.onPick(null),this.host.dispatchEvent(new CustomEvent(`measurement-cancel`)))}),n.addEventListener(`webglcontextlost`,t=>{t.preventDefault(),e.dispatchEvent(new CustomEvent(`viewer-error`,{detail:`Графический контекст потерян. Перезагрузите страницу, чтобы восстановить 3D-просмотр.`}))})}invalidate=()=>{this.frame||=requestAnimationFrame(()=>{this.frame=0,this.renderer.render(this.scene,this.camera)})};load(e,t){De(e,t),this.clearModel(),this.model=e,this.currentElements=e.elements;let n=Tp(e.statistics.physical_elements,window.devicePixelRatio);this.renderer.shadowMap.enabled=n.shadows,this.renderer.setPixelRatio(n.pixelRatio);let r=n.edgeBudget;for(let n of e.elements){let e=n.mesh;if(!e)continue;let i=new Ki;i.setAttribute(`position`,new ji(new Float32Array(t,e.position_byte_offset,e.vertex_count*3),3)),i.setIndex(new ji(e.primitive===`lines`?new Uint32Array:new Uint32Array(t,e.index_byte_offset,e.index_count),1)),i.computeBoundingSphere();for(let t of e.groups)i.addGroup(t.start,t.count,t.material_index);let a=e.styles.map(e=>{let t=n.role===`feature`||n.role===`space`;return new go({color:t?new U(n.role===`space`?6333880:15049804):new U().setRGB(...e.color,nn),side:2,roughness:.85,metalness:.02,flatShading:!0,transparent:t||e.opacity<1,opacity:t?.16:e.opacity,depthWrite:!t&&e.opacity>=1})}),o=new ga(i,a);if(o.userData.elementId=n.id,o.userData.role=n.role,o.userData.filterVisible=n.role===`element`,o.userData.baseColors=a.map(e=>e.color.clone()),o.castShadow=n.role===`element`,o.receiveShadow=!0,o.visible=n.role===`element`,e.primitive===`lines`){let r=i.clone();r.clearGroups(),r.setIndex(new ji(new Uint32Array(t,e.index_byte_offset,e.index_count),1));let s=new Ia(r,new wa({color:a[0]?.color??5793911}));s.userData={elementId:n.id,sourceLines:!0},o.add(s),this.edges.set(n.id,s)}else if(n.role===`element`&&e.index_count<=Math.min(r,15e4)){let t=new Ia(new to(i,25),new wa({color:5793911,transparent:!0,opacity:.25,depthWrite:!1}));o.add(t),this.edges.set(n.id,t),r-=e.index_count,a.forEach(e=>{e.polygonOffset=!0,e.polygonOffsetFactor=1,e.polygonOffsetUnits=1})}this.root.add(o),this.meshes.set(n.id,o)}this.root.updateMatrixWorld(!0);let i=e.coordinate_system.render_origin_m,a=e=>new V(e[0]-i[0],e[2]-i[2],-(e[1]-i[1]));this.bounds.setFromPoints([a(e.coordinate_system.bounds_min_m),a(e.coordinate_system.bounds_max_m)]);let o=this.bounds.getSize(new V),s=Math.max(o.x,o.z,5);this.grid=new js(Math.ceil(s*2.4),28,3621709,2437177),this.updateGridColors(),this.grid.position.set(this.bounds.getCenter(new V).x,this.bounds.min.y-.04,this.bounds.getCenter(new V).z),this.scene.add(this.grid),this.ground=new ga(new no(s*5,s*5),new io({color:0,opacity:.3})),this.ground.rotation.x=-Math.PI/2,this.ground.position.copy(this.grid.position),this.ground.position.y=this.bounds.min.y-.025,this.ground.receiveShadow=!0,this.scene.add(this.ground);let c=this.scene.children.find(e=>e instanceof ts&&e.castShadow);Object.assign(c.shadow.camera,{left:-s,right:s,top:s,bottom:-s,far:s*8}),c.position.set(s,s*1.8,s),c.shadow.camera.updateProjectionMatrix(),this.camera.near=Math.max(s/1e4,.001),this.camera.far=s*1e3,this.controls.minDistance=s*.015,this.controls.maxDistance=s*50,this.fit(),this.host.dataset.renderReady=`true`,this.host.dataset.meshCount=String(this.meshes.size)}fit(e=`iso`,t=!1){if(this.camera.up.set(0,1,0),this.bounds.isEmpty())return;let n=this.site?.group.visible?this.site.siteBounds:this.bounds,r=this.selected?this.meshes.get(this.selected):null;t&&r&&(n=new pi().setFromObject(r));let i=n.getCenter(new V),a=n.getSize(new V),o=Kn.degToRad(this.camera.fov/2),s=e===`top`?new V(0,1,1e-4):e===`front`?new V(0,.14,1):new V(1,.82,1.2);s.normalize();let c=new V(0,1,0).cross(s).normalize(),l=s.clone().cross(c),u=1;for(let e of[-.5,.5])for(let t of[-.5,.5])for(let n of[-.5,.5]){let r=new V(a.x*e,a.y*t,a.z*n),i=r.dot(s);u=Math.max(u,i+Math.abs(r.dot(c))/(Math.tan(o)*this.camera.aspect),i+Math.abs(r.dot(l))/Math.tan(o))}u*=1.08,this.controls.target.copy(i),this.camera.position.copy(i).addScaledVector(s.normalize(),u),this.camera.lookAt(i),this.camera.updateProjectionMatrix(),this.controls.update(),this.invalidate()}orient(e,t){if(this.bounds.isEmpty())return;let n=new V(e[0],e[2],-e[1]).normalize(),r=new V(t[0],t[2],-t[1]).normalize(),i=r.clone().cross(n).normalize();r.copy(n).cross(i).normalize();let a=this.bounds.getCenter(new V),o=this.bounds.getSize(new V),s=Math.tan(Kn.degToRad(this.camera.fov/2)),c=1;for(let e of[-.5,.5])for(let t of[-.5,.5])for(let a of[-.5,.5]){let l=new V(o.x*e,o.y*t,o.z*a),u=l.dot(n);c=Math.max(c,u+Math.abs(l.dot(i))/(s*this.camera.aspect),u+Math.abs(l.dot(r))/s)}this.camera.up.copy(r),this.controls.target.copy(a),this.camera.position.copy(a).addScaledVector(n,c*1.08),this.camera.lookAt(a),this.camera.updateProjectionMatrix(),this.controls.update(),this.invalidate()}show(e){let t=0;for(let[n,r]of this.meshes)r.userData.filterVisible=e.has(n),r.visible=e.has(n),r.visible&&t++;this.host.dataset.visibleMeshes=String(t),this.refreshPresentation(),this.invalidate()}select(e){this.selected=e??void 0,this.highlight&&=(this.scene.remove(this.highlight),this.highlight.dispose(),void 0);let t=e?this.meshes.get(e):void 0;t&&(this.highlight=new Ms(new pi().setFromObject(t),new U(15709790)),this.scene.add(this.highlight)),this.refreshPresentation()}highlightElements(e){this.highlightedElements=new Set(e),this.refreshPresentation()}setXray(e,t){this.xray=e,this.currentElements=t,this.refreshPresentation()}setSourceColors(e){this.sourceColors=e,this.refreshPresentation()}setConstruction(e,t=!1){this.showFuture=t,this.construction=e,this.refreshPresentation()}setSite(e,t=0){e?(this.site?.run.run_id!==e.run_id&&this.model&&(this.site?.dispose(),this.site=new wp(this.model,e,this.meshes),this.scene.add(this.site.group)),this.site&&(this.site.group.visible=!0,this.site.update(t),this.invalidate())):this.site&&(this.site.group.visible=!1)}siteState(){return this.site?.snapshot()??null}focusWorkerRoute(e){let t=(this.site?.states.filter(t=>t.operationId===e).flatMap(e=>e.workers??[])??[]).flatMap(e=>e.route.length?e.route:[e.position]);if(!t.length)return;let n=new pi().setFromPoints(t.map(e=>new V(...e)));n.max.y+=1.8;let r=n.getCenter(new V),i=n.getSize(new V),a=Math.max(8,i.length()*1.6)*Math.max(1,1/this.camera.aspect);this.controls.target.copy(r),this.camera.position.copy(r).addScaledVector(new V(1,.9,1.2).normalize(),a),this.camera.lookAt(r),this.controls.update(),this.invalidate()}focusTargets(e,t=.8,n=.65){let r=new pi;for(let t of e){let e=this.meshes.get(t);e&&r.union(new pi().setFromObject(e))}if(r.isEmpty()){this.cameraOrbit(t,n,.86,`site`);return}let i=r.getCenter(new V),a=r.getSize(new V),o=Math.max(9,a.length()*1.7)*Math.max(1,1/this.camera.aspect);this.controls.target.copy(i),this.camera.position.copy(i).add(new V(Math.cos(t)*Math.cos(n),Math.sin(n),Math.sin(t)*Math.cos(n)).multiplyScalar(o)),this.camera.lookAt(i),this.controls.update(),this.invalidate()}cutaway(e){this.applyClip(e===null?[]:[new Xi(new V(0,-1,0),e)])}section(e,t,n=!1){if(!this.model)return;let r=ff(this.model.coordinate_system,e,t,n);return this.applyClip([new Xi(new V(...r.normal),r.constant)]),r.value}sectionBox(e=!1){let t=this.selected?this.meshes.get(this.selected):null;if(e&&!t)return!1;let n=e?new pi().setFromObject(t).expandByScalar(.05):this.bounds.clone();return this.applyClip([new Xi(new V(1,0,0),-n.min.x),new Xi(new V(-1,0,0),n.max.x),new Xi(new V(0,1,0),-n.min.y),new Xi(new V(0,-1,0),n.max.y),new Xi(new V(0,0,1),-n.min.z),new Xi(new V(0,0,-1),n.max.z)]),!0}applyClip(e){this.clipPlanes=e;for(let t of this.meshes.values())for(let n of t.material)n.clippingPlanes=e,n.clipShadows=!0,n.needsUpdate=!0;for(let t of this.edges.values())t.material.clippingPlanes=e,t.material.needsUpdate=!0;if(this.highlight){let t=Array.isArray(this.highlight.material)?this.highlight.material:[this.highlight.material];for(let n of t)n.clippingPlanes=e,n.needsUpdate=!0}this.invalidate()}cameraOrbit(e,t,n=1,r=`site`,i=[0,0,0]){let a=r===`site`&&this.site?this.site.siteBounds:this.bounds,o=a.getCenter(new V).add(new V(...i)),s=a.getSize(new V).length()/(2*Math.tan(Kn.degToRad(this.camera.fov/2)))*n*Math.max(1,1/this.camera.aspect);this.controls.target.copy(o),this.camera.position.copy(o).add(new V(Math.cos(e)*Math.cos(t),Math.sin(t),Math.sin(e)*Math.cos(t)).multiplyScalar(s)),this.camera.lookAt(o),this.controls.update(),this.invalidate()}modelHeight(){return{min:this.bounds.min.y,max:this.bounds.max.y}}refreshPresentation(){for(let e of this.currentElements){let t=this.meshes.get(e.id);if(!t||!e.mesh)continue;let n=this.construction?.get(e.id);t.visible=!!t.userData.filterVisible&&(!this.construction||n===`active`||n===`complete`||n===`future`&&this.showFuture),this.construction&&this.site?.group.visible&&this.site.hiddenTargets.has(e.id)&&(t.visible=!1);let r=[n,this.showFuture,this.sourceColors,this.xray,this.selected===e.id,this.highlightedElements.has(e.id),this.lightTheme()].join(`|`);if(t.userData.appearance===r)continue;t.userData.appearance=r,t.material.forEach((r,i)=>{let a=e.role===`space`||e.role===`feature`?.16:e.mesh.styles[i].opacity;if(r.color.copy(t.userData.baseColors[i]),this.sourceColors&&e.role===`element`){let t=this.model?.federation?.members.findIndex(t=>t.instance_id===e.source_instance_id)??-1;t>=0&&r.color.set([13219730,5739705,7840394,10779025][t%4])}this.highlightedElements.has(e.id)&&r.color.set(2606272),(n===`active`||this.selected===e.id)&&r.color.set(15709790),r.emissive.set(this.selected===e.id?8411926:this.highlightedElements.has(e.id)?555897:0),r.emissiveIntensity=this.selected===e.id?.34:this.highlightedElements.has(e.id)?.3:0;let o=n===`future`&&this.showFuture?this.edges.has(e.id)?.035:.12:n===`active`?.85:this.xray&&e.role===`element`?Math.min(a,.2):a,s=o<1;r.transparent!==s&&(r.transparent=s,r.needsUpdate=!0),r.opacity=o,r.depthWrite=o>=1});let i=this.edges.get(e.id);i&&(i.userData.sourceLines?(i.material.color.copy(t.material[0].color),i.material.opacity=t.material[0].opacity,i.material.transparent=t.material[0].transparent):(i.material.opacity=n===`future`?.5:.3,i.material.color.set(this.selected===e.id||n===`active`?15709790:n===`future`?9214888:this.lightTheme()?6583686:4214876)))}this.highlight&&(this.highlight.visible=!!this.selected&&this.meshes.get(this.selected)?.visible===!0),this.invalidate()}clearModel(){this.site?.dispose(),this.site=void 0,this.clipPlanes=[],this.showMeasurement([]),this.select(null);for(let e of this.edges.values())e.geometry.dispose(),e.material.dispose();this.edges.clear();for(let e of this.meshes.values()){e.geometry.dispose();for(let t of e.material)t.dispose()}this.meshes.clear(),this.root.clear(),this.xray=!1,this.construction=null,this.currentElements=[];for(let e of[this.grid,this.ground])e&&(this.scene.remove(e),e.geometry.dispose(),(Array.isArray(e.material)?e.material:[e.material]).forEach(e=>e.dispose()));this.grid=void 0,this.ground=void 0}dispose(){this.clearModel(),this.observer.disconnect(),document.removeEventListener(`theme-change`,this.themeChanged),this.controls.dispose(),cancelAnimationFrame(this.frame),this.renderer.dispose()}},Dp=new WeakMap;function Op(e,t){let n=Dp.get(e);for((!n||t<n.tick)&&(n={tick:-1/0,cursor:0,states:new Map,resources:new Map(e.scenario.resources.map(e=>[e.id,0])),operations:new Map(e.scenario.operations.map(e=>[e.id,e]))},Dp.set(e,n));n.cursor<e.events.length&&e.events[n.cursor].time<=t;){let t=e.events[n.cursor++];t.kind===`operation_ready`&&n.states.set(t.operation_id,`ready`),t.kind===`resource_wait`&&n.states.set(t.operation_id,`waiting`),t.kind===`operation_started`&&n.states.set(t.operation_id,`running`),t.kind===`operation_completed`&&n.states.set(t.operation_id,`completed`),t.resource_id&&t.used!==void 0&&n.resources.set(t.resource_id,t.used)}n.tick=t;let r=new Map(n.states),i=new Map(n.resources),a=e.scenario.operations.filter(e=>r.get(e.id)===`running`),o=e.scenario.operations.filter(e=>r.get(e.id)===`waiting`),s=[...r.values()].filter(e=>e===`completed`).length,c=new Map;for(let t of e.scenario.initial_element_ids??[])c.set(t,`complete`);for(let t of e.scenario.excluded_element_ids??[])c.set(t,`absent`);let l=n.operations;for(let t of e.scenario.units){let n=t.operation_ids.length>0&&t.operation_ids.every(e=>r.get(e)===`completed`),i=t.operation_ids.some(e=>l.get(e).visual_phase===`work`&&[`running`,`completed`].includes(r.get(e)??``)),a=t.kind===`demolition`||e.scenario.element_phase_states?.[t.id]===`temporary`;for(let e of t.target_ids)c.set(e,a&&n?`absent`:n?`complete`:i?`active`:t.kind===`demolition`?`complete`:`future`)}return{states:r,resources:i,active:a,waiting:o,completed:s,construction:c}}var kp=class{time=0;playing=!1;rate=60;duration;constructor(e){this.duration=e}seek(e){this.time=Math.min(this.duration,Math.max(0,e))}advance(e){return this.playing&&this.seek(this.time+Math.max(0,e)*this.rate/60),this.time>=this.duration&&(this.playing=!1),this.time}},Ap=!0,J=e=>document.getElementById(e),jp=null,Mp=null,Np=null,Pp=[],Y=e=>String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),Fp=null,Ip=new Set,Lp=new Set,Rp=[],zp=`view`,Bp=null,Vp=new URL(location.href).searchParams.get(`project`)||``,Hp=Vp||`browser-local`,Up=[],Wp=null,Gp=0,Kp=!1,qp=new URL(location.href).searchParams.get(`model`)||``,Jp=new URL(location.href).searchParams.get(`run`)||``,X=null,Z=null,Q=null,$=null,Yp=0,Xp=0,Zp=0,Qp=0,$p=new Zd,em=``,tm=[],nm=[],rm=new Map,im=Vp;document.getElementById(`app`).innerHTML=od;var am=nf(J(`element-tree`),$p,{select:(e,t)=>{gm(e,t),t||X?.focusTargets([e])},show:Qm,isolate:$m,document:dm}),om=uf(J(`level-filter`),`Уровни`,Hm),sm=uf(J(`category-filter`),`Категории`,Hm);F(),Yd(),Xd(()=>Z,e=>{gm(e),X?.focusTargets([e])});var cm=ce({shared:!1,model:()=>Z,documents:()=>[...rm.values()],project:()=>Hp,matches:()=>tm.map(e=>e.id),selection:()=>[...Ip],show:e=>{Ip.clear();for(let t of e)Ip.add(t);Fp=e[0]??null,xm(),gm(Fp),Ip.clear();for(let t of e)Ip.add(t);xm(),X?.focusTargets(e)}}),lm=Bd(e=>{let t=o(e);t&&X&&Z&&(Bm(`view`),J(`reset-visibility`).click(),X.orient(t.direction,t.up),J(`workspace-status`).textContent=`Ориентация вида · реконструкция без оформления, обрезки и фильтров Revit`)},()=>{Bm(`view`),J(`reset-visibility`).click()},{});function um(e){e?.source?.sha256&&rm.set(e.source.sha256,e),lm.set(e),lm.geometryReady(!!X&&!!Z&&!Z.federation&&Z.source.sha256===e?.source?.sha256&&Z.statistics.meshes>0),Ym()}function dm(e,t){let n=!!X&&!!Z&&!Z.federation&&Z.source.sha256===e.source?.sha256;lm.openRecord(e,t,n)}async function fm(e,t){}function pm(e){{let[t,n=``]=e.split(`?`),r=new URLSearchParams(n);if(t===`models`||t===`runs`)return`./demo/`+t+`.json`;if(t===`model`)return`./demo/model-`+r.get(`model_id`)+`.json`;if(t===`geometry.bin`)return`./demo/geometry-`+r.get(`model_id`)+`.bin`;if(t===`run`)return`./demo/run-`+r.get(`run_id`)+`.json`;if(t===`schedule.csv`)return`./demo/schedule-`+r.get(`run_id`)+`.csv`;throw Error(`В демо доступны сохранённые модели и расчёты.`)}}async function mm(e){let t=await fetch(pm(e)),n=await t.json();if(!t.ok)throw Error(n.error);return n}function hm(e){J(`error`).hidden=!1,J(`error`).textContent=e instanceof Error?e.message:String(e)}function gm(e,t=!1){t||Ip.clear(),e&&(t&&Ip.has(e)?Ip.delete(e):Ip.add(e)),xm(),t&&e&&!Ip.has(e)&&(e=[...Ip].at(-1)??null),Fp=e,vm.open(e),J(`resources`).innerHTML=``,J(`selected-visibility-actions`).hidden=!e,e&&(am.reveal(e),J(`show-selected`).disabled=!1,J(`hide-selected`).disabled=[...Ip].every(e=>!$p.visible(e))),X?.select(e),document.querySelectorAll(`.element-item`).forEach(e=>e.setAttribute(`aria-pressed`,String(Ip.has(e.dataset.id??``)))),e&&uh(`inspector`,!0);let n=Z?.elements.find(t=>t.id===e);if(J(`selected-visibility-actions`).hidden=!Ip.size||!n||n.role!==`element`,!n){Am();return}J(`inspector-title`).textContent=n.name;let r=f(n),i=je(Z,n.id),a=e=>Object.entries(e).map(([e,t])=>`<details class="property-set" open><summary>${Y(e)}</summary><dl>${Object.entries(t).map(([e,t])=>`<dt>${Y(e)}</dt><dd>${Jd(t)}</dd>`).join(``)}</dl></details>`).join(``),o={...n,revit_identity:r,systems:i,model_source:Z?.source};J(`inspector`).innerHTML=`<span class="eyebrow">${Y(n.class)}</span><button class="copy-card" data-copy="${Y(JSON.stringify(o,null,2))}">Копировать все свойства</button><dl><dt>Revit ElementId</dt><dd>${r.element_id?Jd(r.element_id):`Не прочитан`}</dd><dt>Revit UniqueId</dt><dd>${r.unique_id?Jd(r.unique_id):`Не прочитан`}</dd><dt>IFC / ID сцены</dt><dd>${Jd(n.id)}</dd><dt>Этаж</dt><dd>${Jd(Z?.storeys.find(e=>e.id===n.storey_id)?.name||`Не прочитан`)}</dd><dt>Материалы</dt><dd>${Jd(n.materials.join(`, `)||`Не прочитаны`)}</dd></dl><p class="identity-basis">${Y(r.basis)}</p>${a(n.quantity_sets)}${a(n.property_sets)}<details><summary>Идентификаторы и источник</summary><dl><dt>IFC GlobalId</dt><dd>${n.global_id?Jd(n.global_id):`Не прочитан`}</dd><dt>Исходный Tag</dt><dd>${n.tag?Jd(n.tag):`Не прочитан`}</dd></dl><pre>${Y(JSON.stringify(n.source,null,2))}</pre></details>`,J(`inspector`).innerHTML+=`<details open><summary>Системы: ${i.length}</summary>${i.map(e=>`<p>${Y(e.name||e.class)} · #${Y(e.id)}</p>`).join(``)||`<p>Принадлежность к системе не прочитана.</p>`}<p>Членство не подтверждает физическое подключение.</p></details>`}try{X=new Ep(J(`canvas`),gm)}catch(e){hm(`3D недоступно; график и расчёты остаются доступны. `+String(e))}var _m=rd(X,()=>Z,()=>Hp,hm,()=>[...Ip],()=>Wp),vm=he(J(`engineering-panel`),()=>Z,{select:e=>gm(e),highlight:e=>{if(Lp=new Set(e),e.length){let t=new Set(Z?.elements.map(e=>e.id));Qm(e.filter(e=>t.has(e)),!0)}else bm()},isolate:$m});function ym(e){J(`engineering-panel`).hidden=!e,J(`property-content`).hidden=e,J(`network-tab`).setAttribute(`aria-pressed`,String(e)),J(`properties-tab`).setAttribute(`aria-pressed`,String(!e)),uh(`inspector`,!0)}J(`network-tab`).onclick=()=>ym(!0),J(`properties-tab`).onclick=()=>ym(!1),J(`open-network`).onclick=()=>{vm.open(Fp),ym(!0)};function bm(){X?.highlightElements(new Set([...Ip,...Lp,...ke(Z,J(`system-filter`).value)]))}function xm(){J(`selection-count`).textContent=`Выбрано `+Ip.size,bm(),document.querySelectorAll(`.element-item`).forEach(e=>e.setAttribute(`aria-pressed`,String(Ip.has(e.dataset.id??``))))}function Sm(){Rp.push({hidden:$p.snapshot(),apply3d:J(`visibility-filter`).checked,filters:Z&&Wp?wm().state.filters:void 0}),Rp.length>30&&Rp.shift(),J(`undo-visibility`).disabled=!1}J(`undo-visibility`).onclick=()=>{let e=Rp.pop();e&&($p.restore(e.hidden),e.filters&&Em(e.filters),J(`visibility-filter`).checked=e.apply3d,Zm(),Hm(),Wm(),J(`undo-visibility`).disabled=!Rp.length)};var Cm=Se({project:()=>Hp,capture:wm,restore:Dm,apply:Tm,matches:()=>tm.map(e=>e.id),selection:()=>[...Ip],show:$m,highlight:e=>{Lp=new Set(e),bm()},error:hm,shared:!1});J(`workspace-settings`).onclick=()=>{J(`file-dialog`).close(),J(`open-workspace`).click()};function wm(){if(!Z||!X||!Wp)throw Error(`Сначала откройте модель`);let e=JSON.parse(localStorage.getItem(Te(Hp))??`[]`);return{state:{version:1,model_id:Z.model_id,source_sha256:Z.source.sha256,hidden:$p.snapshot(),selection:[...Ip],filters:{query:J(`element-search`).value,levels:[...om.selected()],categories:[...sm.selected()],system:J(`system-filter`).value,parameters:[...nm,qm()].filter(e=>e.name.trim()),combine:J(`parameter-combine`).value,apply3d:J(`visibility-filter`).checked,grouping:J(`tree-grouping`).value},view:X.captureView(),measurements:e,sets:Cm.sets(),specifications:cm.definitions()},model:Z,binary:Wp,members:Up}}function Tm(e){if(e.version!==1||!Z||e.model_id!==Z.model_id||e.source_sha256!==Z.source.sha256)throw Error(`Рабочее место относится к другому пакету модели. Сначала откройте соответствующий снимок / модель.`);let t=new Set(Z.elements.map(e=>e.id));if([...e.hidden,...e.selection].some(e=>!t.has(e)))throw Error(`В рабочем месте есть элементы, не найденные в этой модели`);X?.restoreView(e.view),$p.restore(e.hidden),Ip.clear();for(let t of e.selection)Ip.add(t);Em(e.filters),Zm(),Hm(),Wm(),Km(),xm(),localStorage.setItem(Te(Hp),JSON.stringify(e.measurements)),Cm.putSets(e.sets),cm.restore(e.specifications??[]);let n=[...Ip];gm(n.at(-1)??null),Ip.clear();for(let e of n)Ip.add(e);xm(),J(`selected-visibility-actions`).hidden=!Ip.size,Lm=e.view.planes.length>0,J(`cut`).setAttribute(`aria-pressed`,String(Lm)),J(`cut-controls`).hidden=!0,J(`xray`).setAttribute(`aria-pressed`,String(e.view.xray))}function Em(e){J(`element-search`).value=e.query,om.restore(e.levels),sm.restore(e.categories),J(`system-filter`).value=e.system,nm=e.parameters,J(`parameter-name`).value=``,J(`parameter-value`).value=``,J(`parameter-combine`).value=e.combine,J(`visibility-filter`).checked=e.apply3d,J(`tree-grouping`).value=e.grouping,Jm()}async function Dm(e){if(e.project_id!==Hp)throw Error(`Снимок принадлежит другому проекту`);sh?.stop(`Открыто сохранённое рабочее место.`),await km(``),Bm(`view`),ih(),Up=e.members,jp=e.model,Mp=e.binary,Np=null,J(`models`).replaceChildren(new Option(e.model.source.filename,e.model.model_id)),await Om(e.model.model_id),Tm(e.state)}J(`canvas`).addEventListener(`viewer-error`,(e=>hm(e.detail)));async function Om(e){im!==Vp&&(rm.clear(),lm.set(null),im=Vp);let t=++Qp;if(_m.reset(),Ip.clear(),Lp.clear(),Rp.length=0,J(`undo-visibility`).disabled=!0,Fp=null,J(`selected-visibility-actions`).hidden=!0,X?.select(null),X?.setSite(null),Lm=!1,J(`cut-controls`).hidden=!0,J(`cut`).setAttribute(`aria-pressed`,`false`),J(`xray`).setAttribute(`aria-pressed`,`false`),!e){Z=null,vm.reset(),xm(),Wp=null,$p.reset(),em=``,J(`file-title`).textContent=`Модель не выбрана`,J(`no-model`).hidden=!1,J(`geometry-kind`).textContent=`Без геометрии`,X?.show(new Set),Gm(),Am();return}let[n,r]=jp?.model_id===e&&Mp?[jp,Mp]:await Promise.all([mm(`model?model_id=`+encodeURIComponent(e)),fetch(pm(`geometry.bin?model_id=`+encodeURIComponent(e))).then(async e=>{if(!e.ok)throw Error(`Не удалось загрузить геометрию`);return e.arrayBuffer()})]);t===Qp&&(Z=n,vm.reset(),xm(),Wp=r,em!==n.model_id&&($p.reset(),em=n.model_id,$p.set(n.elements.filter(e=>!Vm(e.source_instance_id)).map(e=>e.id),!1)),J(`workspace-status`).textContent=`${n.source.format===`nwd`?n.elements.length+` фрагментов NWD`:n.statistics.physical_elements+` элементов`} · ${n.storeys.length} уровней${n.source.schema===`SyntheticDemo`?` · Учебная модель`:``}`,J(`file-title`).textContent=n.source.filename,Gm(),X?.load(n,r),X?.setSourceColors(n.source.schema!==`SyntheticDemo`),document.dispatchEvent(new Event(`model-data-changed`)),Hm(),J(`no-model`).hidden=!0,fm(n,t),J(`geometry-kind`).textContent=n.source.schema===`SyntheticDemo`?`Синтетическая сводная модель · АР + ОВ`:n.source.schema===`DocumentSpatialModel`?`Условная геометрия по документам`:n.federation?`Сводная геометрия · совмещение требует проверки`:n.source.format===`rvt`?`RVT → IFC · экспериментальная геометрия`:n.source.format===`nwd`?`NWD · геометрические фрагменты · масштаб задан пользователем`:`Геометрия IFC`,Am())}async function km(e){let t=++Zp;Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$&&($.playing=!1),Q=null,$=null;for(let e of[`metrics`,`schedule`,`resources`,`gantt-body`,`gantt-ruler`])J(e).innerHTML=``;for(let e of[`csv`,`journal`])J(e).hidden=!0,J(e).removeAttribute(`href`);for(let e of[`play`,`rewind`,`time`])J(e).disabled=!0;if(J(`clock`).textContent=`0 мин`,J(`time`).value=`0`,J(`assumptions`).textContent=`Нет выбранного расчёта.`,ph(),!e){Am();return}let n=Np?.run_id===e?Np:await mm(`run?run_id=`+encodeURIComponent(e));if(t!==Zp)return;Q=n,$=new kp(Q.duration),$.rate=Number(J(`rate`).value),J(`time`).max=String(Q.duration),J(`time`).disabled=!1,J(`play`).disabled=!1,J(`rewind`).disabled=!1,J(`metrics`).innerHTML=[[Q.scenario.operations.length,`Работ`],[Q.duration,`Расчётных минут`],[n.cpm.duration_minutes,`Минут по одним связям`],[Q.events.filter(e=>e.kind===`resource_wait`).length,`Ожиданий ресурсов`]].map(([e,t])=>`<article><strong>${e}</strong><span>${t}</span></article>`).join(``);for(let[e,t]of[[`csv`,`schedule.csv`],[`journal`,`run`]])J(e).href=Np?.run_id===Q.run_id?oh(e,Q):pm(t+`?run_id=`+encodeURIComponent(Q.run_id)),J(e).hidden=!1;J(`assumptions`).innerHTML=Q.scenario.assumptions.map(e=>`<p>${Y(e)}</p>`).join(``)+`<p>Элементов вне графа работ: ${Q.scenario.unplanned_element_ids.length}. Статус расчёта: ${Y(Q.status)}.</p>`,J(`schedule`).innerHTML=Q.scenario.operations.map(e=>{let t=Q.operation_states[e.id],r=n.cpm.operations[e.id].critical;return`<tr data-operation="${Y(e.id)}"><td><strong>${r?`<span class="critical" title="Критическая по связям">●</span> `:``}<button class="schedule-jump" type="button">${Y(e.name)}</button></strong><small>${Y(e.id)} · ${Y(e.dependencies.join(`, `)||`Начальная работа`)}</small></td><td>${t.start??`—`} → ${t.finish??`—`}</td><td><div class="track"><i style="left:${(t.start||0)/Math.max(1,Q.duration)*100}%;width:${e.duration/Math.max(1,Q.duration)*100}%"></i></div></td><td><span>${Y(e.evidence.kind===`assumed`?`Допущение`:`С источником`)}</span><small>${Y(e.evidence.reason)}</small></td></tr>`}).join(``),ph();let r=Q.scenario.model_id||``;J(`models`).value=r,await Om(r),J(`scenes`).innerHTML=`<option value="">Выберите сцену</option>`+(Z?jd(Q,Z):[]).map((e,t)=>`<option value="${t}">${Y(e.title)}</option>`).join(``),Am()}function Am(){if(zp===`view`){if(X?.setSite(null),X?.setConstruction(null),J(`resources`).innerHTML=``,Fp)return;J(`inspector-title`).textContent=Bp?`Чертёж`:`Свойства модели`,J(`inspector`).innerHTML=Bp?`<p>DWG / DXF: просмотр чертежа, масштабирование и слои.</p><p>Для строительной симуляции нужна модель с элементами и объёмами. Чертёж сам по себе их не подтверждает.</p>`:Z?`<p><strong>${Y(Z.source.filename)}</strong></p><dl><dt>${Z.source.format===`nwd`?`Фрагментов / с геометрией`:`Физических элементов / с геометрией`}</dt><dd>${Z.source.format===`nwd`?Z.elements.length:Z.statistics.physical_elements} / ${Z.statistics.meshes}</dd><dt>Уровней</dt><dd>${Z.storeys.length}</dd><dt>Источник</dt><dd>${Y(Z.source.format===`rvt`?`RVT → `+Z.source.schema:Z.source.schema)}</dd></dl><p>Выберите элемент на модели или в структуре, чтобы увидеть свойства и количества.</p>`:`<p>Откройте DWG, DXF, RVT, IFC или NWD.</p>`;return}if(Fp||(J(`inspector-title`).textContent=`Ход строительства`),!Q||!$){if(J(`active-stage`).textContent=`Сценарий не рассчитан`,X?.setConstruction(null),Fp)return;J(`inspector`).innerHTML=`<p>Модель открыта. Подготовьте сценарий кнопкой «Рассчитать» или с помощью агента.</p>`;return}let e=$.time,t=Op(Q,e);if(J(`gantt`).style.setProperty(`--playhead`,Math.min(100,e/Math.max(1,Q.duration)*100)+`%`),J(`active-stage`).textContent=t.active.length?t.active[0].name+(t.active.length>1?` · ещё `+(t.active.length-1):``):e>=Q.duration?`Сценарий завершён`:`Ожидание начала работ`,X?.setConstruction(t.construction,J(`show-complete`).checked),Z?.model_id===Q.scenario.model_id&&X?.setSite(J(`site`).checked?Q:null,e),J(`clock`).textContent=Math.floor(e)+` мин`,J(`time`).value=String(e),J(`play`).textContent=$.playing?`Ⅱ`:`▶`,J(`play`).setAttribute(`aria-label`,$.playing?`Пауза`:`Воспроизвести`),!Fp){J(`inspector`).innerHTML=`<p><strong>${t.completed} / ${Q.scenario.operations.length}</strong> работ завершено по графику</p><h3>Назначения по графику</h3>${t.active.map(e=>`<p>${Y(e.name)}</p>`).join(``)||`<p>Нет активных работ</p>`}<h3>Ожидают ресурсы</h3>${t.waiting.map(e=>`<p>${Y(e.name)}</p>`).join(``)||`<p>Нет ожидающих работ</p>`}`,J(`resources`).innerHTML=`<h3>Ресурсы</h3>`+Q.scenario.resources.map(e=>`<label>${Y(e.name)}<strong>${t.resources.get(e.id)||0} / ${e.capacity}</strong><progress value="${t.resources.get(e.id)||0}" max="${e.capacity}"></progress></label>`).join(``);let e=J(`site`).checked?X?.siteState():null;if(e){let t=e.actors.flatMap(e=>e.workers??[]).filter(e=>e.visible),n=e=>t.filter(t=>e.includes(t.phase)).length;J(`inspector`).innerHTML+=`<h3>Действия работников</h3><p>Назначено: ${t.length} · Подход / подъём: ${n([`approach`,`climb`])} · Работа у элемента: ${n([`work`])} · Уход: ${n([`depart`])} · Ожидание / блокировка: ${n([`waiting`,`blocked`])}.</p><p>Бирюзовая линия — маршрут. Жёлтая точка — место действия на элементе. Это проверка геометрии сценария, не подтверждение выполненных работ.</p><details><summary>Задания и доступ</summary>${t.map(e=>`<p><strong>${Y(e.action)}</strong> — ${Y(e.targetName)}${e.targetId?` (#`+Y(e.targetId)+`)`:``}${e.reason?`<br>`+Y(e.reason):``}${e.routeBasis.some(e=>e.includes(`assumed`)||e.includes(`proposed`))?`<br>Временный доступ — допущение сценария.`:``}</p>`).join(``)}</details>`,e.warnings.length&&(J(`inspector`).innerHTML+=`<details open><summary>Требуют решения: ${e.warnings.length}</summary>${e.warnings.map(e=>`<p>${Y(e.message)}</p>`).join(``)}</details>`)}}document.querySelectorAll(`[data-operation]`).forEach(e=>e.dataset.state=t.states.get(e.dataset.operation)||`pending`)}async function jm(e,t=!1){Hp=e,++Gp,Up=[],Wm(),++Zp,++Qp,Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$&&($.playing=!1),Vp=e,J(`error`).hidden=!0,J(`back`).href=`https://locia.work/`,J(`back`).textContent=`locia.work ↗`,J(`measurement-link`).hidden=Ap,history.replaceState(null,``,`?project=`+encodeURIComponent(e));let n=Vp,[r,i]=await Promise.all([mm(`models`),mm(`runs`)]);if(n!==Vp)return;if(J(`models`).innerHTML=`<option value="">Без геометрии</option>`+r.items.map(e=>`<option value="${Y(e.model_id)}">${Y(e.name)}</option>`).join(``),J(`runs`).innerHTML=`<option value="">Выберите расчёт</option>`+i.items.map(e=>`<option value="${Y(e.run_id)}">${Y(e.name||e.scenario_id)} · ревизия ${e.scenario_revision} · ${e.duration_minutes} мин</option>`).join(``),t){await km(``);return}let a=i.items.find(e=>e.run_id===Jp);a?(J(`runs`).value=a.run_id,await km(a.run_id)):r.items.some(e=>e.model_id===qp)?(J(`models`).value=qp,await km(``),await Om(qp)):(i.items.length,await km(``),await Om(r.items[0]?.model_id||``),J(`models`).value=r.items[0]?.model_id||``),qp=``,Jp=``}var Mm=!1,Nm=0,Pm=0;function Fm(e){if(!Q||!Z||!$)return;let t=jd(Q,Z)[e];t&&(J(`scenes`).value=String(e),$.seek(t.start),Am(),Rm(t.cut??null),t.targetIds.length?X?.focusTargets(t.targetIds):X?.fit(),t.reference&&(X?.setConstruction(null),X?.setSite(null)))}J(`tour`).addEventListener(`click`,()=>{$&&Q&&Z&&(Mm=!Mm,Nm=0,Pm=0,$.playing=Mm,Xp=0,cancelAnimationFrame(Yp),J(`tour`).setAttribute(`aria-pressed`,String(Mm)),Mm?(Fm(0),Yp=requestAnimationFrame(Im)):Am())});function Im(e){if(Yp=0,Mm&&$?.playing&&Q&&Z){let t=jd(Q,Z);if(Pm+=Xp?(e-Xp)/1e3:0,Xp=e,Pm>=2.6){if(Pm=0,Nm++,Nm>=t.length){Mm=!1,$.playing=!1,J(`tour`).setAttribute(`aria-pressed`,`false`);return}Fm(Nm)}let n=t[Nm];$.seek(n.start+(n.end-n.start)*Pm/2.6),Am(),n.reference&&(X?.setConstruction(null),X?.setSite(null)),Yp=requestAnimationFrame(Im)}else $?.playing&&(Xp&&$.advance((e-Xp)/1e3),Xp=e,Am(),$.playing&&(Yp=requestAnimationFrame(Im)))}J(`projects`).addEventListener(`change`,()=>void jm(J(`projects`).value).catch(hm)),J(`runs`).addEventListener(`change`,()=>void km(J(`runs`).value).catch(hm)),J(`models`).addEventListener(`change`,()=>void Om(J(`models`).value).catch(hm)),J(`play`).addEventListener(`click`,()=>{Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$&&($.time>=$.duration&&$.seek(0),$.playing=!$.playing,Xp=0,cancelAnimationFrame(Yp),Am(),$.playing&&(Yp=requestAnimationFrame(Im)))}),J(`rewind`).addEventListener(`click`,()=>{Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$&&($.playing=!1,$.seek(0),Am())}),J(`time`).addEventListener(`input`,()=>{Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$&&($.playing=!1,$.seek(Number(J(`time`).value)),Am())}),J(`rate`).addEventListener(`change`,()=>{$&&($.rate=Number(J(`rate`).value))}),J(`worker-route`).addEventListener(`click`,()=>{if(!$||!Q||!Z)return;let e=jd(Q,Z)[Number(J(`scenes`).value)],t=X?.siteState()?.actors.filter(e=>e.active&&(e.workers?.length??0)>0)??[],n=t.find(t=>t.operationId===e?.operationId)??t[0];n?.operationId&&(Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$.seek(Q.operation_states[n.operationId].start),$.rate=10,J(`rate`).value=`10`,$.playing=!0,Xp=0,cancelAnimationFrame(Yp),Am(),X?.focusWorkerRoute(n.operationId),Yp=requestAnimationFrame(Im))}),J(`show-complete`).addEventListener(`change`,Am),J(`iso`).addEventListener(`click`,()=>X?.fit(`iso`)),J(`top`).addEventListener(`click`,()=>X?.fit(`top`)),J(`fit`).addEventListener(`click`,()=>X?.fit()),document.addEventListener(`visibilitychange`,()=>{Xp=0}),J(`site`).addEventListener(`change`,()=>{Am(),X?.fit()}),J(`scenes`).addEventListener(`change`,()=>{if(!Q||!Z||!$)return;let e=J(`scenes`).value;if(e===``)return;let t=jd(Q,Z)[Number(e)];Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$.playing=!1,$.seek((t.start+t.end)/2),Am(),Rm(t.cut??null),t.targetIds.length?X?.focusTargets(t.targetIds):X?.fit(),t.reference&&(X?.setConstruction(null),X?.setSite(null))});var Lm=!1;function Rm(e){J(`cut-axis`).value=`Z`,J(`cut-reverse`).checked=!1,Lm=e!==null;let t=X?.modelHeight();e!==null&&t&&(J(`cut-position`).value=String(Math.max(0,Math.min(100,(e-t.min)/Math.max(.001,t.max-t.min)*100)))),zm()}function zm(){let e=J(`cut-axis`).value,t=Lm?X?.section(e,Number(J(`cut-position`).value)/100,J(`cut-reverse`).checked):void 0;Lm||X?.cutaway(null),J(`cut-controls`).hidden=!Lm,J(`cut`).setAttribute(`aria-pressed`,String(Lm)),J(`cut-height`).textContent=t===void 0?``:t.toFixed(2)+` м`}J(`cut`).addEventListener(`click`,()=>{Lm=!Lm,zm()}),J(`cut-position`).addEventListener(`input`,zm),J(`cut-axis`).onchange=zm,J(`cut-reverse`).onchange=zm,J(`cut-box`).onclick=()=>{X?.sectionBox(!0)?J(`cut-height`).textContent=`Область + 50 мм`:hm(`Выберите элемент для ограничения области`)},J(`xray`).onclick=()=>{let e=J(`xray`).getAttribute(`aria-pressed`)!==`true`;J(`xray`).setAttribute(`aria-pressed`,String(e)),X?.setXray(e,Z?.elements??[])},document.body.classList.add(`viewer-app`,`schedule-open`),document.body.dataset.mode=`view`;{let e=document.createElement(`a`);e.href=`./downloads/`,e.textContent=`Исходники`,J(`back`).before(e),J(`back`).hidden=!0,document.body.classList.add(`public-demo`),J(`memory-link`).href=`https://github.com/proovcme/uvyazka`,document.querySelector(`.notice`).textContent=`Учебная модель. Откройте свой файл для просмотра или перейдите в «Симуляцию», чтобы изучить сценарий строительства.`}function Bm(e){e===`simulate`&&Bp?hm(`DWG открыт как чертёж. Для симуляции загрузите IFC или RVT с геометрией и рассчитайте сценарий.`):(_m.reset(),zp=e,document.body.dataset.mode=e,J(`mode-view`).setAttribute(`aria-pressed`,String(e===`view`)),J(`mode-simulate`).setAttribute(`aria-pressed`,String(e===`simulate`)),$&&($.playing=!1),Mm=!1,Xp=0,cancelAnimationFrame(Yp),J(`tour`).setAttribute(`aria-pressed`,`false`),uh(`tree`,!matchMedia(`(max-width: 650px)`).matches),uh(`inspector`,!matchMedia(`(max-width: 950px)`).matches),Hm(),Am(),e===`view`&&X?.fit())}J(`mode-view`).onclick=()=>Bm(`view`),J(`mode-simulate`).onclick=()=>Bm(`simulate`);function Vm(e){return e?Up.find(t=>t.instanceId===e)?.visible!==!1:Up.length!==1||Up[0].visible}function Hm(){if(Bp)return;Ym();let e=J(`visibility-filter`).checked?new Set(tm.map(e=>e.id)):null;X?.show(new Set((Z?.elements??[]).filter(t=>t.role===`element`&&$p.visible(t.id)&&(!e||e.has(t.id))).map(e=>e.id))),bm()}async function Um(e){let t=++Gp;if(!e.length){Up=[],jp=null,Mp=null,Np=null,await km(``),await Om(``),Wm(),document.dispatchEvent(new CustomEvent(`scene-model-changed`,{detail:null}));return}let n=e[0],r=e.length===1&&n.offset.every(e=>e===0)&&n.rotation===0?{model:n.model,binary:n.binary}:await Oe(e);t===Gp&&(Up=e,jp=r.model,Mp=r.binary,Np=null,await km(``),J(`runs`).innerHTML=`<option>Сценарий не рассчитан</option>`,J(`models`).innerHTML=`<option value="${Y(r.model.model_id)}">${Y(r.model.source.filename)}</option>`,await Om(r.model.model_id),X?.setSourceColors(e.length>1),Hm())}function Wm(){let e=J(`scene-members`);e.replaceChildren();let t=document.createElement(`button`);if(t.textContent=`+ Добавить модель`,t.className=`add-scene-model`,t.onclick=()=>{J(`browser-append`).checked=!0,J(`browser-file`).click()},e.append(t),!Up.length)return;let n=document.createElement(`details`);n.className=`scene-composition`,n.open=Kp;let r=document.createElement(`summary`);r.textContent=`Состав сцены · `+Up.length,n.append(r),n.ontoggle=()=>{n.isConnected&&(Kp=n.open)},e.append(n);let i=document.createElement(`p`);i.textContent=Up.length>1?`Общие координаты · совмещение не подтверждено`:`Исходные координаты модели`,n.append(i);for(let e of Up){let t=document.createElement(`details`);t.className=`scene-member`;let r=document.createElement(`summary`);r.textContent=e.model.source.filename,t.append(r);let i=document.createElement(`input`);i.type=`checkbox`;let a=Xm(e.instanceId),o=$p.count(a);i.checked=o.checked,i.indeterminate=o.mixed;let s=document.createElement(`label`);s.className=`check`,s.append(i,document.createTextNode(`Показывать модель`)),t.append(s),i.onchange=()=>{e.visible=i.checked,Qm(a,i.checked)};let c=document.createElement(`div`);c.className=`placement-fields`;let l=[];for(let[t,n]of[`X, м`,`Y, м`,`Z, м`,`Угол Z, °`].entries()){let r=document.createElement(`label`);r.textContent=n;let i=document.createElement(`input`);i.type=`number`,i.step=`any`,i.value=String(t<3?e.offset[t]:e.rotation),i.setAttribute(`aria-label`,n+` · `+e.model.source.filename),l.push(i),r.append(i),c.append(r)}t.append(c);let u=document.createElement(`button`);u.textContent=`Применить размещение`,u.onclick=()=>{let t=l.map(e=>e.value.trim()===``?NaN:Number(e.value));t.every(Number.isFinite)?Um(Up.map(n=>n===e?{...n,offset:[t[0],t[1],t[2]],rotation:t[3]}:n)).then(()=>document.dispatchEvent(new CustomEvent(`scene-model-changed`,{detail:jp}))).catch(hm):hm(`Заполните X, Y, Z и угол конечными числами`)},t.append(u);let d=document.createElement(`button`);d.textContent=`Убрать из сцены`,d.onclick=()=>{Um(Up.filter(t=>t!==e)).then(()=>document.dispatchEvent(new CustomEvent(`scene-model-changed`,{detail:jp}))).catch(hm)},t.append(d);let f=document.createElement(`small`);f.textContent=`${e.model.statistics.physical_elements} элементов · SHA-256 ${e.model.source.sha256.slice(0,12)}…`,t.append(f),n.append(t)}}function Gm(){J(`parameter-names`).replaceChildren(...(Z&&J(`parameter-search-details`).open?sf(Z):[]).map(e=>new Option(e,e))),J(`parameter-name`).value=``,J(`parameter-value`).value=``,om.setChoices([...(Z?.storeys??[]).map(e=>({id:JSON.stringify(e.id),name:e.name})),...(Z?.elements??[]).some(e=>e.role===`element`&&!e.storey_id)?[{id:`null`,name:`Без уровня`}]:[]]);let e=new Map;for(let t of Z?.elements??[])if(t.role===`element`){let n=v(t,Z);e.set(n.key,n.format+` · `+n.name)}sm.setChoices([...e].map(([e,t])=>({id:e,name:t}))),nm=[],Jm(),J(`system-filter`).replaceChildren(new Option(`Все системы`,``),...(Z?.systems??[]).map(e=>new Option(`${e.name||e.class} · ${new Set(e.member_ids).size} · #${e.id}`,e.id))),X?.highlightElements(new Set),Km(),Wm(),Ym()}function Km(){let e=J(`system-filter`).value,t=Z?.systems?.find(t=>t.id===e),n=J(`system-summary`);if(!Z||!t){n.textContent=Z?`${Z.systems?.length??0} систем в прочитанной выгрузке. Отсутствие системы здесь не доказывает её отсутствие в RVT.`:``;return}let r=Ae(Z,e);n.innerHTML=`<strong>${Y(t.name||t.class)}</strong><p>${r.declared} участников в выгрузке · ${r.geometry} с геометрией · ${r.withoutGeometry} без геометрии · ${r.missing} не найдены в модели.</p><p>Бирюзовый цвет — участники системы. Подключение и полнота исходного RVT не подтверждены.</p><details><summary>Свойства системы</summary><button data-copy="${Y(JSON.stringify(t,null,2))}">Копировать свойства системы</button><dl><dt>Класс</dt><dd>${Jd(t.class)}</dd><dt>ID</dt><dd>${Jd(t.id)}</dd><dt>GlobalId</dt><dd>${Jd(t.global_id||`Не прочитан`)}</dd><dt>Описание</dt><dd>${Jd(t.description??`Не прочитано`)}</dd></dl><pre>${Y(JSON.stringify(t.property_sets??{},null,2))}</pre></details>`}function qm(){return{name:J(`parameter-name`).value,value:J(`parameter-value`).value,operator:J(`parameter-operator`).value}}function Jm(){let e=J(`parameter-active`);e.replaceChildren(),nm.forEach((t,n)=>{let r=document.createElement(`div`);r.className=`parameter-chip`;let i=document.createElement(`span`),a=[...J(`parameter-operator`).options].find(e=>e.value===t.operator)?.textContent??t.operator;i.textContent=t.name+` · `+a+` `+t.value;let o=document.createElement(`button`);o.textContent=`×`,o.setAttribute(`aria-label`,`Убрать условие `+t.name),o.onclick=()=>{nm.splice(n,1),Jm(),Hm()},r.append(i,o),e.append(r)})}function Ym(){if(Bp)return;let e=J(`element-search`).value.trim(),t=om.selected(),n=sm.selected(),r=J(`system-filter`).value,i=ke(Z,r),a=[...nm,qm()],o=J(`parameter-combine`).value;tm=(Z?.elements??[]).filter(s=>s.role===`element`&&(!r||i.has(s.id))&&(!t.size||t.has(JSON.stringify(s.storey_id??null)))&&(!n.size||n.has(v(s,Z).key))&&_(s,e)&&lf(s,a,o));let s=!!e||a.some(e=>e.name.trim())||!!t.size||!!n.size||!!r;document.querySelector(`.tree-match-actions`).hidden=!s,am.render(Z,tm,Fp,s,JSON.stringify([e,a,o,[...t],[...n],r]),J(`tree-grouping`).value,[...rm.values()],e);for(let e of[`hide-matches`,`show-matches`,`isolate-matches`])J(e).disabled=!tm.length;xm()}function Xm(e){return(Z?.elements??[]).filter(t=>t.role===`element`&&(t.source_instance_id?t.source_instance_id===e:Up.length===1)).map(e=>e.id)}function Zm(){for(let e of Up){let t=Xm(e.instanceId);e.visible=$p.count(t).shown>0}}function Qm(e,t){if(Sm(),t){Ym();let t=new Set(tm.map(e=>e.id));e.some(e=>!t.has(e))&&(J(`visibility-filter`).checked=!1)}$p.set(e,t),Zm(),Hm(),Wm(),Fp&&(J(`show-selected`).disabled=!1,J(`hide-selected`).disabled=[...Ip].every(e=>!$p.visible(e)))}function $m(e){if(!e.length||!Z)return;Sm();let t=new Set(tm.map(e=>e.id));e.some(e=>!t.has(e))&&(J(`visibility-filter`).checked=!1),$p.isolate(e,Z.elements.filter(e=>e.role===`element`).map(e=>e.id)),Zm(),Hm(),Wm(),X?.focusTargets(e),Fp&&(J(`show-selected`).disabled=!1,J(`hide-selected`).disabled=[...Ip].every(e=>!$p.visible(e)))}var eh,th=()=>{clearTimeout(eh);for(let e of[`hide-matches`,`show-matches`,`isolate-matches`])J(e).disabled=!0;eh=setTimeout(Hm,180)};J(`element-search`).oninput=th,J(`parameter-name`).oninput=th,J(`parameter-value`).oninput=th,J(`parameter-search-details`).addEventListener(`toggle`,()=>{J(`parameter-search-details`).open&&Z&&J(`parameter-names`).replaceChildren(...sf(Z).map(e=>new Option(e,e)))}),J(`parameter-operator`).onchange=()=>{J(`parameter-value`).disabled=[`exists`,`missing`].includes(J(`parameter-operator`).value),Hm()},J(`add-parameter`).onclick=()=>{let e=qm();e.name.trim()&&(nm.push(e),J(`parameter-name`).value=``,J(`parameter-value`).value=``,Jm(),Hm())},J(`parameter-combine`).onchange=Hm,J(`clear-parameter`).onclick=()=>{nm=[],Jm(),J(`parameter-name`).value=``,J(`parameter-value`).value=``,Hm()},J(`hide-matches`).onclick=()=>Qm(tm.map(e=>e.id),!1),J(`show-matches`).onclick=()=>Qm(tm.map(e=>e.id),!0),J(`isolate-matches`).onclick=()=>$m(tm.map(e=>e.id)),J(`hide-selected`).onclick=()=>{Ip.size&&Qm([...Ip],!1)},J(`show-selected`).onclick=()=>{Ip.size&&Qm([...Ip],!0)},J(`isolate-selected`).onclick=()=>{Ip.size&&$m([...Ip])},J(`tree-grouping`).onchange=Ym,J(`system-filter`).onchange=()=>{gm(null),Km(),Hm()},J(`visibility-filter`).onchange=Hm,J(`reset-visibility`).onclick=()=>{Sm(),$p.reset(),Up.forEach(e=>e.visible=!0),om.reset(),sm.reset(),nm=[],Jm(),Lm=!1,zm(),J(`system-filter`).value=``,J(`visibility-filter`).checked=!0,J(`element-search`).value=``,J(`parameter-name`).value=``,J(`parameter-value`).value=``,J(`parameter-operator`).value=`contains`,J(`parameter-value`).disabled=!1,Km(),Hm(),Wm(),Fp&&(J(`show-selected`).disabled=!1,J(`hide-selected`).disabled=!1),X?.fit()};var nh=null,rh=null;function ih(){nh?.(`Загрузка отменена`),nh=null,rh?.(),rh=null,Bp?.remove(),Bp=null,J(`cad-host`).hidden=!0,J(`canvas`).hidden=!1,document.body.classList.remove(`cad-open`),J(`mode-simulate`).disabled=!1,J(`open-model-data`).disabled=!1}async function ah(e){ih(),gm(null),Bm(`view`),J(`canvas`).hidden=!0,J(`cad-host`).hidden=!1,J(`no-model`).hidden=!0,document.body.classList.add(`cad-open`),J(`mode-simulate`).disabled=!0,J(`file-title`).textContent=e.name,J(`geometry-kind`).textContent=`DWG / DXF · чертёж`,J(`open-model-data`).disabled=!0,J(`inspector-title`).textContent=`Чертёж DWG / DXF`,J(`inspector`).textContent=`Чтение `+e.name;let t=document.createElement(`iframe`);t.title=`Просмотр DWG / DXF`,t.src=`./cad/`,Bp=t,J(`cad-host`).append(t),Am(),await new Promise((n,r)=>{let i=crypto.randomUUID(),a=!1,o=null,s=e=>{clearTimeout(l),nh=null,e?(removeEventListener(`message`,c),r(Error(e))):(a=!0,n())},c=n=>{if(n.origin===location.origin&&n.source===t.contentWindow&&n.data?.channel===`uvyazka-cad`&&(n.data.kind===`ready`&&t.contentWindow?.postMessage({channel:`uvyazka-cad`,kind:`open`,job:i,file:e},location.origin),n.data.job===i&&(n.data.kind===`error`&&(a?hm(n.data.message):s(n.data.message)),n.data.kind===`opened`&&(J(`inspector`).innerHTML=`<dl><dt>Файл</dt><dd>${Jd(n.data.filename)}</dd><dt>Объектов в модели</dt><dd>${Jd(n.data.entityCount)}</dd><dt>Слоёв</dt><dd>${Jd(n.data.layers.length)}</dd></dl>`,J(`workspace-status`).textContent=`${n.data.entityCount} объектов · ${n.data.layers.length} слоёв · DWG / DXF`,J(`file-dialog`).close(),o=df(J(`element-tree`),e=>t.contentWindow?.postMessage({channel:`uvyazka-cad`,job:i,...e},location.origin)),o.update(n.data.tree),s()),n.data.kind===`tree-state`&&o?.update(n.data),n.data.kind===`entity-selected`))){let e=n.data.entity;J(`inspector-title`).textContent=`Объект DWG / DXF`,J(`inspector`).innerHTML=`<button data-copy="${Y(JSON.stringify(e,null,2))}">Копировать свойства</button><dl><dt>Handle / ID</dt><dd>${Jd(e.id)}</dd><dt>Тип</dt><dd>${Jd(e.type)}</dd><dt>Слой</dt><dd>${Jd(e.layer)}</dd></dl>`,uh(`inspector`,!0)}},l=setTimeout(()=>s(`Движок DWG не ответил за 120 секунд. Попробуйте меньший файл.`),12e4);nh=s,rh=()=>removeEventListener(`message`,c),addEventListener(`message`,c)})}function oh(e,t){let n=JSON.stringify(t,null,2),r=`application/json`;if(e===`csv`){let e=e=>{let t=String(e??``);return/^[=+@-]/.test(t)&&(t=`'`+t),`"`+t.replaceAll(`"`,`""`)+`"`};n=`﻿`+[[`Работа`,`Начало, мин`,`Конец, мин`,`Длительность, мин`],...t.scenario.operations.map(e=>[e.name,t.operation_states[e.id].start,t.operation_states[e.id].finish,e.duration])].map(t=>t.map(e).join(`,`)).join(`\r
`),r=`text/csv`}let i=URL.createObjectURL(new Blob([n],{type:r}));return Pp.push(i),J(e).download=e===`csv`?`uvyazka-schedule.csv`:`uvyazka-run.json`,i}var sh=Ad({openDocument:()=>lm?.open(),noGeometry:(e,t)=>{J(`file-title`).textContent=e,J(`geometry-kind`).textContent=`RVT · 3D недоступна`,J(`mode-simulate`).disabled=!0,J(`models`).innerHTML=`<option>Геометрия не прочитана</option>`,J(`inspector-title`).textContent=`Результат чтения RVT`,J(`inspector`).innerHTML=`<p><strong>${Y(e)}</strong></p><p>${Y(t)}</p>`},document:(e,t)=>{e?um(e):lm.set(null,t)},drawing:ah,cancelDrawing:ih,reset:e=>{++Gp,e||rm.clear(),lm.set(null),Ym(),e&&Z&&Wp&&!Z.federation&&!Up.length&&(Up=[{instanceId:Z.model_id,model:Z,binary:Wp,offset:[0,0,0],rotation:0,visible:!0}]),e||(Up=[],Wm()),ih(),Bm(`view`),J(`error`).hidden=!0,J(`element-tree`).innerHTML=``,++Zp,++Qp,Vp=`browser-local`,im=Vp,J(`projects`).innerHTML=`<option>Локальный файл в браузере</option>`,J(`runs`).innerHTML=`<option>Сценарий не рассчитан</option>`,J(`models`).innerHTML=`<option>Чтение модели</option>`,J(`scenes`).innerHTML=`<option value="">Выберите сцену</option>`,document.querySelector(`.notice`).textContent=`Свой файл обрабатывается в браузере и не отправляется на сервер. Сценарий предварительный: технология, выработка и связи требуют проверки.`,e||(jp=null,Mp=null),Np=null;for(let e of Pp)URL.revokeObjectURL(e);Pp.length=0;for(let e of[`projects`,`models`,`runs`])J(e).disabled=!0;km(``),e?Gm():Om(``)},model:async(e,t,n)=>{let r={instanceId:e.model_id,model:e,binary:t,offset:[0,0,0],rotation:0,visible:!0},i=n?Up:[];if(i.some(t=>t.model.source.sha256===e.source.sha256))throw Error(`Этот файл уже есть в сцене. Для повторного размещения нужен отдельный экземпляр.`);return await Um([...i,r]),lm.geometryReady(!!X&&!!Z&&!Z.federation&&e.statistics.meshes>0),J(`file-dialog`).close(),jp},run:async e=>{Bm(`simulate`),Np=e;for(let e of Pp)URL.revokeObjectURL(e);Pp.length=0,J(`runs`).innerHTML=`<option value="${Y(e.run_id)}">${Y(e.scenario.name||`Браузерный расчёт`)}</option>`,await km(e.run_id),J(`file-dialog`).close()}});J(`calculate-current`).hidden=!1,J(`calculate-current`).onclick=()=>J(`file-dialog`).showModal();var ch=new URL(location.href).searchParams.get(`example`);async function lh(){if(!sh)return;let e=await fetch(`./demo/examples.json`);if(!e.ok)throw Error(`Не удалось загрузить каталог примеров`);let t=(await e.json()).items,n=document.createElement(`div`);n.className=`demo-toolbar`,n.innerHTML=`<label>Пример<select id="demo-example" aria-label="Демонстрационная модель"></select></label><span role="status" id="demo-status">IFC / RVT · данные и 3D на устройстве</span><a href="./demo/ATTRIBUTION.txt" target="_blank" rel="noopener">Источники и лицензии ↗</a>`,document.querySelector(`.app-header`).after(n);let r=J(`demo-example`);r.replaceChildren(...t.map(e=>new Option(e.name,e.id)));async function i(e){let n=t.find(t=>t.id===e);if(n){r.value=e,r.disabled=!0,J(`demo-status`).textContent=`Открываем `+n.name+`…`;try{if(sh.stop(`Выбран другой демонстрационный пример.`),n.kind===`rvt`){let e=await fetch(new URL(n.url,location.href));if(!e.ok)throw Error(`Не удалось скачать демонстрационный RVT`);let t=await e.arrayBuffer();if(Array.from(new Uint8Array(await crypto.subtle.digest(`SHA-256`,t))).map(e=>e.toString(16).padStart(2,`0`)).join(``)!==n.sha256||t.byteLength!==n.size)throw Error(`Контрольная сумма примера RVT не совпала`);await sh.openFile(new File([t],`RE1-Mechanical.rvt`),!1)}else{jp=null,Mp=null,Np=null,rm.clear(),lm.set(null),ih(),J(`projects`).innerHTML=`<option value="demo-a">Публичные примеры</option>`;for(let e of[`projects`,`models`,`runs`])J(e).disabled=!1;qp=n.id,Jp=``,await jm(`demo-a`),Bm(`view`),document.dispatchEvent(new CustomEvent(`scene-model-changed`,{detail:Z}))}let t=new URL(location.href);t.searchParams.set(`example`,e),history.replaceState(null,``,t),J(`demo-status`).textContent=n.kind===`rvt`?`RVT: результат и покрытие — в журнале обработки.`:`Данные доступны в «Данные модели». Расчёт — в «Симуляции».`}catch(e){hm(e),J(`demo-status`).textContent=String(e)}finally{r.disabled=!1}}}r.onchange=()=>void i(r.value),ch&&t.some(e=>e.id===ch)?await i(ch):(!Z&&t[0]?.kind===`model`&&await Om(t[0].id),r.value=Z?.model_id||t[0]?.id||``,document.dispatchEvent(new CustomEvent(`scene-model-changed`,{detail:Z})))}(async()=>{try{let e=await(await fetch(`./demo/projects.json`)).json();if(Vp===`browser-local`)return;J(`projects`).innerHTML=e.projects.map(e=>`<option value="${Y(e.id)}">${Y(e.name)}</option>`).join(``),Vp||=e.default_project,Vp?(J(`projects`).value=Vp,await jm(Vp,!!ch),await lh()):hm(`Сначала зарегистрируйте проект или запустите uvyazka demo.`)}catch(e){hm(e)}})();function uh(e,t){if(t&&matchMedia(`(max-width: 650px)`).matches){let t=e===`tree`?`inspector`:`tree`;document.body.classList.add(t+`-closed`),J(`toggle-`+t).setAttribute(`aria-expanded`,`false`)}document.body.classList.toggle(e+`-closed`,!t),J(`toggle-`+e).setAttribute(`aria-expanded`,String(t))}J(`toggle-tree`).onclick=()=>uh(`tree`,document.body.classList.contains(`tree-closed`)),J(`toggle-inspector`).onclick=()=>uh(`inspector`,document.body.classList.contains(`inspector-closed`)),J(`close-tree`).onclick=()=>{uh(`tree`,!1),J(`toggle-tree`).focus()},J(`close-inspector`).onclick=()=>{uh(`inspector`,!1),J(`toggle-inspector`).focus()},J(`file-settings`).onclick=()=>J(`file-dialog`).showModal(),J(`close-file`).onclick=()=>J(`file-dialog`).close();function dh(e){J(`browser-append`).checked=e,J(`browser-file`).click()}J(`open-file`).onclick=()=>dh(!0),J(`empty-add-model`).onclick=()=>dh(!0),J(`replace-model`).onclick=()=>dh(!1),J(`help`).onclick=()=>J(`help-dialog`).showModal(),J(`close-help`).onclick=()=>J(`help-dialog`).close(),J(`toggle-schedule`).onclick=()=>{let e=document.body.classList.toggle(`schedule-open`);J(`toggle-schedule`).setAttribute(`aria-expanded`,String(e))};function fh(e){let t=e.target.closest(`[data-operation]`)?.dataset.operation;if(t&&$&&Q&&Number.isFinite(Q.operation_states[t]?.start)&&Q.operation_states[t].start!==null){Mm=!1,J(`tour`).setAttribute(`aria-pressed`,`false`),$.playing=!1,$.seek(Q.operation_states[t].start),Am();let e=Q.scenario.operations.find(e=>e.id===t);e&&X?.focusTargets(e.target_ids)}}J(`schedule`).onclick=fh,J(`gantt-body`).onclick=fh,matchMedia(`(max-width: 650px)`).matches&&uh(`tree`,!1),matchMedia(`(max-width: 950px)`).matches&&uh(`inspector`,!1),J(`status-details`).onclick=()=>J(`file-dialog`).showModal();function ph(){let e=J(`time-unit`).value,t={days:`Сутки от начала`,hours:`Часы от начала`,minutes:`Минуты от начала`}[e];if(!Q){J(`gantt-ruler`).innerHTML=``,J(`gantt-body`).innerHTML=`<p class="gantt-empty">Выберите рассчитанный сценарий в параметрах.</p>`,J(`schedule-summary`).textContent=`Нет выбранного расчёта`;return}J(`gantt-ruler`).innerHTML=`<span class="gantt-title">${t}</span><div class="gantt-axis">${[0,.25,.5,.75,1].map(t=>`<span style="left:${t*100}%">${sd(Q.duration*t,e)}</span>`).join(``)}</div>`;let n=cd(Q);J(`gantt-body`).innerHTML=n.map(t=>`<div class="gantt-row"><span class="gantt-name" title="${Y(t.name)}">${Y(t.name)}</span><div class="gantt-track">${t.bars.map(t=>t.left===null?`<span class="gantt-unscheduled" title="${Y(t.name)}">Без расчётного срока</span>`:`<button class="gantt-bar" data-operation="${Y(t.id)}" style="left:${t.left}%;width:${t.width}%" aria-label="${Y(t.name)}: ${sd(t.start,e)} — ${sd(t.finish,e)}" title="${Y(t.name)} · ${t.start} → ${t.finish} мин · ${t.evidence===`assumed`?`Допущение`:`С источником`}"></button>`).join(``)}</div></div>`).join(``),J(`schedule-summary`).textContent=`${Q.scenario.operations.length} работ · ${n.length} групп · расчётное время без календаря`}J(`time-unit`).onchange=()=>{ph(),Am()},J(`timeline-zoom`).onchange=()=>{J(`gantt`).style.width=Number(J(`timeline-zoom`).value)*100+`%`},J(`schedule-details-toggle`).onclick=()=>{let e=J(`schedule-details`).hidden;J(`schedule-details`).hidden=!e,J(`schedule-details-toggle`).setAttribute(`aria-expanded`,String(e))};var mh=document.createElement(`dialog`);mh.className=`element-context-menu`,mh.setAttribute(`aria-label`,`Действия с выбранными элементами`),document.body.append(mh),J(`element-tree`).addEventListener(`contextmenu`,e=>{let t=e.target.closest(`.element-item`);if(!t?.dataset.id)return;e.preventDefault(),Ip.has(t.dataset.id)||gm(t.dataset.id),mh.replaceChildren();for(let[e,t]of[[`Скрыть`,()=>Qm([...Ip],!1)],[`Показать`,()=>Qm([...Ip],!0)],[`Только выбранные`,()=>$m([...Ip])],[`Инженерные связи`,()=>{vm.open(Fp),ym(!0)}]]){let n=document.createElement(`button`);n.textContent=e,n.onclick=()=>{t(),mh.close()},mh.append(n)}let n=document.createElement(`button`);n.textContent=`Закрыть`,n.onclick=()=>mh.close(),mh.append(n),mh.showModal()});