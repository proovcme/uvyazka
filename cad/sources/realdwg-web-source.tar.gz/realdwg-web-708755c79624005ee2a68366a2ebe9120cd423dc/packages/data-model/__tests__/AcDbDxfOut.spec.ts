import { AcDbDatabase } from '../src/database/AcDbDatabase'
import { acdbHostApplicationServices } from '../src/base'
import { AcDbBlockTableRecord } from '../src/database/AcDbBlockTableRecord'
import { AcDbAttribute } from '../src/entity/AcDbAttribute'
import { AcDbBlockReference } from '../src/entity/AcDbBlockReference'
import { AcDbLine } from '../src/entity/AcDbLine'
import { AcDbMLeader } from '../src/entity/AcDbMLeader'
import { AcDbMLine } from '../src/entity/AcDbMLine'
import { AcDbPolyline } from '../src/entity/AcDbPolyline'
import { AcDbProxyEntity, AcDbRotatedDimension, AcDbSolid } from '../src/entity'
import { AcDbTable } from '../src/entity/AcDbTable'
import { AcDbText } from '../src/entity/AcDbText'
import { AcDbMLeaderStyle } from '../src/object'
import { AcDbLayout } from '../src/object/layout/AcDbLayout'
import { AcGePoint2d } from '@mlightcad/geometry-engine'
import { AcGePoint3d } from '@mlightcad/geometry-engine'
import { AcGeVector3d } from '@mlightcad/geometry-engine'
import { AcGiMTextAttachmentPoint } from '@mlightcad/graphic-interface'

interface DxfPair {
  code: string
  value: string
}

interface DxfRecord {
  type: string
  pairs: DxfPair[]
}

/** ASCII dxfOut result as string (binary mode returns Uint8Array). */
function asAsciiDxf(dxf: string | Uint8Array): string {
  expect(typeof dxf).toBe('string')
  return dxf as string
}

function getSection(dxf: string | Uint8Array, name: string) {
  const text = asAsciiDxf(dxf)
  const startMarker = `0\nSECTION\n2\n${name}\n`
  const start = text.indexOf(startMarker)
  expect(start).toBeGreaterThanOrEqual(0)

  const end = text.indexOf('\n0\nENDSEC\n', start + startMarker.length)
  expect(end).toBeGreaterThan(start)
  return text.slice(start + startMarker.length, end + 1)
}

function parseRecords(content: string): DxfRecord[] {
  const lines = content.trim().split('\n')
  expect(lines.length % 2).toBe(0)

  const records: DxfRecord[] = []
  let current: DxfRecord | null = null
  for (let i = 0; i < lines.length; i += 2) {
    const pair = {
      code: lines[i],
      value: lines[i + 1]
    }

    if (pair.code === '0') {
      if (current) {
        records.push(current)
      }
      current = {
        type: pair.value,
        pairs: [pair]
      }
    } else if (current) {
      current.pairs.push(pair)
    }
  }

  if (current) {
    records.push(current)
  }
  return records
}

function findRecord(
  records: DxfRecord[],
  type: string,
  predicate?: (record: DxfRecord) => boolean
) {
  return records.find(record => {
    if (record.type !== type) return false
    return predicate ? predicate(record) : true
  })
}

function valuesByCode(record: DxfRecord, code: string) {
  return record.pairs.filter(pair => pair.code === code).map(pair => pair.value)
}

describe('AcDbDatabase.dxfOut', () => {
  it('exports the expected DXF sections and default table/object content', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const dxf = asAsciiDxf(db.dxfOut(undefined, 6))

    const headerIndex = dxf.indexOf('0\nSECTION\n2\nHEADER\n')
    const tablesIndex = dxf.indexOf('0\nSECTION\n2\nTABLES\n')
    const blocksIndex = dxf.indexOf('0\nSECTION\n2\nBLOCKS\n')
    const entitiesIndex = dxf.indexOf('0\nSECTION\n2\nENTITIES\n')
    const objectsIndex = dxf.indexOf('0\nSECTION\n2\nOBJECTS\n')
    const eofIndex = dxf.lastIndexOf('0\nEOF\n')

    expect(headerIndex).toBeGreaterThanOrEqual(0)
    expect(tablesIndex).toBeGreaterThan(headerIndex)
    expect(blocksIndex).toBeGreaterThan(tablesIndex)
    expect(entitiesIndex).toBeGreaterThan(blocksIndex)
    expect(objectsIndex).toBeGreaterThan(entitiesIndex)
    expect(eofIndex).toBeGreaterThan(objectsIndex)

    expect(dxf).toContain('9\n$ACADVER\n1\nAC1014\n')
    expect(dxf).toContain('9\n$CLAYER\n8\n0\n')
    expect(dxf).toContain('9\n$CELTYPE\n6\nByLayer\n')
    expect(dxf).toContain('9\n$CMLSTYLE\n2\nStandard\n')
    expect(dxf).toContain('9\n$CMLSCALE\n40\n1\n')
    expect(dxf).toContain('9\n$CMLEADERSTYLE\n2\nStandard\n')
    expect(dxf).toContain('0\nTABLE\n2\nLAYER\n')
    expect(dxf).toContain('0\nLAYER\n')
    expect(dxf).toContain('2\n0\n')
    expect(dxf).toContain('0\nTABLE\n2\nLTYPE\n')
    expect(dxf).toContain('2\nContinuous\n')
    expect(dxf).toContain('0\nTABLE\n2\nSTYLE\n')
    expect(dxf).toContain('2\nStandard\n')
    expect(dxf).toContain('0\nTABLE\n2\nAPPID\n')
    expect(dxf).toContain('2\nmlightcad\n')
    expect(dxf).toContain('0\nTABLE\n2\nBLOCK_RECORD\n')
    expect(dxf).toContain('0\nBLOCK_RECORD\n')
    expect(dxf).toContain('2\n*Model_Space\n')
    expect(dxf).toContain('0\nBLOCK\n')
    expect(dxf).toContain('0\nLAYOUT\n')
    expect(dxf).toContain('1\nModel\n')
  })

  it('writes common entity fields for line, text, and lightweight polyline', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const line = new AcDbLine({ x: 0, y: 0, z: 0 }, { x: 10, y: 5, z: 0 })
    line.layer = '0'

    const text = new AcDbText()
    text.position = new AcGePoint3d(2, 3, 0)
    text.textString = 'DXF TEST'
    text.height = 2.5
    text.styleName = 'Standard'

    const polyline = new AcDbPolyline()
    polyline.addVertexAt(0, new AcGePoint2d(0, 0))
    polyline.addVertexAt(1, new AcGePoint2d(5, 0))
    polyline.addVertexAt(2, new AcGePoint2d(5, 5))
    polyline.closed = true

    db.tables.blockTable.modelSpace.appendEntity([line, text, polyline])

    const entities = parseRecords(
      getSection(db.dxfOut(undefined, 6), 'ENTITIES')
    )

    const lineRecord = findRecord(entities, 'LINE')
    expect(lineRecord).toBeDefined()
    expect(valuesByCode(lineRecord!, '10')).toContain('0')
    expect(valuesByCode(lineRecord!, '20')).toContain('0')
    expect(valuesByCode(lineRecord!, '11')).toContain('10')
    expect(valuesByCode(lineRecord!, '21')).toContain('5')
    expect(valuesByCode(lineRecord!, '8')).toContain('0')

    const textRecord = findRecord(entities, 'TEXT', record =>
      valuesByCode(record, '1').includes('DXF TEST')
    )
    expect(textRecord).toBeDefined()
    expect(valuesByCode(textRecord!, '40')).toContain('2.5')
    expect(valuesByCode(textRecord!, '7')).toContain('Standard')
    expect(valuesByCode(textRecord!, '10')).toContain('2')
    expect(valuesByCode(textRecord!, '20')).toContain('3')

    const lwPolylineRecord = findRecord(entities, 'LWPOLYLINE')
    expect(lwPolylineRecord).toBeDefined()
    expect(valuesByCode(lwPolylineRecord!, '90')).toContain('3')
    expect(valuesByCode(lwPolylineRecord!, '70')).toContain('1')
    expect(valuesByCode(lwPolylineRecord!, '10')).toEqual(['0', '5', '5'])
    expect(valuesByCode(lwPolylineRecord!, '20')).toEqual(['0', '0', '5'])
  })

  it('writes common DIMENSION fields including block name and text metadata', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const dimension = new AcDbRotatedDimension(
      new AcGePoint3d(0, 0, 0),
      new AcGePoint3d(10, 0, 0),
      new AcGePoint3d(5, 2, 0)
    )
    dimension.dimBlockId = '__DIM_BLOCK_TEST__'
    dimension.dimensionStyleName = 'Standard'
    dimension.dimensionText = '10.000'
    dimension.textLineSpacingStyle = 2
    dimension.textLineSpacingFactor = 1.25
    dimension.measurement = 10
    db.tables.blockTable.modelSpace.appendEntity(dimension)

    const entities = parseRecords(
      getSection(db.dxfOut(undefined, 6), 'ENTITIES')
    )
    const dimensionRecord = findRecord(entities, 'DIMENSION', record =>
      valuesByCode(record, '100').includes('AcDbDimension')
    )

    expect(dimensionRecord).toBeDefined()
    expect(valuesByCode(dimensionRecord!, '280')).toContain('0')
    expect(valuesByCode(dimensionRecord!, '2')).toContain('__DIM_BLOCK_TEST__')
    expect(valuesByCode(dimensionRecord!, '72')).toContain('2')
    expect(valuesByCode(dimensionRecord!, '41')).toContain('1.25')
    expect(valuesByCode(dimensionRecord!, '42')).toContain('10')
    expect(valuesByCode(dimensionRecord!, '12')).toContain('0')
    expect(valuesByCode(dimensionRecord!, '22')).toContain('0')
    expect(valuesByCode(dimensionRecord!, '32')).toContain('0')
  })

  it('writes block definitions and insert attributes to BLOCKS and ENTITIES sections', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const block = new AcDbBlockTableRecord()
    block.name = 'TEST_BLOCK'
    db.tables.blockTable.add(block)
    block.appendEntity(new AcDbLine({ x: 0, y: 0, z: 0 }, { x: 4, y: 0, z: 0 }))

    const insert = new AcDbBlockReference('TEST_BLOCK')
    insert.position = new AcGePoint3d(10, 20, 0)

    const attribute = new AcDbAttribute()
    attribute.database = db
    attribute.position = new AcGePoint3d(10, 20, 0)
    attribute.height = 1
    attribute.tag = 'TAG1'
    attribute.textString = 'VALUE1'
    insert.appendAttributes(attribute)

    db.tables.blockTable.modelSpace.appendEntity(insert)

    const dxf = db.dxfOut(undefined, 6)
    const tableRecords = parseRecords(getSection(dxf, 'TABLES'))
    const blockRecords = parseRecords(getSection(dxf, 'BLOCKS'))
    const entityRecords = parseRecords(getSection(dxf, 'ENTITIES'))

    const blockRecord = findRecord(tableRecords, 'BLOCK_RECORD', record =>
      valuesByCode(record, '2').includes('TEST_BLOCK')
    )
    expect(blockRecord).toBeDefined()
    expect(valuesByCode(blockRecord!, '70')).toContain('0')
    expect(valuesByCode(blockRecord!, '10')).toEqual([])

    const blockBegin = findRecord(blockRecords, 'BLOCK', record =>
      valuesByCode(record, '2').includes('TEST_BLOCK')
    )
    expect(blockBegin).toBeDefined()
    expect(valuesByCode(blockBegin!, '3')).toContain('TEST_BLOCK')
    expect(valuesByCode(blockBegin!, '10')).toContain('0')
    expect(valuesByCode(blockBegin!, '20')).toContain('0')
    expect(valuesByCode(blockBegin!, '30')).toContain('0')

    const blockLine = findRecord(blockRecords, 'LINE')
    expect(blockLine).toBeDefined()
    expect(valuesByCode(blockLine!, '11')).toContain('4')

    const insertRecord = findRecord(entityRecords, 'INSERT', record =>
      valuesByCode(record, '2').includes('TEST_BLOCK')
    )
    expect(insertRecord).toBeDefined()
    expect(valuesByCode(insertRecord!, '10')).toContain('10')
    expect(valuesByCode(insertRecord!, '20')).toContain('20')

    const attribRecord = findRecord(entityRecords, 'ATTRIB', record =>
      valuesByCode(record, '2').includes('TAG1')
    )
    expect(attribRecord).toBeDefined()
    expect(valuesByCode(attribRecord!, '1')).toContain('VALUE1')

    const seqendRecord = findRecord(entityRecords, 'SEQEND')
    expect(seqendRecord).toBeDefined()
  })

  it('uses the database CELTYPE for new entities without an explicit linetype', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()
    db.celtype = 'Continuous'

    const line = new AcDbLine({ x: 0, y: 0, z: 0 }, { x: 10, y: 5, z: 0 })
    db.tables.blockTable.modelSpace.appendEntity(line)

    expect(line.lineType).toBe('Continuous')
  })

  it('uses the database CMLSTYLE for new mline entities without an explicit style', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()
    db.cmlstyle = 'FILL'

    const mline = new AcDbMLine()
    mline.startPosition = new AcGePoint3d(0, 0, 0)
    mline.segments = [
      {
        position: { x: 10, y: 0, z: 0 },
        direction: { x: 1, y: 0, z: 0 },
        miterDirection: { x: 0, y: 1, z: 0 },
        elements: []
      }
    ]
    db.tables.blockTable.modelSpace.appendEntity(mline)

    expect(mline.styleName).toBe('FILL')
    expect(asAsciiDxf(db.dxfOut(undefined, 6))).toContain('\n2\nFILL\n')
  })

  it('uses the database CMLEADERSTYLE for new mleader entities without an explicit style', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const baseStyle = new AcDbMLeaderStyle()
    db.objects.mleaderStyle.setAt('BASE', baseStyle)
    const activeStyle = new AcDbMLeaderStyle()
    db.objects.mleaderStyle.setAt('ACTIVE', activeStyle)

    db.cmleaderstyle = 'ACTIVE'

    const mleader = new AcDbMLeader()
    const leaderIndex = mleader.addLeader()
    mleader.addLeaderLine(leaderIndex, [
      new AcGePoint3d(0, 0, 0),
      new AcGePoint3d(5, 0, 0)
    ])
    db.tables.blockTable.modelSpace.appendEntity(mleader)

    expect(mleader.mleaderStyleId).toBe(activeStyle.objectId)
    expect(asAsciiDxf(db.dxfOut(undefined, 6))).toContain(
      '9\n$CMLEADERSTYLE\n2\nACTIVE\n'
    )
  })

  it('writes additional paper space layouts as BLOCK_RECORD, BLOCK, and LAYOUT objects', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const paperSpace = new AcDbBlockTableRecord()
    paperSpace.name = '*Paper_Space0'
    db.tables.blockTable.add(paperSpace)

    const layout = new AcDbLayout()
    layout.layoutName = 'Layout1'
    layout.tabOrder = 1
    layout.blockTableRecordId = paperSpace.objectId
    db.objects.layout.setAt(layout.layoutName, layout)
    paperSpace.layoutId = layout.objectId

    const paperLine = new AcDbLine(
      { x: 100, y: 200, z: 0 },
      { x: 140, y: 260, z: 0 }
    )
    paperSpace.appendEntity(paperLine)

    const dxf = db.dxfOut(undefined, 6)
    const tableRecords = parseRecords(getSection(dxf, 'TABLES'))
    const blockRecords = parseRecords(getSection(dxf, 'BLOCKS'))
    const entityRecords = parseRecords(getSection(dxf, 'ENTITIES'))
    const objectRecords = parseRecords(getSection(dxf, 'OBJECTS'))

    const paperBlockRecord = findRecord(tableRecords, 'BLOCK_RECORD', record =>
      valuesByCode(record, '2').includes('*Paper_Space0')
    )
    expect(paperBlockRecord).toBeDefined()
    expect(valuesByCode(paperBlockRecord!, '70')).toContain('0')

    const paperBlock = findRecord(blockRecords, 'BLOCK', record =>
      valuesByCode(record, '2').includes('*Paper_Space0')
    )
    expect(paperBlock).toBeDefined()
    expect(valuesByCode(paperBlock!, '3')).toContain('*Paper_Space0')

    const paperEndblk = findRecord(blockRecords, 'ENDBLK', record =>
      valuesByCode(record, '330').includes(
        valuesByCode(paperBlockRecord!, '5')[0]
      )
    )
    expect(paperEndblk).toBeDefined()

    const paperLayout = findRecord(objectRecords, 'LAYOUT', record =>
      valuesByCode(record, '1').includes('Layout1')
    )
    expect(paperLayout).toBeDefined()
    expect(valuesByCode(paperLayout!, '71')).toContain('1')
    expect(valuesByCode(paperLayout!, '330')).toContain(
      valuesByCode(paperBlockRecord!, '5')[0]
    )

    const entitiesPaperLine = findRecord(entityRecords, 'LINE', record => {
      const x0 = valuesByCode(record, '10')
      const y0 = valuesByCode(record, '20')
      const x1 = valuesByCode(record, '11')
      const y1 = valuesByCode(record, '21')
      return (
        x0.includes('100') &&
        y0.includes('200') &&
        x1.includes('140') &&
        y1.includes('260')
      )
    })
    expect(entitiesPaperLine).toBeDefined()

    const blocksPaperLine = findRecord(blockRecords, 'LINE', record => {
      const x0 = valuesByCode(record, '10')
      const y0 = valuesByCode(record, '20')
      const x1 = valuesByCode(record, '11')
      const y1 = valuesByCode(record, '21')
      return (
        x0.includes('100') &&
        y0.includes('200') &&
        x1.includes('140') &&
        y1.includes('260')
      )
    })
    expect(blocksPaperLine).toBeUndefined()
  })

  it('exports table cells with text content using 2007+ cell value blocks', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const table = new AcDbTable('TEST_TABLE', 2, 2)
    table.tableDataVersion = 5
    table.tableStyleId = 'EE'
    table.owningBlockRecordId = db.tables.blockTable.modelSpace.objectId
    table.horizontalDirection = new AcGeVector3d(1, 0, 0)
    table.tableValueFlag = 22
    table.attachmentPoint = AcGiMTextAttachmentPoint.TopLeft
    table.position = new AcGePoint3d(0, 0, 0)

    table.setRowHeight(0, 11)
    table.setRowHeight(1, 9)
    table.setColumnWidth(0, 63.5)
    table.setColumnWidth(1, 63.5)

    const cellDefaults = {
      attachmentPoint: AcGiMTextAttachmentPoint.TopLeft,
      cellType: 1,
      textHeight: 6
    }
    table.setCell(0, { ...cellDefaults, text: 'A1' })
    table.setCell(1, { ...cellDefaults, text: 'A2' })
    table.setCell(2, { ...cellDefaults, text: 'B1' })
    table.setCell(3, { ...cellDefaults, text: 'B2' })

    db.tables.blockTable.modelSpace.appendEntity(table)

    const entities = parseRecords(
      getSection(db.dxfOut(undefined, 6, 'AC1021'), 'ENTITIES')
    )
    const tableRecord = findRecord(entities, 'ACAD_TABLE')
    expect(tableRecord).toBeDefined()
    expect(valuesByCode(tableRecord!, '100')).toContain('AcDbTable')
    expect(valuesByCode(tableRecord!, '91')).toContain('2')
    expect(valuesByCode(tableRecord!, '92')).toContain('2')
    expect(valuesByCode(tableRecord!, '141')).toEqual(['11', '9'])
    expect(valuesByCode(tableRecord!, '142')).toEqual(['63.5', '63.5'])
    expect(valuesByCode(tableRecord!, '171')).toEqual(['1', '1', '1', '1'])
    expect(valuesByCode(tableRecord!, '301')).toEqual([
      'CELL_VALUE',
      'CELL_VALUE',
      'CELL_VALUE',
      'CELL_VALUE'
    ])
    expect(valuesByCode(tableRecord!, '302')).toEqual(['A1', 'A2', 'B1', 'B2'])
    expect(valuesByCode(tableRecord!, '140')).toEqual(['6', '6', '6', '6'])
    expect(valuesByCode(tableRecord!, '170')).toEqual(['1', '1', '1', '1'])
  })

  it('exports SOLID entities with type SOLID (dimension arrowheads)', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()

    const solid = new AcDbSolid()
    solid.setPointAt(0, { x: 0, y: 0, z: 0 })
    solid.setPointAt(1, { x: 1, y: 0, z: 0 })
    solid.setPointAt(2, { x: 0.5, y: 2, z: 0 })
    solid.setPointAt(3, { x: 0.5, y: 2, z: 0 })
    db.tables.blockTable.modelSpace.appendEntity(solid)

    const entities = parseRecords(getSection(db.dxfOut(undefined, 6), 'ENTITIES'))
    const solidRecord = findRecord(entities, 'SOLID')
    expect(solidRecord).toBeDefined()
    expect(valuesByCode(solidRecord!, '100')).toContain('AcDbTrace')
    expect(findRecord(entities, 'TRACE')).toBeUndefined()
  })

  it('exports CLASSES and correct ACAD_PROXY_ENTITY group codes', () => {
    const db = new AcDbDatabase()
    db.createDefaultData()
    db.classes = [
      {
        name: 'TH_TOLERANCEENT',
        cppClassName: 'TH_ToleranceEnt',
        appName: 'PCCADDIM',
        proxyFlag: 3071,
        instanceCount: 1,
        wasProxy: false,
        isEntity: true
      }
    ]

    const proxy = new AcDbProxyEntity()
    proxy.proxyEntityClassId = 498
    proxy.applicationEntityClassId = 500
    proxy.objectDrawingFormat = 4128797
    proxy.originalDataFormat = 0
    proxy.setProxyGraphic(new Uint8Array([0x01, 0x02, 0x03, 0x04]))
    db.tables.blockTable.modelSpace.appendEntity(proxy)

    const dxf = asAsciiDxf(db.dxfOut(undefined, 6))
    const headerIndex = dxf.indexOf('0\nSECTION\n2\nHEADER\n')
    const classesIndex = dxf.indexOf('0\nSECTION\n2\nCLASSES\n')
    const tablesIndex = dxf.indexOf('0\nSECTION\n2\nTABLES\n')
    expect(classesIndex).toBeGreaterThan(headerIndex)
    expect(tablesIndex).toBeGreaterThan(classesIndex)
    expect(dxf).toContain('0\nCLASS\n1\nTH_TOLERANCEENT\n2\nTH_ToleranceEnt\n')

    const entities = parseRecords(getSection(dxf, 'ENTITIES'))
    const proxyRecord = findRecord(entities, 'ACAD_PROXY_ENTITY')
    expect(proxyRecord).toBeDefined()
    expect(valuesByCode(proxyRecord!, '90')).toContain('498')
    expect(valuesByCode(proxyRecord!, '91')).toContain('500')
    expect(valuesByCode(proxyRecord!, '95')).toContain('4128797')
    expect(valuesByCode(proxyRecord!, '70')).toContain('0')
    expect(valuesByCode(proxyRecord!, '160')).toContain('4')
    expect(valuesByCode(proxyRecord!, '310')).toContain('01020304')
    expect(valuesByCode(proxyRecord!, '1')).toEqual([])
  })

  it('re-opens its own dxfOut output: transparency header vars round-trip (440 bitfield)', async () => {
    const db = new AcDbDatabase()
    db.createDefaultData()
    acdbHostApplicationServices().workingDatabase = db

    // Non-default ByAlpha values so round-trip asserts more than method.
    db.cetransparency.percentage = 30
    db.hptransparency.percentage = 50
    const ceSerialized = db.cetransparency.serialize()
    const hpSerialized = db.hptransparency.serialize()

    // AC1024+ writes $CETRANSPARENCY/$HPTRANSPARENCY as group-440 32-bit
    // bitfield integers (high byte = method, low byte = alpha).
    const dxf = asAsciiDxf(db.dxfOut(undefined, 6, 'AC1024'))
    expect(dxf).toContain('$CETRANSPARENCY\n440\n')
    expect(dxf).toContain('$HPTRANSPARENCY\n440\n')
    expect(dxf).toContain(`$CETRANSPARENCY\n440\n${ceSerialized}\n`)
    expect(dxf).toContain(`$HPTRANSPARENCY\n440\n${hpSerialized}\n`)

    // The reader must accept its own writer's output: 440 values go through
    // AcCmTransparency.deserialize. Feeding them to fromString as text used
    // to reject bitfield ints > 255 with "Invalid transparency value!" and
    // made every dxfOut-produced file unopenable.
    const { AcDbDxfDocumentReader } = await import('../src/dxf/AcDbDxfDocumentReader')
    const { AcDbDxfFiler } = await import('../src/base/AcDbDxfFiler')
    const db2 = new AcDbDatabase()
    db2.createDefaultData()
    acdbHostApplicationServices().workingDatabase = db2
    await expect(
      new AcDbDxfDocumentReader(db2).read(AcDbDxfFiler.fromString(dxf))
    ).resolves.toBeDefined()
    expect(db2.cetransparency.equals(db.cetransparency)).toBe(true)
    expect(db2.hptransparency.equals(db.hptransparency)).toBe(true)
    expect(db2.cetransparency.serialize()).toBe(ceSerialized)
    expect(db2.hptransparency.serialize()).toBe(hpSerialized)
    expect(db2.cetransparency.percentage).toBe(30)
    expect(db2.hptransparency.percentage).toBe(50)
  })

  it('reads textual transparency header values via fromString, not deserialize', async () => {
    const { AcDbDxfDocumentReader } = await import('../src/dxf/AcDbDxfDocumentReader')
    const { AcDbDxfFiler } = await import('../src/base/AcDbDxfFiler')
    const db = new AcDbDatabase()
    db.createDefaultData()
    acdbHostApplicationServices().workingDatabase = db

    // Non-440 string encoding: percentage must take fromString (ByAlpha ≈
    // alpha 191 for 25%), not deserialize(25) which would be ByLayer|alpha 25.
    const dxf = [
      '0',
      'SECTION',
      '2',
      'HEADER',
      '9',
      '$ACADVER',
      '1',
      'AC1024',
      '9',
      '$CETRANSPARENCY',
      '1',
      '25',
      '9',
      '$HPTRANSPARENCY',
      '1',
      'ByBlock',
      '0',
      'ENDSEC',
      '0',
      'SECTION',
      '2',
      'ENTITIES',
      '0',
      'ENDSEC',
      '0',
      'EOF'
    ].join('\n')

    await new AcDbDxfDocumentReader(db).read(AcDbDxfFiler.fromString(dxf))
    expect(db.cetransparency.percentage).toBe(25)
    expect(db.hptransparency.isByBlock).toBe(true)
  })
})
