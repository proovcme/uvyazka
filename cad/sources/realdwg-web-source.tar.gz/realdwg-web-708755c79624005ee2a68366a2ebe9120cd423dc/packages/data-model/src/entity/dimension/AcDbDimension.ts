import {
  AcGeBox3d,
  AcGeIntersectPrimitive,
  AcGeLine3d,
  AcGeMathUtil,
  AcGeMatrix3d,
  AcGePoint2dLike,
  AcGePoint3d,
  AcGePoint3dLike,
  AcGeVector3d,
  AcGeVector3dLike
} from '@mlightcad/geometry-engine'
import {
  AcGiArrowStyle,
  AcGiArrowType,
  AcGiMTextAttachmentPoint,
  AcGiRenderer
} from '@mlightcad/graphic-interface'

import { AcDbObjectId } from '../../base'
import { AcDbDxfFiler } from '../../base'
import { AcDbDimStyleTableRecord } from '../../database'
import { AcDbRenderingCache } from '../../misc'
import { AcDbOsnapMode } from '../../misc'
import { AcDbBlockReference } from '../AcDbBlockReference'
import { AcDbEntity } from '../AcDbEntity'
import {
  AcDbEntityProperties,
  AcDbEntityPropertyGroup,
  AcDbEntityPropertyType,
  AcDbEntityRuntimeProperty
} from '../AcDbEntityProperties'
import { acdbForEachGripIndex } from '../AcDbGripHelpers'
import { acdbTransformIntersectPrimitives } from '../AcDbIntersectHelpers'

/**
 * Defines the line spacing style for dimension text.
 */
export enum AcDbLineSpacingStyle {
  /** At least the specified spacing */
  AtLeast = 1,
  /** Exactly the specified spacing */
  Exactly = 2
}

/**
 * Abstract base class for all dimension entity types in AutoCAD.
 *
 * This class provides the fundamental functionality for all dimension entities,
 * including dimension text, style management, arrow handling, and measurement
 * calculations. The appearance of dimensions is controlled by dimension variable
 * settings and dimension styles.
 *
 * @example
 * ```typescript
 * class MyDimension extends AcDbDimension {
 *   // Implementation for specific dimension type
 *   draw(renderer: AcGiRenderer) {
 *     // Custom drawing logic
 *   }
 * }
 * ```
 */
export abstract class AcDbDimension extends AcDbEntity {
  /** The entity type name */
  static override typeName: string = 'Dimension'

  override get dxfTypeName() {
    return 'DIMENSION'
  }

  /** The block table record ID containing the dimension entities */
  private _dimBlockId: string | null
  /** The relative position point of the block referenced by the dimension (in WCS coordinates). */
  private _dimBlockPosition: AcGePoint3d
  /**
   * DXF group code 10 definition point captured during {@link dxfInFields}.
   *
   * This is **not** {@link dimBlockPosition} (DXF group 12). Subclasses use it
   * as the dim-line / center / far-chord point when their typed point codes are
   * absent (matching AutoCAD DXF and dxf-json-converter).
   */
  protected _dxfDefinitionPoint: AcGePoint3d
  /** The dimension style name used by this dimension */
  private _dimensionStyleName: string | null
  /** The user-supplied dimension annotation text */
  private _dimensionText: string | null
  /** The measured value of the dimension */
  private _measurement?: number
  /** The line spacing factor for dimension text */
  private _textLineSpacingFactor: number
  /** The line spacing style for dimension text */
  private _textLineSpacingStyle: AcDbLineSpacingStyle
  /** The position of the dimension text */
  private _textPosition: AcGePoint3d
  /** The rotation angle of the dimension text */
  private _textRotation: number
  /**
   * Horizontal direction for the dimension entity (DXF group 51), in radians.
   * Negative of the angle between the OCS X axis and the UCS X axis.
   */
  private _horizontalRotation: number
  /**
   * Dimension type flags (DXF group 70). Low bits select the dimension kind;
   * bit 32 marks user-defined text position, etc.
   */
  private _dimensionType: number
  /** Dimension text attachment point (DXF group 71). */
  private _attachmentPoint: AcGiMTextAttachmentPoint
  /** DXF class version (group 280); 0 = R2010+. */
  private _dxfVersion: number
  /** The cached dimension style record */
  private _dimStyle?: AcDbDimStyleTableRecord
  /** The normal vector of the plane containing the block reference */
  private _normal: AcGeVector3d
  /**
   * Additional rotation (radians) applied when placing the anonymous dimension
   * block. Block geometry is authored at a fixed orientation; this accumulates
   * rigid-body rotations from {@link transformBy} so the block rotates with the
   * dimension definition points.
   */
  private _dimBlockRotation: number

  /**
   * Creates a new dimension entity.
   *
   * This constructor initializes a dimension with default values.
   * Subclasses should override this constructor to set up dimension-specific properties.
   *
   * @example
   * ```typescript
   * const dimension = new MyDimension();
   * dimension.dimensionText = "10.0";
   * dimension.textPosition = new AcGePoint3d(5, 5, 0);
   * ```
   */
  constructor() {
    super()
    this._dimBlockId = null
    this._dimBlockPosition = new AcGePoint3d()
    this._dxfDefinitionPoint = new AcGePoint3d()
    this._dimensionStyleName = null
    this._dimensionText = null
    this._textLineSpacingFactor = 1.0
    this._textLineSpacingStyle = AcDbLineSpacingStyle.AtLeast
    this._textPosition = new AcGePoint3d()
    this._textRotation = 0
    this._horizontalRotation = 0
    this._dimensionType = 0
    this._attachmentPoint = AcGiMTextAttachmentPoint.MiddleCenter
    this._dxfVersion = 0
    this._normal = new AcGeVector3d(0, 0, 1)
    this._dimBlockRotation = 0
  }

  /**
   * Gets the block table record ID containing the entities that this dimension displays.
   *
   * @returns The block table record ID, or null if not set
   *
   * @example
   * ```typescript
   * const blockId = dimension.dimBlockId;
   * console.log(`Dimension block ID: ${blockId}`);
   * ```
   */
  get dimBlockId() {
    return this._dimBlockId
  }

  /**
   * Sets the block table record ID for this dimension.
   *
   * @param value - The block table record ID, or null to clear
   *
   * @example
   * ```typescript
   * dimension.dimBlockId = "MyDimensionBlock";
   * ```
   */
  set dimBlockId(value: string | null) {
    this._dimBlockId = value
  }

  /**
   * Gets the relative position point of the block referenced by the dimension (in WCS coordinates).
   * The block position is the insertion point of the block referenced by the dimension, relative to
   * the primary definition point (DXF group code 10) of the dimension itself.
   *
   * The block position (in WCS) is added to the dimension primary definition point (also in WCS) to
   * get the actual insertion point for the anonymous block that is referenced by the dimension. So,
   * for example, changing a dimension's block position from (0,0,0) to (0,0,1) (in WCS) will cause
   * the dimension to display as though it has been moved 1 unit along the WCS Z axis.
   *
   * For a dimension newly created via any dimension command, the block position will be (0,0,0).
   * For copies of existing dimensions, or if a dimension is moved, the block position will be the
   * offset vector (in WCS) from where the original dimension was located. For example, moving a
   * dimension 1 unit down the WCS Y axis will cause AutoCAD to update the block position value from
   * (0,0,0) to (0,-1,0) (in WCS coordinates).
   *
   * The position point is used for DXF group code 12.
   *
   * @returns The relative position point of the block referenced by the dimension.
   *
   */
  get dimBlockPosition(): AcGePoint3d {
    return this._dimBlockPosition
  }

  /**
   * Sets the relative position point of the block referenced by the dimension (in WCS coordinates).
   * The block position is the insertion point of the block referenced by the dimension, relative to
   * the primary definition point (DXF group code 10) of the dimension itself.
   * 
   * The block position (in WCS) is added to the dimension primary definition point (also in WCS) to
   * get the actual insertion point for the anonymous block that is referenced by the dimension. So,
   * for example, changing a dimension's block position from (0,0,0) to (0,0,1) (in WCS) will cause 
   * the dimension to display as though it has been moved 1 unit along the WCS Z axis.
   * 
   * For a dimension newly created via any dimension command, the block position will be (0,0,0). 
   * For copies of existing dimensions, or if a dimension is moved, the block position will be the 
   * offset vector (in WCS) from where the original dimension was located. For example, moving a 
   * dimension 1 unit down the WCS Y axis will cause AutoCAD to update the block position value from 
   * (0,0,0) to (0,-1,0) (in WCS coordinates).
   * 
   * The position point is used for DXF group code 12.
   *
   * @param value - The relative position point of the block referenced by the dimension.

   */
  set dimBlockPosition(value: AcGePoint3dLike) {
    this._dimBlockPosition.copy(value)
  }

  /**
   * Gets the dimension style name used by this dimension.
   *
   * @returns The dimension style name, or null if not set
   *
   * @example
   * ```typescript
   * const styleName = dimension.dimensionStyleName;
   * console.log(`Dimension style: ${styleName}`);
   * ```
   */
  get dimensionStyleName() {
    return this._dimensionStyleName
  }

  /**
   * Sets the dimension style name for this dimension.
   *
   * @param value - The dimension style name, or null to use default
   *
   * @example
   * ```typescript
   * dimension.dimensionStyleName = "Standard";
   * ```
   */
  set dimensionStyleName(value: string | null) {
    this._dimensionStyleName = value
    this._dimStyle = undefined
  }

  /**
   * Gets the dimension style used by this dimension.
   *
   * This method returns the dimension style record associated with this dimension.
   * If no style is specified, it returns the default dimension style.
   *
   * @returns The dimension style record
   *
   * @example
   * ```typescript
   * const style = dimension.dimensionStyle;
   * console.log(`Style name: ${style.name}`);
   * ```
   */
  get dimensionStyle(): AcDbDimStyleTableRecord {
    if (this._dimStyle == null) {
      let dimStyle: AcDbDimStyleTableRecord | undefined = undefined
      if (this.dimensionStyleName) {
        dimStyle = this.database.tables.dimStyleTable.getAt(
          this.dimensionStyleName
        )
      }
      if (dimStyle == null) dimStyle = new AcDbDimStyleTableRecord()
      this._dimStyle = dimStyle
    }
    return this._dimStyle
  }

  /**
   * Gets the user-supplied dimension annotation text string.
   *
   * This string can contain multiline text formatting characters. The text can be:
   * - Empty string ('') for default text only
   * - Text with angle brackets for mixed default and user text (e.g., 'This is the default text <>')
   * - Period ('.') for no text
   * - User-defined text only
   *
   * @returns The dimension text string
   *
   * @example
   * ```typescript
   * const text = dimension.dimensionText;
   * console.log(`Dimension text: ${text}`);
   * ```
   */
  get dimensionText() {
    return this._dimensionText
  }
  set dimensionText(value: string | null) {
    this._dimensionText = value
  }

  /**
   * The current measurement value for this dimension
   */
  get measurement() {
    return this._measurement
  }
  set measurement(value: number | undefined) {
    this._measurement = value
  }

  /**
   * The line spacing factor (a value between 0.25 and 4.00).
   */
  get textLineSpacingFactor() {
    return this._textLineSpacingFactor
  }
  set textLineSpacingFactor(value: number) {
    this._textLineSpacingFactor = value
  }

  /**
   * The line spacing style for the dimension.
   */
  get textLineSpacingStyle() {
    return this._textLineSpacingStyle
  }
  set textLineSpacingStyle(value: AcDbLineSpacingStyle) {
    this._textLineSpacingStyle = value
  }

  /**
   * The dimension's text position point. This is the middle center point of the text (which is itself an
   * MText object with middle-center justification).
   */
  get textPosition() {
    return this._textPosition
  }
  set textPosition(value: AcGePoint3d) {
    this._textPosition.copy(value)
  }

  /**
   * The rotation angle (in radians) of the dimension's annotation text. This is the angle from the
   * dimension's horizontal axis to the horizontal axis used by the text. The angle is in the dimension's
   * OCS X-Y plane with positive angles going counterclockwise when looking down the OCS Z axis towards
   * the OCS origin. The value obtained from: (2 * pi) + the dimension's text rotation angle--the
   * dimension's horizontal rotation angle
   */
  get textRotation() {
    return this._textRotation
  }
  set textRotation(value: number) {
    this._textRotation = value
  }

  /**
   * Horizontal direction for the dimension entity (DXF group 51), in radians.
   *
   * Per the AutoCAD DXF reference this is the negative of the angle between
   * the OCS X axis and the UCS X axis, always in the OCS XY plane.
   */
  get horizontalRotation() {
    return this._horizontalRotation
  }
  set horizontalRotation(value: number) {
    this._horizontalRotation = value
  }

  /**
   * Dimension type flags from DXF group 70.
   *
   * Bits 0–3 encode the dimension kind; bit 5 (32) indicates the text was
   * placed at a user-defined location.
   */
  get dimensionType() {
    return this._dimensionType
  }
  set dimensionType(value: number) {
    this._dimensionType = value
  }

  /**
   * Attachment point of the dimension text (DXF group 71).
   */
  get attachmentPoint() {
    return this._attachmentPoint
  }
  set attachmentPoint(value: AcGiMTextAttachmentPoint) {
    this._attachmentPoint = value
  }

  /**
   * DXF class version (group 280). `0` means R2010+.
   */
  get dxfVersion() {
    return this._dxfVersion
  }
  set dxfVersion(value: number) {
    this._dxfVersion = value
  }

  /**
   * Gets the normal vector of the plane containing the dimension.
   *
   * @returns The normal vector
   */
  get normal(): AcGeVector3d {
    return this._normal
  }

  /**
   * Sets the normal vector of the plane containing the dimension.
   *
   * @param value - The new normal vector
   */
  set normal(value: AcGeVector3dLike) {
    this._normal.copy(value).normalize()
  }

  override get properties(): AcDbEntityProperties {
    return this.getBaseProperties()
  }

  protected getBaseProperties(): AcDbEntityProperties {
    return {
      type: this.type,
      groups: [this.getGeneralProperties(), this.getDimensionProperties()]
    }
  }

  /**
   * Transforms this dimension by the specified matrix.
   */
  transformBy(matrix: AcGeMatrix3d): this {
    const origin = this._textPosition.clone()
    const rotationPoint = this._textPosition
      .clone()
      .add(
        new AcGeVector3d(
          Math.cos(this._textRotation),
          Math.sin(this._textRotation),
          0
        )
      )

    this._dimBlockPosition.applyMatrix4(matrix)
    this._textPosition.applyMatrix4(matrix)
    this._normal.transformDirection(matrix)

    const dimBlockRotationAxis = new AcGeVector3d(1, 0, 0).transformDirection(
      matrix
    )
    if (dimBlockRotationAxis.lengthSq() > 0) {
      this._dimBlockRotation += Math.atan2(
        dimBlockRotationAxis.y,
        dimBlockRotationAxis.x
      )
    }

    origin.applyMatrix4(matrix)
    rotationPoint.applyMatrix4(matrix)
    const rotationVector = new AcGeVector3d(rotationPoint).sub(origin)
    if (rotationVector.lengthSq() > 0) {
      this._textRotation = Math.atan2(rotationVector.y, rotationVector.x)
    }

    this.subTransformBy(matrix)
    return this
  }

  /**
   * Resolves osnap points through the anonymous dimension block.
   *
   * Dimensions are rendered from `dimBlockId` contents, so osnap queries need
   * to delegate to the block entities and map points between block-local space
   * and WCS.
   */
  override subGetOsnapPoints(
    osnapMode: AcDbOsnapMode,
    pickPoint: AcGePoint3dLike,
    lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[],
    gsMark?: AcDbObjectId
  ) {
    const blockTableRecord = this.getDimBlockTableRecord()
    if (!blockTableRecord) return

    const blockTransform = this.getFullDimBlockTransform()
    const localPickPoint = new AcGePoint3d(pickPoint).applyMatrix4(
      blockTransform.clone().invert()
    )
    const localLastPoint = new AcGePoint3d(lastPoint).applyMatrix4(
      blockTransform.clone().invert()
    )

    const appendEntitySnapPoints = (
      entity: AcDbEntity,
      subEntityId?: AcDbObjectId
    ) => {
      const localSnapPoints: AcGePoint3d[] = []
      entity.subGetOsnapPoints(
        osnapMode,
        localPickPoint,
        localLastPoint,
        localSnapPoints,
        subEntityId,
        blockTransform
      )

      if (entity instanceof AcDbBlockReference) {
        localSnapPoints.forEach(point => snapPoints.push(point.clone()))
      } else {
        localSnapPoints.forEach(point =>
          snapPoints.push(new AcGePoint3d(point).applyMatrix4(blockTransform))
        )
      }
    }

    if (gsMark) {
      const target = blockTableRecord.getIdAt(gsMark)
      if (target) {
        appendEntitySnapPoints(target, gsMark)
        if (snapPoints.length > 0) return
      }
    }

    for (const entity of blockTableRecord.newIterator()) {
      appendEntitySnapPoints(entity)
    }
  }

  /**
   * @inheritdoc
   */
  subWorldDraw(renderer: AcGiRenderer) {
    const blockTableRecord = this.getDimBlockTableRecord()
    if (blockTableRecord) {
      const matrix = this.computeDimBlockTransform()
      const group = AcDbRenderingCache.instance.draw(
        renderer,
        blockTableRecord,
        this.resolvedColor,
        [],
        false,
        matrix,
        this._normal
      )
      return group
    }
    const group = renderer.group([])
    return group
  }

  /** @inheritdoc */
  override subGetIntersectCurves(): AcGeIntersectPrimitive[] {
    const blockTableRecord = this.getDimBlockTableRecord()
    if (!blockTableRecord) return []
    const matrix = this.getFullDimBlockTransform()
    const primitives: AcGeIntersectPrimitive[] = []
    for (const entity of blockTableRecord.newIterator()) {
      primitives.push(
        ...acdbTransformIntersectPrimitives(
          entity.subGetIntersectCurves(),
          matrix
        )
      )
    }
    return primitives
  }

  /**
   * Computes transformed geometric extents from the anonymous dimension block.
   */
  protected getDimBlockGeometricExtents(): AcGeBox3d {
    const box = new AcGeBox3d()
    const blockTableRecord = this.getDimBlockTableRecord()
    if (!blockTableRecord) return box

    for (const entity of blockTableRecord.newIterator()) {
      box.union(entity.geometricExtents)
    }

    box.applyMatrix4(this.getFullDimBlockTransform())
    return box
  }

  /**
   * Builds geometric extents from a dimension block when present, otherwise from
   * the supplied WCS definition points and user-placed text position.
   */
  protected getGeometricExtentsFromDimBlockOrPoints(
    points: AcGePoint3dLike[]
  ): AcGeBox3d {
    const blockExtents = this.getDimBlockGeometricExtents()
    if (!blockExtents.isEmpty()) {
      return blockExtents
    }

    const box = new AcGeBox3d()
    for (const point of points) {
      box.expandByPoint(point)
    }
    if (this.hasExplicitTextPosition()) {
      box.expandByPoint(this.textPosition)
    }
    return box
  }

  /**
   * Returns true when dimension text has been placed away from the default origin.
   */
  private hasExplicitTextPosition(): boolean {
    const { x, y, z } = this.textPosition
    return x !== 0 || y !== 0 || z !== 0
  }

  /**
   * Collects dimension-specific definition grip points in WCS coordinates.
   *
   * Subclasses override this to expose their editable definition points,
   * matching AutoCAD `AcDbDimension::getGripPoints` behavior.
   */
  protected collectDimensionDefinitionGripPoints(): AcGePoint3d[] {
    return []
  }

  /**
   * Gets the grip points for this dimension.
   *
   * Returns definition points together with the dimension text position.
   *
   * @returns Array of grip points as 3D points
   */
  subGetGripPoints() {
    return this.collectDimensionDefinitionGripPoints().concat([
      this.textPosition
    ])
  }

  /**
   * Moves dimension definition and text grip points by the given offset.
   */
  subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike) {
    const definitionPoints = this.collectDimensionDefinitionGripPoints()
    acdbForEachGripIndex(indices, index => {
      if (index >= 0 && index < definitionPoints.length) {
        definitionPoints[index].add(offset)
      } else if (index === definitionPoints.length) {
        this.textPosition.add(offset)
      }
    })
    return this
  }

  /**
   * Looks up the anonymous block referenced by `dimBlockId`.
   */
  protected getDimBlockTableRecord() {
    return this.dimBlockId
      ? this.database.tables.blockTable.getAt(this.dimBlockId)
      : undefined
  }

  protected getDimensionProperties(): AcDbEntityPropertyGroup {
    return {
      groupName: 'dimension',
      properties: [
        this.createProperty(
          'dimensionStyleName',
          'string',
          () => this.dimensionStyleName ?? '',
          (value: string) => {
            this.dimensionStyleName = value.trim() === '' ? null : value
          }
        ),
        this.createProperty(
          'dimensionText',
          'string',
          () => this.dimensionText ?? '',
          (value: string) => {
            this.dimensionText = value
          }
        ),
        this.createProperty('measurement', 'float', () =>
          this.getMeasurementPropertyValue()
        ),
        this.createProperty(
          'dimBlockId',
          'string',
          () => this.dimBlockId ?? ''
        ),
        ...this.createPoint3dProperties(
          'dimBlockPosition',
          () => this.dimBlockPosition
        ),
        ...this.createPoint3dProperties(
          'textPosition',
          () => this.textPosition
        ),
        this.createProperty(
          'textRotation',
          'float',
          () => this.textRotation,
          (value: number) => {
            this.textRotation = value
          }
        ),
        this.createProperty(
          'textLineSpacingFactor',
          'float',
          () => this.textLineSpacingFactor,
          (value: number) => {
            this.textLineSpacingFactor = value
          }
        ),
        this.createProperty(
          'textLineSpacingStyle',
          'enum',
          () => this.textLineSpacingStyle,
          (value: AcDbLineSpacingStyle) => {
            this.textLineSpacingStyle = value
          },
          [
            {
              label: AcDbLineSpacingStyle[AcDbLineSpacingStyle.AtLeast],
              value: AcDbLineSpacingStyle.AtLeast
            },
            {
              label: AcDbLineSpacingStyle[AcDbLineSpacingStyle.Exactly],
              value: AcDbLineSpacingStyle.Exactly
            }
          ]
        ),
        ...this.createPoint3dProperties('normal', () => this.normal)
      ]
    }
  }

  protected createProperty<T>(
    name: string,
    type: AcDbEntityPropertyType,
    get: () => T,
    set?: (value: T) => void,
    options?: { label: string; value: unknown }[]
  ): AcDbEntityRuntimeProperty<T> {
    return {
      name,
      type,
      editable: set != null,
      options,
      accessor: set ? { get, set } : { get }
    }
  }

  protected createPoint3dProperties(
    prefix: string,
    getPoint: () => AcGePoint3d
  ): AcDbEntityRuntimeProperty<number>[] {
    return [
      this.createProperty(
        `${prefix}X`,
        'float',
        () => getPoint().x,
        (value: number) => {
          getPoint().x = value
        }
      ),
      this.createProperty(
        `${prefix}Y`,
        'float',
        () => getPoint().y,
        (value: number) => {
          getPoint().y = value
        }
      ),
      this.createProperty(
        `${prefix}Z`,
        'float',
        () => getPoint().z,
        (value: number) => {
          getPoint().z = value
        }
      )
    ]
  }

  protected getMeasurementPropertyValue(): number | undefined {
    return this.measurement
  }

  /**
   * Builds the complete dimension-block transform (OCS transform + extrusion).
   */
  protected getFullDimBlockTransform() {
    const dimBlockTransform = this.computeDimBlockTransform()
    if (this._normal.x === 0 && this._normal.y === 0 && this._normal.z === 1) {
      return dimBlockTransform
    }

    const extrusion = new AcGeMatrix3d().setFromExtrusionDirection(this._normal)
    return new AcGeMatrix3d().multiplyMatrices(extrusion, dimBlockTransform)
  }

  protected get arrowScaleFactor() {
    const dimStyle = this.dimensionStyle
    // TODO:
    // 1. DIMASZ has no effect when DIMTSZ is other than zero.
    // 2. Calculate scale factor based on unit
    return dimStyle.dimasz
  }

  /**
   * Arrow style of the first arrow
   */
  protected get firstArrowStyle(): AcGiArrowStyle {
    return {
      type: this.firstArrowType,
      scale: this.arrowScaleFactor,
      appended: this.isAppendArrow,
      visible: this.dimensionStyle.dimse1 == 0
    }
  }

  /**
   * Arrow style of the second arrow
   */
  protected get secondArrowStyle(): AcGiArrowStyle {
    return {
      type: this.secondArrowType,
      scale: this.arrowScaleFactor,
      appended: this.isAppendArrow,
      visible: this.dimensionStyle.dimse2 == 0
    }
  }

  /**
   * The flag to determinate how to attach arrow to endpoint of the line.
   * - true: append arrow to endpoint of the line
   * - false: overlap arrow with endpoint of the line
   */
  protected get isAppendArrow() {
    return true
  }

  /**
   * The BTR id associated with the first arrow type
   */
  protected get firstArrowTypeBtrId() {
    const dimStyle = this.dimensionStyle
    return dimStyle.dimsah == 0 ? dimStyle.dimblk : dimStyle.dimblk1
  }

  /**
   * The first arrow type
   */
  protected get firstArrowType() {
    const btrId = this.firstArrowTypeBtrId
    return this.getArrowName(btrId)
  }

  /**
   * The BTR id associated with the second arrow type
   */
  protected get secondArrowTypeBtrId() {
    const dimStyle = this.dimensionStyle
    return dimStyle.dimsah == 0 ? dimStyle.dimblk : dimStyle.dimblk2
  }

  /**
   * The second arrow type
   */
  protected get secondArrowType() {
    const btrId = this.secondArrowTypeBtrId
    return this.getArrowName(btrId)
  }

  /**
   * The maximum number of arrow lines of this dimension
   */
  protected get arrowLineCount() {
    return 1
  }

  /**
   * Find the point `p3` on a line along the line direction at a distance `length` from `p2`.
   *
   * @param p1 - The start point of the line.
   * @param p2 - The end point of the line.
   * @param length - The distance from `p2` to `p3`.
   * @returns Return the point `p3`.
   */
  protected findPointOnLine1(
    p1: AcGePoint3d,
    p2: AcGePoint3d,
    length: number
  ): AcGePoint3d {
    // Calculate the direction vector from p1 to p2
    const direction = new AcGePoint3d().subVectors(p2, p1).normalize()

    // Calculate p3 by moving in the direction from p2 by the specified length
    const p3 = new AcGePoint3d(p2).addScaledVector(direction, length)

    return p3
  }

  /**
   * Find the point `p2` on a line starting from `p1` at a specified angle
   * and at a distance `length` from `p1`.
   *
   * @param p1 - The start point of the line.
   * @param angle - The angle of the line in radians relative to the x-axis.
   * @param length - The distance from `p1` to `p2`.
   * @returns Return the point `p2`.
   */
  protected findPointOnLine2(
    p1: AcGePoint2dLike,
    angle: number,
    length: number
  ): AcGePoint2dLike {
    // Calculate the new point p2
    const x = p1.x + length * Math.cos(angle)
    const y = p1.y + length * Math.sin(angle)
    return { x, y }
  }

  /**
   * Adjust start point and end point of extension line according current dimension style
   * @param extensionLine Input extension line to adjust its start point and end point
   */
  protected adjustExtensionLine(extensionLine: AcGeLine3d) {
    const dimStyle = this.dimensionStyle
    extensionLine.extend(dimStyle.dimexe)
    extensionLine.extend(-dimStyle.dimexo, true)
  }

  /**
   * Get dimension style name by dimension block id
   * @param id Input dimension block id
   * @returns Return dimension style name by dimension block id
   */
  private getArrowName(id: AcDbObjectId) {
    const blockTableRecord = this.database.tables.blockTable.getIdAt(id)
    return (
      blockTableRecord
        ? blockTableRecord.name.toUpperCase()
        : AcGiArrowType.Closed
    ) as AcGiArrowType
  }

  /**
   * Computes the block-local transformation matrix for the anonymous block
   * referenced by this dimension entity.
   *
   * In AutoCAD, each dimension references an **anonymous block** that contains
   * the graphical representation of the dimension (dimension line, extension
   * lines, arrows, and text). That block is defined in the **dimension?? Object
   * Coordinate System (OCS)**.
   *
   * This method computes the transformation that positions the anonymous
   * dimension block **within the dimension?? OCS**, excluding any extrusion
   * (normal) transformation.
   *
   * Conceptually, AutoCAD applies the following steps when displaying a
   * dimension block:
   *
   * 1. Translate block geometry by the negative block base point
   * 2. Translate by the dimension block position (DXF group code 12)
   * 3. Finally, transform from OCS to WCS using the dimension normal (DXF 210)
   *
   * This method implements **steps 1 and 2 only**.
   *
   * The OCS ??WCS transformation derived from {@link normal} is **intentionally
   * excluded** and must be applied **after rendering** (see
   * {@link AcDbRenderingCache.draw}). This matches AutoCAD / RealDWG behavior and
   * ensures:
   *
   * - Dimension text rotation remains defined in OCS
   * - Arrow orientation and extension line directions remain correct
   * - Anonymous dimension blocks can be safely cached and reused
   *
   * ### Matrix composition (right-multiply convention)
   *
   * ```
   * dimBlockTransform =
   *   T(dimBlockPosition)
   * ? R(dimBlockRotation)
   * ? T(-blockBasePoint)
   * ```
   *
   * ### Notes
   *
   * - The returned matrix operates entirely in dimension OCS
   * - {@link transformBy} accumulates extra block rotation so cached anonymous
   *   block geometry rotates with the dimension definition points
   * - {@link normal} is applied later as a final orientation step
   *
   * @returns A transformation matrix that positions the anonymous dimension
   *          block in OCS space, excluding extrusion.
   */
  private computeDimBlockTransform(): AcGeMatrix3d {
    const blockTableRecord = this.dimBlockId
      ? this.database.tables.blockTable.getAt(this.dimBlockId)
      : undefined

    // The base point of the anonymous dimension block definition
    const basePoint = blockTableRecord?.origin ?? AcGePoint3d.ORIGIN

    // ------------------------------------------------------------
    // Step 1: Base point compensation
    //
    // Move block geometry so that the block base point
    // coincides with the origin of dimension OCS.
    // ------------------------------------------------------------
    const mBase = new AcGeMatrix3d().makeTranslation(
      -basePoint.x,
      -basePoint.y,
      -basePoint.z
    )

    // ------------------------------------------------------------
    // Step 2: Insertion offset (DXF group code 12)
    //
    // This is the relative offset of the dimension block
    // in WCS, applied in dimension OCS coordinates.
    // ------------------------------------------------------------
    const mInsert = new AcGeMatrix3d().makeTranslation(
      this._dimBlockPosition.x,
      this._dimBlockPosition.y,
      this._dimBlockPosition.z
    )

    const mRot = new AcGeMatrix3d().makeRotationZ(this._dimBlockRotation)

    // ------------------------------------------------------------
    // Final matrix (OCS space only):
    //
    // dimBlockTransform =
    //   T(dimBlockPosition)
    // ? R(dimBlockRotation)
    // ? T(-blockBasePoint)
    //
    // NOTE:
    // - This matrix operates entirely in dimension OCS
    // - The extrusion / normal is intentionally excluded
    // ------------------------------------------------------------
    return new AcGeMatrix3d().multiplyMatrices(
      mInsert,
      new AcGeMatrix3d().multiplyMatrices(mRot, mBase)
    )
  }

  /**
   * Subclasses can override this to transform their own definition points.
   */
  protected subTransformBy(_matrix: AcGeMatrix3d) {}

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    super.dxfOutFields(filer)
    const dimStyle =
      this.dimensionStyleName != null
        ? this.database.tables.dimStyleTable.getAt(this.dimensionStyleName)
        : undefined
    filer.writeSubclassMarker('AcDbDimension')
    filer.writeInt16(280, this.dxfVersion)
    filer.writeString(2, this.dimBlockId ?? undefined)
    filer.writeString(3, this.dimensionStyleName ?? this.dimensionStyle.name)
    filer.writePoint3d(10, this._dxfDefinitionPoint)
    filer.writeString(1, this.dimensionText ?? '')
    filer.writeAngle(53, this.textRotation)
    if (this.horizontalRotation !== 0) {
      filer.writeAngle(51, this.horizontalRotation)
    }
    filer.writePoint3d(11, this.textPosition)
    // Group 12 is the anonymous-block insertion point (OCS). It lives in the
    // AcDbDimension section, before any typed subclass marker.
    filer.writePoint3d(12, this.dimBlockPosition)
    filer.writeInt16(70, this.dimensionType)
    filer.writeInt16(71, this.attachmentPoint)
    filer.writeInt16(72, this.textLineSpacingStyle)
    filer.writeDouble(41, this.textLineSpacingFactor)
    filer.writeDouble(42, this.measurement)
    filer.writeVector3d(210, this.normal)
    filer.writeObjectId(340, dimStyle?.objectId)
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)
    // Tolerate missing AcDbDimension marker.
    filer.atSubclassData('AcDbDimension')

    // Group 10 is the definition point. Group 12 is the anonymous-block
    // insertion point. Do not substitute group 10 for a missing group 12:
    // *D* block geometry is often already in WCS, and using group 10 would
    // double-offset it. Some writers place group 12 after the typed subclass
    // marker; those are applied by the subclass and must not be cleared here.
    let dx = this._dxfDefinitionPoint.x
    let dy = this._dxfDefinitionPoint.y
    let dz = this._dxfDefinitionPoint.z
    let tx = this.textPosition.x
    let ty = this.textPosition.y
    let tz = this.textPosition.z
    let ix = this._dimBlockPosition.x
    let iy = this._dimBlockPosition.y
    let iz = this._dimBlockPosition.z
    let hasBlockPosition = false
    let textRotDeg = (this.textRotation * 180) / Math.PI
    let nx = this.normal.x
    let ny = this.normal.y
    let nz = this.normal.z

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      const n = Number(item.value)
      if (code === 100) {
        // Next dimension subclass (AcDbAlignedDimension, …).
        filer.pushBackItem(item)
        break
      }
      switch (code) {
        case 1:
          this.dimensionText = String(item.value)
          break
        case 2:
          this.dimBlockId = String(item.value)
          break
        case 3:
          this.dimensionStyleName = String(item.value)
          break
        case 10:
          dx = n
          break
        case 20:
          dy = n
          break
        case 30:
          dz = n
          break
        case 11:
          tx = n
          break
        case 21:
          ty = n
          break
        case 31:
          tz = n
          break
        case 12:
          ix = n
          hasBlockPosition = true
          break
        case 22:
          iy = n
          hasBlockPosition = true
          break
        case 32:
          iz = n
          hasBlockPosition = true
          break
        case 41:
          this.textLineSpacingFactor = n
          break
        case 42:
          this.measurement = n
          break
        case 53:
          textRotDeg = n
          break
        case 51:
          this.horizontalRotation = AcGeMathUtil.degToRad(n)
          break
        case 70:
          this.dimensionType = n
          break
        case 71:
          this.attachmentPoint = n as AcGiMTextAttachmentPoint
          break
        case 72:
          this.textLineSpacingStyle = n as AcDbLineSpacingStyle
          break
        case 210:
          nx = n
          break
        case 220:
          ny = n
          break
        case 230:
          nz = n
          break
        case 280:
          this.dxfVersion = n
          break
        case 340:
          // Dimstyle hard pointer — style is resolved via name (group 3).
          break
        default:
          // Dimstyle overrides and other optional codes may appear here.
          // Keep scanning so the typed subclass marker (100) is still reached.
          break
      }
    }

    this._dxfDefinitionPoint.set(dx, dy, dz)
    this.textPosition.copy(new AcGePoint3d(tx, ty, tz))
    if (hasBlockPosition) {
      this.dimBlockPosition = { x: ix, y: iy, z: iz }
    }
    this.textRotation = (textRotDeg * Math.PI) / 180
    this.normal.copy(new AcGeVector3d(nx, ny, nz))
    return this
  }
}
