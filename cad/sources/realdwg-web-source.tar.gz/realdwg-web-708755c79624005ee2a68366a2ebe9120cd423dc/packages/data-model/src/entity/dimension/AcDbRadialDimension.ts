import {
  AcGeMatrix3d,
  AcGePoint3d,
  AcGePoint3dLike
} from '@mlightcad/geometry-engine'

import { AcDbDxfFiler } from '../../base'
import { AcDbEntityProperties } from '../AcDbEntityProperties'
import { AcDbDimension } from './AcDbDimension'

/**
 * Represents a radial dimension entity in AutoCAD.
 *
 * A radial dimension measures the radius of a curve (typically a circle or arc).
 * This dimension type requires a center point and a point on the curve being dimensioned
 * in order to draw the dimension line from the center point through the point on the curve.
 *
 * The dimension utilizes a "leader length" value to determine how far the dimension line
 * extends out past the curve before doing a horizontal dogleg (if necessary) to the annotation text.
 *
 * @example
 * ```typescript
 * // Create a radial dimension
 * const radialDim = new AcDbRadialDimension(
 *   new AcGePoint3d(0, 0, 0),    // Center point
 *   new AcGePoint3d(5, 0, 0),    // Point on curve
 *   2.0,                         // Leader length
 *   "5.0",                       // Dimension text
 *   "Standard"                   // Dimension style
 * );
 *
 * // Access dimension properties
 * console.log(`Center: ${radialDim.center}`);
 * console.log(`Chord point: ${radialDim.chordPoint}`);
 * console.log(`Leader length: ${radialDim.leaderLength}`);
 * ```
 */
export class AcDbRadialDimension extends AcDbDimension {
  /** The entity type name */
  static override typeName: string = 'RadialDimension'

  /** The center point of the curve being dimensioned */
  private _center: AcGePoint3d
  /** The point where the dimension line intersects the curve being dimensioned */
  private _chordPoint: AcGePoint3d
  /** The extension arc start angle in radians */
  private _extArcStartAngle: number
  /** The extension arc end angle in radians */
  private _extArcEndAngle: number
  /** The leader length distance */
  private _leaderLength: number

  /**
   * Creates a new radial dimension entity.
   *
   * This constructor initializes a radial dimension using the specified center point,
   * chord point, and leader length. The dimension line behavior depends on whether
   * the text is inside or outside the curve being dimensioned.
   *
   * - If the text is inside the curve, the dimension line is drawn from the center
   *   to the chordPoint, with a break for the annotation text.
   * - If the text is outside the curve, the dimension line is drawn from the center,
   *   through the chordPoint and out the leaderLength distance past the chordPoint
   *   where it does a short horizontal dogleg (if appropriate) to the annotation text.
   *
   * @param center - Center point (in WCS coordinates) of curve being dimensioned
   * @param chordPoint - Point (in WCS coordinates) on the curve being dimensioned
   * @param leaderLength - Leader length distance
   * @param dimText - Text string to use as the dimension annotation (optional)
   * @param dimStyle - String name of dimension style table record to use (optional)
   *
   * @example
   * ```typescript
   * // Create a radial dimension with default text and style
   * const radialDim = new AcDbRadialDimension(
   *   new AcGePoint3d(0, 0, 0),
   *   new AcGePoint3d(5, 0, 0),
   *   2.0
   * );
   *
   * // Create a radial dimension with custom text and style
   * const radialDim2 = new AcDbRadialDimension(
   *   new AcGePoint3d(10, 10, 0),
   *   new AcGePoint3d(15, 10, 0),
   *   3.0,
   *   "5.0",
   *   "Architectural"
   * );
   * ```
   */
  constructor(
    center: AcGePoint3dLike,
    chordPoint: AcGePoint3dLike,
    leaderLength: number,
    dimText: string | null = null,
    dimStyle: string | null = null
  ) {
    super()
    this._center = new AcGePoint3d().copy(center)
    this._chordPoint = new AcGePoint3d().copy(chordPoint)
    this._leaderLength = leaderLength
    this._extArcStartAngle = 0
    this._extArcEndAngle = 0

    this.dimensionText = dimText
    // TODO: Set it to the current default dimStyle within the AutoCAD editor if dimStyle is null
    this.dimensionStyleName = dimStyle
  }

  /**
   * Gets the center point of the curve being dimensioned.
   *
   * This point is the primary definition point for this dimension type.
   *
   * @returns The center point in WCS coordinates
   *
   * @example
   * ```typescript
   * const center = radialDim.center;
   * console.log(`Center point: ${center.x}, ${center.y}, ${center.z}`);
   * ```
   */
  get center() {
    return this._center
  }

  /**
   * Sets the center point of the curve being dimensioned.
   *
   * @param value - The new center point
   *
   * @example
   * ```typescript
   * radialDim.center = new AcGePoint3d(0, 0, 0);
   * ```
   */
  set center(value: AcGePoint3d) {
    this._center.copy(value)
  }

  /**
   * Gets the point where the dimension line intersects the curve being dimensioned.
   *
   * @returns The chord point in WCS coordinates
   *
   * @example
   * ```typescript
   * const chordPoint = radialDim.chordPoint;
   * console.log(`Chord point: ${chordPoint.x}, ${chordPoint.y}, ${chordPoint.z}`);
   * ```
   */
  get chordPoint() {
    return this._chordPoint
  }

  /**
   * Sets the point where the dimension line intersects the curve being dimensioned.
   *
   * @param value - The new chord point
   *
   * @example
   * ```typescript
   * radialDim.chordPoint = new AcGePoint3d(5, 0, 0);
   * ```
   */
  set chordPoint(value: AcGePoint3d) {
    this._chordPoint.copy(value)
  }

  /**
   * Gets the extension arc start angle.
   *
   * @returns The extension arc start angle in radians
   *
   * @example
   * ```typescript
   * const startAngle = radialDim.extArcStartAngle;
   * console.log(`Extension arc start angle: ${startAngle} radians`);
   * ```
   */
  get extArcStartAngle() {
    return this._extArcStartAngle
  }

  /**
   * Sets the extension arc start angle.
   *
   * @param value - The new extension arc start angle in radians
   *
   * @example
   * ```typescript
   * radialDim.extArcStartAngle = 0;
   * ```
   */
  set extArcStartAngle(value: number) {
    this._extArcStartAngle = value
  }

  /**
   * Gets the extension arc end angle.
   *
   * @returns The extension arc end angle in radians
   *
   * @example
   * ```typescript
   * const endAngle = radialDim.extArcEndAngle;
   * console.log(`Extension arc end angle: ${endAngle} radians`);
   * ```
   */
  get extArcEndAngle() {
    return this._extArcEndAngle
  }

  /**
   * Sets the extension arc end angle.
   *
   * @param value - The new extension arc end angle in radians
   *
   * @example
   * ```typescript
   * radialDim.extArcEndAngle = Math.PI / 2;
   * ```
   */
  set extArcEndAngle(value: number) {
    this._extArcEndAngle = value
  }

  /**
   * Gets the leader length.
   *
   * The leader length is the distance from the chordPoint dimension definition point
   * out to where the dimension does a horizontal dogleg to the annotation text
   * (or stops if no dogleg is needed).
   *
   * @returns The leader length value
   *
   * @example
   * ```typescript
   * const leaderLength = radialDim.leaderLength;
   * console.log(`Leader length: ${leaderLength}`);
   * ```
   */
  get leaderLength() {
    return this._leaderLength
  }

  set leaderLength(value: number) {
    this._leaderLength = value
  }

  /**
   * Sets the leader length.
   *
   * @param value - The new leader length value
   *
   * @example
   * ```typescript
   * radialDim.leaderLength = 3.0;
   * ```
   */
  set leaderLenght(value: number) {
    this._leaderLength = value
  }

  override get properties(): AcDbEntityProperties {
    const baseProperties = this.getBaseProperties()
    return {
      type: this.type,
      groups: [
        ...baseProperties.groups,
        {
          groupName: 'geometry',
          properties: [
            ...this.createPoint3dProperties('center', () => this.center),
            ...this.createPoint3dProperties(
              'chordPoint',
              () => this.chordPoint
            ),
            this.createProperty(
              'leaderLength',
              'float',
              () => this.leaderLength,
              (value: number) => {
                this.leaderLength = value
              }
            ),
            this.createProperty(
              'extArcStartAngle',
              'float',
              () => this.extArcStartAngle,
              (value: number) => {
                this.extArcStartAngle = value
              }
            ),
            this.createProperty(
              'extArcEndAngle',
              'float',
              () => this.extArcEndAngle,
              (value: number) => {
                this.extArcEndAngle = value
              }
            )
          ]
        }
      ]
    }
  }

  /**
   * @inheritdoc
   */
  protected override collectDimensionDefinitionGripPoints() {
    return [this.center, this.chordPoint]
  }

  /**
   * @inheritdoc
   */
  protected override subTransformBy(matrix: AcGeMatrix3d) {
    this._center.applyMatrix4(matrix)
    this._chordPoint.applyMatrix4(matrix)
  }

  protected override getMeasurementPropertyValue() {
    return this.measurement ?? this.center.distanceTo(this.chordPoint)
  }

  /**
   * @inheritdoc
   */
  get geometricExtents() {
    const points = [this.center, this.chordPoint]
    if (this.leaderLength > 0) {
      const direction = this.chordPoint.clone().sub(this.center)
      if (direction.lengthSq() > 0) {
        direction.normalize().multiplyScalar(this.leaderLength)
        points.push(this.chordPoint.clone().add(direction))
      }
    }
    return this.getGeometricExtentsFromDimBlockOrPoints(points)
  }

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    super.dxfOutFields(filer)
    filer.writeSubclassMarker('AcDbRadialDimension')
    filer.writePoint3d(15, this.center)
    filer.writePoint3d(13, this.chordPoint)
    filer.writeDouble(40, this.leaderLength)
    filer.writeAngle(52, this.extArcStartAngle)
    filer.writeAngle(53, this.extArcEndAngle)
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)
    filer.atSubclassData('AcDbRadialDimension')

    // Match AutoCAD DXF / dxf-json-converter:
    // group 10 (definition point) = center, group 15 = chord point.
    const cx = this._dxfDefinitionPoint.x
    const cy = this._dxfDefinitionPoint.y
    const cz = this._dxfDefinitionPoint.z
    let hx = this.chordPoint.x
    let hy = this.chordPoint.y
    let hz = this.chordPoint.z
    let hasChord = false
    let startDeg = (this.extArcStartAngle * 180) / Math.PI
    let endDeg = (this.extArcEndAngle * 180) / Math.PI

    const commit = () => {
      this.center = new AcGePoint3d(cx, cy, cz)
      this.chordPoint = new AcGePoint3d(hx, hy, hz)
      this.extArcStartAngle = (startDeg * Math.PI) / 180
      this.extArcEndAngle = (endDeg * Math.PI) / 180
    }

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      const n = Number(item.value)
      switch (code) {
        case 15:
          hx = n
          hasChord = true
          break
        case 25:
          hy = n
          hasChord = true
          break
        case 35:
          hz = n
          hasChord = true
          break
        case 13:
          // ObjectARX write uses 13 for chord; prefer 15 when both exist.
          if (!hasChord) hx = n
          break
        case 23:
          if (!hasChord) hy = n
          break
        case 33:
          if (!hasChord) hz = n
          break
        case 40:
          this.leaderLength = n
          break
        case 52:
          startDeg = n
          break
        case 53:
          endDeg = n
          break
        default:
          break
      }
    }

    commit()
    return this
  }
}
