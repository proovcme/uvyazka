# @mlightcad/realdwg-web-example

## 0.15.11

### Patch Changes

- fix: guards browser-only globals so public package entry points load in both browsers and Node. File loading, converter workers, OLE metafile rasterization, and EMF decoding no longer assume document, window, or Worker exist when a module is first imported. A dual-runtime test bundles each public package in both environments so import-time DOM or worker access fails in CI before it ships.
- Updated dependencies
  - @mlightcad/data-model@1.15.11
  - @mlightcad/libredwg-converter@3.15.11

## 0.15.10

### Patch Changes

- feat: adds annotation scale support for annotative MTEXT by reading SCALE, DICTIONARYVAR, and context data from DXF and LibreDWG, honoring CANNOSCALE when drawing so extents, grips, and osnap stay aligned with the active scale. Also reuses the objectId already-stored guard when filling materialized DICTIONARY entries so mojibake ACAD_LAYOUT names do not create a second layout slot
- Updated dependencies
  - @mlightcad/data-model@1.15.10
  - @mlightcad/libredwg-converter@3.15.10

## 0.15.9

### Patch Changes

- fix: resolve nested INSERT osnap targeting and keep open wide polylines visible. Fixes osnap on nested INSERT entities by correctly resolving the #n occurrence index via gsMark. Also ensures open wide polylines remain visible by drawing a centerline stroke regardless of fill-area success.
- Updated dependencies
  - @mlightcad/data-model@1.15.9
  - @mlightcad/libredwg-converter@3.15.9

## 0.15.8

### Patch Changes

- fix: keeps hatch boundary paths intact when edge endpoints drift, gives each wide-polyline subpath its own area so multi-area wide polylines stay off direct batching, and resolves large-block osnap plus loglevel side effects and read() input handling
- Updated dependencies
  - @mlightcad/data-model@1.15.8
  - @mlightcad/libredwg-converter@3.15.8

## 0.15.7

### Patch Changes

- fix: keeps MLeader textWidth 0 as auto wrap and lands doglegs on contentBasePosition when dogleg length is undersized, and builds splines from fit-point arrays when the declared count is omitted. Also upgrades the LibreDWG web dependency to v0.8.0
- Updated dependencies
  - @mlightcad/data-model@1.15.7
  - @mlightcad/libredwg-converter@3.15.7

## 0.15.6

### Patch Changes

- fix: renders nearly-closed wide polylines through offsetRing instead of rejecting open loops that close on themselves, drops the thin-ring area-ratio gate that blocked building-scale outlines, and makes area hierarchy nesting deterministic so polyline fills stay correct
- Updated dependencies
  - @mlightcad/data-model@1.15.6
  - @mlightcad/libredwg-converter@3.15.6

## 0.15.5

### Patch Changes

- fix: restores R12 DXF read/write round-trip, skips mojibake ACAD_LAYOUT aliases that would collide with existing layouts, and prefers CONTENTS bitmaps over OlePres clipboard icons so OLE frames show the embedded picture instead of a generic icon
- Updated dependencies
  - @mlightcad/data-model@1.15.5
  - @mlightcad/libredwg-converter@3.15.5

## 0.15.4

### Patch Changes

- feat: exposes paper-space viewport frozen layers so renderers can honor VPLAYER freezes. AcGiViewport now carries frozenLayerIds and the resolved frozen layer names from AcDbViewport, so model-space entities on layers frozen in a paper-space viewport can be hidden during display.
- Updated dependencies
  - @mlightcad/data-model@1.15.4
  - @mlightcad/libredwg-converter@3.15.4

## 0.15.3

### Patch Changes

- fix: corrects DXF import for DIMENSION block insertion, VIEWPORT width/height, hatch colors, multileader arrowhead size from CONTEXT_DATA, and $DWGCODEPAGE encoding for binary and legacy ASCII DXF. ATTRIB/ATTDEF ignore embedded Xrecord flags, and model space stays findable when it claims handle 2
- Updated dependencies
  - @mlightcad/data-model@1.15.3
  - @mlightcad/libredwg-converter@3.15.3

## 0.15.2

### Patch Changes

- fix: maps OCS geometry into WCS so TRACE and SOLID corners convert correctly and entities with extrusion (0,0,-1) land in world space. Rendering cache is kept across convert finish so drawings do not drop cached graphics when conversion completes
- Updated dependencies
  - @mlightcad/data-model@1.15.2
  - @mlightcad/libredwg-converter@3.15.2

## 0.15.1

### Patch Changes

- feat: paints wipeouts with the layout background fill so covered geometry stays hidden. DXF export expands XData points and binary chunks, and attribute definitions keep their owner ids when block table record handles collide. Imported XData is stored in a compacted form that uses less memory
- Updated dependencies
  - @mlightcad/data-model@1.15.1
  - @mlightcad/libredwg-converter@3.15.1

## 0.15.0

### Minor Changes

- fix: aligns DWG converter license failure markers with the current @mlightcad/dwg-converter messages so expired evaluation and invalid license key errors classify correctly as license_expired and license_invalid instead of falling through as generic open failures

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.15.0
  - @mlightcad/libredwg-converter@3.15.0

## 0.14.14

### Patch Changes

- feat: vendors emf-converter as the @mlightcad/emf-converter workspace package and exposes raster image and OLE frame properties so the property palette can edit them. Missing image paths draw without MTEXT control codes, and DWG import no longer aborts when handles are assigned before attributes
- Updated dependencies
  - @mlightcad/data-model@1.14.14
  - @mlightcad/libredwg-converter@3.14.14

## 0.14.13

### Patch Changes

- feat: draws closed wide polylines with index-aligned offsetRing so outer and inner stroke loops share sample order and count, letting renderers triangulate the stroke band without area holes. fillType updates stay on the successful draw path, and closed wide polylines skip area batching
- Updated dependencies
  - @mlightcad/data-model@1.14.13
  - @mlightcad/libredwg-converter@3.14.13

## 0.14.12

### Patch Changes

- fix: keeps compact MTEXT line spacing under the At Least style so lines expand only when the factor would pack them closer than the text height, and passes Exact spacing through DWG import. DXF load and block draw allocate less via span-based pair parsing, lazy entity geometry, in-place OCS transforms, and LRU rendering-cache eviction. Incomplete MLINESTYLE entries no longer abort opens, and WASM out-of-memory faults are reported as worker_oom
- Updated dependencies
  - @mlightcad/data-model@1.14.12
  - @mlightcad/libredwg-converter@3.14.12

## 0.14.11

### Patch Changes

- feat: adds dynamic block INSERT drawing via anonymous \*U representations and LibreDWG dyn-block dictionary metadata, plus AcDbArcAlignedText with DXF group 90 color round-trip. AcDbBlockRepresentationData remains for converters and dyn-block references but is no longer publicly re-exported
- Updated dependencies
  - @mlightcad/data-model@1.14.11
  - @mlightcad/libredwg-converter@3.14.11

## 0.14.10

### Patch Changes

- fix: keeps tapered LWPOLYLINE vertex widths when converting from libredwg-web 0.7.13 so valve triangles and other variable-width polylines retain start and end widths instead of collapsing to constant width
- Updated dependencies
  - @mlightcad/data-model@1.14.10
  - @mlightcad/libredwg-converter@3.14.10

## 0.14.9

### Patch Changes

- fix: preserves complex linetype shape and text DXF extras on round-trip by reading and writing shape number, style object id, scale, rotation, X/Y offsets, and embedded text for non-dash pattern elements, so those attributes are no longer dropped when parsing or exporting DXF linetype table records
- Updated dependencies
  - @mlightcad/data-model@1.14.9
  - @mlightcad/libredwg-converter@3.14.9

## 0.14.8

### Patch Changes

- fix: renders tapered wide polylines that taper to zero width as filled geometry instead of falling back to strokes, including collapsed-inner circular widths as solid disks. LibreDWG solid hatches named \_SOLID (and leading-underscore variants) are recognized as solid fills so empty definitionLines are no longer dropped during convert
- Updated dependencies
  - @mlightcad/data-model@1.14.8
  - @mlightcad/libredwg-converter@3.14.8

## 0.14.7

### Patch Changes

- fix: decodes Korean CP949 DXF text via euc-kr so layer names and annotations no longer garble, hardens DXF transparency header reads and full-ellipse/full-circle hatch arcs for round-trip fidelity, and fixes Excel OLE EMF text clipping plus CJK font fallback when rendering embedded previews
- Updated dependencies
  - @mlightcad/data-model@1.14.7
  - @mlightcad/libredwg-converter@3.14.7

## 0.14.6

### Patch Changes

- fix: anchors TEXT by DXF group 11 presence instead of matching coordinates, prefers Ole10Native BMP over OlePres WMF for Paintbrush OLE so raster previews render correctly, and flattens INSERT elevation in blockTransform so 2D clipping no longer misses elevated block references
- Updated dependencies
  - @mlightcad/data-model@1.14.6
  - @mlightcad/libredwg-converter@3.14.6

## 0.14.5

### Patch Changes

- fix: ignores non-finite geometry points so NaN bounding boxes no longer poison spatial indexes, and empty polyline OCS boxes return an empty WCS box instead of transforming infinity. Also skips drawing non-constant ATTDEFs inside block definitions so only constant attribute templates render as block geometry while INSERT ATTRIB draws the editable values
- Updated dependencies
  - @mlightcad/data-model@1.14.5
  - @mlightcad/libredwg-converter@3.14.5

## 0.14.4

### Patch Changes

- feat: extracts and rasterizes OLE WMF/EMF metafile previews so embedded OLE content can render as images, and classifies DWG converter license failures into clearer open-database errors. LibreDWG layer import maps CMC RGB true colors when colorIndex is 256 instead of losing those layer colors
- Updated dependencies
  - @mlightcad/data-model@1.14.4
  - @mlightcad/libredwg-converter@3.14.4

## 0.14.3

### Patch Changes

- feat: adds chord-height curve tessellation so short arcs use fewer segments than a full circle, while opening a drawing without circleSides defaults to draft quality so stored VIEWRES 1000 is not applied accidentally. Circles, arcs, ellipses, polylines, leaders, and splines tessellate from the open-time setting, and renderers can read drawCircleSides from the draw context
- Updated dependencies
  - @mlightcad/data-model@1.14.3
  - @mlightcad/libredwg-converter@3.14.3

## 0.14.2

### Patch Changes

- feat: adds AutoCAD-compatible DWG Compare system variables so drawings can store COMPAREHATCH, COMPARETEXT, COMPARERCMARGIN, and COMPARETOLERANCE with AutoCAD defaults and ranges, while COMPAREPROPS stays a registry-backed bitcode for property-only diffs. DXF HEADER import reads in-range compare values and ignores out-of-range ones, and the database exposes typed getters plus COMPAREPROPS color, layer, and linetype bit flags
- Updated dependencies
  - @mlightcad/data-model@1.14.2
  - @mlightcad/libredwg-converter@3.14.2

## 0.14.1

### Patch Changes

- fix: defaults omitted DXF entity colors to ByLayer instead of the current CECOLOR system variable, matching AutoCAD when color group 62 is absent. LibreDWG dwg2dxf often writes $CECOLOR 0 while omitting that group on ByLayer entities, so import no longer copies CECOLOR onto them. Also upgrades @mlightcad/libredwg-web to 0.7.10
- Updated dependencies
  - @mlightcad/data-model@1.14.1
  - @mlightcad/libredwg-converter@3.14.1

## 0.14.0

### Minor Changes

- feat: adds ObjectARX-style entity intersection so callers can query WCS intersection points between drawing entities via AcDbEntity.intersectWith, with extend-this, extend-arg, and extend-both flags plus optional apparent intersection on a projection plane. Curve entities, hatches, inserts, and dimensions expose primitives, while text-like entities stay empty. The geometry engine adds acgeIntersectCurves for pairwise line, arc, ellipse, and spline intersection with de-duplication

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.14.0
  - @mlightcad/libredwg-converter@3.14.0

## 0.13.1

### Patch Changes

- feat: adds circular-arc factory helpers so callers can build 2D circles and arcs from center-radius, diameter, three points, start-end-bulge, and start-center-end constructions. Three-point arcs now pick a unique circumcircle and honor AutoCAD-style reverse-direction sweep, so near-collinear points and complementary arcs stay numerically stable
- Updated dependencies
  - @mlightcad/data-model@1.13.1
  - @mlightcad/libredwg-converter@3.13.1

## 0.13.0

### Minor Changes

- feat: adds a session-scoped LOGINNAME system variable so drawings can expose the current login name, and fixes LibreDWG converter packaging so the wasm module is emitted beside the parser worker for reliable runtime loading

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.13.0
  - @mlightcad/libredwg-converter@3.13.0

## 0.12.5

### Patch Changes

- feat: adds directBatchPrimitive for faster entity geometry batching, fixes OCS transforms for non-default extrusions so arcs and circles render correctly, and tolerates missing LibreDWG symbol and table names without throwing
- Updated dependencies
  - @mlightcad/data-model@1.12.5
  - @mlightcad/libredwg-converter@3.12.5

## 0.12.4

### Patch Changes

- feat: speeds up drawing open by loading fonts on demand, skipping font work when no loader is set, streaming large-block font collection, batching font loads in parallel, and deferring mid-size block compaction
- Updated dependencies
  - @mlightcad/data-model@1.12.4
  - @mlightcad/libredwg-converter@3.12.4

## 0.12.3

### Patch Changes

- feat: improve block rendering cache hits, trim font preload, and correctly apply ACIS body transforms to solid geometry
- Updated dependencies
  - @mlightcad/data-model@1.12.3
  - @mlightcad/libredwg-converter@3.12.3

## 0.12.2

### Patch Changes

- feat: faster DWG/DXF parsing via zero-copy worker transfers and windowed UTF-8 decoding, plus private dwg-converter setup tooling
- Updated dependencies
  - @mlightcad/data-model@1.12.2
  - @mlightcad/libredwg-converter@3.12.2

## 0.12.1

### Patch Changes

- feat: adds time-budgeted UI feedback, block-cache templates, MINSERT parameters, OLE2FRAME geometry, ByBlock ACI7, native DXF registration, and migrates GPL converters
- Updated dependencies
  - @mlightcad/data-model@1.12.1
  - @mlightcad/libredwg-converter@3.12.1

## 0.12.0

### Minor Changes

- Fix xref import, add MIT DXF converter, attach ACDSDATA to 3DSOLIDs, and improve DXF open progress

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.12.0
  - @mlightcad/dxf-json-converter@1.12.0
  - @mlightcad/libredwg-converter@3.12.0

## 0.11.3

### Patch Changes

- feat: support drawing thumbnails and viewport DCS-to-WCS mapping
- Updated dependencies
  - @mlightcad/data-model@1.11.3
  - @mlightcad/dxf-json-converter@1.11.3
  - @mlightcad/libredwg-converter@3.11.3

## 0.11.2

### Patch Changes

- fix: draw ATTDEF per AutoCAD semantics and fix DXF flags
- Updated dependencies
  - @mlightcad/data-model@1.11.2
  - @mlightcad/dxf-json-converter@1.11.2
  - @mlightcad/libredwg-converter@3.11.2

## 0.11.1

### Patch Changes

- feat: upgraded to Vite 6 & dxf-json 1.2.8, and improved data model by storing block PreviewIcons as bytes and fixed nested layer filter behavior
- Updated dependencies
  - @mlightcad/data-model@1.11.1
  - @mlightcad/dxf-json-converter@1.11.1
  - @mlightcad/libredwg-converter@3.11.1

## 0.11.0

### Patch Changes

- feat: adds support for OLE frames and layer filters, improves image frame selection, assigns TEMP handles to unbound AcDbObjects, and refactors helper naming with consistent acdb/acge prefixes for better maintainability
- Updated dependencies
  - @mlightcad/data-model@1.11.0
  - @mlightcad/dxf-json-converter@1.11.0
  - @mlightcad/libredwg-converter@3.11.0

## 0.10.7

### Patch Changes

- feat: added block cross-reference flags & unresolved detection, and improved data model flexibility by making the CLASSES conversion stage optional
- Updated dependencies
  - @mlightcad/data-model@1.10.7
  - @mlightcad/dxf-json-converter@1.10.7
  - @mlightcad/libredwg-converter@3.10.7

## 0.10.6

### Patch Changes

- feat: improved DXF compatibility and data integrity with corrected group codes, CLASSES and SOLID export support, fixed proxy DXF codes, preserved SHAPE round-trip identity, and maintained circular arc endpoints when reversing loop edges
- Updated dependencies
  - @mlightcad/data-model@1.10.6
  - @mlightcad/dxf-json-converter@1.10.6
  - @mlightcad/libredwg-converter@3.10.6

## 0.10.5

### Patch Changes

- feat: added a heuristic memory estimator for AcDbDatabase and fixed saved view restoration by correctly applying VPORT view target and twist, improving memory estimation and view consistency
- Updated dependencies
  - @mlightcad/data-model@1.10.5
  - @mlightcad/dxf-json-converter@1.10.5
  - @mlightcad/libredwg-converter@3.10.5

## 0.10.4

### Patch Changes

- feat: sync latest upstream changes for ACIS SAB decoding, 3DSOLID wireframes, CI update, and FCF GDT/TOLERANCE improvements
- Updated dependencies
  - @mlightcad/data-model@1.10.4
  - @mlightcad/dxf-json-converter@1.10.4
  - @mlightcad/libredwg-converter@3.10.4

## 0.10.3

### Patch Changes

- feat: add AcDbFcf and AcDb3dSolid
- Updated dependencies
  - @mlightcad/data-model@1.10.3
  - @mlightcad/dxf-json-converter@1.10.3
  - @mlightcad/libredwg-converter@3.10.3

## 0.10.2

### Patch Changes

- feat: improved data model reliability with structured database error reporting, resilient font loading, accurate leader hook line rendering, and global handle registry to prevent cross-table handle collisions
- Updated dependencies
  - @mlightcad/data-model@1.10.2
  - @mlightcad/dxf-json-converter@1.10.2
  - @mlightcad/libredwg-converter@3.10.2

## 0.10.1

### Patch Changes

- fix: improved AutoCAD compatibility by normalizing symbol table names and enhanced wide polyline fill rendering for self-overlapping paths
- Updated dependencies
  - @mlightcad/data-model@1.10.1
  - @mlightcad/dxf-json-converter@1.10.1
  - @mlightcad/libredwg-converter@3.10.1

## 0.10.0

### Minor Changes

- feat: refactor symbol table storage with typed attributes, enforce write access controls, dispatch layerModified events, fix entityModified dispatch on commit, and resolve MLine grip issues for improved data integrity

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.10.0
  - @mlightcad/dxf-json-converter@1.10.0
  - @mlightcad/libredwg-converter@3.10.0

## 0.3.14

### Patch Changes

- fix(data-model): correct transforms for dimensions, proxy entities, and block attributes
- Updated dependencies
  - @mlightcad/data-model@1.9.14
  - @mlightcad/dxf-json-converter@1.9.14
  - @mlightcad/libredwg-converter@3.7.14

## 0.3.13

### Patch Changes

- feat(data-model): enhance grip editing with GRIPS sysvar and entity-specific grips
- Updated dependencies
  - @mlightcad/data-model@1.9.13
  - @mlightcad/dxf-json-converter@1.9.13
  - @mlightcad/libredwg-converter@3.7.13

## 0.3.12

### Patch Changes

- feat(data-model,dxf-json-converter): add edit shortcuts and binary DXF parsing
- Updated dependencies
  - @mlightcad/data-model@1.9.12
  - @mlightcad/dxf-json-converter@1.9.12
  - @mlightcad/libredwg-converter@3.7.12

## 0.3.11

### Patch Changes

- feat: implement database transaction manager with undo/redo
- Updated dependencies
  - @mlightcad/data-model@1.9.11
  - @mlightcad/dxf-json-converter@1.9.11
  - @mlightcad/libredwg-converter@3.7.11

## 0.3.10

### Patch Changes

- feat: support reading AcDb2LineAngularDimension and add DWGNAME system variable
- Updated dependencies
  - @mlightcad/dxf-json-converter@1.9.10
  - @mlightcad/libredwg-converter@3.7.10
  - @mlightcad/data-model@1.9.10

## 0.3.9

### Patch Changes

- feat: introduced grip point editing across entity types and unified DWG/DXF font collection through AcDbFontNameCollector for improved editing and font management consistency
- Updated dependencies
  - @mlightcad/data-model@1.9.9
  - @mlightcad/dxf-json-converter@1.9.9
  - @mlightcad/libredwg-converter@3.7.9

## 0.3.8

### Patch Changes

- feat: improve SPLINE conversion with tolerant factory methods
- Updated dependencies
  - @mlightcad/data-model@1.9.8
  - @mlightcad/dxf-json-converter@1.9.8
  - @mlightcad/libredwg-converter@3.7.8

## 0.3.7

### Patch Changes

- feat: improve LibreDWG converter with enhanced MLeader conversion and SHAPE entity support, and restore initial view from \*ACTIVE VPORT with added sanity checks for robustness
- Updated dependencies
  - @mlightcad/data-model@1.9.7
  - @mlightcad/dxf-json-converter@1.9.7
  - @mlightcad/libredwg-converter@3.7.7

## 0.3.6

### Patch Changes

- feat: refactor AcGiContext into a class, fix SHAPE font resolution, and add STYLE table shape file support with draw-time database context handling
- Updated dependencies
  - @mlightcad/data-model@1.9.6
  - @mlightcad/dxf-json-converter@1.9.6
  - @mlightcad/libredwg-converter@3.7.6

## 0.3.5

### Patch Changes

- feat: fix rendering and color resolution: resolve sub-entity RGB at draw time via AcGiContext and correctly compute ByBlock/ByLayer attribute colors from owning INSERT, improving consistency of block and entity display
- Updated dependencies
  - @mlightcad/data-model@1.9.5
  - @mlightcad/dxf-json-converter@1.9.5
  - @mlightcad/libredwg-converter@3.7.5

## 0.3.4

### Patch Changes

- feat: upgrade libredwg-web to v0.7.4 to fix some issues on parsing dwg files
- Updated dependencies
  - @mlightcad/libredwg-converter@3.7.4
  - @mlightcad/data-model@1.9.4
  - @mlightcad/dxf-json-converter@1.9.4

## 0.3.3

### Patch Changes

- feat: support proxy entity for dwg file
- Updated dependencies
  - @mlightcad/data-model@1.9.3
  - @mlightcad/dxf-json-converter@1.9.3
  - @mlightcad/libredwg-converter@3.7.3

## 0.3.2

### Patch Changes

- feat: add AcDbProxyEntity with proxy graphic decoding
- Updated dependencies
  - @mlightcad/data-model@1.9.2
  - @mlightcad/dxf-json-converter@1.9.2
  - @mlightcad/libredwg-converter@3.7.2

## 0.3.1

### Patch Changes

- fix(data-model): break circular deps via direct imports and add CJS bundle test (#106)
- Updated dependencies
  - @mlightcad/data-model@1.9.1
  - @mlightcad/dxf-json-converter@1.9.1
  - @mlightcad/libredwg-converter@3.7.1

## 0.3.0

### Minor Changes

- feat: adds area support on curve, hatch, and geometry classes, extracts DXF conversion into the standalone @mlightcad/dxf-json-converter package, and documents GPL Web Worker isolation with example JSDoc

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.9.0
  - @mlightcad/dxf-json-converter@1.9.0
  - @mlightcad/libredwg-converter@3.7.0

## 0.2.4

### Patch Changes

- feat: added drawNoPlotLayers policy for controlling no-plot layer visibility, fixed hatch pattern angle handling when explicit lines are defined, updated project license, and migrated npm publishing to Trusted Publishing via OIDC
- Updated dependencies
  - @mlightcad/data-model@1.8.4
  - @mlightcad/libredwg-converter@3.6.4

## 0.2.3

### Patch Changes

- feat: geometricExtents for text, dimensions, table, and viewport; VPORT aspect ratio; case-insensitive VPORT lookup
- Updated dependencies
  - @mlightcad/data-model@1.8.3
  - @mlightcad/libredwg-converter@3.6.3

## 0.2.2

### Patch Changes

- feat(data-model): add SHAPE entity support and honor DXF visibility in blocks
- Updated dependencies
  - @mlightcad/data-model@1.8.2
  - @mlightcad/libredwg-converter@3.6.2

## 0.2.1

### Patch Changes

- feat: extend object snap support across entities and add ORTHOMODE, POLARMODE, POLARANG, and POLARADDANG system variables
- Updated dependencies
  - @mlightcad/data-model@1.8.1
  - @mlightcad/libredwg-converter@3.6.1

## 0.2.0

### Minor Changes

- feat: replace WHITEBKCOLOR with MODELBKCOLOR and PAPERBKCOLOR

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.8.0
  - @mlightcad/libredwg-converter@4.0.0

## 0.1.40

### Patch Changes

- fix: resolve text styles during progressive conversion and fix TRACE boundary order
- Updated dependencies
  - @mlightcad/data-model@1.7.40
  - @mlightcad/libredwg-converter@3.5.40

## 0.1.39

### Patch Changes

- feat: add AcDbCurve::getOffsetCurves and centralize offset tolerance checks with AcGeTol
- Updated dependencies
  - @mlightcad/data-model@1.7.39
  - @mlightcad/libredwg-converter@3.5.39

## 0.1.38

### Patch Changes

- fix: default layout manager factory survives production tree-shaking
- Updated dependencies
  - @mlightcad/data-model@1.7.38
  - @mlightcad/libredwg-converter@3.5.38

## 0.1.37

### Patch Changes

- feat: improve tree-shaking with explicit ESM exports and add geometry snap helpers
- Updated dependencies
  - @mlightcad/data-model@1.7.37
  - @mlightcad/libredwg-converter@3.5.37

## 0.1.36

### Patch Changes

- feat: add AcDbFormatter for AutoCAD-style length, point, and angle display
- Updated dependencies
  - @mlightcad/data-model@1.7.36
  - @mlightcad/libredwg-converter@3.5.36

## 0.1.35

### Patch Changes

- feat: LUNITS/LUPREC/AUPREC, VPORT fallbacks, angbase/angdir; pnpm 10 + CI
- Updated dependencies
  - @mlightcad/data-model@1.7.35
  - @mlightcad/libredwg-converter@3.5.35

## 0.1.34

### Patch Changes

- fix: build entity color via assignment to support AcDbHatch override
- Updated dependencies
  - @mlightcad/data-model@1.7.34
  - @mlightcad/libredwg-converter@3.5.34

## 0.1.33

### Patch Changes

- fix: prefer anonymous table blocks when rendering AcDbTable
- Updated dependencies
  - @mlightcad/data-model@1.7.33
  - @mlightcad/libredwg-converter@3.5.33

## 0.1.32

### Patch Changes

- feat: add SVG rendering support for hatch gradient previews and correct anchor for non-default TEXT/ATTRIB alignment
- Updated dependencies
  - @mlightcad/data-model@1.7.32
  - @mlightcad/libredwg-converter@3.5.32

## 0.1.31

### Patch Changes

- feat: add hatch related system variables and fix SOLID hatch handling & preview rendering
- Updated dependencies
  - @mlightcad/data-model@1.7.31
  - @mlightcad/libredwg-converter@3.5.31

## 0.1.30

### Patch Changes

- feat: add PAT parsing, predefined libraries, and SVG preview support
- Updated dependencies
  - @mlightcad/data-model@1.7.30
  - @mlightcad/libredwg-converter@3.5.30

## 0.1.29

### Patch Changes

- feat: refine mline rendering
- Updated dependencies
  - @mlightcad/data-model@1.7.29
  - @mlightcad/libredwg-converter@3.5.29

## 0.1.28

### Patch Changes

- feat: add mline and mleader supports
- Updated dependencies
  - @mlightcad/data-model@1.7.28
  - @mlightcad/libredwg-converter@3.5.28

## 0.1.27

### Patch Changes

- fix: fix cad-viewer issue #243 and #183
- Updated dependencies
  - @mlightcad/data-model@1.7.27
  - @mlightcad/libredwg-converter@3.5.27

## 0.1.26

### Patch Changes

- feat: add gradient hatch support
- Updated dependencies
  - @mlightcad/data-model@1.7.26
  - @mlightcad/libredwg-converter@3.5.26

## 0.1.25

### Patch Changes

- feat: introduce explicit draw order and fix issues on closed wide LWPOLYLINE rendering and OCS arc/circle conversion
- Updated dependencies
  - @mlightcad/data-model@1.7.25
  - @mlightcad/libredwg-converter@3.5.25

## 0.1.24

### Patch Changes

- fix: fix issues on dimension selection and snapping
- Updated dependencies
  - @mlightcad/data-model@1.7.24
  - @mlightcad/libredwg-converter@3.5.24

## 0.1.23

### Patch Changes

- fix: fix block reference osnap resolution for transformed and nested entities and issue on color resolution for libredwg-converter
- Updated dependencies
  - @mlightcad/data-model@1.7.23
  - @mlightcad/libredwg-converter@3.5.23

## 0.1.22

### Patch Changes

- feat: render wide LWPOLYLINE entities as filled geometry and add SVG linetype previews and demo rendering in example app
- Updated dependencies
  - @mlightcad/data-model@1.7.22
  - @mlightcad/libredwg-converter@3.5.22

## 0.1.21

### Patch Changes

- feat: add CELTYPE support across database and DXF/DWG converters
- Updated dependencies
  - @mlightcad/data-model@1.7.21
  - @mlightcad/libredwg-converter@3.5.21

## 0.1.20

### Patch Changes

- fix: fix issue #200 in cad-viewer
- Updated dependencies
  - @mlightcad/data-model@1.7.20
  - @mlightcad/libredwg-converter@3.5.20

## 0.1.19

### Patch Changes

- feat: add clone method
- Updated dependencies
  - @mlightcad/data-model@1.7.19
  - @mlightcad/libredwg-converter@3.5.19

## 0.1.18

### Patch Changes

- feat: improve text style fallback resolution and bump libredwg-web to 0.6.10
- Updated dependencies
  - @mlightcad/data-model@1.7.18
  - @mlightcad/libredwg-converter@3.5.18

## 0.1.17

### Patch Changes

- feat: implement missing geometry/entity transforms and expand transform regression coverage
- Updated dependencies
  - @mlightcad/data-model@1.7.17
  - @mlightcad/libredwg-converter@3.5.17

## 0.1.16

### Patch Changes

- feat(sysvars): add DYNMODE and DYNPROMPT system variables
- Updated dependencies
  - @mlightcad/data-model@1.7.16
  - @mlightcad/libredwg-converter@3.5.16

## 0.1.15

### Patch Changes

- feat: improve geometry and optimize build configuration
- Updated dependencies
  - @mlightcad/data-model@1.7.15
  - @mlightcad/libredwg-converter@3.5.15

## 0.1.14

### Patch Changes

- fix: improve DXF export functionality and refine AcDbSpline
- Updated dependencies
  - @mlightcad/data-model@1.7.14
  - @mlightcad/libredwg-converter@3.5.14

## 0.1.13

### Patch Changes

- fix: fix #issue 150 in cad-viewer (#43)
- Updated dependencies
  - @mlightcad/data-model@1.7.13
  - @mlightcad/libredwg-converter@3.5.13

## 0.1.12

### Patch Changes

- fix: upgrade dxf-json to fix bug #132 in cad-viewer repo
- Updated dependencies
  - @mlightcad/data-model@1.7.12
  - @mlightcad/libredwg-converter@3.5.12

## 0.1.11

### Patch Changes

- fix issue on converting spline with fit points
- Updated dependencies
  - @mlightcad/data-model@1.7.11
  - @mlightcad/libredwg-converter@3.5.11

## 0.1.10

### Patch Changes

- fix: fix bugs on building loops for hatch and revome dependency on verb-nurbs
- Updated dependencies
  - @mlightcad/data-model@1.7.10
  - @mlightcad/libredwg-converter@3.5.10

## 0.1.9

### Patch Changes

- feat: improve DXF export
- Updated dependencies
  - @mlightcad/data-model@1.7.9
  - @mlightcad/libredwg-converter@3.5.9

## 0.1.8

### Patch Changes

- fix: fix issue on reading dxf file caused by last release
- Updated dependencies
  - @mlightcad/data-model@1.7.8
  - @mlightcad/libredwg-converter@3.5.8

## 0.1.7

### Patch Changes

- feat: add DXF export support
- Updated dependencies
  - @mlightcad/data-model@1.7.7
  - @mlightcad/libredwg-converter@3.5.7

## 0.1.6

### Patch Changes

- feat: support changing foreground color
- Updated dependencies
  - @mlightcad/data-model@1.7.6
  - @mlightcad/libredwg-converter@3.5.6

## 0.1.5

### Patch Changes

- chore: add system variables MEASUREMENTCOLOR, OSMODE, and TEXTCOLOR
- Updated dependencies
  - @mlightcad/data-model@1.7.5
  - @mlightcad/libredwg-converter@3.5.5

## 0.1.4

### Patch Changes

- feat: add configurable parser worker timeout for drawing conversion and centralize database system variable names
- Updated dependencies
  - @mlightcad/data-model@1.7.4
  - @mlightcad/libredwg-converter@3.5.4

## 0.1.3

### Patch Changes

- fix: fix issue 101
- Updated dependencies
  - @mlightcad/data-model@1.7.3
  - @mlightcad/libredwg-converter@3.5.3

## 0.1.2

### Patch Changes

- feat(data-model): emit sysVarChanged only when sysvar value actually changes and add system variable 'LWDISPLAY'
- Updated dependencies
  - @mlightcad/data-model@1.7.2
  - @mlightcad/libredwg-converter@3.5.2

## 0.1.1

### Patch Changes

- feat: set entity line weight and line type scale for newly created entity
- Updated dependencies
  - @mlightcad/data-model@1.7.1
  - @mlightcad/libredwg-converter@3.5.1

## 0.1.0

### Patch Changes

- feat: support xdata and xrecord
- Updated dependencies
  - @mlightcad/data-model@1.6.11
  - @mlightcad/libredwg-converter@3.4.14

## 0.0.13

### Patch Changes

- feat: respect value of system variables 'cecolor' and 'clayer' when creating one new entity
- Updated dependencies
  - @mlightcad/data-model@1.6.10
  - @mlightcad/libredwg-converter@3.4.13

## 0.0.12

### Patch Changes

- feat: enhance polyline
- Updated dependencies
  - @mlightcad/data-model@1.6.9
  - @mlightcad/libredwg-converter@3.4.12

## 0.0.11

### Patch Changes

- fix: fix issues 89 and 90 in cad-viewer repo
- Updated dependencies
  - @mlightcad/data-model@1.6.8
  - @mlightcad/libredwg-converter@3.4.11

## 0.0.10

### Patch Changes

- feat: support ATTDEF ATTRIB entities when reading DXF file
- Updated dependencies
  - @mlightcad/data-model@1.6.7
  - @mlightcad/libredwg-converter@3.4.10

## 0.0.9

### Patch Changes

- feat: support ATTDEF and ATTRIB entities
- Updated dependencies
  - @mlightcad/data-model@1.6.6
  - @mlightcad/libredwg-converter@3.4.9

## 0.0.8

### Patch Changes

- Updated dependencies
  - @mlightcad/libredwg-converter@3.4.8
  - @mlightcad/data-model@1.6.5

## 0.0.7

### Patch Changes

- Updated dependencies
  - @mlightcad/data-model@1.6.4
  - @mlightcad/libredwg-converter@3.4.7

## 0.0.6

### Patch Changes

- Updated dependencies
  - @mlightcad/libredwg-converter@3.4.6

## 0.0.5

### Patch Changes

- Updated dependencies
  - @mlightcad/libredwg-converter@3.4.5

## 0.0.4

### Patch Changes

- Updated dependencies
  - @mlightcad/libredwg-converter@3.4.4
  - @mlightcad/data-model@1.6.3

## 0.0.3

### Patch Changes

- Updated dependencies
  - @mlightcad/libredwg-converter@3.4.3

## 0.0.2

### Patch Changes

- Updated dependencies
  - @mlightcad/libredwg-converter@3.4.2
  - @mlightcad/data-model@1.6.2
