/**
 * @fileoverview Example web application entry point for DWG/DXF parsing and PAT preview.
 *
 * This module wires up the demo UI: file selection, deferred parse on
 * "Run parse", layer/linetype inspection, DXF export, and hatch pattern (PAT)
 * parsing with SVG previews.
 *
 * @module example/main
 */

import {
  AcDbDatabase,
  AcDbDatabaseConverterManager,
  acdbEstimateDatabaseMemory,
  AcDbFileType,
  acdbFormatMemoryEstimate,
  acdbHostApplicationServices,
  AcDbNativeDxfConverter,
  AcDbOpenDatabaseOptions,
  AcDbPatDocument,
  AcDbPatParser,
  AcDbPatSvgRenderer,
  AcDbPredefinedAcadIsoPat,
  AcDbPredefinedAcadPat,
  acdbThumbnailImageToDataUrl
} from '@mlightcad/data-model'
import { AcDbLibreDwgConverter } from '@mlightcad/libredwg-converter'

const fileInput = document.getElementById('fileInput') as HTMLInputElement
const runButton = document.getElementById('runButton') as HTMLButtonElement
const status = document.getElementById('status') as HTMLDivElement
const output = document.getElementById('output') as HTMLPreElement
const exportButton = document.createElement('button')
const thumbnailPreviewPanel = document.createElement('section')
const linetypePreviewPanel = document.createElement('section')
const patSourceSelect = document.getElementById(
  'patSourceSelect'
) as HTMLSelectElement
const patFileInput = document.getElementById('patFileInput') as HTMLInputElement
const parsePatButton = document.getElementById(
  'parsePatButton'
) as HTMLButtonElement
const patStatus = document.getElementById('patStatus') as HTMLDivElement
const patTableOutput = document.getElementById(
  'patTableOutput'
) as HTMLDivElement
const tabButtons = Array.from(
  document.querySelectorAll<HTMLButtonElement>('.tab-button[data-tab]')
)
const tabPanels = {
  parse: document.getElementById('panelParse') as HTMLElement,
  pat: document.getElementById('panelPat') as HTMLElement
} as const

type ExampleTab = keyof typeof tabPanels

/**
 * Switches the visible example tab (Parse / PAT).
 */
const setActiveTab = (tab: ExampleTab) => {
  for (const button of tabButtons) {
    const selected = button.dataset.tab === tab
    button.setAttribute('aria-selected', selected ? 'true' : 'false')
  }
  for (const [id, panel] of Object.entries(tabPanels)) {
    panel.hidden = id !== tab
  }
}

for (const button of tabButtons) {
  button.addEventListener('click', () => {
    const tab = button.dataset.tab as ExampleTab | undefined
    if (tab && tab in tabPanels) setActiveTab(tab)
  })
}

exportButton.type = 'button'
exportButton.textContent = 'Export DXF'
exportButton.hidden = true
exportButton.disabled = true
exportButton.style.marginLeft = '8px'
runButton.insertAdjacentElement('afterend', exportButton)
status.insertAdjacentElement('afterend', thumbnailPreviewPanel)
output.insertAdjacentElement('afterend', linetypePreviewPanel)

thumbnailPreviewPanel.style.marginTop = '12px'
thumbnailPreviewPanel.style.display = 'none'
linetypePreviewPanel.style.marginTop = '16px'
linetypePreviewPanel.style.display = 'none'

let lastFile: File | null = null
let lastBuffer: ArrayBuffer | null = null
let lastParsedDatabase: AcDbDatabase | null = null
let lastDownloadUrl: string | null = null
const patSvgRenderer = new AcDbPatSvgRenderer()
const patParser = new AcDbPatParser()

/**
 * Registers DWG and DXF converters with the global manager.
 *
 * DWG uses LibreDWG in a web worker; DXF uses the native streaming converter.
 * Registration failures are logged but do not throw.
 *
 * @param fileType - Format being parsed; DXF registration is skipped for DWG.
 */
const registerConverters = (fileType: AcDbFileType) => {
  try {
    const converter = new AcDbLibreDwgConverter({
      convertByEntityType: false,
      useWorker: true,
      parserWorkerUrl: './assets/libredwg-parser-worker.js'
    })
    AcDbDatabaseConverterManager.instance.register(AcDbFileType.DWG, converter)
  } catch (error) {
    console.error('Failed to register dwg converter: ', error)
  }

  if (fileType !== AcDbFileType.DXF) return

  try {
    AcDbDatabaseConverterManager.instance.register(
      AcDbFileType.DXF,
      new AcDbNativeDxfConverter({
        convertByEntityType: false,
        useWorker: false
      })
    )
  } catch (error) {
    console.error('Failed to register dxf converter: ', error)
  }
}

/**
 * Human-readable label for the converter used in a parse run.
 */
const describeConverterMode = (fileType: AcDbFileType): string => {
  if (fileType === AcDbFileType.DWG) {
    return 'LibreDWG (web worker)'
  }
  return 'native AcDbNativeDxfConverter (main thread)'
}

/**
 * Infers the CAD file type from a file name extension.
 *
 * @param fileName - Original file name, with or without path segments.
 * @returns {@link AcDbFileType.DWG} when the extension is `.dwg` (case-insensitive); otherwise {@link AcDbFileType.DXF}.
 */
const getFileType = (fileName: string) => {
  const extension = fileName.split('.').pop()?.toLocaleLowerCase()
  return extension === 'dwg' ? AcDbFileType.DWG : AcDbFileType.DXF
}

/**
 * Formats a duration in milliseconds for display in the output panel.
 *
 * @param value - Elapsed time in milliseconds.
 * @returns Human-readable string with two decimal places, e.g. `"123.45 ms"`.
 */
const formatMs = (value: number) => `${value.toFixed(2)} ms`

/**
 * Collects layer table metadata from an opened database.
 *
 * @param database - Parsed drawing database whose layer table will be iterated.
 * @returns Layer count and an ordered list of layer names.
 */
const collectLayers = (database: AcDbDatabase) => {
  const layers = database.tables.layerTable.newIterator()
  const names: string[] = []
  for (const layer of layers) {
    names.push(layer.name)
  }
  return {
    count: layers.count,
    names
  }
}

/**
 * Outcome of a single parse attempt.
 *
 * Uses a discriminated union on `skipped`:
 * - When `skipped` is `true`, parsing did not produce a database and `reason` explains why.
 * - When `skipped` is `false`, parsing succeeded and timing, layer summary, and the database are available.
 */
type ParseResult =
  | { skipped: true; reason: string }
  | {
      database: AcDbDatabase
      skipped: false
      durationMs: number
      layers: { count: number; names: string[] }
    }

/**
 * Parses a drawing buffer once using the configured converters and open options.
 *
 * Creates a fresh {@link AcDbDatabase}, assigns it as the host working database, and
 * measures wall-clock time for {@link AcDbDatabase.read}. Converters are registered
 * on each call before parsing.
 *
 * @param buffer - Raw file bytes (DXF or DWG).
 * @param fileType - Format hint passed to the database reader.
 * @returns Parsed database with timing and layer info, or a skipped result if parsing is not attempted.
 */
const parseOnce = async (
  buffer: ArrayBuffer,
  fileType: AcDbFileType
): Promise<ParseResult> => {
  registerConverters(fileType)

  const database = new AcDbDatabase()
  acdbHostApplicationServices().workingDatabase = database
  const options: AcDbOpenDatabaseOptions = {
    minimumChunkSize: 1000,
    readOnly: true
  }

  const start = performance.now()
  await database.read(buffer, options, fileType)
  const end = performance.now()

  return {
    database,
    skipped: false,
    durationMs: end - start,
    layers: collectLayers(database)
  }
}

/**
 * Updates the global status line shown above the parse output.
 *
 * @param message - Status text; pass an empty string to clear the line.
 */
const setStatus = (message: string) => {
  status.textContent = message
}

/**
 * Derives the download file name for a DXF export from the original upload name.
 *
 * Replaces the last extension segment with `.dxf`, or appends `.dxf` when no extension exists.
 *
 * @param fileName - Original uploaded file name.
 * @returns Suggested export file name ending in `.dxf`.
 */
const getExportFileName = (fileName: string) => {
  const suffixIndex = fileName.lastIndexOf('.')
  const baseName = suffixIndex >= 0 ? fileName.slice(0, suffixIndex) : fileName
  return `${baseName}.dxf`
}

/**
 * Shows or hides the DXF export button based on current session state.
 *
 * The button is visible when a file has been selected and enabled only when a database
 * has been successfully parsed and is available for export.
 */
const updateExportButton = () => {
  const shouldShow = lastFile != null
  exportButton.hidden = !shouldShow
  exportButton.disabled = !shouldShow || lastParsedDatabase == null
}

/**
 * Formats layer table summary lines for the text output area.
 *
 * @param layerInfo - Layer count and names from {@link collectLayers}; omit to return an empty array.
 * @returns Lines suitable for joining into the `<pre>` output, including a header and bullet list.
 */
const renderLayers = (layerInfo?: { count: number; names: string[] }) => {
  if (!layerInfo) return []
  const lines = [`Layers (${layerInfo.count})`]
  layerInfo.names.forEach(name => lines.push(`- ${name}`))
  return lines
}

/**
 * Renders the drawing thumbnail preview when the parsed database contains one.
 *
 * Clears and hides the panel when `database` is null or has no thumbnail bytes.
 *
 * @param database - Parsed drawing database, or `null` to reset the panel.
 */
const renderThumbnailPreview = (database: AcDbDatabase | null) => {
  thumbnailPreviewPanel.innerHTML = ''
  if (!database?.thumbnailImage?.length) {
    thumbnailPreviewPanel.style.display = 'none'
    return
  }

  const dataUrl = acdbThumbnailImageToDataUrl(database.thumbnailImage)
  if (!dataUrl) {
    thumbnailPreviewPanel.style.display = 'none'
    return
  }

  const title = document.createElement('h3')
  title.textContent = 'Drawing preview'
  title.style.margin = '0 0 8px 0'
  title.style.fontSize = '16px'

  const image = document.createElement('img')
  image.src = dataUrl
  image.alt = 'Drawing thumbnail preview'
  image.style.display = 'block'
  image.style.maxWidth = 'min(100%, 512px)'
  image.style.height = 'auto'
  image.style.border = '1px solid #dadada'
  image.style.borderRadius = '6px'
  image.style.background = '#f8f9fa'

  const caption = document.createElement('div')
  caption.textContent = `${database.thumbnailImage.length.toLocaleString()} bytes`
  caption.style.marginTop = '6px'
  caption.style.fontSize = '12px'
  caption.style.color = '#5f6368'

  thumbnailPreviewPanel.appendChild(title)
  thumbnailPreviewPanel.appendChild(image)
  thumbnailPreviewPanel.appendChild(caption)
  thumbnailPreviewPanel.style.display = 'block'
}

/**
 * Renders SVG previews for every linetype record in the parsed database.
 *
 * Clears and hides the preview panel when `database` is null. Otherwise builds a grid of
 * rows with linetype name/comments and inline SVG from {@link AcDbLinetypeTableRecord.toPreviewSvgString}.
 *
 * @param database - Parsed drawing database, or `null` to reset the panel.
 */
const renderLinetypePreviews = (database: AcDbDatabase | null) => {
  linetypePreviewPanel.innerHTML = ''
  if (!database) {
    linetypePreviewPanel.style.display = 'none'
    return
  }

  const records = database.tables.linetypeTable
    .newIterator()
    .toArray()
    .sort((a, b) => a.name.localeCompare(b.name))

  const title = document.createElement('h3')
  title.textContent = `Linetypes (${records.length})`
  title.style.margin = '0 0 8px 0'
  title.style.fontSize = '16px'
  linetypePreviewPanel.appendChild(title)

  const list = document.createElement('div')
  list.style.display = 'grid'
  list.style.gridTemplateColumns = '1fr'
  list.style.gap = '8px'

  for (const record of records) {
    const row = document.createElement('div')
    row.style.display = 'grid'
    row.style.gridTemplateColumns = '220px auto'
    row.style.alignItems = 'center'
    row.style.gap = '12px'
    row.style.padding = '6px 8px'
    row.style.border = '1px solid #dadada'
    row.style.borderRadius = '6px'

    const label = document.createElement('div')
    label.textContent = record.comments
      ? `${record.name} - ${record.comments}`
      : record.name
    label.title = record.name
    label.style.fontFamily = 'monospace'
    label.style.fontSize = '13px'
    label.style.whiteSpace = 'nowrap'
    label.style.overflow = 'hidden'
    label.style.textOverflow = 'ellipsis'

    const preview = document.createElement('div')
    preview.innerHTML = record.toPreviewSvgString({
      width: 150,
      height: 10,
      padding: 8,
      strokeWidth: 2,
      stroke: '#202124',
      repeats: 4
    })

    row.appendChild(label)
    row.appendChild(preview)
    list.appendChild(row)
  }

  linetypePreviewPanel.appendChild(list)
  linetypePreviewPanel.style.display = 'block'
}

/**
 * Updates the PAT section status line.
 *
 * @param message - Status text shown below the PAT controls.
 */
const setPatStatus = (message: string) => {
  patStatus.textContent = message
}

/**
 * Removes all rendered PAT pattern rows from the preview table container.
 */
const clearPatPreview = () => {
  patTableOutput.innerHTML = ''
}

/**
 * Source of hatch pattern (PAT) definitions in the demo.
 *
 * - `predefined-acad` — Built-in `acad.pat` patterns shipped with the data model.
 * - `predefined-acadiso` — Built-in ISO `acadiso.pat` patterns.
 * - `file` — User-selected local `.pat` file loaded via the file input.
 */
type PatSource = 'predefined-acad' | 'predefined-acadiso' | 'file'

/**
 * Resolves a built-in PAT document for predefined sources.
 *
 * @param source - Selected PAT source; must not be `'file'`.
 * @returns The corresponding {@link AcDbPatDocument}, or `null` when the source is `'file'`.
 */
const getPredefinedPatDocument = (
  source: PatSource
): AcDbPatDocument | null => {
  if (source === 'predefined-acad') return AcDbPredefinedAcadPat
  if (source === 'predefined-acadiso') return AcDbPredefinedAcadIsoPat
  return null
}

/**
 * Builds an HTML table listing each pattern's JSON definition and SVG preview.
 *
 * Each row shows pretty-printed pattern metadata and a rasterized SVG thumbnail produced
 * by {@link AcDbPatSvgRenderer.renderPattern}. No-op when the document contains zero patterns.
 *
 * @param patDocument - Parsed or predefined PAT document to display.
 */
const renderPatTable = (patDocument: AcDbPatDocument) => {
  patTableOutput.innerHTML = ''
  if (patDocument.patterns.length === 0) return

  const table = document.createElement('table')
  table.style.width = '100%'
  table.style.borderCollapse = 'collapse'
  table.style.tableLayout = 'fixed'
  table.style.marginTop = '8px'

  const thead = document.createElement('thead')
  const headerRow = document.createElement('tr')
  const jsonHeader = document.createElement('th')
  jsonHeader.textContent = 'Pattern JSON'
  jsonHeader.style.textAlign = 'left'
  jsonHeader.style.padding = '8px'
  jsonHeader.style.border = '1px solid #dadada'
  jsonHeader.style.background = '#f3f4f6'

  const svgHeader = document.createElement('th')
  svgHeader.textContent = 'PAT Preview'
  svgHeader.style.textAlign = 'left'
  svgHeader.style.padding = '8px'
  svgHeader.style.border = '1px solid #dadada'
  svgHeader.style.background = '#f3f4f6'

  headerRow.appendChild(jsonHeader)
  headerRow.appendChild(svgHeader)
  thead.appendChild(headerRow)
  table.appendChild(thead)

  const tbody = document.createElement('tbody')
  patDocument.patterns.forEach(pattern => {
    const row = document.createElement('tr')

    const jsonCell = document.createElement('td')
    jsonCell.style.verticalAlign = 'top'
    jsonCell.style.border = '1px solid #dadada'
    jsonCell.style.padding = '8px'

    const jsonTitle = document.createElement('div')
    jsonTitle.style.fontFamily = 'monospace'
    jsonTitle.style.fontWeight = 'bold'
    jsonTitle.style.marginBottom = '6px'
    jsonTitle.textContent = pattern.description
      ? `${pattern.name} - ${pattern.description}`
      : pattern.name

    const jsonPre = document.createElement('pre')
    jsonPre.style.margin = '0'
    jsonPre.style.whiteSpace = 'pre-wrap'
    jsonPre.style.wordBreak = 'break-word'
    jsonPre.style.fontSize = '12px'
    jsonPre.textContent = JSON.stringify(pattern, null, 2)

    jsonCell.appendChild(jsonTitle)
    jsonCell.appendChild(jsonPre)

    const previewCell = document.createElement('td')
    previewCell.style.verticalAlign = 'top'
    previewCell.style.border = '1px solid #dadada'
    previewCell.style.padding = '8px'
    previewCell.style.width = '380px'
    previewCell.innerHTML = patSvgRenderer.renderPattern(pattern, {
      width: 360,
      height: 220,
      stroke: '#1f2937',
      strokeWidth: 1.25,
      background: '#f8fafc'
    })

    row.appendChild(jsonCell)
    row.appendChild(previewCell)
    tbody.appendChild(row)
  })

  table.appendChild(tbody)
  patTableOutput.appendChild(table)
}

/**
 * Parses raw PAT file text and loads the result into the preview UI.
 *
 * @param text - Full contents of a `.pat` file.
 */
const parsePatText = (text: string) => {
  const parsed = patParser.parse(text)
  loadPatDocument(parsed, 'Local PAT file')
}

/**
 * Displays a PAT document in the table and updates the PAT status summary.
 *
 * @param patDocument - Document whose patterns and issues will be summarized.
 * @param sourceLabel - Human-readable label for the pattern source (file name or built-in id).
 */
const loadPatDocument = (patDocument: AcDbPatDocument, sourceLabel: string) => {
  renderPatTable(patDocument)

  const summaryParts = [
    `Source: ${sourceLabel}`,
    `Patterns: ${patDocument.patterns.length}`
  ]
  if (patDocument.issues.length > 0) {
    summaryParts.push(`Issues: ${patDocument.issues.length}`)
  }
  setPatStatus(summaryParts.join(' | '))
}

/**
 * Enables or disables PAT file controls based on the selected {@link PatSource}.
 *
 * File input and parse button are active only when source is `'file'`.
 */
const updatePatSourceUi = () => {
  const source = patSourceSelect.value as PatSource
  const isFileSource = source === 'file'
  patFileInput.disabled = !isFileSource
  parsePatButton.disabled = !isFileSource
}

/**
 * Applies the current PAT source selection: loads predefined documents or prompts for a file.
 *
 * For built-in sources, immediately renders the corresponding document. For `'file'`, clears
 * the preview and instructs the user to upload and parse a local PAT file.
 */
const applyPatSource = () => {
  const source = patSourceSelect.value as PatSource
  updatePatSourceUi()

  if (source === 'file') {
    clearPatPreview()
    setPatStatus('Select a PAT file and click "Parse PAT".')
    return
  }

  const predefined = getPredefinedPatDocument(source)
  if (!predefined) {
    clearPatPreview()
    setPatStatus('No predefined PAT document is available for current source.')
    return
  }

  const sourceLabel = source === 'predefined-acad' ? 'acad.pat' : 'acadiso.pat'
  loadPatDocument(predefined, sourceLabel)
}

/**
 * Main parse workflow triggered by the Run parse button.
 *
 * Validates that a file buffer is loaded, registers the selected converter,
 * parses the drawing, writes timing and layer output, refreshes linetype
 * previews, and updates export button state. UI controls are disabled for the
 * duration of parsing to prevent concurrent runs.
 */
const runParse = async () => {
  if (!lastFile || !lastBuffer) {
    output.textContent = 'Please select a DWG or DXF file first.'
    renderThumbnailPreview(null)
    renderLinetypePreviews(null)
    return
  }

  const fileType = getFileType(lastFile.name)
  const converterMode = describeConverterMode(fileType)
  const lines: string[] = []
  let parsedDatabase: AcDbDatabase | null = null

  lastParsedDatabase = null
  updateExportButton()

  runButton.disabled = true
  fileInput.disabled = true
  exportButton.disabled = true

  try {
    setStatus(`Parsing with ${converterMode}…`)
    lines.push(`File: ${lastFile.name}`)
    lines.push(`Converter: ${converterMode}`)
    lines.push('')

    const result = await parseOnce(lastBuffer.slice(0), fileType)
    setStatus('')
    if (result.skipped) {
      lines.push(`Parse: skipped (${result.reason})`)
    } else {
      parsedDatabase = result.database
      lines.push(`Parse: ${formatMs(result.durationMs)}`)
      lines.push('')
      lines.push(...renderLayers(result.layers))
      lines.push('')
      const memory = acdbEstimateDatabaseMemory(result.database)
      lines.push(acdbFormatMemoryEstimate(memory))
      console.log(acdbFormatMemoryEstimate(memory))
    }
  } catch (error) {
    console.error(error)
    lines.push(`Error: ${(error as Error).message}`)
  } finally {
    lastParsedDatabase = parsedDatabase
    setStatus('')
    output.textContent = lines.join('\n')
    renderThumbnailPreview(lastParsedDatabase)
    renderLinetypePreviews(lastParsedDatabase)
    runButton.disabled = false
    fileInput.disabled = false
    updateExportButton()
  }
}

fileInput.addEventListener('change', async () => {
  const file = fileInput.files?.[0]
  if (!file) return
  lastFile = file
  lastParsedDatabase = null
  renderThumbnailPreview(null)
  renderLinetypePreviews(null)
  updateExportButton()

  output.textContent = 'Loading file...\n'
  setStatus('Loading file…')
  lastBuffer = await file.arrayBuffer()
  output.textContent = `Loaded: ${file.name} (${lastBuffer.byteLength.toLocaleString()} bytes)\n\nClick "Run parse" to start.`
  setStatus('File loaded. Click "Run parse" to start.')
})

runButton.addEventListener('click', async () => {
  await runParse()
})

exportButton.addEventListener('click', () => {
  if (!lastFile || !lastParsedDatabase) return

  exportButton.disabled = true

  try {
    setStatus('Generating DXF export...')
    const dxf = lastParsedDatabase.dxfOut(undefined, 6)
    const fileName = getExportFileName(lastFile.name)
    const blob = new Blob([dxf], {
      type: 'application/dxf;charset=utf-8'
    })

    if (lastDownloadUrl) {
      URL.revokeObjectURL(lastDownloadUrl)
    }

    lastDownloadUrl = URL.createObjectURL(blob)

    const anchor = document.createElement('a')
    anchor.href = lastDownloadUrl
    anchor.download = fileName
    document.body.appendChild(anchor)
    anchor.click()
    anchor.remove()
    setStatus(`DXF exported: ${fileName}`)
  } catch (error) {
    console.error(error)
    setStatus(`DXF export failed: ${(error as Error).message}`)
  } finally {
    updateExportButton()
  }
})

patFileInput.addEventListener('change', async () => {
  if ((patSourceSelect.value as PatSource) !== 'file') return
  const file = patFileInput.files?.[0]
  if (!file) return

  parsePatButton.disabled = true
  setPatStatus('Loading PAT file...')
  clearPatPreview()

  try {
    const text = await file.text()
    parsePatText(text)
  } catch (error) {
    console.error(error)
    setPatStatus(`PAT load failed: ${(error as Error).message}`)
  } finally {
    parsePatButton.disabled = false
  }
})

parsePatButton.addEventListener('click', async () => {
  if ((patSourceSelect.value as PatSource) !== 'file') {
    setPatStatus(
      'Switch source to "From local PAT file" to parse uploaded files.'
    )
    return
  }
  const file = patFileInput.files?.[0]
  if (!file) {
    setPatStatus('Please select a PAT file first.')
    return
  }

  parsePatButton.disabled = true
  setPatStatus('Parsing PAT...')
  try {
    const text = await file.text()
    parsePatText(text)
  } catch (error) {
    console.error(error)
    setPatStatus(`PAT parse failed: ${(error as Error).message}`)
  } finally {
    parsePatButton.disabled = false
  }
})

patSourceSelect.addEventListener('change', () => {
  applyPatSource()
})

applyPatSource()
