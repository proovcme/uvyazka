//! `Column` + `Beam` + `StructuralColumn` + `StructuralFraming` —
//! the bones of the building. In Revit:
//!
//! - An **architectural column** (class `Column`) is a vertical
//!   prismatic element spanning from `base_level` to `top_level` with
//!   a profile (rectangular / round / W-shape / …) carried by its
//!   symbol.
//! - A **structural column** (class `StructuralColumn`) is the same
//!   geometry plus analytical-model attachments (released DOFs,
//!   material strength overrides). Concrete / steel columns live
//!   here.
//! - A **beam** (class `Beam` or `StructuralFraming`) is a horizontal
//!   or sloped member running along a 2D/3D curve — `start` and `end`
//!   endpoints plus a cross-section profile.
//!
//! All four decode the same location / level / symbol fields so we
//! share `StructuralCommon` similar to `OpeningCommon` in
//! `openings.rs`.
//!
//! # Typical field shape
//!
//! Column / StructuralColumn:
//!
//! | Field | Type | Semantics |
//! |---|---|---|
//! | `m_base_level_id` | ElementId | Bottom of column |
//! | `m_top_level_id` | ElementId | Top of column |
//! | `m_base_offset` | f64 | Feet above base level |
//! | `m_top_offset` | f64 | Feet above top level |
//! | `m_symbol_id` | ElementId | Column FamilySymbol (profile + material) |
//! | `m_location_x`, `m_location_y`, `m_location_z` | f64 | Insertion point |
//! | `m_rotation` | f64 | Rotation about vertical axis, radians |
//! | `m_is_structural` | bool | True for StructuralColumn, false for architectural |
//!
//! Beam / StructuralFraming:
//!
//! | Field | Type | Semantics |
//! |---|---|---|
//! | `m_level_id` | ElementId | Reference level for the beam |
//! | `m_symbol_id` | ElementId | FamilySymbol defining the profile |
//! | `m_start_x`, `m_start_y`, `m_start_z` | f64 | Start endpoint |
//! | `m_end_x`, `m_end_y`, `m_end_z` | f64 | End endpoint |
//! | `m_cross_section_rotation` | f64 | Rotation of profile about the beam axis |
//! | `m_start_level_offset` / `m_end_level_offset` | f64 | Per-end offsets from level |

use super::level::normalise_field_name;
use crate::formats;
use crate::geometry::Point3;
use crate::walker::{DecodedElement, ElementDecoder, HandleIndex, InstanceField};
use crate::{Error, Result};

macro_rules! simple_decoder {
    ($Struct:ident, $name:literal) => {
        pub struct $Struct;

        impl ElementDecoder for $Struct {
            fn class_name(&self) -> &'static str {
                $name
            }

            fn decode(
                &self,
                bytes: &[u8],
                schema: &formats::ClassEntry,
                index: &HandleIndex,
            ) -> Result<DecodedElement> {
                self.decode_with_limits(
                    bytes,
                    schema,
                    index,
                    crate::walker::WalkerLimits::default(),
                )
            }

            fn decode_with_limits(
                &self,
                bytes: &[u8],
                schema: &formats::ClassEntry,
                _index: &HandleIndex,
                limits: crate::walker::WalkerLimits,
            ) -> Result<DecodedElement> {
                if schema.name != $name {
                    return Err(Error::BasicFileInfo(format!(
                        "{} received wrong schema: {}",
                        stringify!($Struct),
                        schema.name
                    )));
                }
                Ok(crate::walker::decode_instance_with_limits(
                    bytes, 0, schema, limits,
                ))
            }
        }
    };
}

simple_decoder!(ColumnDecoder, "Column");
simple_decoder!(StructuralColumnDecoder, "StructuralColumn");
simple_decoder!(BeamDecoder, "Beam");
simple_decoder!(StructuralFramingDecoder, "StructuralFraming");

/// Typed view of a decoded Column (architectural or structural — the
/// `is_structural` flag disambiguates).
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Column {
    pub base_level_id: Option<u32>,
    pub top_level_id: Option<u32>,
    pub base_offset_feet: Option<f64>,
    pub top_offset_feet: Option<f64>,
    pub symbol_id: Option<u32>,
    pub location: Option<Point3>,
    pub rotation_radians: Option<f64>,
    pub is_structural: Option<bool>,
}

impl Column {
    pub fn from_decoded(decoded: &DecodedElement) -> Self {
        let mut out = Self::default();
        let mut lx = None;
        let mut ly = None;
        let mut lz = None;
        for (field_name, value) in &decoded.fields {
            match (normalise_field_name(field_name).as_str(), value) {
                ("baselevelid" | "levelid", InstanceField::ElementId { id, .. }) => {
                    out.base_level_id = Some(*id);
                }
                ("toplevelid", InstanceField::ElementId { id, .. }) => {
                    out.top_level_id = Some(*id);
                }
                ("baseoffset", InstanceField::Float { value, .. }) => {
                    out.base_offset_feet = Some(*value);
                }
                ("topoffset", InstanceField::Float { value, .. }) => {
                    out.top_offset_feet = Some(*value);
                }
                ("symbolid" | "typeid" | "familysymbolid", InstanceField::ElementId { id, .. }) => {
                    out.symbol_id = Some(*id);
                }
                ("locationx", InstanceField::Float { value, .. }) => lx = Some(*value),
                ("locationy", InstanceField::Float { value, .. }) => ly = Some(*value),
                ("locationz", InstanceField::Float { value, .. }) => lz = Some(*value),
                ("rotation", InstanceField::Float { value, .. }) => {
                    out.rotation_radians = Some(*value);
                }
                ("isstructural" | "structural", InstanceField::Bool(b)) => {
                    out.is_structural = Some(*b);
                }
                _ => {}
            }
        }
        if let (Some(x), Some(y), Some(z)) = (lx, ly, lz) {
            out.location = Some(Point3::new(x, y, z));
        }
        out
    }

    /// Column height in feet, from base_offset above base_level to
    /// top_offset above top_level. Returns None if we can't compute
    /// (missing offsets — level elevations are looked up separately
    /// via the Level decoder, not stored on the column).
    ///
    /// Note: this returns the *offset component* of the height; the
    /// caller must add `top_level.elevation - base_level.elevation`
    /// separately. Kept here to surface the offset delta explicitly.
    pub fn offset_span_feet(&self) -> Option<f64> {
        Some(self.top_offset_feet? - self.base_offset_feet?)
    }
}

/// Typed view of a decoded Beam.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Beam {
    pub level_id: Option<u32>,
    pub symbol_id: Option<u32>,
    pub start: Option<Point3>,
    pub end: Option<Point3>,
    pub cross_section_rotation_radians: Option<f64>,
    pub start_level_offset_feet: Option<f64>,
    pub end_level_offset_feet: Option<f64>,
}

impl Beam {
    pub fn from_decoded(decoded: &DecodedElement) -> Self {
        let mut out = Self::default();
        let mut sx = None;
        let mut sy = None;
        let mut sz = None;
        let mut ex = None;
        let mut ey = None;
        let mut ez = None;
        for (field_name, value) in &decoded.fields {
            match (normalise_field_name(field_name).as_str(), value) {
                ("levelid" | "hostlevelid", InstanceField::ElementId { id, .. }) => {
                    out.level_id = Some(*id);
                }
                ("symbolid" | "typeid" | "familysymbolid", InstanceField::ElementId { id, .. }) => {
                    out.symbol_id = Some(*id);
                }
                ("startx", InstanceField::Float { value, .. }) => sx = Some(*value),
                ("starty", InstanceField::Float { value, .. }) => sy = Some(*value),
                ("startz", InstanceField::Float { value, .. }) => sz = Some(*value),
                ("endx", InstanceField::Float { value, .. }) => ex = Some(*value),
                ("endy", InstanceField::Float { value, .. }) => ey = Some(*value),
                ("endz", InstanceField::Float { value, .. }) => ez = Some(*value),
                ("crosssectionrotation", InstanceField::Float { value, .. }) => {
                    out.cross_section_rotation_radians = Some(*value);
                }
                ("startleveloffset", InstanceField::Float { value, .. }) => {
                    out.start_level_offset_feet = Some(*value);
                }
                ("endleveloffset", InstanceField::Float { value, .. }) => {
                    out.end_level_offset_feet = Some(*value);
                }
                _ => {}
            }
        }
        if let (Some(x), Some(y), Some(z)) = (sx, sy, sz) {
            out.start = Some(Point3::new(x, y, z));
        }
        if let (Some(x), Some(y), Some(z)) = (ex, ey, ez) {
            out.end = Some(Point3::new(x, y, z));
        }
        out
    }

    /// Straight-line beam length in feet. None when either endpoint
    /// is missing. For a curved beam this is the chord, not the arc:
    /// curved beam axes are not read yet (#94).
    pub fn length_feet(&self) -> Option<f64> {
        let (s, e) = (self.start?, self.end?);
        let dx = e.x - s.x;
        let dy = e.y - s.y;
        let dz = e.z - s.z;
        Some((dx * dx + dy * dy + dz * dz).sqrt())
    }

    /// True when the beam is horizontal (start.z ≈ end.z). Useful for
    /// distinguishing floor-framing beams from sloped members.
    pub fn is_horizontal(&self, eps: f64) -> Option<bool> {
        let (s, e) = (self.start?, self.end?);
        Some((s.z - e.z).abs() < eps)
    }
}
