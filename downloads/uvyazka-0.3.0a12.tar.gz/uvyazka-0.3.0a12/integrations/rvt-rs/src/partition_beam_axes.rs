//! Beam location lines from their serialised element data (RE-49).
//!
//! A structural-framing element's data (its element-data header and
//! ElementId, see [`crate::partition_names::element_data_header`]) carries
//! its location line as a bounded line:
//!
//! ```text
//! +0   04 00 08 01   BOUNDED_LINE_TAG
//! +4   f64           start parameter, feet
//! +12  f64           end parameter, feet
//! +20  f64 × 3       origin, model feet
//! +44  f64 × 3       unit direction
//! ```
//!
//! The line runs from `origin + start · direction` to
//! `origin + end · direction`. On Autodesk's Snowdon Towers 2024 structural
//! sample, the data of every one of the 942 structural-framing elements
//! rvt-rs exports has one, and on 940 both ends lie inside the element's
//! record box (the other two lie far outside it and are not read). The same
//! record appears in the data of walls, model lines and sketch lines; only
//! framing is read here.
//!
//! [`beam_body`] turns the line and the record's box into the beam's solid:
//! a box `length × width × depth` along the line. The length is the line's.
//! The section is what the box leaves once the line's own extent is taken
//! out of it: the depth from the vertical extent, the width from one plan
//! extent, and the other plan extent is a check the solve must pass. It
//! passes, to [`CLOSURE_TOLERANCE_FEET`], on 923 of the 940 (802 level beams
//! on a model axis, 111 level beams rotated in plan, 10 sloped). The 17 that
//! fail keep their box: 15 are oblique beams whose end cuts are not square to
//! the line, and 2 have a box longer than their line.
//!
//! Measured against the meshes of the same beams in a VIM export of a later
//! edition of the sample (`reports/element-framing/RE-49-beam-axes.md`,
//! `examples/probe_re49_beam_axes.rs`), the section across the line is
//! Revit's on 613 of the 839 beams that edition kept unchanged, and Revit's
//! less the top a floor join cuts away on 179 more. What the line does not
//! carry is where Revit trims a beam at its supports (on 352 of the 839, by
//! a median 0.625 ft at the larger end), so the solid runs the line's full
//! length.

use crate::{Result, RevitFile};
use std::collections::{BTreeMap, BTreeSet};

/// Releases where this layout is measured.
pub const BEAM_AXIS_SUPPORTED_REVIT_VERSIONS: &[u32] = &[2024];

/// The bytes a bounded line starts with.
pub const BOUNDED_LINE_TAG: [u8; 4] = [0x04, 0x00, 0x08, 0x01];

/// How far into an element's data a line is looked for, when the next
/// element-data header does not end it first. The first line of a Snowdon
/// beam sits at most `0x64a8` bytes in (a concrete beam's long data); most
/// sit within `0x600`.
pub const BEAM_DATA_WINDOW: usize = 0x1_0000;

/// How far a line's end may lie outside the record's box. Measured ends are
/// inside to the last bit or far outside, never in between.
pub const END_TOLERANCE_FEET: f64 = 1e-6;

/// How closely the plan extent the section solve does not use must be
/// reproduced by the solved box.
pub const CLOSURE_TOLERANCE_FEET: f64 = 0.01;

/// The least horizontal share of a line's direction that still gives the
/// section a horizontal width axis. Steeper members are not solved.
pub const MIN_PLAN_SHARE: f64 = 0.1;

/// Below this vertical share a direction is horizontal.
pub const HORIZONTAL_EPS: f64 = 1e-9;

/// Whether `revit_version` is a release this layout is measured on.
pub fn supports_revit_version(revit_version: u32) -> bool {
    BEAM_AXIS_SUPPORTED_REVIT_VERSIONS.contains(&revit_version)
}

/// A bounded line record.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BoundedLine {
    pub start_parameter: f64,
    pub end_parameter: f64,
    pub origin: [f64; 3],
    pub direction: [f64; 3],
}

impl BoundedLine {
    fn point(&self, parameter: f64) -> [f64; 3] {
        [
            self.origin[0] + parameter * self.direction[0],
            self.origin[1] + parameter * self.direction[1],
            self.origin[2] + parameter * self.direction[2],
        ]
    }

    /// The line's first end, model feet.
    pub fn start(&self) -> [f64; 3] {
        self.point(self.start_parameter)
    }

    /// The line's second end, model feet.
    pub fn end(&self) -> [f64; 3] {
        self.point(self.end_parameter)
    }
}

fn read_f64(buf: &[u8], at: usize) -> Option<f64> {
    buf.get(at..at.checked_add(8)?)
        .map(|s| f64::from_le_bytes(s.try_into().expect("8 bytes")))
}

/// The bounded line whose tag starts at `at`: finite values, a unit
/// direction and a start parameter below the end one.
pub fn bounded_line_at(buf: &[u8], at: usize) -> Option<BoundedLine> {
    if buf.get(at..at.checked_add(4)?)? != BOUNDED_LINE_TAG {
        return None;
    }
    let mut values = [0.0f64; 8];
    for (index, value) in values.iter_mut().enumerate() {
        *value = read_f64(buf, at + 4 + 8 * index)?;
    }
    if !values.iter().all(|v| v.is_finite()) {
        return None;
    }
    let [start_parameter, end_parameter, ox, oy, oz, dx, dy, dz] = values;
    if (dx * dx + dy * dy + dz * dz - 1.0).abs() > 1e-9 || start_parameter >= end_parameter {
        return None;
    }
    Some(BoundedLine {
        start_parameter,
        end_parameter,
        origin: [ox, oy, oz],
        direction: [dx, dy, dz],
    })
}

/// The first bounded line in `data`. `None` where the data's first curve
/// record is an arc ([`bounded_arc_at`]): its axes would read as a line.
pub fn first_bounded_line(data: &[u8]) -> Option<BoundedLine> {
    let first = memchr::memmem::find(data, &BOUNDED_LINE_TAG)?;
    if bounded_arc_at(data, first).is_some() {
        return None;
    }
    memchr::memmem::find_iter(data, &BOUNDED_LINE_TAG).find_map(|at| bounded_line_at(data, at))
}

/// A circular arc record (RE-75): the [`BOUNDED_LINE_TAG`] record preceded
/// by a `u64` 1 where a line's is 0, and laid out
///
/// ```text
/// -8   u64 1         the record is an arc
/// +0   04 00 08 01   BOUNDED_LINE_TAG
/// +4   f64           start angle, radians
/// +12  f64           end angle, radians
/// +20  f64 × 3       unit X axis
/// +44  f64 × 3       unit Y axis, square to X
/// +68  f64           radius, feet
/// +76  f64 × 3       centre, model feet
/// ```
///
/// The arc runs from `centre + radius · (cos a · X + sin a · Y)` at the
/// start angle to the end angle. On Autodesk's Snowdon Towers 2024
/// architectural sample it is the first curve record of 32 walls, and on
/// the 24 of them Revit's IFC4 export draws with an arc axis, its centre and
/// radius are that axis's to 1e-5 ft.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BoundedArc {
    pub start_angle: f64,
    pub end_angle: f64,
    pub x_axis: [f64; 3],
    pub y_axis: [f64; 3],
    pub radius: f64,
    pub centre: [f64; 3],
}

impl BoundedArc {
    /// The point at `angle` on the arc, model feet.
    pub fn point(&self, angle: f64) -> [f64; 3] {
        let (sin, cos) = angle.sin_cos();
        [0, 1, 2].map(|axis| {
            self.centre[axis] + self.radius * (cos * self.x_axis[axis] + sin * self.y_axis[axis])
        })
    }
}

/// The arc whose tag starts at `at`: the `u64` before it is 1, the values
/// are finite, the axes are unit and square to each other, the radius is
/// positive and the start angle is below the end one.
pub fn bounded_arc_at(buf: &[u8], at: usize) -> Option<BoundedArc> {
    if buf.get(at..at.checked_add(4)?)? != BOUNDED_LINE_TAG {
        return None;
    }
    let kind = buf
        .get(at.checked_sub(8)?..at)
        .map(|s| u64::from_le_bytes(s.try_into().expect("8 bytes")))?;
    if kind != 1 {
        return None;
    }
    arc_values_at(buf, at)
}

/// The record at `at` read as an arc ([`bounded_arc_at`]'s layout), whatever
/// the `u64` before it: a sketch line's arc is not marked (RE-96).
pub fn arc_values_at(buf: &[u8], at: usize) -> Option<BoundedArc> {
    if buf.get(at..at.checked_add(4)?)? != BOUNDED_LINE_TAG {
        return None;
    }
    let mut values = [0.0f64; 12];
    for (index, value) in values.iter_mut().enumerate() {
        *value = read_f64(buf, at + 4 + 8 * index)?;
    }
    if !values.iter().all(|v| v.is_finite()) {
        return None;
    }
    let [
        start_angle,
        end_angle,
        xx,
        xy,
        xz,
        yx,
        yy,
        yz,
        radius,
        cx,
        cy,
        cz,
    ] = values;
    let unit = |v: [f64; 3]| (v[0] * v[0] + v[1] * v[1] + v[2] * v[2] - 1.0).abs() <= 1e-9;
    let (x_axis, y_axis) = ([xx, xy, xz], [yx, yy, yz]);
    if !unit(x_axis)
        || !unit(y_axis)
        || (xx * yx + xy * yy + xz * yz).abs() > 1e-9
        || radius <= 0.0
        || start_angle >= end_angle
    {
        return None;
    }
    Some(BoundedArc {
        start_angle,
        end_angle,
        x_axis,
        y_axis,
        radius,
        centre: [cx, cy, cz],
    })
}

/// The arc a wall's data stores where its first curve record is one
/// ([`bounded_arc_at`]).
pub fn first_bounded_arc(data: &[u8]) -> Option<BoundedArc> {
    bounded_arc_at(data, memchr::memmem::find(data, &BOUNDED_LINE_TAG)?)
}

/// The tag of a full circle's record (RE-100): [`bounded_arc_at`]'s layout
/// with both angles 0, where a bounded curve's tag ends in 1.
pub const CIRCLE_TAG: [u8; 4] = [0x04, 0x00, 0x08, 0x00];

/// The full circle in `data`: the first [`CIRCLE_TAG`] record whose angles
/// are both 0, axes unit and square to each other, and radius positive,
/// returned as an arc from 0 to a full turn (RE-100).
pub fn first_circle(data: &[u8]) -> Option<BoundedArc> {
    memchr::memmem::find_iter(data, &CIRCLE_TAG).find_map(|at| {
        let mut values = [0.0f64; 12];
        for (index, value) in values.iter_mut().enumerate() {
            *value = read_f64(data, at + 4 + 8 * index)?;
        }
        if !values.iter().all(|v| v.is_finite()) {
            return None;
        }
        let [a0, a1, xx, xy, xz, yx, yy, yz, radius, cx, cy, cz] = values;
        let unit = |v: [f64; 3]| (v[0] * v[0] + v[1] * v[1] + v[2] * v[2] - 1.0).abs() <= 1e-9;
        let (x_axis, y_axis) = ([xx, xy, xz], [yx, yy, yz]);
        (a0 == 0.0
            && a1 == 0.0
            && unit(x_axis)
            && unit(y_axis)
            && (xx * yx + xy * yy + xz * yz).abs() <= 1e-9
            && radius > 0.0)
            .then_some(BoundedArc {
                start_angle: 0.0,
                end_angle: std::f64::consts::TAU,
                x_axis,
                y_axis,
                radius,
                centre: [cx, cy, cz],
            })
    })
}

/// The full circle of each sketch line in `ids` ([`first_circle`]), read as
/// [`scan_bounded_lines`] reads lines (RE-100).
pub fn scan_sketch_circles(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
) -> Result<BTreeMap<u32, BoundedArc>> {
    if !supports_revit_version(revit_version) {
        return Ok(BTreeMap::new());
    }
    scan_first_records(rf, revit_version, ids, first_circle)
}

/// A sketch line's curve (RE-96): the first [`BOUNDED_LINE_TAG`] record in
/// its data that reads as a line or as an arc, with both readings where it
/// reads as both. A sketch line's record does not say which it is, so the
/// caller keeps the reading its record box holds.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SketchCurve {
    /// The record read as a line.
    pub line: Option<BoundedLine>,
    /// The record read as an arc.
    pub arc: Option<BoundedArc>,
}

/// See [`SketchCurve`].
pub fn first_sketch_curve(data: &[u8]) -> Option<SketchCurve> {
    memchr::memmem::find_iter(data, &BOUNDED_LINE_TAG).find_map(|at| {
        let curve = SketchCurve {
            line: bounded_line_at(data, at),
            arc: arc_values_at(data, at),
        };
        (curve.line.is_some() || curve.arc.is_some()).then_some(curve)
    })
}

/// The curve of each sketch line in `ids` ([`first_sketch_curve`]), read as
/// [`scan_bounded_lines`] reads lines (RE-96). Empty for a release this
/// layout is not measured on.
pub fn scan_sketch_curves(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
) -> Result<BTreeMap<u32, SketchCurve>> {
    if !supports_revit_version(revit_version) {
        return Ok(BTreeMap::new());
    }
    scan_first_records(rf, revit_version, ids, first_sketch_curve)
}

/// The first bounded line in the element data of each id in `ids` (a
/// beam's location line, or a sketch line's segment, RE-50), read from every
/// partition. The data runs from its header to the next header, at most
/// [`BEAM_DATA_WINDOW`] bytes. An id whose copies disagree is dropped; the
/// map is empty for a release this layout is not measured on.
pub fn scan_bounded_lines(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
) -> Result<BTreeMap<u32, BoundedLine>> {
    if !supports_revit_version(revit_version) {
        return Ok(BTreeMap::new());
    }
    scan_first_bounded_lines(rf, revit_version, ids)
}

/// Releases where a sketch line's own data is measured to hold its segment
/// as a bounded line: 2024 (RE-50) and 2025 (RE-199, the roof sketches of
/// #356's `R2025_Models.zip`, each line's ends on Revit's exported outline).
pub const SKETCH_LINE_SUPPORTED_REVIT_VERSIONS: &[u32] = &[2024, 2025];

/// Each sketch line's segment, read as [`scan_bounded_lines`] reads a beam's
/// line, on the releases in [`SKETCH_LINE_SUPPORTED_REVIT_VERSIONS`]; empty
/// on others.
pub fn scan_sketch_bounded_lines(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
) -> Result<BTreeMap<u32, BoundedLine>> {
    if !SKETCH_LINE_SUPPORTED_REVIT_VERSIONS.contains(&revit_version) {
        return Ok(BTreeMap::new());
    }
    scan_first_bounded_lines(rf, revit_version, ids)
}

/// [`scan_bounded_lines`] without its release gate, for callers that
/// measured the layout on other releases (a wall's location line on 2025,
/// RE-55). Empty where the element-data header is not known.
pub fn scan_first_bounded_lines(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
) -> Result<BTreeMap<u32, BoundedLine>> {
    scan_first_records(rf, revit_version, ids, first_bounded_line)
}

/// The arc in the element data of each id in `ids` whose first curve record
/// is one ([`first_bounded_arc`]), read as [`scan_first_bounded_lines`]
/// reads lines (RE-75).
pub fn scan_first_bounded_arcs(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
) -> Result<BTreeMap<u32, BoundedArc>> {
    scan_first_records(rf, revit_version, ids, first_bounded_arc)
}

/// What `read` finds in the element data of each id in `ids`, from every
/// partition. An id whose copies disagree is dropped.
fn scan_first_records<T: PartialEq>(
    rf: &mut RevitFile,
    revit_version: u32,
    ids: &BTreeSet<u32>,
    read: fn(&[u8]) -> Option<T>,
) -> Result<BTreeMap<u32, T>> {
    let Some(layout) = crate::partition_names::element_data_layout(revit_version) else {
        return Ok(BTreeMap::new());
    };
    let header = layout.header;
    let mut found: BTreeMap<u32, Option<T>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let buf = inflated.bytes();
        let hits: Vec<usize> = memchr::memmem::find_iter(buf, &header).collect();
        for (index, &hit) in hits.iter().enumerate() {
            let id_at = hit + header.len();
            let Some(id) = layout.id_at(buf, id_at) else {
                continue;
            };
            if !ids.contains(&id) {
                continue;
            }
            let end = hits
                .get(index + 1)
                .copied()
                .unwrap_or(buf.len())
                .min(hit.saturating_add(BEAM_DATA_WINDOW))
                .min(buf.len());
            let Some(line) = buf.get(id_at + 8..end).and_then(read) else {
                continue;
            };
            match found.get_mut(&id) {
                None => {
                    found.insert(id, Some(line));
                }
                Some(held) => {
                    if held.as_ref() != Some(&line) {
                        *held = None;
                    }
                }
            }
        }
    }
    Ok(found
        .into_iter()
        .filter_map(|(id, line)| line.map(|line| (id, line)))
        .collect())
}

/// A beam's solid: a box along its location line.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BeamBody {
    /// Centre of the box, model feet: the centre of the record's box.
    pub centre: [f64; 3],
    /// Unit direction of the line.
    pub direction: [f64; 3],
    /// Extent along the line, feet: the line's length.
    pub length_feet: f64,
    /// Horizontal extent across the line, feet.
    pub width_feet: f64,
    /// Extent across the line in its vertical plane, feet.
    pub depth_feet: f64,
}

impl BeamBody {
    /// Whether the line is level.
    pub fn is_horizontal(&self) -> bool {
        self.direction[2].abs() <= HORIZONTAL_EPS
    }

    /// Plan angle of the line from +X, radians.
    pub fn plan_angle_radians(&self) -> f64 {
        self.direction[1].atan2(self.direction[0])
    }

    /// The ends of the box's centreline, model feet.
    pub fn centreline(&self) -> ([f64; 3], [f64; 3]) {
        let half = self.length_feet / 2.0;
        let at = |sign: f64| {
            [
                self.centre[0] + sign * half * self.direction[0],
                self.centre[1] + sign * half * self.direction[1],
                self.centre[2] + sign * half * self.direction[2],
            ]
        };
        (at(-1.0), at(1.0))
    }
}

/// How closely a beam's body must be as wide and as deep as its type's I
/// section, and its line lie on its record box's top, feet (RE-103).
pub const I_SECTION_TOLERANCE_FEET: f64 = 0.01;

/// The body of a beam whose type is an I section `section` (RE-103): its
/// body along its line where that is as wide and as deep as the section.
/// A level beam set down from its line has a record box that runs from the
/// line, on the box's top, down to the steel's bottom: where the box is as
/// wide as the section and deeper, and both ends of the line lie on its
/// top, the section sits on the box's bottom. Otherwise `None`.
pub fn i_section_body(
    body: BeamBody,
    section: &crate::partition_type_parameters::ISection,
    bbox: [f64; 6],
    start: [f64; 3],
    end: [f64; 3],
) -> Option<BeamBody> {
    let near = |a: f64, b: f64| (a - b).abs() <= I_SECTION_TOLERANCE_FEET;
    if !near(body.width_feet, section.width_feet) {
        return None;
    }
    if near(body.depth_feet, section.depth_feet) {
        return Some(body);
    }
    let set_down = body.is_horizontal()
        && body.depth_feet > section.depth_feet
        && near(start[2], bbox[5])
        && near(end[2], bbox[5]);
    set_down.then(|| BeamBody {
        centre: [
            body.centre[0],
            body.centre[1],
            bbox[2] + section.depth_feet / 2.0,
        ],
        depth_feet: section.depth_feet,
        ..body
    })
}

/// The box along the line from `start` to `end` whose axis-aligned extent is
/// the record box `bbox` (`[min x, min y, min z, max x, max y, max z]`, model
/// feet), or `None` when the line leaves the box, is too steep for a
/// horizontal width axis, or no such box reproduces the box's extents.
pub fn beam_body(bbox: [f64; 6], start: [f64; 3], end: [f64; 3]) -> Option<BeamBody> {
    if !bbox.iter().chain(&start).chain(&end).all(|v| v.is_finite()) {
        return None;
    }
    for axis in 0..3 {
        let (low, high) = (bbox[axis], bbox[axis + 3]);
        if low > high {
            return None;
        }
        for point in [start, end] {
            if point[axis] < low - END_TOLERANCE_FEET || point[axis] > high + END_TOLERANCE_FEET {
                return None;
            }
        }
    }
    let delta = [end[0] - start[0], end[1] - start[1], end[2] - start[2]];
    let length = (delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2]).sqrt();
    if length <= 0.0 {
        return None;
    }
    let d = [delta[0] / length, delta[1] / length, delta[2] / length];
    let plan = d[0].hypot(d[1]);
    if plan < MIN_PLAN_SHARE {
        return None;
    }
    // Width axis: horizontal, across the line. Depth axis: the line's
    // vertical plane, across the line (d × u).
    let u = [-d[1] / plan, d[0] / plan, 0.0];
    let w = [-d[2] * d[0] / plan, -d[2] * d[1] / plan, plan];
    let extent = [bbox[3] - bbox[0], bbox[4] - bbox[1], bbox[5] - bbox[2]];
    // Each extent is length·|d| + width·|u| + depth·|w| on its axis.
    let depth = (extent[2] - length * d[2].abs()) / w[2];
    let (solve, check) = if u[0].abs() >= u[1].abs() {
        (0, 1)
    } else {
        (1, 0)
    };
    let width = (extent[solve] - length * d[solve].abs() - depth * w[solve].abs()) / u[solve].abs();
    let closure = length * d[check].abs() + width * u[check].abs() + depth * w[check].abs();
    if !(width > 0.0 && depth > 0.0) || (closure - extent[check]).abs() > CLOSURE_TOLERANCE_FEET {
        return None;
    }
    Some(BeamBody {
        centre: [
            (bbox[0] + bbox[3]) / 2.0,
            (bbox[1] + bbox[4]) / 2.0,
            (bbox[2] + bbox[5]) / 2.0,
        ],
        direction: d,
        length_feet: length,
        width_feet: width,
        depth_feet: depth,
    })
}
