"""Attributed, selectively vendored code."""
