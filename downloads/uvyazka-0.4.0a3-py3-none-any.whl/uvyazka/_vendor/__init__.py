"""Attributed, selectively vendored code."""
