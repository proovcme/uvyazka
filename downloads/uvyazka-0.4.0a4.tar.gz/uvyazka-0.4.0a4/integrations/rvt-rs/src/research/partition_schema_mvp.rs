//! Uvyazka modification: preserve native MEP membership and extraction warnings.
//! Uvyazka modification: native MEP membership and visible extraction warnings.
//! Schema / partition MVP recovers for production `iter_elements`.
//!
//! Extends the ArcWall-only partition merge with fail-closed recovers
//! for Level and Material, and (on Revit 2024) ArcWallRectOpening index
//! rows, plus `OST_Columns` / `OST_Walls` / `OST_Doors` /
//! `OST_Windows` element records
//! ([`instances_from_partition_category_records`]),
//! `OST_Floors` / `OST_BuildingPad` slab instances
//! ([`slabs_from_partition_category_records`], #212 / RE-22) and
//! `OST_Rooms` room instances
//! ([`rooms_from_partition_category_records`], #90 / RE-29) on the
//! releases whose element records decode.
//!
//! Semantic `Door` / `Window` classes are still **not** invented from
//! opening-index rows — those keep surfacing as `ArcWallRectOpening`
//! with related-id provenance only, and RE-19's negative (no
//! discriminator in the opening-index bytes, no schema-field Wall)
//! stands untouched. Typed `Wall` / `Door` / `Window` come from a
//! different carrier: the element record's own `BuiltInCategory`
//! field, which names the category outright (#211). Opening-index
//! related ids are cross-checked against `Global/ElemTable` when
//! present; a hit confirms the id is declared, not that it is a host
//! Wall or a Door/Window family instance.
//!
//! # Version guard
//!
//! Partition byte scans reuse [`crate::partition_scanner`] /
//! [`crate::partition_arc_walls`] / [`crate::rect_opening_index`]
//! version gates. Unsupported releases yield empty lists.
//!
//! # Honesty
//!
//! - Never invent ElementIds, host walls, elevations, or geometry.
//! - Tier1 synthetics have no partition building elements — callers
//!   must observe zero Level/Material/Floor/opening hits there.
//! - Rooms and floors come from element records or not at all. The
//!   name-only rooms and plan-loop floors that once filled in were
//!   removed after they matched nothing in Revit's own exports.

use crate::le_bytes;
use crate::partition_arc_walls::{self, PartitionArcWall};
use crate::partition_name_candidates::{
    NameBucket, building_storey_name_candidates, classify_name, collect_name_candidates,
};
use crate::rect_opening_index::ArcWallRectOpeningIndex;
use crate::walker::{DecodedElement, ElementProvenance, InstanceField, WalkerLimits};
use crate::{Result, RevitFile};
use std::collections::{BTreeMap, BTreeSet};
use std::f64::consts::FRAC_PI_4;

/// Bundle of partition-derived MVP `DecodedElement`s.
#[derive(Debug, Clone, Default)]
pub struct PartitionSchemaMvp {
    pub levels: Vec<DecodedElement>,
    pub materials: Vec<DecodedElement>,
    pub rooms: Vec<DecodedElement>,
    /// Placed Areas from their partition chain records, written as
    /// `IfcSpace` (#763, [`crate::partition_area_records`]).
    pub areas: Vec<DecodedElement>,
    /// 2024 ArcWallRectOpening index rows — not typed Door/Window.
    pub rect_openings: Vec<DecodedElement>,
    /// 2024 `OST_Columns` partition element records (#204).
    // Tracker: M4-09.
    pub columns: Vec<DecodedElement>,
    /// 2024 `OST_Walls` partition element records (#211).
    pub walls: Vec<DecodedElement>,
    /// 2024 `OST_Doors` partition element records (#211).
    pub doors: Vec<DecodedElement>,
    /// 2024 `OST_Windows` partition element records (#211).
    pub windows: Vec<DecodedElement>,
    /// `OST_Floors` / `OST_BuildingPad` partition element records
    /// (#212, RE-22), the only source of floors.
    pub slabs: Vec<DecodedElement>,
    /// Furniture, casework, fixtures, curtain-wall parts, railings, wall
    /// sweeps, ducts and pipes from partition element records
    /// ([`crate::partition_element_records::PRODUCT_RECORD_CATEGORIES`],
    /// RE-33).
    pub products: Vec<DecodedElement>,
}

impl PartitionSchemaMvp {
    /// Flatten in a stable order for merging into `iter_elements`.
    pub fn into_elements(self) -> Vec<DecodedElement> {
        let mut out = Vec::with_capacity(
            self.levels.len()
                + self.materials.len()
                + self.rooms.len()
                + self.areas.len()
                + self.rect_openings.len()
                + self.columns.len()
                + self.walls.len()
                + self.doors.len()
                + self.windows.len()
                + self.slabs.len()
                + self.products.len(),
        );
        out.extend(self.levels);
        out.extend(self.materials);
        out.extend(self.rooms);
        out.extend(self.areas);
        out.extend(self.rect_openings);
        out.extend(self.columns);
        out.extend(self.walls);
        out.extend(self.doors);
        out.extend(self.windows);
        out.extend(self.slabs);
        out.extend(self.products);
        out
    }
}

/// Recover partition MVP elements for a file (version-gated, fail-closed).
pub fn recover_partition_schema_mvp(
    rf: &mut RevitFile,
    revit_version: u32,
    limits: WalkerLimits,
) -> Result<PartitionSchemaMvp> {
    let mut out = PartitionSchemaMvp::default();

    // --- Levels + Materials from partition strings / ArcWall elev ---
    let strings = rf.partition_string_records().unwrap_or_default();
    let string_values: Vec<&str> = strings.iter().map(|r| r.value.as_str()).collect();

    let level_names = building_storey_name_candidates(string_values.iter().copied());
    let name_set = collect_name_candidates(string_values.iter().copied());

    let arc_walls = rf.memoised_arc_wall_scan(revit_version, limits);

    out.levels = levels_from_storeys_and_names(&arc_walls.walls, &level_names);
    out.materials = match materials_from_records(rf, revit_version) {
        Some(materials) => materials,
        None => materials_from_names(&name_set),
    };

    // Rooms and floors come from partition element records only. The
    // name-only rooms (space-like display strings) and ArcWall-excluded
    // plan-loop floors that used to fill in matched nothing in Revit's own
    // exports: every family file gained a room named "Office Equipment",
    // the Revit 2025 RE1 MEP models 38 slabs and 71 spaces where their
    // exports hold none, and no 2023 plan loop (mostly triangles) came
    // within 10% of the plan area of a slab in two paired exports.

    // --- 2024 opening index (not Door/Window) ---
    if ArcWallRectOpeningIndex::supports_revit_version(revit_version) {
        out.rect_openings = rect_openings_from_partitions(rf, revit_version, limits)?;
    }

    // --- Revit 2015 to 2023 element records (RE-81, RE-180, RE-181, #421):
    // identity, category and box only; nothing else 2024 decodes on top of
    // records is read. ---
    if crate::partition_element_records_2023::is_32bit_release(revit_version) {
        recover_2023_records(rf, revit_version, &mut out);
        attach_room_outlines(rf, revit_version, &mut out.rooms);
        // --- Storeys from the Levels the records name (RE-107), by the
        // same rules as 2024's (RE-59, RE-68) ---
        let level_elevations: BTreeMap<u32, f64> =
            crate::partition_level_records::recover_partition_levels(rf, revit_version)
                .unwrap_or_default()
                .iter()
                .map(|level| (level.element_id, level.elevation_feet))
                .collect();
        let mut record_backed = [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.rooms,
            &mut out.products,
        ];
        resolve_framing_top_levels(&level_elevations, &mut record_backed);
        resolve_base_constraint_levels(&level_elevations, &mut record_backed);
        resolve_base_at_level(&level_elevations, &mut record_backed);
        resolve_remaining_levels(&level_elevations, &mut record_backed);
        // --- System families' names (RE-63); a wall's, roof's or
        // ceiling's needs its type's layers, not read on 2023 ---
        attach_system_family_names(
            rf,
            revit_version,
            &mut [&mut out.walls, &mut out.slabs, &mut out.products],
        );
        // --- Walls', floors' and roofs' layers, for their material layer
        // sets (RE-114) ---
        attach_wall_layers(rf, revit_version, &mut out.walls);
        attach_slab_layers(
            rf,
            revit_version,
            out.slabs
                .iter_mut()
                .chain(out.products.iter_mut())
                .collect(),
        );
        // --- The materials each family type's geometry uses (RE-113). A
        // system type's data holds its layers where a family type's holds
        // its map, and a layer reads as a one-entry map, so the types of
        // system-family elements are left out. ---
        let mut type_materials =
            crate::partition_type_materials::type_material_names_32(rf, revit_version);
        for element in out.walls.iter().chain(&out.slabs).chain(&out.products) {
            let system = element.fields.iter().any(|(name, value)| {
                name == FAMILY_NAME_SOURCE_FIELD
                    && matches!(value, InstanceField::String(source) if source == SYSTEM_FAMILY_SOURCE)
            });
            let type_id = element.fields.iter().find_map(|(name, value)| match value {
                InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
                _ => None,
            });
            if let (true, Some(type_id)) = (system, type_id) {
                type_materials.remove(&type_id);
            }
        }
        for elements in [
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.products,
        ] {
            attach_type_materials(&type_materials, elements);
        }
        // Uvyazka: explicit native MEP edges on the validated 2021 framing.
        attach_mep_systems(rf, revit_version, [
            &mut out.walls, &mut out.columns, &mut out.doors,
            &mut out.windows, &mut out.slabs, &mut out.products,
        ]);
        return Ok(out);
    }

    // --- 2024 partition element records (#204 columns, #211 the rest) ---
    //
    // The `Level` ElementId set costs one partition sweep and is read
    // once here for every category below: each record-backed element
    // binds to the Level its counted reference list names, when it
    // names exactly one (#219, RE-27).
    let level_ids = level_element_ids(rf, revit_version)?;
    // Columns and walls come out of one sweep: Revit cuts a column
    // with the walls it is joined to, so the column body needs the
    // wall boxes (#239, RE-29 §5), and inflating the partitions twice
    // to get them would dominate the cost.
    let (column_records, wall_records) = column_and_wall_records(rf, revit_version)?;
    let wall_instances: Vec<crate::partition_element_records::PartitionElementRecord> =
        select_instance_records(wall_records.clone())
            .into_values()
            .collect();
    out.walls = wall_instances_from_records(wall_records, &level_ids);
    out.columns = column_instances_from_records(column_records, &level_ids, &wall_instances);
    // Doors and windows bind to a host wall (#222, RE-23). The
    // candidate set is exactly the wall instances recovered above —
    // a recovered host that is not itself an exported wall is
    // discarded rather than emitted, so the join is self-checking.
    let wall_ids: BTreeSet<u32> = out.walls.iter().filter_map(|wall| wall.id).collect();
    out.doors = openings_from_partition_category_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_DOORS,
        "Door",
        &wall_ids,
        &level_ids,
    )?;
    out.windows = openings_from_partition_category_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_WINDOWS,
        "Window",
        &wall_ids,
        &level_ids,
    )?;

    // --- Slab instances from element records (#212, RE-22) ---
    //
    // Record-backed slabs carry an ElementId, a model bounding box,
    // a measured thickness and a storey.
    out.slabs = slabs_from_partition_category_records(rf, revit_version, &level_ids)?;

    // --- Room instances from element records (#90, RE-29) ---
    //
    // A record-backed room carries an ElementId, a model bounding box
    // that is exactly the reference export's plan envelope and
    // floor-to-ceiling extent, a number, a name and a host Level, none
    // of which a partition *string* can supply.
    out.rooms = rooms_from_partition_category_records(rf, revit_version, &level_ids)?;
    // Their outlines from the faces of their stored solids (RE-101).
    attach_room_outlines(rf, revit_version, &mut out.rooms);
    // Their heights from their native records (RE-255).
    attach_room_heights(rf, revit_version, &mut out.rooms);
    // --- Areas, which carry no record box (#763) ---
    out.areas = crate::partition_area_records::areas_from_partition_chain_records(
        rf,
        revit_version,
        &level_ids,
    );

    // --- Other product categories from element records (RE-33) ---
    out.products = product_instances_from_partition_records(rf, revit_version, &level_ids)?;
    // --- Base constraints of elements naming two Levels (RE-59), then
    // railings by their host and elements by the Level objects they name
    // (RE-60) ---
    let level_elevations: BTreeMap<u32, f64> =
        crate::partition_level_records::recover_partition_levels(rf, revit_version)
            .unwrap_or_default()
            .iter()
            .map(|level| (level.element_id, level.elevation_feet))
            .collect();
    let mut record_backed = [
        &mut out.walls,
        &mut out.columns,
        &mut out.doors,
        &mut out.windows,
        &mut out.slabs,
        &mut out.rooms,
        &mut out.products,
    ];
    resolve_base_constraint_levels(&level_elevations, &mut record_backed);
    resolve_base_at_level(&level_elevations, &mut record_backed);
    resolve_hosted_levels(rf, &level_elevations, &mut record_backed);
    resolve_remaining_levels(&level_elevations, &mut record_backed);
    // --- Stair parts under their stairs (#323) ---
    attach_aggregate_wholes(rf, &mut out.products);
    // --- Curtain walls and their panels and mullions (RE-46) ---
    attach_curtain_walls(
        rf,
        revit_version,
        &mut out.walls,
        &mut out.products,
        [&mut out.doors, &mut out.windows],
    );
    // --- Doors and windows in the nearest listed wall that is not a curtain wall (#439) ---
    bind_opening_hosts(&out.walls, &mut out.doors);
    bind_opening_hosts(&out.walls, &mut out.windows);
    // --- Stair and flight riser and tread dimensions (RE-47) ---
    attach_stair_dimensions(rf, revit_version, &mut out.products);
    // --- Stair runs' treads and risers, and their run type (RE-52) ---
    attach_stair_run_bodies(rf, revit_version, &mut out.products);
    attach_stair_nosing_lengths(&mut out.products);
    // --- Spiral runs as their treads (#357) ---
    attach_spiral_run_bodies(rf, revit_version, &mut out.products);
    // --- Monolithic landings as their slabs (#824) ---
    attach_landing_slabs(rf, revit_version, &mut out.products);
    // --- Beams along their location lines (RE-49) ---
    attach_beam_axes(rf, revit_version, &mut out.products);
    // --- Pipes as cylinders along their ends (RE-131) ---
    attach_pipe_axes(rf, revit_version, &mut out.products);
    // --- Which element each end of a duct or pipe is joined to (RE-138) ---
    attach_connector_pairs(rf, revit_version, &mut out.products);
    // --- Roof outlines from their sketch lines (RE-50) ---
    attach_roof_profiles(rf, revit_version, &mut out.products);
    // --- Shaft openings cut the outlines within their height (RE-99) ---
    attach_shaft_voids(rf, revit_version, [&mut out.slabs, &mut out.products]);

    // --- The Revit class each record names at +0x4a (RE-76, #154) ---
    if let Ok(classes) = rf.memoised_schema_classes() {
        for elements in [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.rooms,
            &mut out.products,
        ] {
            attach_revit_classes(&classes, elements);
        }
    }

    // --- A turned family instance's plan axis (RE-87) ---
    attach_instance_axes(
        rf,
        revit_version,
        [&mut out.doors, &mut out.windows, &mut out.products],
    );
    // --- Curtain mullions and panels turned or tilted off the model's axes,
    // with their three axes (RE-106) ---
    attach_curtain_axes(rf, revit_version, &mut out.products);
    // --- Each door's and window's facing, for its type's flip (B72) ---
    attach_opening_facings(rf, revit_version, [&mut out.doors, &mut out.windows]);
    // --- Each family instance's original symbol, whose GlobalId Revit's
    // export gives its type (RE-167, B60) ---
    attach_original_symbols(
        rf,
        revit_version,
        [
            &mut out.doors,
            &mut out.windows,
            &mut out.columns,
            &mut out.products,
        ],
    );

    // --- Family and type names (RE-38) ---
    for elements in [
        &mut out.walls,
        &mut out.columns,
        &mut out.doors,
        &mut out.windows,
        &mut out.slabs,
        &mut out.products,
    ] {
        attach_family_and_type_names(rf, elements);
    }
    // --- The phase each element was created in (spike 257) ---
    attach_phases_created(
        rf,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ],
    );
    // --- Pipes' types, which have no name entry (RE-130) ---
    attach_pipe_type_names(rf, &mut out.products);
    // --- Ducts' and pipes' sizes, and ducts' types (RE-134) ---
    attach_curve_fields(rf, revit_version, &mut out.products);
    // --- Which connector each end of a duct is (#847) ---
    attach_duct_end_keys(rf, revit_version, &mut out.products);
    // --- Pipe fittings' nominal sizes, from their connectors (RE-165) ---
    attach_fitting_nominal_diameters(rf, revit_version, &mut out.products);
    // --- The shared parameter Serial Number (RE-156) ---
    attach_serial_numbers(
        rf,
        revit_version,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ],
    );
    // --- The MEP systems each element is a member of (RE-162) ---
    attach_mep_systems(
        rf,
        revit_version,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ],
    );
    // --- System-family type names (#322) ---
    let mut unnamed: Vec<&mut DecodedElement> = [&mut out.walls, &mut out.slabs, &mut out.products]
        .into_iter()
        .flat_map(|elements| elements.iter_mut())
        .filter(|element| {
            !element
                .fields
                .iter()
                .any(|(name, _)| name == TYPE_NAME_FIELD)
        })
        .collect();
    attach_system_type_names(rf, revit_version, &mut unnamed);
    // --- Railings' heights (RE-231) ---
    attach_railing_heights(rf, revit_version, &mut out.products);
    // --- Stair railings' Length (RE-254) ---
    attach_railing_lengths(rf, revit_version, &mut out.products);
    // --- Each element's type Function (RE-158) ---
    attach_type_functions(
        rf,
        revit_version,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ],
    );
    // --- Curtain panels that are walls (RE-64) ---
    let mut unnamed_panels: Vec<&mut DecodedElement> = out
        .products
        .iter_mut()
        .filter(|element| {
            element.class == "CurtainWallPanel"
                && !element
                    .fields
                    .iter()
                    .any(|(name, _)| name == TYPE_NAME_FIELD)
        })
        .collect();
    attach_panel_wall_types(rf, revit_version, &mut unnamed_panels);
    // --- Model text (RE-67) ---
    attach_model_text_types(rf, revit_version, &mut out.products);
    // --- Wall sweeps (RE-69) ---
    attach_wall_sweep_types(rf, revit_version, &mut out.products);
    // --- Pipes, wall sweeps and ramps typed in their own record (RE-240) ---
    attach_native_type_names(rf, &mut out.products);
    // --- Curtain mullions drawn as an extrusion of their section (RE-243) ---
    attach_mullion_plain_hosts(rf, &mut out.products);
    // --- Walls' layers and exterior side (RE-53) ---
    attach_wall_layers(rf, revit_version, &mut out.walls);
    // --- The openings a wall's edited elevation profile cuts (B55) ---
    attach_wall_profile_openings(rf, revit_version, &mut out.walls);
    // --- A shed roof's slope (RE-56) ---
    attach_roof_slopes(rf, revit_version, &mut out.products);
    // --- A roof by extrusion's section (RE-211) ---
    attach_extrusion_roofs(rf, revit_version, &mut out.products);
    // --- Floors', roofs' and ceilings' layers (RE-57) ---
    attach_slab_layers(
        rf,
        revit_version,
        out.slabs
            .iter_mut()
            .chain(out.products.iter_mut())
            .collect(),
    );
    // --- System families' names (RE-63) ---
    attach_system_family_names(
        rf,
        revit_version,
        &mut [&mut out.walls, &mut out.slabs, &mut out.products],
    );
    // --- Stairs and their parts named as Revit names them (RE-65) ---
    attach_stair_names(rf, revit_version, &mut out.products);
    attach_native_stair_names(rf, revit_version, &mut out.products);
    // --- Stair runs' shape, from their treads, and each stair's type from
    // its runs and landings, once every part names its stair (#323) ---
    attach_stair_run_shapes(rf, revit_version, &mut out.products);
    // --- IFC export overrides, the element's own or its type's (RE-45) ---
    attach_ifc_export_overrides(
        rf,
        revit_version,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ],
    );
    // --- Empty curtain panels are left out, as Revit leaves them out (#309) ---
    out.products
        .retain(|product| !is_empty_curtain_panel(product));
    // --- Curtain panels that are walls export as curtain walls (RE-72) ---
    // Last, so every step above still sees them as panels.
    for product in &mut out.products {
        if product.class == "CurtainWallPanel"
            && product.fields.iter().any(|(name, value)| {
                name == CURTAIN_PANEL_WALL_FIELD && matches!(value, InstanceField::Bool(true))
            })
        {
            product.class = CURTAIN_PANEL_WALL_CLASS.into();
        }
    }

    // --- Column bottoms from the geometry node (RE-173) ---
    if revit_version == 2024 {
        apply_column_node_bottoms(rf, [&mut out.columns, &mut out.products]);
        apply_column_cut_bodies(rf, [&mut out.columns, &mut out.products]);
    }

    // --- Type text parameters (RE-77, #35) ---
    let type_parameters = crate::partition_type_parameters::type_text_parameters(rf, revit_version);
    if !type_parameters.is_empty() {
        for elements in [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ] {
            attach_type_text_parameters(&type_parameters, elements);
        }
    }

    // --- Level parameters from the per-element association record (RE-172),
    // stairs' Base and Top Level from the same record and the Level named in
    // the element record's id lists where the field holds none (RE-174) ---
    let (level_parameters, (level_names, level_elevations)) =
        crate::partition_level_parameters::level_parameters(rf, revit_version);
    if !level_names.is_empty() {
        let mut lists = [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ];
        for elements in lists.iter_mut() {
            for element in elements.iter_mut() {
                attach_level_parameters(
                    rf,
                    element,
                    &level_parameters,
                    &level_names,
                    &level_elevations,
                );
            }
        }
    }

    // --- The materials each family type's geometry uses (RE-82, #355) ---
    let mut type_materials =
        crate::partition_type_materials::type_material_names(rf, revit_version);
    // The map read by name, where the scan also takes a nested component's
    // materials (RE-203).
    let partly_unset = refine_type_materials(rf, revit_version, &mut type_materials, &out);
    if !type_materials.is_empty() {
        for elements in [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.products,
        ] {
            attach_type_materials(&type_materials, elements);
        }
    }
    if !partly_unset.is_empty() {
        let instance_materials =
            instance_parameter_material_names(rf, revit_version, &partly_unset, &out);
        for elements in [&mut out.columns, &mut out.products] {
            attach_partly_unset_materials(&partly_unset, &instance_materials, elements);
        }
    }

    // --- Every column's joins, in one native pass (RE-202, RE-247) ---
    let column_ids: BTreeSet<u64> = out
        .columns
        .iter()
        .chain(out.products.iter())
        .filter(|element| is_column_class(&element.class))
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    let column_joins = crate::native_column_joins::joins(rf, &column_ids).ok();

    // --- Family instances whose type draws with no material (RE-149, #355) ---
    // An instance whose own material parameters name its materials takes
    // them instead (RE-200).
    let unset_types = crate::partition_type_materials::unset_material_types(rf, revit_version);
    if !unset_types.is_empty() {
        let instance_materials =
            instance_parameter_material_names(rf, revit_version, &unset_types, &out);
        for elements in [&mut out.columns, &mut out.products] {
            attach_unnamed_materials(&unset_types, &instance_materials, elements);
        }
        // The first joined wall's layer on the column's side (RE-202), then
        // the joined walls' one shared set (#580).
        attach_first_join_materials(
            rf,
            column_joins.as_ref().map(|joins| &joins.order),
            &mut out.columns,
            &out.walls,
        );
        attach_joined_wall_materials(&mut out.columns, &out.walls);
    }
    // --- Columns no `CleanPairGStep` joins, which Revit's export draws as
    // an extrusion (RE-247) ---
    if let Some(joins) = &column_joins {
        for element in out.columns.iter_mut().chain(out.products.iter_mut()) {
            if is_column_class(&element.class)
                && element
                    .id
                    .is_some_and(|id| joins.without_clean_steps.contains(&u64::from(id)))
            {
                element
                    .fields
                    .push((COLUMN_UNJOINED_FIELD.into(), InstanceField::Bool(true)));
            }
        }
    }

    // --- Curtain mullions' and panels' materials, from their types (RE-166, B66) ---
    attach_curtain_materials(rf, revit_version, &mut out.products);

    // --- Rendered content (RPC, planting) is `<Unnamed>` (RE-202, #355) ---
    attach_rendered_content_materials(rf, &mut out.products);

    // --- Each window's opening from its type and transform (RE-93, #227) ---
    attach_window_openings(rf, revit_version, &mut out.windows);
    // --- Each door's rough opening from its type (RE-94, #227), after RE-84
    // marks the doors that are openings alone ---
    attach_door_openings(rf, revit_version, &mut out.doors);
    // --- Each door's Width and Height from its type (RE-187, #759) ---
    attach_door_sizes(rf, revit_version, &mut out.doors);
    // --- Each door's and window's size from the outline its symbol cuts
    // (RE-215, #844) ---
    let walls: BTreeSet<u32> = out.walls.iter().filter_map(|wall| wall.id).collect();
    let plain_walls: BTreeSet<u32> = out
        .walls
        .iter()
        .filter(|wall| wall.class != CURTAIN_WALL_CLASS)
        .filter_map(|wall| wall.id)
        .collect();
    attach_cut_loop_sizes(
        rf,
        revit_version,
        [&mut out.doors, &mut out.windows],
        &walls,
        &plain_walls,
    );
    // --- Steel beams' and columns' I sections from their type (RE-103, RE-104) ---
    attach_beam_sections(rf, revit_version, &mut out.products);
    // --- Hollow structural sections from their type's family parameters (W6) ---
    attach_hollow_sections(rf, revit_version, [&mut out.columns, &mut out.products]);
    // --- A wall's and a curtain panel wall's type Function, from its native
    // type record (RE-185), after RE-72 has relabelled the panels ---
    attach_wall_type_functions(
        rf,
        revit_version,
        out.walls.iter_mut().chain(
            out.products
                .iter_mut()
                .filter(|product| product.class == CURTAIN_PANEL_WALL_CLASS),
        ),
    );
    // --- IsExternal: the parameters named for it, and Revit's calculation (RE-193) ---
    attach_is_external(
        rf,
        revit_version,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.rooms,
            &mut out.areas,
            &mut out.products,
        ],
    );
    // --- The parameters named for a standard set's other properties (RE-194) ---
    attach_named_parameters(
        rf,
        revit_version,
        [
            &mut out.walls,
            &mut out.columns,
            &mut out.doors,
            &mut out.windows,
            &mut out.slabs,
            &mut out.rooms,
            &mut out.areas,
            &mut out.products,
        ],
    );
    Ok(out)
}

/// Field naming the IFC entity an element's "Export to IFC As" override,
/// or its type's "Export Type to IFC As", names (#212, RE-45). The decoder
/// does not act on it; [`crate::ifc::category_map::lookup_export_override`]
/// decides which values the IFC writer honours.
pub const IFC_EXPORT_AS_FIELD: &str = "m_ifc_export_as";

/// Field naming the IFC predefined type an element's or its type's export
/// parameters set (RE-45). The IFC writer uses it only when it is an
/// enumerator of the entity the element exports as.
pub const IFC_PREDEFINED_TYPE_FIELD: &str = "m_ifc_predefined_type";

/// Field carrying the Revit release that saved the file, beside
/// [`IFC_EXPORT_AS_FIELD`]: whether Revit's exporter acts on the value can
/// depend on it ([`crate::ifc::category_map::export_override_applies`],
/// RE-188).
pub const IFC_EXPORT_RELEASE_FIELD: &str = "m_ifc_export_release";

/// Attach each element's IFC export overrides (RE-45): the element's own
/// "Export to IFC As" and predefined type, else those its type sets
/// ([`TYPE_ID_FIELD`], from RE-38 or #322). A type's `IfcCoveringType`
/// names `IfcCovering`.
fn attach_ifc_export_overrides(
    rf: &mut RevitFile,
    revit_version: u32,
    lists: [&mut Vec<DecodedElement>; 6],
) {
    use crate::partition_ifc_export_overrides as ieo;
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let parameters = ieo::scan_export_parameters(rf, revit_version, &declared).unwrap_or_default();
    if parameters.is_empty() {
        return;
    }
    let none = ieo::ExportParameters::default();
    for elements in lists {
        for element in elements.iter_mut() {
            let own = element
                .id
                .and_then(|id| parameters.get(&id))
                .unwrap_or(&none);
            let of_type = element
                .fields
                .iter()
                .find_map(|(name, value)| match value {
                    InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
                    _ => None,
                })
                .and_then(|id| parameters.get(&id));
            if let Some(entity) = own.effective_export_as(of_type) {
                element
                    .fields
                    .push((IFC_EXPORT_AS_FIELD.into(), InstanceField::String(entity)));
                element.fields.push((
                    IFC_EXPORT_RELEASE_FIELD.into(),
                    InstanceField::Integer {
                        value: i64::from(revit_version),
                        signed: false,
                        size: 4,
                    },
                ));
            }
            if let Some(predefined) = own.effective_predefined_type(of_type) {
                element.fields.push((
                    IFC_PREDEFINED_TYPE_FIELD.into(),
                    InstanceField::String(predefined),
                ));
            }
        }
    }
}

/// Give elements of system families (walls, floors, roofs, ceilings,
/// railings) their type's name (#322).
///
/// The type is the one type-definition record of the element's category
/// that its reference list names (RE-28,
/// [`crate::partition_type_records::unique_type_reference`]). Its name is
/// read from its serialised data
/// ([`crate::partition_names::find_element_data_names`]). Such a type has no
/// family in the file, since Revit names the system family ("Basic Wall")
/// in its own UI language, so only [`TYPE_ID_FIELD`] and [`TYPE_NAME_FIELD`]
/// are set.
fn attach_system_type_names(
    rf: &mut RevitFile,
    revit_version: u32,
    elements: &mut [&mut DecodedElement],
) {
    use crate::partition_type_records as ptr;
    if elements.is_empty() || !ptr::supports_revit_version(revit_version) {
        return;
    }
    let Some(header) = crate::partition_names::element_data_header(revit_version) else {
        return;
    };
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let mut type_ids_by_category: BTreeMap<i64, BTreeSet<u32>> = BTreeMap::new();
    let mut picks: Vec<(usize, u32)> = Vec::new();
    for (index, element) in elements.iter().enumerate() {
        let Some((references, category)) = record_references(rf, element) else {
            continue;
        };
        let type_ids = type_ids_by_category.entry(category).or_insert_with(|| {
            let records =
                ptr::scan_type_records(rf, revit_version, category, &declared).unwrap_or_default();
            ptr::type_definition_ids(&records)
        });
        if let Some(type_id) = ptr::unique_type_reference(&references, type_ids) {
            picks.push((index, type_id));
        }
    }
    // B45: a railing whose reference list names no type definition holds its
    // type in its own data object.
    let unpicked: Vec<(usize, u32)> = elements
        .iter()
        .enumerate()
        .filter(|(index, element)| {
            element.class == "Railing" && !picks.iter().any(|(picked, _)| picked == index)
        })
        .filter_map(|(index, element)| Some((index, element.id?)))
        .collect();
    let mut railing_names = BTreeMap::new();
    if revit_version >= 2024 && !unpicked.is_empty() {
        let (railing_picks, names) = railing_type_picks(rf, &unpicked);
        picks.extend(railing_picks);
        railing_names = names;
    }
    if picks.is_empty() {
        return;
    }
    let wanted: BTreeSet<u32> = picks.iter().map(|(_, id)| *id).collect();
    let mut names = type_data_names(rf, &header, &wanted);
    // RE-230: a curtain wall type's data gives no name; its native record
    // does.
    let unread: BTreeSet<u64> = wanted
        .iter()
        .filter(|id| !names.contains_key(id))
        .map(|id| u64::from(*id))
        .collect();
    let curtain_names = if unread.is_empty() {
        BTreeMap::new()
    } else {
        crate::native_walls::curtain_wall_type_names(rf, &unread).unwrap_or_default()
    };
    for (id, name) in curtain_names {
        if let Ok(id) = u32::try_from(id) {
            names.insert(id, Some(name));
        }
    }
    // A railing type with no element data keeps its name in its type object
    // (RE-66, measured on Revit 2024, and B45's RE1 railing on 2025).
    let railing_types: BTreeSet<u32> = picks
        .iter()
        .filter(|(index, id)| {
            elements[*index].class == "Railing" && !matches!(names.get(id), Some(Some(_)))
        })
        .map(|(_, id)| *id)
        .collect();
    let railing_tags = rf
        .memoised_schema_classes()
        .ok()
        .and_then(|classes| crate::partition_names::RailingTypeTags::from_classes(&classes));
    if let Some(tags) = railing_tags.filter(|_| revit_version >= 2024 && !railing_types.is_empty())
    {
        for stream in rf.partition_stream_names() {
            let Ok(inflated) = rf.inflated_partition(&stream) else {
                continue;
            };
            for (id, name) in crate::partition_names::find_railing_type_names(
                inflated.bytes(),
                &railing_types,
                tags,
            ) {
                match names.get(&id) {
                    Some(Some(held)) if *held != name => {
                        names.insert(id, None);
                    }
                    Some(None) => {}
                    _ => {
                        names.insert(id, Some(name));
                    }
                }
            }
        }
    }
    for (id, name) in railing_names {
        if !matches!(names.get(&id), Some(Some(_))) {
            names.insert(id, Some(name));
        }
    }
    attach_type_picks(elements, picks, &names);
}

/// The type of each of `railings` (index, ElementId) that its own
/// `BaseRailing` data object (RE-153) names: the one ElementId in the
/// object's payload, at any offset, of a railing type's `StairsRailingAttr`
/// object. RE1 Architecture's railing 462556 holds its type 446543, Revit's
/// `IfcRailingType` Tag, at +283 of its 329-byte object. With the picks, the
/// picked types' names their own objects hold
/// ([`crate::partition_names::railing_type_name_in`]). Revit 2024 and later.
// Tracker: B45.
fn railing_type_picks(
    rf: &mut RevitFile,
    railings: &[(usize, u32)],
) -> (Vec<(usize, u32)>, BTreeMap<u32, String>) {
    let Ok(classes) = rf.memoised_schema_classes() else {
        return Default::default();
    };
    let tag_of = |name: &str| {
        classes
            .classes
            .iter()
            .find(|class| class.name == name)
            .map(|class| u32::from(class.tag))
    };
    let (Some(railing_tag), Some(type_tag)) = (tag_of("BaseRailing"), tag_of("StairsRailingAttr"))
    else {
        return Default::default();
    };
    let name_tags = crate::partition_names::RailingTypeTags::from_classes(&classes);
    let wanted: BTreeSet<u32> = railings.iter().map(|(_, id)| *id).collect();
    let mut type_ids: BTreeSet<u32> = BTreeSet::new();
    // Each type's name where its copies that read one agree; a copy whose
    // name does not read takes no part.
    let mut type_names: BTreeMap<u32, Option<String>> = BTreeMap::new();
    let mut held: BTreeMap<u32, BTreeSet<u32>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let buf = inflated.bytes();
        let Ok(objects) = rf.memoised_partition_data_objects(&stream) else {
            continue;
        };
        for &(p, object) in objects.iter() {
            let class = object.class & 0xffff;
            if class == type_tag {
                let name = name_tags.and_then(|tags| {
                    crate::partition_names::railing_type_name_in(&buf[p..object.end], tags)
                });
                type_ids.insert(object.element_id);
                if let Some(name) = name {
                    let held = type_names
                        .entry(object.element_id)
                        .or_insert_with(|| Some(name.clone()));
                    if held.as_deref() != Some(name.as_str()) {
                        *held = None;
                    }
                }
            } else if class == railing_tag && wanted.contains(&object.element_id) {
                let payload =
                    &buf[p + crate::partition_room_parameters::DATA_OBJECT_HEADER..object.end];
                let values = held.entry(object.element_id).or_default();
                for word in payload.windows(4) {
                    values.insert(u32::from_le_bytes(word.try_into().expect("4 bytes")));
                }
            }
        }
    }
    let picks: Vec<(usize, u32)> = railings
        .iter()
        .filter_map(|(index, id)| {
            let mut named = held.get(id)?.intersection(&type_ids);
            match (named.next(), named.next()) {
                (Some(&type_id), None) => Some((*index, type_id)),
                _ => None,
            }
        })
        .collect();
    let names = picks
        .iter()
        .filter_map(|(_, type_id)| Some((*type_id, type_names.get(type_id)?.clone()?)))
        .collect();
    (picks, names)
}

/// Each wanted type's name, read from its serialised data
/// ([`crate::partition_names::find_element_data_names`]), from the latest
/// partition that holds one (#807, RE-145); `None` when two copies there
/// disagree. On the BIM4LCA office's permit file every type has an older copy
/// with its Finnish name and a newer one with its English name.
fn type_data_names(
    rf: &mut RevitFile,
    header: &[u8; 10],
    wanted: &BTreeSet<u32>,
) -> BTreeMap<u32, Option<String>> {
    use crate::partition_room_parameters::{LatestCopy, partition_number};
    let mut names = LatestCopy::default();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let partition = partition_number(&stream);
        for (id, name) in
            crate::partition_names::find_element_data_names(inflated.bytes(), header, wanted)
        {
            names.offer(id, partition, name);
        }
    }
    names.into_options()
}

/// Set [`TYPE_ID_FIELD`] and [`TYPE_NAME_FIELD`] on each picked element
/// whose type has one agreed name.
fn attach_type_picks(
    elements: &mut [&mut DecodedElement],
    picks: Vec<(usize, u32)>,
    names: &BTreeMap<u32, Option<String>>,
) {
    for (index, type_id) in picks {
        let Some(Some(name)) = names.get(&type_id) else {
            continue;
        };
        let element = &mut elements[index];
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: type_id,
            },
        ));
        element
            .fields
            .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
    }
}

/// Give wall sweeps their type and family, or Revit's name for one without a
/// type (RE-69).
///
/// A wall sweep's type is a system-family type with no type-definition
/// record of the sweep category, so RE-44's join finds none. Its record
/// names it among other things: its profile (a family type with a name
/// entry, RE-38), its material, the walls it runs along. The type is the
/// one id the record names that has a type object
/// ([`crate::partition_names::find_type_object_ids`]), no name entry, and
/// an element-data name; the sweep is then named `Wall Sweep:<type>:<id>`.
/// A sweep whose record names no such object at all is a sweep of a wall
/// type's own structure, which Revit names by its ElementId alone.
///
/// Measured on Snowdon Towers only (Revit 2024): 249 sweeps take a type and
/// 9 are named by ElementId, all as Revit's export names them.
fn attach_wall_sweep_types(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    if revit_version != 2024 {
        return;
    }
    let Some(header) = crate::partition_names::element_data_header(revit_version) else {
        return;
    };
    let has = |element: &DecodedElement, field: &str| {
        element.fields.iter().any(|(name, _)| name == field)
    };
    let mut lists: Vec<(usize, BTreeSet<u32>)> = Vec::new();
    for (index, element) in products.iter().enumerate() {
        if element.class != "WallSweep"
            || has(element, TYPE_NAME_FIELD)
            || has(element, FAMILY_NAME_FIELD)
            || has(element, ELEMENT_NAME_FIELD)
        {
            continue;
        }
        let Some((references, _)) = record_references(rf, element) else {
            continue;
        };
        let named: BTreeSet<u32> = references
            .iter()
            .filter_map(|&slot| u32::try_from(slot).ok())
            .filter(|id| Some(*id) != element.id)
            .collect();
        lists.push((index, named));
    }
    if lists.is_empty() {
        return;
    }
    let entries = rf.memoised_element_names();
    let wanted: BTreeSet<u32> = lists
        .iter()
        .flat_map(|(_, ids)| ids.iter().copied())
        .filter(|id| !entries.entries.contains_key(id))
        .collect();
    let mut objects: BTreeSet<u32> = BTreeSet::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        objects.extend(crate::partition_names::find_type_object_ids(
            inflated.bytes(),
            &wanted,
        ));
    }
    let names = type_data_names(rf, &header, &objects);
    for (index, ids) in lists {
        let types: Vec<u32> = ids
            .iter()
            .copied()
            .filter(|id| objects.contains(id))
            .collect();
        let element = &mut products[index];
        match types.as_slice() {
            [] => {
                if let Some(id) = element.id {
                    element.fields.push((
                        ELEMENT_NAME_FIELD.into(),
                        InstanceField::String(id.to_string()),
                    ));
                }
            }
            [type_id] => {
                let Some(Some(name)) = names.get(type_id) else {
                    continue;
                };
                element.fields.push((
                    TYPE_ID_FIELD.into(),
                    InstanceField::ElementId {
                        tag: 0,
                        id: *type_id,
                    },
                ));
                element
                    .fields
                    .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
                element.fields.push((
                    FAMILY_NAME_FIELD.into(),
                    InstanceField::String("Wall Sweep".into()),
                ));
                element.fields.push((
                    FAMILY_NAME_SOURCE_FIELD.into(),
                    InstanceField::String(SYSTEM_FAMILY_SOURCE.into()),
                ));
            }
            _ => {}
        }
    }
}

/// Mark each curtain mullion that stands on a straight curtain wall with an
/// unedited profile and whose type has its own rectangular section
/// ([`crate::native_mullion_hosts::mullions_on_plain_hosts`], RE-243) with
/// [`MULLION_PLAIN_HOST_FIELD`].
fn attach_mullion_plain_hosts(rf: &mut RevitFile, products: &mut [DecodedElement]) {
    let mullions: BTreeSet<u64> = products
        .iter()
        .filter(|element| element.class == "CurtainWallMullion")
        .filter_map(|element| Some(u64::from(element.id?)))
        .collect();
    let Ok(plain) = crate::native_mullion_hosts::mullions_on_plain_hosts(rf, &mullions) else {
        return;
    };
    for element in products.iter_mut() {
        if element.class == "CurtainWallMullion"
            && element.id.is_some_and(|id| plain.contains(&u64::from(id)))
        {
            element
                .fields
                .push((MULLION_PLAIN_HOST_FIELD.into(), InstanceField::Bool(true)));
        }
    }
}

/// Give each pipe, wall sweep and ramp still without a type, or a name of
/// its own, the type its native record names
/// ([`crate::native_element_types::system_type_names`], RE-240). Its family
/// is then its class's system family ([`system_family`]), and a sweep's is
/// Wall Sweep, as RE-69 names it.
fn attach_native_type_names(rf: &mut RevitFile, products: &mut [DecodedElement]) {
    let has = |element: &DecodedElement, field: &str| {
        element.fields.iter().any(|(name, _)| name == field)
    };
    let wanted: BTreeMap<u64, String> = products
        .iter()
        .filter(|element| {
            crate::native_element_types::reads_class(&element.class)
                && !has(element, TYPE_NAME_FIELD)
                && !has(element, ELEMENT_NAME_FIELD)
        })
        .filter_map(|element| Some((u64::from(element.id?), element.class.clone())))
        .collect();
    if wanted.is_empty() {
        return;
    }
    let Ok(found) = crate::native_element_types::system_type_names(rf, &wanted) else {
        return;
    };
    for element in products.iter_mut() {
        let Some((type_id, name)) = element.id.and_then(|id| found.get(&u64::from(id))) else {
            continue;
        };
        let Ok(type_id) = u32::try_from(*type_id) else {
            continue;
        };
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: type_id,
            },
        ));
        element
            .fields
            .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
        if element.class == "WallSweep" {
            element.fields.push((
                FAMILY_NAME_FIELD.into(),
                InstanceField::String("Wall Sweep".into()),
            ));
            element.fields.push((
                FAMILY_NAME_SOURCE_FIELD.into(),
                InstanceField::String(SYSTEM_FAMILY_SOURCE.into()),
            ));
        }
    }
}

/// Give model text its type and family (RE-67).
///
/// A model text element is in the Generic Models category, but it is not a
/// family instance: its reference list names a text type, which has no name
/// entry (RE-38) and no type-definition record of the category. The text
/// type is the one id the list names whose type object carries a font
/// ([`crate::partition_names::find_text_type_names`]), and Revit names the
/// element `Model Text:<type>:<ElementId>`. Measured on Snowdon Towers only
/// (Revit 2024), where it names all 7 model texts as Revit's export does.
fn attach_model_text_types(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    if revit_version != 2024 {
        return;
    }
    let has = |element: &DecodedElement, field: &str| {
        element.fields.iter().any(|(name, _)| name == field)
    };
    let mut lists: Vec<(usize, BTreeSet<u32>)> = Vec::new();
    for (index, element) in products.iter().enumerate() {
        if element.class != "GenericModel"
            || has(element, TYPE_NAME_FIELD)
            || has(element, FAMILY_NAME_FIELD)
        {
            continue;
        }
        let Some((references, _)) = record_references(rf, element) else {
            continue;
        };
        let named: BTreeSet<u32> = references
            .iter()
            .filter_map(|&slot| u32::try_from(slot).ok())
            .filter(|id| Some(*id) != element.id)
            .collect();
        lists.push((index, named));
    }
    if lists.is_empty() {
        return;
    }
    let wanted: BTreeSet<u32> = lists
        .iter()
        .flat_map(|(_, ids)| ids.iter().copied())
        .collect();
    let mut names: BTreeMap<u32, Option<String>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        for (id, name) in crate::partition_names::find_text_type_names(inflated.bytes(), &wanted) {
            match names.get(&id) {
                Some(Some(held)) if *held != name => {
                    names.insert(id, None);
                }
                Some(None) => {}
                _ => {
                    names.insert(id, Some(name));
                }
            }
        }
    }
    for (index, ids) in lists {
        let text_types: Vec<(u32, &String)> = ids
            .iter()
            .filter_map(|id| match names.get(id) {
                Some(Some(name)) => Some((*id, name)),
                _ => None,
            })
            .collect();
        let [(type_id, name)] = text_types.as_slice() else {
            continue;
        };
        let element = &mut products[index];
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: *type_id,
            },
        ));
        element.fields.push((
            TYPE_NAME_FIELD.into(),
            InstanceField::String((*name).clone()),
        ));
        element.fields.push((
            FAMILY_NAME_FIELD.into(),
            InstanceField::String("Model Text".into()),
        ));
        element.fields.push((
            FAMILY_NAME_SOURCE_FIELD.into(),
            InstanceField::String(TYPE_KIND_FAMILY_SOURCE.into()),
        ));
    }
}

/// Give a curtain panel that is a wall its wall type (RE-64).
///
/// Revit lets a curtain grid cell hold a basic wall instead of a panel. The
/// element keeps the panel category, but its reference list names a wall
/// type rather than a panel type, so [`attach_system_type_names`] finds no
/// type for it. Here the type is the one wall-type record the list names,
/// taken only when that type has compound layers
/// ([`crate::partition_compound_structure::scan_type_layers`]): a panel's
/// list also names its curtain wall, whose type is a wall type with none.
/// [`attach_system_family_names`] then names its family "Basic Wall".
fn attach_panel_wall_types(
    rf: &mut RevitFile,
    revit_version: u32,
    panels: &mut [&mut DecodedElement],
) {
    use crate::partition_type_records as ptr;
    if panels.is_empty()
        || !ptr::supports_revit_version(revit_version)
        || !crate::partition_compound_structure::COMPOUND_STRUCTURE_SUPPORTED_REVIT_VERSIONS
            .contains(&revit_version)
    {
        return;
    }
    let Some(header) = crate::partition_names::element_data_header(revit_version) else {
        return;
    };
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let wall_types = ptr::type_definition_ids(
        &ptr::scan_type_records(
            rf,
            revit_version,
            crate::partition_element_records::OST_WALLS,
            &declared,
        )
        .unwrap_or_default(),
    );
    let mut picks: Vec<(usize, u32)> = Vec::new();
    for (index, panel) in panels.iter().enumerate() {
        let Some((references, _)) = record_references(rf, panel) else {
            continue;
        };
        if let Some(type_id) = ptr::unique_type_reference(&references, &wall_types) {
            picks.push((index, type_id));
        }
    }
    if picks.is_empty() {
        return;
    }
    let candidates: BTreeSet<u32> = picks.iter().map(|(_, id)| *id).collect();
    let materials: BTreeSet<u32> =
        ptr::scan_type_records(rf, revit_version, ptr::OST_MATERIALS, &declared)
            .unwrap_or_default()
            .iter()
            .map(|record| record.element_id)
            .collect();
    let layered: BTreeSet<u32> = crate::partition_compound_structure::scan_type_layers(
        rf,
        revit_version,
        &candidates,
        &materials,
        &declared,
    )
    .unwrap_or_default()
    .into_iter()
    .filter(|(_, layers)| !layers.is_empty())
    .map(|(id, _)| id)
    .collect();
    picks.retain(|(_, id)| layered.contains(id));
    let names = type_data_names(rf, &header, &layered);
    attach_type_picks(panels, picks, &names);
    // RE-72: Revit exports such a panel as a curtain wall of its own.
    for panel in panels.iter_mut() {
        let wall_type = panel.fields.iter().any(|(name, value)| {
            matches!(value, InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD && layered.contains(id))
        });
        if wall_type {
            panel
                .fields
                .push((CURTAIN_PANEL_WALL_FIELD.into(), InstanceField::Bool(true)));
        }
    }
}

/// The family Revit names its empty curtain panel type after (#309). Revit's
/// IFC4 export leaves every panel of it out: all 24 on Snowdon Towers. The
/// name is Revit's English one, so a file saved in another language keeps
/// its empty panels. The panel type's unset material
/// ([`crate::partition_names::find_panel_type_materials`]) is only a
/// cross-check, since a panel set to "By Category" may store no material
/// either.
pub const EMPTY_PANEL_FAMILY_NAME: &str = "Empty System Panel";

/// Whether `element` is a curtain panel of the [`EMPTY_PANEL_FAMILY_NAME`]
/// family.
fn is_empty_curtain_panel(element: &DecodedElement) -> bool {
    element.class == "CurtainWallPanel"
        && element.fields.iter().any(|(name, value)| {
            matches!(value, InstanceField::String(family) if name == FAMILY_NAME_FIELD && family == EMPTY_PANEL_FAMILY_NAME)
        })
}

/// The curtain panels left out as empty (#309): how many, and the types of
/// theirs whose material is set, which would contradict the name.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct EmptyCurtainPanels {
    /// Placed panels of the [`EMPTY_PANEL_FAMILY_NAME`] family.
    pub count: usize,
    /// Their types whose material is set.
    pub types_with_material: BTreeSet<u32>,
}

/// Count the placed curtain panels of the [`EMPTY_PANEL_FAMILY_NAME`]
/// family, the ones recovery leaves out, through the same name-entry type
/// and family join ([`crate::partition_names::resolve_type`],
/// [`crate::partition_names::resolve_family`]).
pub fn scan_empty_curtain_panels(
    rf: &mut RevitFile,
    revit_version: u32,
) -> Result<EmptyCurtainPanels> {
    use crate::partition_element_records as per;
    let mut out = EmptyCurtainPanels::default();
    if !per::supports_revit_version(revit_version) {
        return Ok(out);
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(out),
    };
    let names = rf.memoised_element_names();
    let empty_families: BTreeSet<u32> = names
        .entries
        .iter()
        .filter(|(_, entry)| entry.name == EMPTY_PANEL_FAMILY_NAME)
        .map(|(id, _)| *id)
        .collect();
    if empty_families.is_empty() {
        return Ok(out);
    }
    let records =
        per::scan_category_records(rf, revit_version, per::OST_CURTAIN_WALL_PANELS, &declared)?;
    let options = rf.memoised_design_options();
    let phases = rf.memoised_phase_filter();
    let mut panels: BTreeSet<u32> = BTreeSet::new();
    let mut types: BTreeSet<u32> = BTreeSet::new();
    for record in records.iter().filter(|r| {
        r.is_exported_instance() && !options.excludes(r) && !phases.excludes(r) && r.has_volume()
    }) {
        let Some(type_id) = crate::partition_names::resolve_type(
            &names,
            &record.references,
            record.builtin_category,
            record.element_id,
        ) else {
            continue;
        };
        if crate::partition_names::resolve_family(&names, type_id)
            .is_some_and(|family| empty_families.contains(&family))
        {
            panels.insert(record.element_id);
            types.insert(type_id);
        }
    }
    out.count = panels.len();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        for (id, material) in
            crate::partition_names::find_panel_type_materials(inflated.bytes(), &types)
        {
            if material.is_some() {
                out.types_with_material.insert(id);
            }
        }
    }
    Ok(out)
}

/// Field marking a curtain panel that holds a basic wall (RE-64, RE-72).
pub const CURTAIN_PANEL_WALL_FIELD: &str = "m_curtain_panel_is_wall";

/// Class of a curtain panel that holds a basic wall. Revit's IFC4 export
/// writes each as an `IfcCurtainWall` with its own body, nested under the
/// curtain wall it is a panel of: all 18 on Snowdon Towers (RE-72).
pub const CURTAIN_PANEL_WALL_CLASS: &str = "CurtainPanelWall";

/// Field naming an element-record element's type, from the partition name
/// entries (RE-38).
pub const TYPE_NAME_FIELD: &str = "m_type_name";
/// Field naming the family of that type (RE-38).
pub const FAMILY_NAME_FIELD: &str = "m_family_name";
/// Field carrying the type's ElementId (RE-38).
pub const TYPE_ID_FIELD: &str = "m_type_id";

/// Give each element-record element its family and type names (RE-38).
///
/// The record's reference list is read again at its source offset. Its type
/// is the one reference with a name entry of the record's category, and
/// the family is the one such id in the type's own partition record
/// ([`crate::partition_names::resolve_type`] /
/// [`crate::partition_names::resolve_family`]). An element gets the fields
/// only when both joins are unique.
/// Field carrying the class tag an element record holds at `+0x4a` (RE-76).
pub const CLASS_TAG_FIELD: &str = "m_class_tag";
/// Field carrying the name of that class in the file's own schema (RE-76).
pub const REVIT_CLASS_FIELD: &str = "m_revit_class";

/// Name each record-backed element's class (RE-76): the tag its record
/// holds at `+0x4a` is the definition ordinal of a class in the file's own
/// schema, `SWall`, `ArcWall`, `Floor`, `FamilyInstance` and so on. An
/// element whose tag resolves to no class gets no name.
fn attach_revit_classes(classes: &crate::formats::SchemaClasses, elements: &mut [DecodedElement]) {
    for element in elements.iter_mut() {
        let tag = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Integer { value, .. } if name == CLASS_TAG_FIELD => {
                u16::try_from(*value).ok()
            }
            _ => None,
        });
        if let Some(class) = tag.and_then(|tag| classes.by_tag(tag)) {
            element.fields.push((
                REVIT_CLASS_FIELD.into(),
                InstanceField::String(class.name.clone()),
            ));
        }
    }
}

/// Fields holding the three axes of a curtain mullion or panel turned or
/// tilted off the model's axes (RE-106), from its transform: X, then Y,
/// then Z, each as model x, y and z.
pub const CURTAIN_AXES_FIELDS: [&str; 9] = [
    "m_curtain_axis_xx",
    "m_curtain_axis_xy",
    "m_curtain_axis_xz",
    "m_curtain_axis_yx",
    "m_curtain_axis_yy",
    "m_curtain_axis_yz",
    "m_curtain_axis_zx",
    "m_curtain_axis_zy",
    "m_curtain_axis_zz",
];

/// Classes whose turned or tilted instances carry [`CURTAIN_AXES_FIELDS`] (RE-106).
pub const CURTAIN_AXES_CLASSES: [&str; 2] = ["CurtainWallMullion", "CurtainWallPanel"];

/// Field holding the model axis (0 for X, 1 for Y, 2 for Z) a curtain
/// mullion on the model's axes runs along: the one its transform's Z axis
/// lies on (RE-226). A turned or tilted mullion carries
/// [`CURTAIN_AXES_FIELDS`] instead.
pub const CURTAIN_MULLION_ALONG_FIELD: &str = "m_curtain_mullion_along";
/// Set on a curtain mullion that stands on a straight curtain wall with an
/// unedited profile and whose type has its own rectangular section (RE-246):
/// Revit's export draws it as an extrusion of its box's section along its
/// length (RE-243).
pub const MULLION_PLAIN_HOST_FIELD: &str = "m_mullion_plain_host";

/// The three axes [`CURTAIN_AXES_FIELDS`] record, X, Y and Z.
pub fn curtain_axes_from_fields(fields: &[(String, InstanceField)]) -> Option<[[f64; 3]; 3]> {
    let values = CURTAIN_AXES_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    let mut axes = [[0.0; 3]; 3];
    for (index, value) in values.into_iter().enumerate() {
        axes[index / 3][index % 3] = value?;
    }
    Some(axes)
}

/// Give each curtain mullion and panel whose transform (RE-87) turns or
/// tilts it off the model's axes its three axes (RE-106). One on the
/// model's axes keeps its record box as its body's box; a mullion there gets
/// the model axis it runs along ([`CURTAIN_MULLION_ALONG_FIELD`]).
fn attach_curtain_axes(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    let ids: BTreeSet<u32> = products
        .iter()
        .filter(|element| CURTAIN_AXES_CLASSES.contains(&element.class.as_str()))
        .filter_map(|element| element.id)
        .collect();
    if ids.is_empty() {
        return;
    }
    let Ok(transforms) =
        crate::partition_instance_transforms::scan_instance_transforms(rf, revit_version, &ids)
    else {
        return;
    };
    for element in products.iter_mut() {
        let Some(transform) = element.id.and_then(|id| transforms.get(&id)) else {
            continue;
        };
        // On the model's axes: each axis has one component, the other two
        // within INSTANCE_TURN_MIN_RADIANS of zero.
        let on_axes = transform.axes.iter().all(|axis| {
            axis.iter()
                .filter(|v| v.abs() > INSTANCE_TURN_MIN_RADIANS)
                .count()
                == 1
        });
        if on_axes {
            if element.class == "CurtainWallMullion" {
                if let Some(along) = transform.axes[2]
                    .iter()
                    .position(|v| v.abs() > INSTANCE_TURN_MIN_RADIANS)
                {
                    element.fields.push((
                        CURTAIN_MULLION_ALONG_FIELD.into(),
                        InstanceField::Integer {
                            value: along as i64,
                            signed: false,
                            size: 4,
                        },
                    ));
                }
            }
            continue;
        }
        let values = transform.axes.iter().flatten().copied();
        for (name, value) in CURTAIN_AXES_FIELDS.iter().zip(values) {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
}

/// Fields holding a door's or window's facing: the plan direction of
/// its transform's Y axis (RE-87), which Revit's exporter sets against its
/// host wall to decide whether the door's symbol is flipped.
// Tracker: B72.
pub const OPENING_FACING_FIELDS: [&str; 2] = ["m_opening_facing_x", "m_opening_facing_y"];

/// Give each door and window whose transform (RE-87) is found its facing
/// ([`OPENING_FACING_FIELDS`]).
fn attach_opening_facings(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 2],
) {
    let ids: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter())
        .filter_map(|element| element.id)
        .collect();
    if ids.is_empty() {
        return;
    }
    let Ok(transforms) =
        crate::partition_instance_transforms::scan_instance_transforms(rf, revit_version, &ids)
    else {
        return;
    };
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        let Some(transform) = element.id.and_then(|id| transforms.get(&id)) else {
            continue;
        };
        let [x, y, _] = transform.axes[1];
        for (name, value) in OPENING_FACING_FIELDS.iter().zip([x, y]) {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
}

/// The plan facing [`OPENING_FACING_FIELDS`] record.
pub fn opening_facing_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 2]> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [x, y] = OPENING_FACING_FIELDS.map(float);
    Some([x?, y?])
}

/// Field carrying a family instance's original symbol (RE-167): the
/// FamilySymbol `ExporterIFCUtils.GetOriginalSymbol` returns, whose GlobalId
/// Revit's export gives the instance's type object while its `Tag` stays the
/// instance's symbol.
pub const ORIGINAL_SYMBOL_FIELD: &str = "m_original_symbol";
/// The [`ORIGINAL_SYMBOL_FIELD`] of an instance that has no original symbol
/// because it uses its own geometry (Revit's invalid ElementId, -1): its
/// `GElement` object holds `0xffffffff` there. Revit's export then gives its
/// type a sub-element GlobalId of the instance's own (RE-167): all 164 such
/// columns of Core Interior.
pub const INSTANCE_GEOMETRY: u32 = u32::MAX;
/// The schema classes of the elements an original symbol may be: a family's
/// symbol, and the mullion and panel types curtain parts take theirs from
/// (RE-166, RE-167: RE1 Architecture's mullions' original symbols are
/// `SysMullionFamSym` objects, its panels' `SysPanelFamSym`).
pub const ORIGINAL_SYMBOL_CLASSES: [&str; 3] =
    ["FamilySymbol", "SysMullionFamSym", "SysPanelFamSym"];
/// Bytes before the end of a family instance's `GElement` data object
/// (RE-153) where it holds its original symbol's ElementId (RE-167): at +300
/// of 320 bytes on RE1 Architecture, +330 of 350 and +392 of 412 on the MEP
/// models.
pub const ORIGINAL_SYMBOL_FROM_END: usize = 20;

/// Give each family instance ([`REVIT_CLASS_FIELD`] `FamilyInstance`, and
/// each curtain mullion and panel) its original symbol ([`ORIGINAL_SYMBOL_FIELD`], RE-167): the ElementId its
/// `GElement` data object holds [`ORIGINAL_SYMBOL_FROM_END`] bytes before its
/// end, when the copies in the highest-numbered partition stream holding one
/// give the same one and it is an [`ORIGINAL_SYMBOL_CLASSES`] element's, or
/// [`INSTANCE_GEOMETRY`]. On the RE1 models that is the element whose GlobalId Revit
/// gives the type of every one of 162 family instances; it is the symbol
/// itself for most, another FamilySymbol (often the instance's id plus one)
/// for many furniture, fittings, mullions and panels. Revit 2024 and later.
fn attach_original_symbols<const N: usize>(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; N],
) {
    if revit_version < 2024 {
        return;
    }
    // Curtain mullions and panels are family instances too, of classes of
    // their own.
    let is_instance = |element: &DecodedElement| {
        CURTAIN_AXES_CLASSES.contains(&element.class.as_str())
            || element.fields.iter().any(|(name, value)| {
                name == REVIT_CLASS_FIELD
                    && matches!(value, InstanceField::String(class) if class == "FamilyInstance")
            })
    };
    let instances: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter())
        .filter(|element| is_instance(element))
        .filter_map(|element| element.id)
        .collect();
    if instances.is_empty() {
        return;
    }
    let Ok(classes) = rf.memoised_schema_classes() else {
        return;
    };
    let tag_of = |name: &str| {
        classes
            .classes
            .iter()
            .find(|class| class.name == name)
            .map(|class| u32::from(class.tag))
    };
    let Some(element_tag) = tag_of("GElement") else {
        return;
    };
    let symbol_tags: BTreeSet<u32> = ORIGINAL_SYMBOL_CLASSES
        .iter()
        .filter_map(|name| tag_of(name))
        .collect();
    // Each instance's GElement values, by the number of the partition stream
    // holding the copy.
    let mut held: BTreeMap<u32, BTreeMap<u32, BTreeSet<u32>>> = BTreeMap::new();
    let mut symbols: BTreeSet<u32> = BTreeSet::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let partition = stream
            .rsplit('/')
            .next()
            .and_then(|number| number.parse::<u32>().ok())
            .unwrap_or(0);
        let buf = inflated.bytes();
        let Ok(objects) = rf.memoised_partition_data_objects(&stream) else {
            continue;
        };
        for &(p, object) in objects.iter() {
            let class = object.class & 0xffff;
            if symbol_tags.contains(&class) {
                symbols.insert(object.element_id);
            } else if class == element_tag && instances.contains(&object.element_id) {
                let Some(at) = object.end.checked_sub(ORIGINAL_SYMBOL_FROM_END) else {
                    continue;
                };
                if at < p {
                    continue;
                }
                let Some(value) = le_bytes::u32_at(buf, at) else {
                    continue;
                };
                held.entry(object.element_id)
                    .or_default()
                    .entry(partition)
                    .or_default()
                    .insert(value);
            }
        }
    }
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        // Copies in two partitions can disagree; the copy in the highest-
        // numbered one is the one Revit's export goes by (Core Interior's
        // doors: Partitions/59 over 46 and 51).
        let Some((_, values)) = element
            .id
            .and_then(|id| held.get(&id))
            .and_then(|by_partition| by_partition.iter().next_back())
        else {
            continue;
        };
        let mut values = values.iter();
        if let (Some(&original), None) = (values.next(), values.next()) {
            if symbols.contains(&original) || original == INSTANCE_GEOMETRY {
                element.fields.push((
                    ORIGINAL_SYMBOL_FIELD.into(),
                    InstanceField::ElementId {
                        tag: 0,
                        id: original,
                    },
                ));
            }
        }
    }
}

/// Fields holding the plan direction of a family instance turned off the
/// model's axes (RE-87), from its transform: its X axis where its Z axis is
/// the model's, or else its first flat axis where one axis is vertical, as
/// for a fixture hosted on a ceiling or a wall (RE-90).
pub const INSTANCE_X_AXIS_FIELDS: [&str; 2] = ["m_instance_x_axis_x", "m_instance_x_axis_y"];
/// Fields holding the plan origin of a turned family instance, model feet,
/// from its transform (RE-87): the point a window's opening in a tapered
/// wall is centred on (RE-89).
pub const INSTANCE_ORIGIN_FIELDS: [&str; 2] = ["m_instance_origin_x", "m_instance_origin_y"];

/// How far off the model's axes a family instance must be turned to be
/// drawn turned (RE-87): 1e-4 radians, 0.001 ft at 10 ft. RE1 Architecture
/// holds 34 instances off them by less than 0.001 degrees, round-off rather
/// than a turn; Snowdon Towers' 628 turned ones are all 0.01 degrees or more
/// off.
pub const INSTANCE_TURN_MIN_RADIANS: f64 = 1e-4;

/// Give each family instance ([`REVIT_CLASS_FIELD`] `FamilyInstance`) with
/// a vertical axis that is turned off the model's axes by at least
/// [`INSTANCE_TURN_MIN_RADIANS`] its plan direction
/// ([`crate::partition_instance_transforms::InstanceTransform::plan_axis`],
/// RE-87, RE-90). Any other keeps its record box as it is.
fn attach_instance_axes(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 3],
) {
    let is_instance = |element: &DecodedElement| {
        element.fields.iter().any(|(name, value)| {
            name == REVIT_CLASS_FIELD
                && matches!(value, InstanceField::String(class) if class == "FamilyInstance")
        })
    };
    let ids: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter())
        .filter(|element| is_instance(element))
        .filter_map(|element| element.id)
        .collect();
    if ids.is_empty() {
        return;
    }
    let Ok(transforms) =
        crate::partition_instance_transforms::scan_instance_transforms(rf, revit_version, &ids)
    else {
        return;
    };
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        let Some((transform, [x, y])) = element
            .id
            .and_then(|id| transforms.get(&id))
            .and_then(|transform| Some((transform, transform.plan_axis()?)))
        else {
            continue;
        };
        let turn = y.abs().atan2(x.abs());
        if turn.min(std::f64::consts::FRAC_PI_2 - turn) < INSTANCE_TURN_MIN_RADIANS {
            continue;
        }
        let [ox, oy, _] = transform.origin;
        for (name, value) in INSTANCE_X_AXIS_FIELDS
            .iter()
            .zip([x, y])
            .chain(INSTANCE_ORIGIN_FIELDS.iter().zip([ox, oy]))
        {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
}

/// Fields holding a window's or door's opening as Revit's export cuts it
/// (RE-93, RE-94): the plan point it is centred on (the element's origin),
/// its plan direction (the element's X axis), its base elevation (the
/// origin's, plus a window type's Default Sill Height), and its width and
/// height, feet: a window type's Width and Height, a door type's Rough
/// Width and Rough Height.
pub const FILLER_OPENING_FIELDS: [&str; 7] = [
    "m_filler_opening_x",
    "m_filler_opening_y",
    "m_filler_opening_axis_x",
    "m_filler_opening_axis_y",
    "m_filler_opening_base",
    "m_filler_opening_width",
    "m_filler_opening_height",
];

/// A door's or window's opening as [`FILLER_OPENING_FIELDS`] records it.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FillerOpening {
    /// Plan point the opening is centred on, model feet.
    pub centre: [f64; 2],
    /// Unit plan direction of its width.
    pub axis: [f64; 2],
    /// Elevation of its bottom, model feet.
    pub base_feet: f64,
    /// Feet.
    pub width_feet: f64,
    /// Feet.
    pub height_feet: f64,
}

/// Give each upright window whose type's Width, Height and Default Sill
/// Height are read its opening (RE-93,
/// [`crate::partition_type_parameters::type_window_openings`]).
fn attach_window_openings(rf: &mut RevitFile, revit_version: u32, windows: &mut [DecodedElement]) {
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let types: BTreeSet<u32> = windows.iter().filter_map(type_of).collect();
    let openings =
        crate::partition_type_parameters::type_window_openings(rf, revit_version, &types);
    if openings.is_empty() {
        return;
    }
    let ids: BTreeSet<u32> = windows
        .iter()
        .filter(|element| type_of(element).is_some_and(|id| openings.contains_key(&id)))
        .filter_map(|element| element.id)
        .collect();
    let Ok(transforms) =
        crate::partition_instance_transforms::scan_instance_transforms(rf, revit_version, &ids)
    else {
        return;
    };
    for element in windows.iter_mut() {
        let Some((opening, transform)) = type_of(element)
            .and_then(|id| openings.get(&id))
            .zip(element.id.and_then(|id| transforms.get(&id)))
        else {
            continue;
        };
        push_filler_opening(
            element,
            transform,
            0.0,
            opening.default_sill_feet,
            opening.width_feet,
            opening.height_feet,
        );
    }
}

/// How close a door's record box height must be to its type's Rough Height
/// for the door to take its rough opening (RE-94), feet.
pub const DOOR_ROUGH_HEIGHT_TOLERANCE_FEET: f64 = 1e-3;

/// Give each upright door whose record box is its type's Rough Height tall
/// its type's rough opening, from its origin up (RE-94,
/// [`crate::partition_type_parameters::type_door_openings`]). On Snowdon
/// Towers every door Revit cuts at its rough opening has a body that tall,
/// and every other door a body its frame's height instead.
/// Fields carrying a beam's I section from its type (RE-103): flange
/// width, overall depth, web thickness and flange thickness, feet.
pub const BEAM_I_SECTION_FIELDS: [&str; 4] = [
    "m_i_section_width",
    "m_i_section_depth",
    "m_i_section_web",
    "m_i_section_flange",
];

/// The I section [`BEAM_I_SECTION_FIELDS`] record.
pub fn beam_i_section_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<crate::partition_type_parameters::ISection> {
    let [width, depth, web, flange] = BEAM_I_SECTION_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some(crate::partition_type_parameters::ISection {
        width_feet: width?,
        depth_feet: depth?,
        web_feet: web?,
        flange_feet: flange?,
    })
}

/// Fields carrying a hollow-section column's outside width and height, wall
/// thickness and outside corner radius, feet
/// ([`crate::partition_type_parameters::type_hollow_sections`], W6).
pub const HOLLOW_SECTION_FIELDS: [&str; 4] = [
    "m_hollow_section_width",
    "m_hollow_section_height",
    "m_hollow_section_wall",
    "m_hollow_section_radius",
];

/// The hollow section [`HOLLOW_SECTION_FIELDS`] record.
pub fn hollow_section_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<crate::partition_type_parameters::HollowSection> {
    let [width, height, wall, radius] = HOLLOW_SECTION_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some(crate::partition_type_parameters::HollowSection {
        width_feet: width?,
        height_feet: height?,
        wall_feet: wall?,
        outer_radius_feet: radius?,
    })
}

/// Set on a column whose record holds no `CleanPairGStep`
/// ([`crate::native_column_joins::ColumnJoins::without_clean_steps`]):
/// Revit's export draws it as an extrusion, and gives it the extrusion's
/// depth as its `Qto_ColumnBaseQuantities.Length` (RE-247).
pub const COLUMN_UNJOINED_FIELD: &str = "m_column_unjoined";

/// Whether `class` is a column's, architectural or structural.
fn is_column_class(class: &str) -> bool {
    matches!(class, "Column" | "StructuralColumn")
}

/// Classes whose type's hollow section is read (W6).
pub const HOLLOW_SECTION_CLASSES: [&str; 2] = ["StructuralColumn", "Column"];

/// Give each column whose type is a hollow structural section
/// ([`crate::partition_type_parameters::type_hollow_sections`]) and holds no
/// I section that section (W6). The exporter draws it only where its record
/// box is the section's outside.
fn attach_hollow_sections(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 2],
) {
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let mut elements: Vec<&mut DecodedElement> = groups
        .into_iter()
        .flat_map(|group| group.iter_mut())
        .filter(|element| HOLLOW_SECTION_CLASSES.contains(&element.class.as_str()))
        .filter(|element| beam_i_section_from_fields(&element.fields).is_none())
        .collect();
    let types: BTreeSet<u32> = elements
        .iter()
        .filter_map(|element| type_of(element))
        .collect();
    if types.is_empty() {
        return;
    }
    let sections =
        crate::partition_type_parameters::type_hollow_sections(rf, revit_version, &types);
    for element in elements.iter_mut() {
        let Some(section) = type_of(element).and_then(|id| sections.get(&id)).copied() else {
            continue;
        };
        let values = [
            section.width_feet,
            section.height_feet,
            section.wall_feet,
            section.outer_radius_feet,
        ];
        for (name, value) in HOLLOW_SECTION_FIELDS.iter().zip(values) {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
}

/// Fields carrying the plan direction of an I-section structural column's
/// X axis, from its transform (RE-104): its flanges run along it.
pub const COLUMN_I_AXIS_FIELDS: [&str; 2] = ["m_i_section_axis_x", "m_i_section_axis_y"];

/// Classes whose type's I section is read (RE-103, RE-104).
const I_SECTION_CLASSES: [&str; 2] = ["StructuralFraming", "StructuralColumn"];

/// Give each structural-framing element and structural column whose type is
/// an I section ([`crate::partition_type_parameters::type_i_sections`]) that
/// section (RE-103, RE-104), and each such upright column its X axis in plan
/// from its transform. The exporter draws a beam's section only where its
/// body along its line holds it, and a column's only where the section
/// turned to that axis fills its record box.
fn attach_beam_sections(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let types: BTreeSet<u32> = products
        .iter()
        .filter(|element| I_SECTION_CLASSES.contains(&element.class.as_str()))
        .filter_map(type_of)
        .collect();
    let sections = crate::partition_type_parameters::type_i_sections(rf, revit_version, &types);
    let columns: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.class == "StructuralColumn")
        .filter(|element| type_of(element).is_some_and(|id| sections.contains_key(&id)))
        .filter_map(|element| element.id)
        .collect();
    let transforms = if columns.is_empty() {
        BTreeMap::new()
    } else {
        crate::partition_instance_transforms::scan_instance_transforms(rf, revit_version, &columns)
            .unwrap_or_default()
    };
    for element in products
        .iter_mut()
        .filter(|element| I_SECTION_CLASSES.contains(&element.class.as_str()))
    {
        let Some(section) = type_of(element).and_then(|id| sections.get(&id)).copied() else {
            continue;
        };
        let values = [
            section.width_feet,
            section.depth_feet,
            section.web_feet,
            section.flange_feet,
        ];
        for (name, value) in BEAM_I_SECTION_FIELDS.iter().zip(values) {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
        let axis = element
            .id
            .and_then(|id| transforms.get(&id))
            .filter(|transform| transform.is_upright())
            .and_then(|transform| transform.plan_axis());
        if let Some(axis) = axis {
            for (name, value) in COLUMN_I_AXIS_FIELDS.iter().zip(axis) {
                element
                    .fields
                    .push(((*name).into(), InstanceField::Float { value, size: 8 }));
            }
        }
    }
}

fn attach_door_openings(rf: &mut RevitFile, revit_version: u32, doors: &mut [DecodedElement]) {
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let box_height = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == "m_bboxHeight" => Some(*value),
            _ => None,
        })
    };
    let types: BTreeSet<u32> = doors.iter().filter_map(type_of).collect();
    let openings = crate::partition_type_parameters::type_door_openings(rf, revit_version, &types);
    // A door whose type draws no geometry (RE-84) is an opening alone, which
    // Revit does not cut at its rough size: RE1 Architecture's cased
    // opening is 1.0 m wide against a Rough Width of 1.1 m.
    let rough = |element: &DecodedElement| {
        if element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_WITHOUT_GEOMETRY_FIELD)
        {
            return None;
        }
        let opening = type_of(element).and_then(|id| openings.get(&id))?;
        let height = box_height(element)?;
        ((height - opening.rough_height_feet).abs() <= DOOR_ROUGH_HEIGHT_TOLERANCE_FEET)
            .then_some(*opening)
    };
    let ids: BTreeSet<u32> = doors
        .iter()
        .filter(|element| rough(element).is_some())
        .filter_map(|element| element.id)
        .collect();
    if ids.is_empty() {
        return;
    }
    let Ok(transforms) =
        crate::partition_instance_transforms::scan_instance_transforms(rf, revit_version, &ids)
    else {
        return;
    };
    for element in doors.iter_mut() {
        let Some((opening, transform)) =
            rough(element).zip(element.id.and_then(|id| transforms.get(&id)))
        else {
            continue;
        };
        push_filler_opening(
            element,
            transform,
            0.0,
            0.0,
            opening.rough_width_feet,
            opening.rough_height_feet,
        );
    }
}

/// Fields carrying a door's Width and Height from its type (RE-187), feet.
pub const DOOR_TYPE_SIZE_FIELDS: [&str; 2] = ["m_door_type_width", "m_door_type_height"];

/// Fields carrying the Width and Height of the symbol that draws a door or
/// window (its `InstanceInfo.m_symbolId`): its type's, or the symbol its own
/// parameters make, which revit-ifc's `WidthCalculator`, `HeightCalculator`
/// and `AreaCalculator` read for its base quantities (#1016), feet.
pub const DRAWN_SIZE_FIELDS: [&str; 2] = ["m_drawn_symbol_width", "m_drawn_symbol_height"];

/// The Width and Height [`DRAWN_SIZE_FIELDS`] record, feet.
pub fn drawn_size_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 2]> {
    let [width, height] = DRAWN_SIZE_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some([width?, height?])
}

/// The size [`DOOR_TYPE_SIZE_FIELDS`] record.
pub fn door_type_size_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<crate::partition_type_parameters::DoorTypeSize> {
    let [width, height] = DOOR_TYPE_SIZE_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some(crate::partition_type_parameters::DoorTypeSize {
        width_feet: width?,
        height_feet: height?,
    })
}

/// Give each door whose type's Width and Height are read
/// ([`crate::partition_type_parameters::type_door_sizes`]) that size (RE-187),
/// whether or not its opening is read. A door that is an opening alone
/// (RE-84) is written as that opening, and gets none.
fn attach_door_sizes(rf: &mut RevitFile, revit_version: u32, doors: &mut [DecodedElement]) {
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let types: BTreeSet<u32> = doors.iter().filter_map(type_of).collect();
    let sizes = crate::partition_type_parameters::type_door_sizes(rf, revit_version, &types);
    for element in doors.iter_mut() {
        if element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_WITHOUT_GEOMETRY_FIELD)
        {
            continue;
        }
        let Some(size) = type_of(element).and_then(|id| sizes.get(&id)).copied() else {
            continue;
        };
        for (name, value) in DOOR_TYPE_SIZE_FIELDS
            .iter()
            .zip([size.width_feet, size.height_feet])
        {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
}

/// Fields carrying the extent along X and along Z of the outline a door's
/// or window's symbol cuts in its host (RE-215), feet.
pub const CUT_LOOP_SIZE_FIELDS: [&str; 2] = ["m_cut_loop_width", "m_cut_loop_height"];

/// Fields carrying a door's or window's record box extent along its own X
/// axis and its height, where its symbol cuts no loop (#810), feet.
pub const INSTANCE_BOX_SIZE_FIELDS: [&str; 2] = ["m_instance_box_width", "m_instance_box_height"];

/// The width and height [`INSTANCE_BOX_SIZE_FIELDS`] record, feet.
pub fn instance_box_size_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 2]> {
    let [width, height] = INSTANCE_BOX_SIZE_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some([width?, height?])
}

/// Fields carrying the extents along X, Y and Z of the solid a door's or
/// window's symbol cuts where it cuts no loop (RE-225), feet.
pub const CUT_SOLID_SIZE_FIELDS: [&str; 3] = [
    "m_cut_solid_width",
    "m_cut_solid_depth",
    "m_cut_solid_height",
];

/// The extents [`CUT_SOLID_SIZE_FIELDS`] record, feet.
pub fn cut_solid_size_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 3]> {
    let [width, depth, height] = CUT_SOLID_SIZE_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some([width?, depth?, height?])
}

/// Releases a door's or window's cut loop is measured on (RE-215): 2024
/// (Core Interior) and 2025 (RE1 Architecture, the R2025 models).
pub const CUT_LOOP_REVIT_VERSIONS: &[u32] = &[2024, 2025];

/// The width and height [`CUT_LOOP_SIZE_FIELDS`] record, feet.
pub fn cut_loop_size_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 2]> {
    let [width, height] = CUT_LOOP_SIZE_FIELDS.map(|wanted| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    });
    Some([width?, height?])
}

/// Give each door and window the extents of the outline the symbol that
/// draws it cuts in its host
/// ([`crate::native_symbol_cuts::instance_cut_loops`]), which Revit's export
/// writes as its `OverallWidth` and `OverallHeight` (RE-215). A door that is
/// an opening alone (RE-84) is written as that opening, and gets none.
fn attach_cut_loop_sizes(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 2],
    walls: &BTreeSet<u32>,
    plain_walls: &BTreeSet<u32>,
) {
    if !CUT_LOOP_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let mut elements: Vec<&mut DecodedElement> = groups
        .into_iter()
        .flat_map(|group| group.iter_mut())
        .filter(|element| {
            !element
                .fields
                .iter()
                .any(|(name, _)| name == TYPE_WITHOUT_GEOMETRY_FIELD)
        })
        .collect();
    let ids: BTreeSet<u64> = elements
        .iter()
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    let Ok((loops, uncut, drawn_by, hosts, solids)) =
        crate::native_symbol_cuts::instance_cuts_and_symbols(rf, &ids)
    else {
        return;
    };
    // RE-245: a door or window set in a wall is set in the one its current
    // native record names, which the reference list's nearest wall
    // (`attach_host_candidates`) is not where the list names several.
    for element in elements.iter_mut() {
        let Some(native) = element
            .id
            .and_then(|id| hosts.get(&u64::from(id)))
            .and_then(|host| u32::try_from(*host).ok())
        else {
            continue;
        };
        let bound = element
            .fields
            .iter_mut()
            .find_map(|(name, value)| match value {
                InstanceField::ElementId { id, .. } if name == OPENING_HOST_FIELD => Some(id),
                _ => None,
            });
        if let Some(bound) = bound {
            if *bound != native && plain_walls.contains(&native) {
                *bound = native;
            }
        }
    }
    // RE-225: a door or window set in a wall whose symbol cuts a solid and
    // no loop carries the solid's extents, which Revit's export cuts its
    // opening to (the BIM4LCA office's windows).
    for element in elements.iter_mut() {
        let Some(id) = element.id.map(u64::from) else {
            continue;
        };
        let in_wall = hosts
            .get(&id)
            .and_then(|host| u32::try_from(*host).ok())
            .is_some_and(|host| walls.contains(&host));
        let Some(solid) = solids.get(&id).filter(|_| in_wall) else {
            continue;
        };
        for (name, value) in
            CUT_SOLID_SIZE_FIELDS
                .iter()
                .zip([solid.x_feet, solid.y_feet, solid.z_feet])
        {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
    for element in elements.iter_mut() {
        let Some(cut) = element.id.and_then(|id| loops.get(&u64::from(id))) else {
            continue;
        };
        for (name, value) in CUT_LOOP_SIZE_FIELDS
            .iter()
            .zip([cut.width_feet(), cut.height_feet()])
        {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
    // #1016: its base quantities' size, where the symbol that draws it and
    // its type have the same Width and Height. revit-ifc reads the
    // instance's own Width and Height parameters before its type's; where
    // its own parameters make a symbol of its own, which of them that
    // symbol's size stands for is not read (2 office doors take theirs from
    // it, 5 from their type), so those get none.
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let symbols: BTreeSet<u32> = drawn_by
        .values()
        .filter_map(|symbol| u32::try_from(*symbol).ok())
        .chain(elements.iter().filter_map(|element| type_of(element)))
        .collect();
    let sizes = crate::partition_type_parameters::type_door_sizes(rf, revit_version, &symbols);
    for element in elements.iter_mut() {
        let drawn = element
            .id
            .and_then(|id| drawn_by.get(&u64::from(id)))
            .and_then(|symbol| u32::try_from(*symbol).ok())
            .and_then(|symbol| sizes.get(&symbol));
        let typed = type_of(element).and_then(|id| sizes.get(&id));
        let Some(size) = drawn.zip(typed).and_then(|(drawn, typed)| {
            ((drawn.width_feet - typed.width_feet).abs() < 1e-9
                && (drawn.height_feet - typed.height_feet).abs() < 1e-9)
                .then_some(drawn)
        }) else {
            continue;
        };
        for (name, value) in DRAWN_SIZE_FIELDS
            .iter()
            .zip([size.width_feet, size.height_feet])
        {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
    // #227: where no opening is read yet, the opening is the loop, carried
    // by the instance's transform (RE-87); across the wall it keeps the
    // host's band, which the loop's plane and its mirror bound.
    let has_opening =
        |element: &DecodedElement| filler_opening_from_fields(&element.fields).is_some();
    let open: BTreeSet<u32> = elements
        .iter()
        .filter(|element| !has_opening(element))
        .filter_map(|element| element.id)
        .filter(|id| loops.contains_key(&u64::from(*id)))
        .collect();
    // Only where the symbol cuts no outline at all: one whose outline is not
    // read (an arc, several loops) keeps the sizes it had.
    let loopless: BTreeSet<u32> = elements
        .iter()
        .filter_map(|element| element.id)
        .filter(|id| uncut.contains(&u64::from(*id)))
        .collect();
    if open.is_empty() && loopless.is_empty() {
        return;
    }
    let Ok(transforms) = crate::partition_instance_transforms::scan_instance_transforms(
        rf,
        revit_version,
        &open.union(&loopless).copied().collect(),
    ) else {
        return;
    };
    // #810: a door or window whose symbol cuts no loop is sized by its
    // record box, as Revit's export sizes it: its width along its own X
    // axis and, in a wall or a curtain wall that its element record names,
    // its height through the box: all 269 windows of the BIM4LCA office, 71
    // of its doors and RE1's curtain-wall door. Any other's height is the
    // box's extent along its own Y axis, as revit-ifc's
    // `GetDoorWindowDimensionFromSymbol` measures the height of a family not
    // hosted by a wall (CLEANROOM.md source 5): the office's four roof
    // hatches and four doors of type 3267242. An instance turned off the
    // model's axes, whose box is not along its own, gets no size.
    let mut in_wall: BTreeSet<u32> = BTreeSet::new();
    for element in elements.iter() {
        let Some(id) = element.id.filter(|id| loopless.contains(id)) else {
            continue;
        };
        if let Some((references, _)) = record_references(rf, element) {
            if references
                .iter()
                .any(|r| u32::try_from(*r).is_ok_and(|r| walls.contains(&r)))
            {
                in_wall.insert(id);
            }
        }
    }
    for element in elements.iter_mut() {
        let Some(id) = element.id.filter(|id| loopless.contains(id)) else {
            continue;
        };
        let (Some(transform), Some(bbox)) = (transforms.get(&id), element_record_bbox(element))
        else {
            continue;
        };
        if !transform.is_upright() {
            continue;
        }
        let Some([ax, ay]) = transform.plan_axis() else {
            continue;
        };
        let (across_x, across_y) = (bbox[3] - bbox[0], bbox[4] - bbox[1]);
        let (width, along_y) = if (ax.abs() - 1.0).abs() <= INSTANCE_AXIS_TOLERANCE {
            (across_x, across_y)
        } else if (ay.abs() - 1.0).abs() <= INSTANCE_AXIS_TOLERANCE {
            (across_y, across_x)
        } else {
            continue;
        };
        let height = if in_wall.contains(&id) {
            bbox[5] - bbox[2]
        } else {
            along_y
        };
        if !(width > 0.0 && height > 0.0) {
            continue;
        }
        for (name, value) in INSTANCE_BOX_SIZE_FIELDS.iter().zip([width, height]) {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
    }
    for element in elements.iter_mut() {
        let Some(id) = element.id.filter(|id| open.contains(id)) else {
            continue;
        };
        let (Some(cut), Some(transform)) = (loops.get(&u64::from(id)), transforms.get(&id)) else {
            continue;
        };
        push_filler_opening(
            element,
            transform,
            (cut.min[0] + cut.max[0]) / 2.0,
            cut.min[2],
            cut.width_feet(),
            cut.height_feet(),
        );
    }
}

/// How closely an instance's plan X axis must lie along a model axis for
/// its record box to be along its own axes (#810).
pub const INSTANCE_AXIS_TOLERANCE: f64 = 1e-6;

/// Record on an upright door or window the opening centred `along` its X
/// axis from its origin, `base` above the origin ([`FILLER_OPENING_FIELDS`]).
fn push_filler_opening(
    element: &mut DecodedElement,
    transform: &crate::partition_instance_transforms::InstanceTransform,
    along: f64,
    base: f64,
    width: f64,
    height: f64,
) {
    if !transform.is_upright() {
        return;
    }
    let Some([ax, ay]) = transform.plan_axis() else {
        return;
    };
    let [ox, oy, oz] = transform.origin;
    let values = [
        ox + ax * along,
        oy + ay * along,
        ax,
        ay,
        oz + base,
        width,
        height,
    ];
    for (name, value) in FILLER_OPENING_FIELDS.iter().zip(values) {
        element
            .fields
            .push(((*name).into(), InstanceField::Float { value, size: 8 }));
    }
}

/// The opening [`FILLER_OPENING_FIELDS`] record.
pub fn filler_opening_from_fields(fields: &[(String, InstanceField)]) -> Option<FillerOpening> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [x, y, ax, ay, base, width, height] = FILLER_OPENING_FIELDS.map(float);
    Some(FillerOpening {
        centre: [x?, y?],
        axis: [ax?, ay?],
        base_feet: base?,
        width_feet: width?,
        height_feet: height?,
    })
}

/// The plan origin [`INSTANCE_ORIGIN_FIELDS`] record.
pub fn instance_origin_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 2]> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [x, y] = INSTANCE_ORIGIN_FIELDS.map(float);
    Some([x?, y?])
}

/// The plan X axis [`INSTANCE_X_AXIS_FIELDS`] record.
pub fn instance_x_axis_from_fields(fields: &[(String, InstanceField)]) -> Option<[f64; 2]> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [x, y] = INSTANCE_X_AXIS_FIELDS.map(float);
    Some([x?, y?])
}

/// Prefix of the fields carrying an element's type text parameters (RE-77):
/// `m_type_parameter:Type Mark` and so on.
pub const TYPE_PARAMETER_FIELD_PREFIX: &str = "m_type_parameter:";

/// Give each element the text parameters of its type ([`TYPE_ID_FIELD`],
/// RE-38 and #322), as Revit shows a type's parameters on its instances.
/// Field carrying, once per material, the name of a material an element's
/// type draws its geometry in (RE-82), in the order the type names them.
pub const TYPE_MATERIAL_FIELD: &str = "m_type_material";
/// Field set on an element whose type has a parameter value block with no
/// geometry-material map: a type that draws no geometry (RE-84). Revit's
/// export writes such a door or window as its opening alone.
pub const TYPE_WITHOUT_GEOMETRY_FIELD: &str = "m_type_without_geometry";

/// Give each element the materials its type's geometry uses (RE-82).
fn attach_type_materials(materials: &BTreeMap<u32, Vec<String>>, elements: &mut [DecodedElement]) {
    for element in elements.iter_mut() {
        let type_id = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        });
        let Some(names) = type_id.and_then(|id| materials.get(&id)) else {
            continue;
        };
        if names.is_empty() {
            element.fields.push((
                TYPE_WITHOUT_GEOMETRY_FIELD.into(),
                InstanceField::Bool(true),
            ));
        }
        for name in names {
            element.fields.push((
                TYPE_MATERIAL_FIELD.into(),
                InstanceField::String(name.clone()),
            ));
        }
    }
}

/// Replace each family type's scanned materials with those its native
/// `m_geomTag2MaterialId` names ([`crate::native_type_materials`], RE-203)
/// where that names any and every one is named, for the types of columns,
/// doors, windows and products. The scanned order is kept where the two
/// name the same set. Returns the replaced types that also map geometry to
/// no material that their family shows ([`crate::native_family_forms`]),
/// whose instances take their own material parameters' or
/// `<Unnamed>` for it ([`attach_partly_unset_materials`]). Left as scanned
/// where the native record path or the material names are not read.
fn refine_type_materials(
    rf: &mut RevitFile,
    revit_version: u32,
    type_materials: &mut BTreeMap<u32, Vec<String>>,
    out: &PartitionSchemaMvp,
) -> BTreeSet<u32> {
    let mut partly_unset = BTreeSet::new();
    if type_materials.is_empty() {
        return partly_unset;
    }
    let types: BTreeSet<u64> = out
        .columns
        .iter()
        .chain(&out.doors)
        .chain(&out.windows)
        .chain(&out.products)
        .filter_map(|element| {
            element.fields.iter().find_map(|(name, value)| match value {
                InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => {
                    Some(u64::from(*id))
                }
                _ => None,
            })
        })
        .collect();
    let Ok(records) = crate::elem_table::parse_records(rf) else {
        return partly_unset;
    };
    let declared = crate::elem_table::declared_ids(&records);
    let Ok(names) = crate::partition_materials::scan_material_names(rf, revit_version, &declared)
    else {
        return partly_unset;
    };
    let materials: BTreeSet<u32> = names.keys().copied().collect();
    let Ok(found) = crate::native_type_materials::geometry_materials(rf, &types, &materials) else {
        return partly_unset;
    };
    // A family whose geometry with no material is all hidden or void has
    // no `<Unnamed>` in Revit's export (RE-204), and a material only its
    // hidden forms have is not exported (RE-205).
    let families: BTreeSet<u64> = found.values().filter_map(|found| found.family).collect();
    let forms = crate::native_family_forms::family_forms(rf, &families).unwrap_or_default();
    for (type_id, found) in found {
        let Ok(type_id) = u32::try_from(type_id) else {
            continue;
        };
        let family = found.family.and_then(|family| forms.get(&family));
        let ids: Vec<u32> = found
            .materials
            .iter()
            .copied()
            .filter(|id| !family.is_some_and(|family| family.hidden_only.contains(id)))
            .collect();
        let shown = family.and_then(|family| family.shows_unset).unwrap_or(true);
        if ids.is_empty() {
            // Only hidden forms had materials: what is shown is the
            // geometry with none (RE-206).
            if found.unset && shown {
                type_materials.insert(
                    type_id,
                    vec![crate::partition_type_materials::UNNAMED_MATERIAL.to_string()],
                );
            }
            continue;
        }
        let resolved: Vec<String> = ids.iter().filter_map(|id| names.get(id).cloned()).collect();
        if resolved.len() != ids.len() {
            continue;
        }
        let scanned = type_materials.entry(type_id).or_default();
        let same: BTreeSet<&String> = scanned.iter().collect();
        if found.unset && shown {
            partly_unset.insert(type_id);
        }
        if found.unset || same != resolved.iter().collect::<BTreeSet<_>>() {
            *scanned = resolved;
        }
    }
    partly_unset
}

/// Give each instance of a type in `partly_unset`, which maps some geometry
/// to no material, the materials its own material parameters name
/// (`instance_materials`, RE-200), or else `<Unnamed>` (RE-149), alongside
/// its type's (RE-203): Revit's export does, on Snowdon Towers' 31 "Sink
/// Vanity-Round", 21 refrigerators, 21 washer-dryers and RE1
/// Architecture's microwave.
fn attach_partly_unset_materials(
    partly_unset: &BTreeSet<u32>,
    instance_materials: &BTreeMap<u32, Vec<String>>,
    elements: &mut [DecodedElement],
) {
    for element in elements.iter_mut() {
        let type_id = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        });
        if !type_id.is_some_and(|id| partly_unset.contains(&id)) {
            continue;
        }
        let names = element
            .id
            .and_then(|id| instance_materials.get(&id))
            .cloned()
            .unwrap_or_else(|| vec![crate::partition_type_materials::UNNAMED_MATERIAL.into()]);
        for name in names {
            let present = element.fields.iter().any(|(field, value)| {
                field == TYPE_MATERIAL_FIELD
                    && matches!(value, InstanceField::String(s) if *s == name)
            });
            if !present {
                element
                    .fields
                    .push((TYPE_MATERIAL_FIELD.into(), InstanceField::String(name)));
            }
        }
    }
}

/// The material names the instance parameters of each column and product
/// whose type is one of `unset_types` give it, by the instance's ElementId
/// ([`crate::native_instance_materials`], RE-200). Empty where the native
/// record path or the material names are not read.
fn instance_parameter_material_names(
    rf: &mut RevitFile,
    revit_version: u32,
    unset_types: &BTreeSet<u32>,
    out: &PartitionSchemaMvp,
) -> BTreeMap<u32, Vec<String>> {
    let instances: BTreeSet<u64> = out
        .columns
        .iter()
        .chain(&out.products)
        .filter(|element| {
            element.fields.iter().any(|(name, value)| {
                matches!(value, InstanceField::ElementId { id, .. }
                    if name == TYPE_ID_FIELD && unset_types.contains(id))
            })
        })
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    if instances.is_empty() {
        return BTreeMap::new();
    }
    let Ok(records) = crate::elem_table::parse_records(rf) else {
        return BTreeMap::new();
    };
    let declared = crate::elem_table::declared_ids(&records);
    let Ok(names) = crate::partition_materials::scan_material_names(rf, revit_version, &declared)
    else {
        return BTreeMap::new();
    };
    let materials: BTreeSet<u32> = names.keys().copied().collect();
    let Ok(found) =
        crate::native_instance_materials::instance_parameter_materials(rf, &instances, &materials)
    else {
        return BTreeMap::new();
    };
    found
        .into_iter()
        .filter_map(|(instance, ids)| {
            let instance = u32::try_from(instance).ok()?;
            let resolved: Vec<String> =
                ids.iter().filter_map(|id| names.get(id).cloned()).collect();
            // Every value named, or none taken: a set missing a material
            // would be a wrong set, where `<Unnamed>` is Revit's fallback.
            (resolved.len() == ids.len()).then_some((instance, resolved))
        })
        .collect()
}

/// Give each element whose type draws its geometry with no material of its
/// own, and that has no type material yet, the materials its own material
/// parameters name (`instance_materials`, RE-200), or else the material
/// Revit's export writes for such geometry,
/// [`crate::partition_type_materials::UNNAMED_MATERIAL`] (RE-149). Doors,
/// windows, walls and slabs are left alone: a door or window type without a
/// material map is written as its opening (RE-84).
fn attach_unnamed_materials(
    unset_types: &BTreeSet<u32>,
    instance_materials: &BTreeMap<u32, Vec<String>>,
    elements: &mut [DecodedElement],
) {
    for element in elements.iter_mut() {
        if element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_MATERIAL_FIELD)
        {
            continue;
        }
        let type_id = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        });
        if type_id.is_some_and(|id| unset_types.contains(&id)) {
            // The type draws geometry, so it is not a type without
            // geometry (RE-84), which `attach_type_materials` took its empty
            // map to mean; a hosted instance would otherwise be written as
            // its opening alone (reported by Cursor Bugbot on #580).
            element
                .fields
                .retain(|(name, _)| name != TYPE_WITHOUT_GEOMETRY_FIELD);
            let names = element
                .id
                .and_then(|id| instance_materials.get(&id))
                .cloned()
                .unwrap_or_else(|| vec![crate::partition_type_materials::UNNAMED_MATERIAL.into()]);
            for name in names {
                element
                    .fields
                    .push((TYPE_MATERIAL_FIELD.into(), InstanceField::String(name)));
            }
        }
    }
}

/// Give each curtain wall mullion and panel ([`CURTAIN_AXES_CLASSES`]) that
/// has no type material yet the material its type holds
/// ([`crate::partition_curtain_materials`], RE-166), by name, as Revit's
/// export associates it.
fn attach_curtain_materials(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_curtain_materials as pcm;
    let is_part = |element: &DecodedElement| CURTAIN_AXES_CLASSES.contains(&element.class.as_str());
    if !pcm::supports_revit_version(revit_version) || !products.iter().any(is_part) {
        return;
    }
    let Ok(records) = crate::elem_table::parse_records(rf) else {
        return;
    };
    let declared = crate::elem_table::declared_ids(&records);
    let Ok(names) = crate::partition_materials::scan_material_names(rf, revit_version, &declared)
    else {
        return;
    };
    let materials: BTreeSet<u32> = names.keys().copied().collect();
    let Ok(type_materials) = pcm::scan_curtain_type_materials(rf, revit_version, &materials) else {
        return;
    };
    for element in products.iter_mut().filter(|element| is_part(element)) {
        // A part whose type's map holds only unset values has `<Unnamed>`
        // (#580); its type's own material replaces it (RE-201).
        if element.fields.iter().any(|(name, value)| {
            name == TYPE_MATERIAL_FIELD
                && !matches!(value, InstanceField::String(s) if s == crate::partition_type_materials::UNNAMED_MATERIAL)
        }) {
            continue;
        }
        let type_id = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        });
        let Some(name) = type_id
            .and_then(|id| type_materials.get(&id))
            .and_then(|material| names.get(material))
        else {
            continue;
        };
        element
            .fields
            .retain(|(field, _)| field != TYPE_MATERIAL_FIELD);
        element.fields.push((
            TYPE_MATERIAL_FIELD.into(),
            InstanceField::String(name.clone()),
        ));
    }
}

/// Whether `element`'s only type material is
/// [`crate::partition_type_materials::UNNAMED_MATERIAL`].
fn has_unnamed_material_only(element: &DecodedElement) -> bool {
    use crate::partition_type_materials::UNNAMED_MATERIAL;
    let mut materials = element
        .fields
        .iter()
        .filter(|(name, _)| name == TYPE_MATERIAL_FIELD)
        .peekable();
    materials.peek().is_some()
        && materials
            .all(|(_, value)| matches!(value, InstanceField::String(s) if s == UNNAMED_MATERIAL))
}

/// Replace `element`'s type materials with `names`.
fn set_type_materials(element: &mut DecodedElement, names: Vec<String>) {
    element
        .fields
        .retain(|(name, _)| name != TYPE_MATERIAL_FIELD);
    for name in names {
        element
            .fields
            .push((TYPE_MATERIAL_FIELD.into(), InstanceField::String(name)));
    }
}

/// A column with only `<Unnamed>` takes a layer of the wall it was first
/// joined to (RE-202, #355; [`crate::native_column_joins`]): the first join
/// among the walls that overlap it ([`COLUMN_JOINED_WALL_FIELD`]) where any
/// do, so that a foundation wall below it is passed over (RE-205). Its
/// exterior layer where the column stands out past both of the wall's faces
/// or its box centre is on the wall's exterior side, the interior layer
/// otherwise. Revit's export gives all 108 of Snowdon Towers' off-centre
/// columns that layer. The rule for a column past both faces rests on one
/// column whose wall's two faces differ (1366814): the other 50 such columns
/// are in walls with the same material on both faces. A column whose wall is
/// not straight, or whose layer on that side has no named material, is left
/// alone.
///
/// [`COLUMN_JOINED_WALL_FIELD`]: crate::element_record_column_cuts::COLUMN_JOINED_WALL_FIELD
fn attach_first_join_materials(
    rf: &mut RevitFile,
    joined: Option<&BTreeMap<u64, Vec<u64>>>,
    columns: &mut [DecodedElement],
    walls: &[DecodedElement],
) {
    use crate::element_record_column_cuts::COLUMN_JOINED_WALL_FIELD;
    use crate::element_record_wall_joins::WALL_THICKNESS_FIELD;
    use crate::native_column_joins as joins;
    let float = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let Some(joined) = joined else {
        return;
    };
    let first: BTreeMap<u64, u64> = columns
        .iter()
        .filter(|column| has_unnamed_material_only(column))
        .filter_map(|column| {
            let id = u64::from(column.id?);
            let order = joined.get(&id)?;
            let overlapping: BTreeSet<u64> = column
                .fields
                .iter()
                .filter_map(|(name, value)| match value {
                    InstanceField::ElementId { id, .. } if name == COLUMN_JOINED_WALL_FIELD => {
                        Some(u64::from(*id))
                    }
                    _ => None,
                })
                .collect();
            let wall = order
                .iter()
                .find(|wall| overlapping.contains(wall))
                .or_else(|| order.first())?;
            Some((id, *wall))
        })
        .collect();
    // Each wall's layers, thickness and centreline point (RE-54).
    struct WallData {
        layers: Vec<Option<String>>,
        thickness: Option<f64>,
        axis: Option<[f64; 2]>,
    }
    let wall_data: BTreeMap<u64, WallData> = walls
        .iter()
        .filter_map(|wall| {
            let id = u64::from(wall.id?);
            if !first.values().any(|joined| *joined == id) {
                return None;
            }
            let bands = wall
                .fields
                .iter()
                .find_map(|(name, value)| (name == WALL_LAYERS_FIELD).then_some(value))
                .and_then(layer_bands_from_field)?;
            let names: Vec<Option<String>> = bands.into_iter().map(|band| band.name).collect();
            let [ax, ay] = WALL_AXIS_START_FIELDS.map(|name| float(wall, name));
            let axis = ax.zip(ay).map(|(x, y)| [x, y]);
            (!names.is_empty()).then_some((
                id,
                WallData {
                    layers: names,
                    thickness: float(wall, WALL_THICKNESS_FIELD),
                    axis,
                },
            ))
        })
        .collect();
    let Ok(sides) = joins::wall_sides(rf, &wall_data.keys().copied().collect()) else {
        return;
    };
    for column in columns.iter_mut() {
        let Some(id) = column.id.map(u64::from) else {
            continue;
        };
        let Some(wall) = first.get(&id) else {
            continue;
        };
        let (Some(x), Some(y)) = (float(column, "m_locationX"), float(column, "m_locationY"))
        else {
            continue;
        };
        let (Some(data), Some(side)) = (wall_data.get(wall), sides.get(wall)) else {
            continue;
        };
        let (layers, thickness, axis) = (&data.layers, data.thickness, data.axis);
        // How far the column's box reaches each way across the wall.
        let reach = match (float(column, "m_bboxWidth"), float(column, "m_bboxDepth")) {
            (Some(width), Some(depth)) => {
                (side.exterior[0].abs() * width + side.exterior[1].abs() * depth) / 2.0
            }
            _ => 0.0,
        };
        let centre = side.offset([x, y], axis.unwrap_or(side.origin));
        let past_both = thickness.is_some_and(|thickness| {
            axis.is_some() && centre - reach < -thickness / 2.0 && centre + reach > thickness / 2.0
        });
        let layer = if past_both || side.is_exterior([x, y]) {
            layers.first()
        } else {
            layers.last()
        };
        if let Some(Some(layer)) = layer {
            set_type_materials(column, vec![layer.clone()]);
        }
    }
}

/// An instance of rendered content (a family whose
/// `Family.m_eRenderModelType` is 4: RPC people and plants, Snowdon Towers'
/// Honey-Locust trees) has the one material `<Unnamed>`, as Revit's export
/// writes it (RE-202, #355; [`crate::native_rendered_content`]).
fn attach_rendered_content_materials(rf: &mut RevitFile, products: &mut [DecodedElement]) {
    use crate::partition_type_materials::UNNAMED_MATERIAL;
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(u64::from(*id)),
            _ => None,
        })
    };
    let types: BTreeSet<u64> = products
        .iter()
        .filter(|element| {
            element
                .fields
                .iter()
                .any(|(name, _)| name == TYPE_MATERIAL_FIELD)
        })
        .filter_map(type_of)
        .collect();
    let Ok(rendered) = crate::native_rendered_content::rendered_content_types(rf, &types) else {
        return;
    };
    for element in products.iter_mut() {
        if type_of(element).is_some_and(|id| rendered.contains(&id))
            && element
                .fields
                .iter()
                .any(|(name, _)| name == TYPE_MATERIAL_FIELD)
        {
            set_type_materials(element, vec![UNNAMED_MATERIAL.to_string()]);
        }
    }
}

/// A column whose type draws with no material and that walls are joined to
/// takes the joined walls' material (#355): Revit's export gives the 149
/// columns of `2024_Core_Interior.rvt` that walls are joined to "Default
/// Wall", the material of those walls, and `<Unnamed>` to the 107 no wall
/// joins. Only when every joined wall's layers name the same one set of
/// materials; otherwise the column keeps `<Unnamed>`.
fn attach_joined_wall_materials(columns: &mut [DecodedElement], walls: &[DecodedElement]) {
    use crate::element_record_column_cuts::COLUMN_JOINED_WALL_FIELD;
    use crate::partition_type_materials::UNNAMED_MATERIAL;

    let wall_materials: BTreeMap<u32, BTreeSet<String>> = walls
        .iter()
        .filter_map(|wall| {
            let layers = element_layers_from_fields(&wall.fields)?;
            let names: Option<BTreeSet<String>> =
                layers.layers.iter().map(|band| band.name.clone()).collect();
            Some((wall.id?, names.filter(|n| !n.is_empty())?))
        })
        .collect();
    for column in columns.iter_mut() {
        let unnamed_only = column
            .fields
            .iter()
            .filter(|(name, _)| name == TYPE_MATERIAL_FIELD)
            .all(|(_, value)| matches!(value, InstanceField::String(s) if s == UNNAMED_MATERIAL));
        let has_material = column
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_MATERIAL_FIELD);
        if !(unnamed_only && has_material) {
            continue;
        }
        let joined: Vec<u32> = column
            .fields
            .iter()
            .filter_map(|(name, value)| match value {
                InstanceField::ElementId { id, .. } if name == COLUMN_JOINED_WALL_FIELD => {
                    Some(*id)
                }
                _ => None,
            })
            .collect();
        let sets: Vec<&BTreeSet<String>> = joined
            .iter()
            .filter_map(|id| wall_materials.get(id))
            .collect();
        let Some(first) = sets.first() else {
            continue;
        };
        if sets.len() != joined.len() || sets.iter().any(|set| set != first) {
            continue;
        }
        let names = (*first).clone();
        column
            .fields
            .retain(|(name, _)| name != TYPE_MATERIAL_FIELD);
        for name in names {
            column
                .fields
                .push((TYPE_MATERIAL_FIELD.into(), InstanceField::String(name)));
        }
    }
}

fn attach_type_text_parameters(
    parameters: &BTreeMap<u32, BTreeMap<&'static str, String>>,
    elements: &mut [DecodedElement],
) {
    for element in elements.iter_mut() {
        let type_id = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        });
        let Some(values) = type_id.and_then(|id| parameters.get(&id)) else {
            continue;
        };
        for (name, value) in values {
            element.fields.push((
                format!("{TYPE_PARAMETER_FIELD_PREFIX}{name}"),
                InstanceField::String(value.clone()),
            ));
        }
    }
}

/// Give each pipe without a type the one id in its record's reference
/// list that carries a pipe or duct type name
/// ([`crate::partition_names::find_mep_curve_type_names`], RE-130). Pipe
/// and duct types have no name entry, so
/// [`crate::partition_names::resolve_type`] finds none for them. Ducts are
/// left alone: their system family follows their type's shape, which is not
/// read.
fn attach_pipe_type_names(rf: &mut RevitFile, elements: &mut [DecodedElement]) {
    let has_type = |element: &DecodedElement| {
        element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_NAME_FIELD)
    };
    if !elements
        .iter()
        .any(|element| element.class == "Pipe" && !has_type(element))
    {
        return;
    }
    let mut pending: Vec<(usize, BTreeSet<u32>)> = Vec::new();
    for (index, element) in elements.iter().enumerate() {
        if element.class != "Pipe" || has_type(element) {
            continue;
        }
        let (Some(own), Some((references, _))) = (element.id, record_references(rf, element))
        else {
            continue;
        };
        // The list's first slot is a constant 3, not a reference (#228); the
        // name pattern can match after it by chance.
        let references: BTreeSet<u32> = references
            .iter()
            .skip(1)
            .filter_map(|&id| u32::try_from(id).ok())
            .filter(|&id| id != own)
            .collect();
        pending.push((index, references));
    }
    if pending.is_empty() {
        return;
    }
    let wanted: BTreeSet<u32> = pending
        .iter()
        .flat_map(|(_, ids)| ids.iter().copied())
        .collect();
    let mut names: BTreeMap<u32, Option<String>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        for (id, name) in
            crate::partition_names::find_mep_curve_type_names(inflated.bytes(), &wanted)
        {
            match names.get_mut(&id) {
                None => {
                    names.insert(id, Some(name));
                }
                Some(held) => {
                    if held.as_deref() != Some(name.as_str()) {
                        *held = None;
                    }
                }
            }
        }
    }
    for (index, references) in pending {
        let mut typed = references
            .iter()
            .filter_map(|id| Some((*id, names.get(id)?.clone()?)));
        let (Some((type_id, type_name)), None) = (typed.next(), typed.next()) else {
            continue;
        };
        let element = &mut elements[index];
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: type_id,
            },
        ));
        element
            .fields
            .push((TYPE_NAME_FIELD.into(), InstanceField::String(type_name)));
    }
}

fn attach_family_and_type_names(rf: &mut RevitFile, elements: &mut [DecodedElement]) {
    let names = rf.memoised_element_names();
    if names.entries.is_empty() {
        return;
    }
    for element in elements.iter_mut() {
        let Some(own) = element.id else {
            continue;
        };
        let Some((references, category)) = record_references(rf, element) else {
            continue;
        };
        let Some(type_id) =
            crate::partition_names::resolve_type(&names, &references, category, own)
        else {
            continue;
        };
        let Some(family_id) = crate::partition_names::resolve_family(&names, type_id) else {
            continue;
        };
        let (Some(type_entry), Some(family_entry)) =
            (names.entries.get(&type_id), names.entries.get(&family_id))
        else {
            continue;
        };
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: type_id,
            },
        ));
        element.fields.push((
            TYPE_NAME_FIELD.into(),
            InstanceField::String(type_entry.name.clone()),
        ));
        element.fields.push((
            FAMILY_NAME_FIELD.into(),
            InstanceField::String(family_entry.name.clone()),
        ));
    }
}

/// Field naming the ElementId of the stair a run, landing or stringer
/// belongs to (#323).
pub const AGGREGATE_WHOLE_FIELD: &str = "m_aggregate_whole";

/// Classes that aggregate parts instead of carrying a body of their own.
pub const AGGREGATE_WHOLE_CLASSES: &[&str] = &["Stair", CURTAIN_WALL_CLASS];

/// Class of a wall that is a curtain wall (RE-46): one a curtain-wall
/// mullion names in its reference list.
pub const CURTAIN_WALL_CLASS: &str = "CurtainWall";

/// Classes that are parts of a curtain wall when their reference list names
/// exactly one (RE-46).
///
/// Doors are not among them: of the doors whose lists name a Snowdon
/// curtain wall, Revit's export aggregates only the panel doors, and nothing
/// read so far tells those from doors inserted in the wall.
pub const CURTAIN_WALL_PART_CLASSES: &[&str] = &["CurtainWallPanel", "CurtainWallMullion"];

/// Classes that are parts of a stair when their reference list names one.
///
/// Railings are not among them: Revit's export aggregates 65 of the 70
/// Snowdon railings whose lists name a stair, and nothing read so far tells
/// the other five apart, so railings stay standalone elements.
pub const STAIR_PART_CLASSES: &[&str] = &["StairsRun", "StairsLanding", "StairsStringer"];

/// The reference list and category of an element-record element, read
/// again at its source offset.
fn record_references(rf: &mut RevitFile, element: &DecodedElement) -> Option<(Vec<u64>, i64)> {
    let mut stream = None;
    let mut offset = None;
    let mut category = None;
    for (name, value) in &element.fields {
        match (name.as_str(), value) {
            ("m_source_stream", InstanceField::String(v)) => stream = Some(v.clone()),
            ("m_source_offset", InstanceField::Integer { value, .. }) => {
                offset = usize::try_from(*value).ok();
            }
            ("m_builtinCategory", InstanceField::Integer { value, .. }) => {
                category = Some(*value);
            }
            _ => {}
        }
    }
    let inflated = rf.inflated_partition(&stream?).ok()?;
    let references = offset?
        .checked_add(crate::partition_element_records::REFERENCE_LIST_OFFSET)
        .and_then(|at| {
            crate::partition_element_records::decode_reference_list(inflated.bytes(), at)
        })
        .unwrap_or_default();
    Some((references, category?))
}

/// Give each stair part the ElementId of the one exported stair its
/// reference list names (#323). On Snowdon Towers every run, landing and
/// stringer Revit aggregates under a stair, but one stringer, names that
/// stair in its reference list. A part that names none, or more than one,
/// stays a standalone element here; [`attach_stair_names`] joins one that
/// names several when exactly one of them has a type listing the part's
/// type (RE-65).
fn attach_aggregate_wholes(rf: &mut RevitFile, products: &mut [DecodedElement]) {
    let stairs: BTreeSet<u32> = products
        .iter()
        .filter(|element| AGGREGATE_WHOLE_CLASSES.contains(&element.class.as_str()))
        .filter_map(|element| element.id)
        .collect();
    if stairs.is_empty() {
        return;
    }
    for element in products.iter_mut() {
        if !STAIR_PART_CLASSES.contains(&element.class.as_str()) {
            continue;
        }
        let Some((references, _)) = record_references(rf, element) else {
            continue;
        };
        let named: BTreeSet<u32> = references
            .iter()
            .filter_map(|&id| u32::try_from(id).ok())
            .filter(|id| stairs.contains(id) && Some(*id) != element.id)
            .collect();
        if named.len() == 1 {
            let whole = *named.iter().next().expect("one stair");
            element.fields.push((
                AGGREGATE_WHOLE_FIELD.into(),
                InstanceField::ElementId { tag: 0, id: whole },
            ));
        }
    }
}

/// Field holding an element's IFC `Name` where Revit's export does not name
/// it `Family:Type:ElementId`: a stair and its parts (RE-65).
pub const ELEMENT_NAME_FIELD: &str = "m_element_name";

/// Value of [`FAMILY_NAME_SOURCE_FIELD`] for a stair component's family,
/// read from its type's construction flag (RE-65).
pub const TYPE_KIND_FAMILY_SOURCE: &str = "system_family_by_type_kind";

/// The word Revit's export puts before a stair part's number (RE-65).
fn stair_part_word(class: &str) -> Option<&'static str> {
    match class {
        "StairsRun" => Some("Run"),
        "StairsLanding" => Some("Landing"),
        "StairsStringer" => Some("Stringer"),
        _ => None,
    }
}

/// Name stairs and their parts as Revit's export names them (RE-65).
///
/// - A stair's system family is its type's construction (Assembled or
///   Cast-In-Place Stair), and Revit names the stair `Family:Stair:ElementId`.
/// - A run's family is Monolithic or Non-Monolithic Run, by its run type's
///   monolithic flag (RE-52); a landing's is Non-Monolithic Landing; a
///   stringer's or carriage's is Stringer or Carriage
///   ([`crate::partition_stairs::component_type_at`]). With the type's name
///   these give the part's `ObjectType`.
/// - A part is named after its stair, `<stair> Run 2`, numbered in ElementId
///   order among every record of its category that names the stair,
///   exported or not.
///
/// A stair type lists its run, landing and support types
/// ([`crate::partition_stairs::STAIR_TYPE_COMPONENTS_OFFSET`]). When a
/// part's reference list names several types of its category, or several
/// stairs, the one pair its stair's type lists decides both, and the part
/// joins that stair (#323).
///
/// Measured on Snowdon Towers only (Revit 2024): the other oracles have no
/// stairs.
fn attach_stair_names(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_element_records as per;
    use crate::partition_stairs as ps;
    use crate::partition_type_records as ptr;
    use std::collections::BTreeMap;
    if !ps::supports_revit_version(revit_version) || !ptr::supports_revit_version(revit_version) {
        return;
    }
    let has = |element: &DecodedElement, field: &str| {
        element.fields.iter().any(|(name, _)| name == field)
    };
    let id_field = |element: &DecodedElement, field: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == field => Some(*id),
            _ => None,
        })
    };
    if !products.iter().any(|element| element.class == "Stair") {
        return;
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let type_ids = |rf: &mut RevitFile, category: i64| {
        ptr::type_definition_ids(
            &ptr::scan_type_records(rf, revit_version, category, &declared).unwrap_or_default(),
        )
    };
    let named = |references: &[u64], set: &BTreeSet<u32>| -> BTreeSet<u32> {
        references
            .iter()
            .filter_map(|&slot| u32::try_from(slot).ok())
            .filter(|id| set.contains(id))
            .collect()
    };

    // Stairs: their type, family and name.
    let stair_type_ids = type_ids(rf, per::OST_STAIRS);
    let mut stair_type_of: BTreeMap<u32, u32> = BTreeMap::new();
    for element in products.iter() {
        let (Some(id), "Stair") = (element.id, element.class.as_str()) else {
            continue;
        };
        if let Some((references, _)) = record_references(rf, element) {
            if let Some(type_id) = ptr::unique_type_reference(&references, &stair_type_ids) {
                stair_type_of.insert(id, type_id);
            }
        }
    }
    let stair_types = ps::scan_component_types(
        rf,
        revit_version,
        ps::ComponentKind::Stair,
        &stair_type_of.values().copied().collect(),
    )
    .unwrap_or_default();
    let stair_ids: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.class == "Stair")
        .filter_map(|element| element.id)
        .collect();
    let components_of = |stair: u32| {
        stair_type_of
            .get(&stair)
            .and_then(|type_id| stair_types.get(type_id))
            .map(|found| &found.components)
    };

    // Parts: their type, and their stair where the list names several.
    let part_kinds = [
        ("StairsRun", per::OST_STAIRS_RUNS, None),
        (
            "StairsLanding",
            per::OST_STAIRS_LANDINGS,
            Some(ps::ComponentKind::Landing),
        ),
        (
            "StairsStringer",
            per::OST_STAIRS_STRINGER_CARRIAGE,
            Some(ps::ComponentKind::Support),
        ),
    ];
    let mut part_type: BTreeMap<usize, u32> = BTreeMap::new();
    let mut joins: Vec<(usize, u32)> = Vec::new();
    for (class, category, _) in part_kinds {
        let own_types = type_ids(rf, category);
        for (index, element) in products.iter().enumerate() {
            if element.class != class {
                continue;
            }
            let Some((references, _)) = record_references(rf, element) else {
                continue;
            };
            let candidates = match id_field(element, TYPE_ID_FIELD) {
                Some(id) => BTreeSet::from([id]),
                None => named(&references, &own_types),
            };
            let stairs: Vec<u32> = match id_field(element, AGGREGATE_WHOLE_FIELD) {
                Some(stair) => vec![stair],
                None => named(&references, &stair_ids)
                    .into_iter()
                    .filter(|id| Some(*id) != element.id)
                    .collect(),
            };
            let pairs: Vec<(u32, u32)> = stairs
                .iter()
                .flat_map(|&stair| candidates.iter().map(move |&type_id| (stair, type_id)))
                .filter(|(stair, type_id)| {
                    components_of(*stair).is_some_and(|listed| listed.contains(type_id))
                })
                .collect();
            let chosen_type = match (candidates.len(), pairs.as_slice()) {
                (1, _) => candidates.iter().next().copied(),
                (_, [(_, type_id)]) => Some(*type_id),
                _ => None,
            };
            if let Some(type_id) = chosen_type {
                part_type.insert(index, type_id);
            }
            if let ([_, _, ..], [(stair, _)]) = (stairs.as_slice(), pairs.as_slice()) {
                joins.push((index, *stair));
            }
        }
    }
    for (index, stair) in joins {
        products[index].fields.push((
            AGGREGATE_WHOLE_FIELD.into(),
            InstanceField::ElementId { tag: 0, id: stair },
        ));
    }

    // Families and type names.
    let mut found: BTreeMap<usize, (Option<&'static str>, Option<String>)> = BTreeMap::new();
    for (index, element) in products.iter().enumerate() {
        if let (Some(id), "Stair") = (element.id, element.class.as_str()) {
            if let Some(stair_type) = stair_type_of.get(&id).and_then(|t| stair_types.get(t)) {
                found.insert(index, (stair_type.family, Some(stair_type.name.clone())));
            }
        }
    }
    for (class, _, kind) in part_kinds {
        let ids: BTreeSet<u32> = part_type
            .iter()
            .filter(|(index, _)| products[**index].class == class)
            .map(|(_, id)| *id)
            .collect();
        let of_class = part_type
            .iter()
            .filter(|(index, _)| products[**index].class == class);
        match kind {
            Some(kind) => {
                let types =
                    ps::scan_component_types(rf, revit_version, kind, &ids).unwrap_or_default();
                for (&index, type_id) in of_class {
                    if let Some(read) = types.get(type_id) {
                        found.insert(index, (read.family, Some(read.name.clone())));
                    }
                }
            }
            None => {
                let types = ps::scan_run_types(rf, revit_version, &ids).unwrap_or_default();
                for (&index, type_id) in of_class {
                    if let Some(read) = types.get(type_id) {
                        let family = if read.monolithic {
                            "Monolithic Run"
                        } else {
                            "Non-Monolithic Run"
                        };
                        found.insert(index, (Some(family), read.name.clone()));
                    }
                }
            }
        }
    }
    for (index, (family, name)) in found {
        let element = &mut products[index];
        if has(element, FAMILY_NAME_FIELD) {
            continue;
        }
        if let (Some(name), false) = (&name, has(element, TYPE_NAME_FIELD)) {
            let type_id = part_type
                .get(&index)
                .copied()
                .or_else(|| element.id.and_then(|id| stair_type_of.get(&id).copied()));
            if let Some(type_id) = type_id {
                element.fields.push((
                    TYPE_ID_FIELD.into(),
                    InstanceField::ElementId {
                        tag: 0,
                        id: type_id,
                    },
                ));
            }
            element
                .fields
                .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
        }
        if let (Some(family), true) = (family, has(element, TYPE_NAME_FIELD)) {
            element.fields.push((
                FAMILY_NAME_FIELD.into(),
                InstanceField::String(family.into()),
            ));
            element.fields.push((
                FAMILY_NAME_SOURCE_FIELD.into(),
                InstanceField::String(TYPE_KIND_FAMILY_SOURCE.into()),
            ));
        }
    }

    // The stairs' names, then each part's number among the records of its
    // category that name its stair.
    let mut stair_names: BTreeMap<u32, String> = BTreeMap::new();
    for element in products.iter_mut() {
        let (Some(id), "Stair") = (element.id, element.class.as_str()) else {
            continue;
        };
        let Some(family) = stair_type_of
            .get(&id)
            .and_then(|type_id| stair_types.get(type_id))
            .and_then(|stair_type| stair_type.family)
        else {
            continue;
        };
        let name = format!("{family}:Stair:{id}");
        element.fields.push((
            ELEMENT_NAME_FIELD.into(),
            InstanceField::String(name.clone()),
        ));
        stair_names.insert(id, name);
    }
    if stair_names.is_empty() {
        return;
    }
    let Some(marker) = per::file_bbox_marker(rf, revit_version) else {
        return;
    };
    let assigned = rf.memoised_second_prologue_ids();
    let none = BTreeMap::new();
    let mut members: BTreeMap<(u32, &'static str), BTreeSet<u32>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let ids = assigned.get(&stream).unwrap_or(&none);
        let categories: Vec<i64> = part_kinds
            .iter()
            .map(|(_, category, _)| *category)
            .collect();
        let found = per::find_categories_records_assigned(
            &stream,
            inflated.bytes(),
            &categories,
            &declared,
            &marker,
            ids,
        );
        for ((class, _, _), records) in part_kinds.iter().zip(found) {
            let Some(word) = stair_part_word(class) else {
                continue;
            };
            for record in records {
                for stair in named(&record.references, &stair_ids) {
                    if stair_names.contains_key(&stair) {
                        members
                            .entry((stair, word))
                            .or_default()
                            .insert(record.element_id);
                    }
                }
            }
        }
    }
    for element in products.iter_mut() {
        let (Some(id), Some(word)) = (element.id, stair_part_word(&element.class)) else {
            continue;
        };
        let Some(stair) = id_field(element, AGGREGATE_WHOLE_FIELD) else {
            continue;
        };
        let (Some(stair_name), Some(ids)) = (stair_names.get(&stair), members.get(&(stair, word)))
        else {
            continue;
        };
        let Some(rank) = ids.iter().position(|member| *member == id) else {
            continue;
        };
        element.fields.push((
            ELEMENT_NAME_FIELD.into(),
            InstanceField::String(format!("{stair_name} {word} {}", rank + 1)),
        ));
    }
}

/// Field holding a stair's or flight's number of risers (RE-47).
pub const STAIR_RISER_COUNT_FIELD: &str = "m_stair_riser_count";
/// Field holding a stair's or flight's riser height, feet (RE-47).
pub const STAIR_RISER_HEIGHT_FIELD: &str = "m_stair_riser_height";
/// Field holding a stair's or flight's tread depth, feet (RE-47).
pub const STAIR_TREAD_DEPTH_FIELD: &str = "m_stair_tread_depth";
/// Field holding a flight's number of treads: its risers, one fewer when it
/// begins and ends with a riser, one more for each end that is a tread
/// (RE-92).
pub const STAIR_TREAD_COUNT_FIELD: &str = "m_stair_tread_count";
/// Field holding how far a flight's treads overhang its risers, its run
/// type's nosing length, feet; on a stair, the one every run of it has
/// (RE-52).
pub const STAIR_NOSING_LENGTH_FIELD: &str = "m_stair_nosing_length";

/// Give each Revit 2025 stair its actual risers, riser height and tread
/// depth, and each run its risers, its height over its risers, its stair's
/// tread depth and its number of treads, from their native records
/// ([`crate::native_stairs::native_stair_counts`]).
fn attach_native_stair_dimensions(rf: &mut RevitFile, products: &mut [DecodedElement]) {
    let ids = |class: &str| -> BTreeSet<u64> {
        products
            .iter()
            .filter(|element| element.class == class)
            .filter_map(|element| element.id.map(u64::from))
            .collect()
    };
    let (stairs, runs) = (ids("Stair"), ids("StairsRun"));
    let Ok((stair_counts, run_counts)) =
        crate::native_stairs::native_stair_counts(rf, &stairs, &runs)
    else {
        return;
    };
    let integer = |value: i64| InstanceField::Integer {
        value,
        signed: false,
        size: 4,
    };
    let scalar = |value: f64| InstanceField::Float { value, size: 8 };
    for element in products.iter_mut() {
        let Some(id) = element.id.map(u64::from) else {
            continue;
        };
        let mut fields = Vec::new();
        if element.class == "Stair" {
            if let Some(found) = stair_counts.get(&id) {
                fields.push((STAIR_RISER_COUNT_FIELD, integer(found.risers)));
                fields.push((STAIR_RISER_HEIGHT_FIELD, scalar(found.riser_height_feet)));
                fields.push((STAIR_TREAD_DEPTH_FIELD, scalar(found.tread_depth_feet)));
            }
        } else if element.class == "StairsRun" {
            if let Some(run) = run_counts.get(&id) {
                fields.push((STAIR_RISER_COUNT_FIELD, integer(run.risers)));
                fields.push((
                    STAIR_RISER_HEIGHT_FIELD,
                    scalar(run.height_feet / run.risers as f64),
                ));
                if let Some(stair) = stair_counts.get(&run.stair) {
                    fields.push((STAIR_TREAD_DEPTH_FIELD, scalar(stair.tread_depth_feet)));
                }
                let treads = run.risers - 1
                    + i64::from(!run.begin_with_riser)
                    + i64::from(!run.end_with_riser);
                fields.push((STAIR_TREAD_COUNT_FIELD, integer(treads)));
            }
        }
        element
            .fields
            .extend(fields.into_iter().map(|(name, value)| (name.into(), value)));
    }
}

/// Give each stair its riser height, tread depth and number of risers, and
/// each of its runs the same riser height and tread depth and, where
/// [`crate::partition_stairs::flight_riser_counts`] can tell, its own number
/// of risers (RE-47). Runs are the stair's parts (#323).
fn attach_stair_dimensions(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_stairs as ps;
    if crate::native_stairs::NATIVE_RUN_REVIT_VERSIONS.contains(&revit_version) {
        attach_native_stair_dimensions(rf, products);
        return;
    }
    if !ps::supports_revit_version(revit_version) {
        return;
    }
    let stairs: Vec<u32> = products
        .iter()
        .filter(|element| element.class == "Stair")
        .filter_map(|element| element.id)
        .collect();
    let whole_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == AGGREGATE_WHOLE_FIELD => Some(*id),
            _ => None,
        })
    };
    let runs: Vec<(u32, u32)> = products
        .iter()
        .filter(|element| element.class == "StairsRun")
        .filter_map(|element| Some((element.id?, whole_of(element)?)))
        .filter(|(_, stair)| stairs.contains(stair))
        .collect();
    if stairs.is_empty() {
        return;
    }
    let run_ids: Vec<u32> = runs.iter().map(|(run, _)| *run).collect();
    let Ok((dimensions, run_counts)) =
        ps::scan_stair_dimensions(rf, revit_version, &stairs, &run_ids)
    else {
        return;
    };
    let mut flight_counts: BTreeMap<u32, u32> = BTreeMap::new();
    for (stair, found) in &dimensions {
        let of_stair: Vec<(u32, Option<u32>)> = runs
            .iter()
            .filter(|(_, whole)| whole == stair)
            .map(|(run, _)| (*run, run_counts.get(run).copied()))
            .collect();
        flight_counts.extend(ps::flight_riser_counts(found.riser_count, &of_stair));
    }
    let push = |element: &mut DecodedElement, found: &ps::StairDimensions, risers: Option<u32>| {
        if let Some(risers) = risers {
            element.fields.push((
                STAIR_RISER_COUNT_FIELD.into(),
                InstanceField::Integer {
                    value: i64::from(risers),
                    signed: false,
                    size: 4,
                },
            ));
        }
        element.fields.push((
            STAIR_RISER_HEIGHT_FIELD.into(),
            InstanceField::Float {
                value: found.riser_height_feet,
                size: 8,
            },
        ));
        element.fields.push((
            STAIR_TREAD_DEPTH_FIELD.into(),
            InstanceField::Float {
                value: found.tread_depth_feet,
                size: 8,
            },
        ));
    };
    for element in products.iter_mut() {
        let Some(id) = element.id else {
            continue;
        };
        if element.class == "Stair" {
            if let Some(found) = dimensions.get(&id) {
                push(element, found, Some(found.riser_count));
            }
        } else if element.class == "StairsRun" {
            let Some(found) = whole_of(element).and_then(|stair| dimensions.get(&stair)) else {
                continue;
            };
            let found = *found;
            push(element, &found, flight_counts.get(&id).copied());
        }
    }
}

/// Fields holding the unit plan direction from a wall's inside to its
/// exterior face, model axes (RE-53).
pub const WALL_EXTERIOR_FIELDS: [&str; 2] = ["m_wall_exterior_x", "m_wall_exterior_y"];
/// Field holding a wall's layers, exterior first: each a vector of width
/// (feet), shading colour (`0x00BBGGRR`, or -1 for the category's) and
/// transparency (RE-53).
pub const WALL_LAYERS_FIELD: &str = "m_wall_layers";

/// Fields holding a wall's centreline start and end in plan, model feet
/// (RE-54).
pub const WALL_AXIS_START_FIELDS: [&str; 2] = ["m_wall_axis_start_x", "m_wall_axis_start_y"];
/// See [`WALL_AXIS_START_FIELDS`].
pub const WALL_AXIS_END_FIELDS: [&str; 2] = ["m_wall_axis_end_x", "m_wall_axis_end_y"];
/// Fields holding a curved wall's location arc (RE-75), in plan: its centre
/// `x` and `y`, radius, start and end angle (radians), and the `x` and `y`
/// of its unit X and Y axes. The arc runs from
/// `centre + radius · (cos a · X + sin a · Y)` at the start angle to the end
/// angle.
pub const WALL_ARC_FIELDS: [&str; 9] = [
    "m_wall_arc_centre_x",
    "m_wall_arc_centre_y",
    "m_wall_arc_radius",
    "m_wall_arc_start_angle",
    "m_wall_arc_end_angle",
    "m_wall_arc_x_axis_x",
    "m_wall_arc_x_axis_y",
    "m_wall_arc_y_axis_x",
    "m_wall_arc_y_axis_y",
];
/// Field holding a wall's thickness, its type's layers summed (RE-54).
pub const WALL_TYPE_THICKNESS_FIELD: &str = "m_wall_type_thickness";
/// Field holding how far a tapered wall's exterior face leans from
/// vertical, radians, wider at the base (RE-86). Its line and
/// [`WALL_TYPE_THICKNESS_FIELD`] give the body at the wall's top.
pub const WALL_EXTERIOR_FACE_ANGLE_FIELD: &str = "m_wall_exterior_face_angle";
/// Fields holding how far past the start and the end of its centreline a
/// wall's body reaches at a butt join, feet, negative where it stops short
/// (RE-70), or at a T joint (RE-73). Absent at an end neither decides.
pub const WALL_JOIN_REACH_FIELDS: [&str; 2] = ["m_wall_join_start_reach", "m_wall_join_end_reach"];
/// Fields holding the one wall a wall butt-joins at its start and at its
/// end, where the join lists decide which of the two runs through (RE-70),
/// or the wall it stops against at a T joint (RE-73).
pub const WALL_JOIN_PARTNER_FIELDS: [&str; 2] = ["m_wall_join_start_wall", "m_wall_join_end_wall"];
/// Fields holding how far past the start and the end of its centreline
/// each of a wall's layers reaches at a layered butt join (RE-71) or T
/// joint (RE-73), exterior first, feet.
pub const WALL_JOIN_LAYER_REACH_FIELDS: [&str; 2] = [
    "m_wall_join_start_layer_reaches",
    "m_wall_join_end_layer_reaches",
];
/// Fields holding, at an angled join, how far past the start and the end of
/// its centreline each of a wall's layers reaches along its exterior-side
/// and its interior-side edge, exterior first, two values per layer, feet
/// (RE-74).
pub const WALL_JOIN_LAYER_EDGE_REACH_FIELDS: [&str; 2] = [
    "m_wall_join_start_layer_edge_reaches",
    "m_wall_join_end_layer_edge_reaches",
];
/// Fields holding whether a wall runs through that join (true) or stops at
/// it (false) (RE-70).
pub const WALL_JOIN_THROUGH_FIELDS: [&str; 2] =
    ["m_wall_join_start_through", "m_wall_join_end_through"];

/// A wall's centreline and its type's thickness (RE-54).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WallAxis {
    /// Plan start, model feet.
    pub start: [f64; 2],
    /// Plan end, model feet.
    pub end: [f64; 2],
    /// The type's layers summed, feet.
    pub thickness_feet: f64,
    /// How far past its start and its end the body reaches at a butt join,
    /// where the join lists decide it (RE-70).
    pub join_reach_feet: [Option<f64>; 2],
}

/// The centreline and thickness [`WALL_AXIS_START_FIELDS`],
/// [`WALL_AXIS_END_FIELDS`] and [`WALL_TYPE_THICKNESS_FIELD`] record, with
/// the [`WALL_JOIN_REACH_FIELDS`] present.
pub fn wall_axis_from_fields(fields: &[(String, InstanceField)]) -> Option<WallAxis> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [sx, sy] = WALL_AXIS_START_FIELDS.map(float);
    let [ex, ey] = WALL_AXIS_END_FIELDS.map(float);
    Some(WallAxis {
        start: [sx?, sy?],
        end: [ex?, ey?],
        thickness_feet: float(WALL_TYPE_THICKNESS_FIELD)?,
        join_reach_feet: WALL_JOIN_REACH_FIELDS.map(float),
    })
}

/// A curved wall's location arc and its type's thickness (RE-75).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WallArc {
    /// Plan centre, model feet.
    pub centre: [f64; 2],
    /// Radius, feet.
    pub radius: f64,
    /// Start and end angle, radians.
    pub angles: [f64; 2],
    /// Plan unit X axis.
    pub x_axis: [f64; 2],
    /// Plan unit Y axis.
    pub y_axis: [f64; 2],
    /// The type's layers summed, feet.
    pub thickness_feet: f64,
}

impl WallArc {
    /// The plan point `offset` feet out from the arc (away from its centre)
    /// at `angle`.
    pub fn point(&self, angle: f64, offset: f64) -> [f64; 2] {
        let (sin, cos) = angle.sin_cos();
        let radius = self.radius + offset;
        [0, 1].map(|axis| {
            self.centre[axis] + radius * (cos * self.x_axis[axis] + sin * self.y_axis[axis])
        })
    }
}

/// A tapered wall's exterior face (RE-86).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WallTaper {
    /// How far the exterior face leans from vertical, radians, wider at
    /// the base.
    pub angle_radians: f64,
    /// Plan unit vector towards the exterior face.
    pub exterior: [f64; 2],
}

/// Whether the wall carries [`WALL_EXTERIOR_FACE_ANGLE_FIELD`], so its line
/// alone does not give its body.
pub fn wall_is_tapered(fields: &[(String, InstanceField)]) -> bool {
    fields
        .iter()
        .any(|(name, _)| name == WALL_EXTERIOR_FACE_ANGLE_FIELD)
}

/// The [`WALL_EXTERIOR_FACE_ANGLE_FIELD`] and [`WALL_EXTERIOR_FIELDS`]
/// record; `None` without either.
pub fn wall_taper_from_fields(fields: &[(String, InstanceField)]) -> Option<WallTaper> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [x, y] = WALL_EXTERIOR_FIELDS.map(float);
    Some(WallTaper {
        angle_radians: float(WALL_EXTERIOR_FACE_ANGLE_FIELD)?,
        exterior: [x?, y?],
    })
}

/// The arc [`WALL_ARC_FIELDS`] and [`WALL_TYPE_THICKNESS_FIELD`] record.
pub fn wall_arc_from_fields(fields: &[(String, InstanceField)]) -> Option<WallArc> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [cx, cy, radius, start, end, xx, xy, yx, yy] = WALL_ARC_FIELDS.map(float);
    Some(WallArc {
        centre: [cx?, cy?],
        radius: radius?,
        angles: [start?, end?],
        x_axis: [xx?, xy?],
        y_axis: [yx?, yy?],
        thickness_feet: float(WALL_TYPE_THICKNESS_FIELD)?,
    })
}

/// Where each layer of a wall ends at its layered butt joins (RE-71).
#[derive(Debug, Clone, PartialEq)]
pub struct WallLayerEnds {
    /// Plan unit vector towards the wall's exterior face.
    pub exterior: [f64; 2],
    /// The layers' widths, exterior first, feet.
    pub widths: Vec<f64>,
    /// How far past its start and its end each layer reaches along its
    /// exterior-side and its interior-side edge, exterior first, where a
    /// layered or angled join decides it. The two are equal where the end
    /// is square.
    pub reach_feet: [Option<Vec<[f64; 2]>>; 2],
}

/// The [`WALL_JOIN_LAYER_EDGE_REACH_FIELDS`] or
/// [`WALL_JOIN_LAYER_REACH_FIELDS`] a wall carries, with its layers' widths
/// and exterior side. `None` without a layered or angled join at either
/// end, or where a reach list does not match the layers.
pub fn wall_layer_ends_from_fields(fields: &[(String, InstanceField)]) -> Option<WallLayerEnds> {
    let floats = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Vector(items) if name == wanted => items
                .iter()
                .map(|item| match item {
                    InstanceField::Float { value, .. } => Some(*value),
                    _ => None,
                })
                .collect::<Option<Vec<f64>>>(),
            _ => None,
        })
    };
    let square = WALL_JOIN_LAYER_REACH_FIELDS.map(floats);
    let slanted = WALL_JOIN_LAYER_EDGE_REACH_FIELDS.map(floats);
    if square.iter().chain(&slanted).all(Option::is_none) {
        return None;
    }
    let widths: Vec<f64> = fields
        .iter()
        .find_map(|(name, value)| {
            (name == WALL_LAYERS_FIELD).then(|| layer_bands_from_field(value))
        })
        .flatten()?
        .iter()
        .map(|band| band.width_feet)
        .collect();
    if square
        .iter()
        .flatten()
        .any(|reach| reach.len() != widths.len())
        || slanted
            .iter()
            .flatten()
            .any(|reach| reach.len() != 2 * widths.len())
    {
        return None;
    }
    let [start, end] = [0, 1].map(|slot| match (&slanted[slot], &square[slot]) {
        (Some(edges), _) => Some(edges.chunks(2).map(|pair| [pair[0], pair[1]]).collect()),
        (None, Some(reaches)) => Some(reaches.iter().map(|reach| [*reach, *reach]).collect()),
        (None, None) => None,
    });
    let reach_feet = [start, end];
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let [Some(ex), Some(ey)] = WALL_EXTERIOR_FIELDS.map(float) else {
        return None;
    };
    Some(WallLayerEnds {
        exterior: [ex, ey],
        widths,
        reach_feet,
    })
}

/// Field holding a floor's, roof's or ceiling's layers, top first, in the
/// form of [`WALL_LAYERS_FIELD`] (RE-57).
pub const SLAB_LAYERS_FIELD: &str = "m_slab_layers";

/// The layers [`WALL_LAYERS_FIELD`] records on a wall with no
/// [`WALL_EXTERIOR_FIELDS`]: its type's, where its data does not place it
/// (RE-88).
pub fn unplaced_wall_layers_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<Vec<crate::ifc::LayerBand>> {
    if fields
        .iter()
        .any(|(name, _)| WALL_EXTERIOR_FIELDS.contains(&name.as_str()))
    {
        return None;
    }
    fields
        .iter()
        .find_map(|(name, value)| (name == WALL_LAYERS_FIELD).then_some(value))
        .and_then(layer_bands_from_field)
}

/// The total width of the layers [`WALL_LAYERS_FIELD`] records on a wall,
/// its type's thickness, feet: Revit's `Wall.Width`, which revit-ifc's
/// `CreateWallBaseQuantities` writes as the wall's `Width` (CLEANROOM.md
/// source 5) whether or not the wall is drawn from its centreline (#1016).
pub fn wall_layers_width_from_fields(fields: &[(String, InstanceField)]) -> Option<f64> {
    let bands = fields
        .iter()
        .find_map(|(name, value)| (name == WALL_LAYERS_FIELD).then_some(value))
        .and_then(layer_bands_from_field)?;
    let width: f64 = bands.iter().map(|band| band.width_feet).sum();
    (width.is_finite() && width > 0.0).then_some(width)
}

/// The layers of a [`WALL_LAYERS_FIELD`] or [`SLAB_LAYERS_FIELD`] value.
fn layer_bands_from_field(value: &InstanceField) -> Option<Vec<crate::ifc::LayerBand>> {
    let InstanceField::Vector(items) = value else {
        return None;
    };
    let bands = items
        .iter()
        .map(|item| match item {
            InstanceField::Vector(parts) => match parts.as_slice() {
                [
                    InstanceField::Float { value: width, .. },
                    InstanceField::Integer { value: colour, .. },
                    InstanceField::Float {
                        value: transparency,
                        ..
                    },
                    rest @ ..,
                ] => Some(crate::ifc::LayerBand {
                    width_feet: *width,
                    color_packed: u32::try_from(*colour).ok(),
                    transparency: *transparency,
                    name: match rest {
                        [InstanceField::String(name)] => Some(name.clone()),
                        _ => None,
                    },
                }),
                _ => None,
            },
            _ => None,
        })
        .collect::<Option<Vec<_>>>()?;
    (!bands.is_empty()).then_some(bands)
}

/// The field form of a type's layers, each with its material's shading and,
/// where it is read, its name (RE-58); membranes, which have no width, are
/// left out.
fn layer_bands_field(
    layers: &[crate::partition_compound_structure::CompoundLayer],
    appearances: &BTreeMap<u32, crate::partition_materials::MaterialAppearance>,
    names: &BTreeMap<u32, String>,
) -> InstanceField {
    InstanceField::Vector(
        layers
            .iter()
            .filter(|layer| layer.width_feet > 0.0)
            .map(|layer| {
                let appearance = layer.material.and_then(|m| appearances.get(&m));
                let mut band = vec![
                    InstanceField::Float {
                        value: layer.width_feet,
                        size: 8,
                    },
                    InstanceField::Integer {
                        value: appearance.map_or(-1, |a| i64::from(a.color_packed())),
                        signed: true,
                        size: 8,
                    },
                    InstanceField::Float {
                        value: appearance.map_or(0.0, |a| f64::from(a.transparency)),
                        size: 8,
                    },
                ];
                if let Some(name) = layer.material.and_then(|m| names.get(&m)) {
                    band.push(InstanceField::String(name.clone()));
                }
                InstanceField::Vector(band)
            })
            .collect(),
    )
}

/// The layers [`WALL_LAYERS_FIELD`] and [`WALL_EXTERIOR_FIELDS`], or
/// [`SLAB_LAYERS_FIELD`], record.
pub fn element_layers_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<crate::ifc::ElementLayers> {
    let field = |wanted: &str| {
        fields
            .iter()
            .find_map(|(name, value)| (name == wanted).then_some(value))
    };
    if let Some(layers) = field(SLAB_LAYERS_FIELD).and_then(layer_bands_from_field) {
        return Some(crate::ifc::ElementLayers {
            exterior_normal: [0.0, 0.0],
            layers,
            stacked: true,
            system_family: None,
        });
    }
    let float = |wanted: &str| match field(wanted) {
        Some(InstanceField::Float { value, .. }) => Some(*value),
        _ => None,
    };
    let [x, y] = WALL_EXTERIOR_FIELDS.map(float);
    let layers = field(WALL_LAYERS_FIELD).and_then(layer_bands_from_field)?;
    Some(crate::ifc::ElementLayers {
        exterior_normal: [x?, y?],
        layers,
        stacked: false,
        system_family: None,
    })
}

/// The Revit system family of a record-backed element's type (RE-61,
/// RE-63). Revit derives the name rather than storing it, from the type's
/// kind, and the category gives it where only one system family fits:
/// - a curtain wall (RE-46) is a Curtain Wall, and a railing a Railing;
/// - a floor is a Floor, and a building pad a Pad;
/// - a slab edge is a Slab Edge, and a ramp a Ramp (RE-64);
/// - a wall, ceiling or roof whose type has compound layers (`has_layers`)
///   is a Basic Wall, a Compound Ceiling or a Basic Roof, since a Curtain
///   or Stacked Wall, a Basic Ceiling and Sloped Glazing have none;
/// - a curtain panel whose type is a wall type with layers is a Basic Wall
///   (RE-64);
/// - a pipe is a Pipe Types, Revit's one pipe system family (RE-130).
///
/// Measured against the `Family:Type:ElementId` names Revit's own IFC
/// export gives the same elements, on every record-backed wall, floor,
/// ceiling, roof and building pad of Snowdon Towers, Core Interior and RE1
/// Architecture: 1,444 walls, 283 floors, 74 ceilings, 20 roofs and 1 pad.
pub fn system_family(class: &str, has_layers: bool) -> Option<&'static str> {
    match (class, has_layers) {
        (CURTAIN_WALL_CLASS, _) => Some("Curtain Wall"),
        ("Railing", _) => Some("Railing"),
        ("Floor", _) => Some("Floor"),
        ("BuildingPad", _) => Some("Pad"),
        ("SlabEdge", _) => Some("Slab Edge"),
        ("Ramp", _) => Some("Ramp"),
        ("Pipe", _) => Some("Pipe Types"),
        ("Wall" | "CurtainWallPanel", true) => Some("Basic Wall"),
        ("Ceiling", true) => Some("Compound Ceiling"),
        ("Roof", true) => Some("Basic Roof"),
        _ => None,
    }
}

/// The name Revit's export gives system family `family` in a file saved
/// in `locale` (`BasicFileInfo`'s "Locale when saved", e.g. `ENU`, `PTB`).
///
/// A system family's name is not in the file: Revit supplies it in the
/// language the file is saved in. Four files saved in `PTB` (two Revit
/// 2023, two Revit 2025) name their walls, floors and roofs this way
/// in Revit's own export, 28 walls, 3 floors and 1 roof, and no other
/// system family occurs in them (RE-123). Every other family, and every
/// other locale, keeps the `ENU` name [`system_family`] gives, which is
/// what the `ENU` files measure.
pub fn localized_system_family(family: &'static str, locale: Option<&str>) -> &'static str {
    match (locale, family) {
        (Some("PTB"), "Basic Wall") => "Parede básica",
        (Some("PTB"), "Floor") => "Piso",
        (Some("PTB"), "Basic Roof") => "Telhado básico",
        _ => family,
    }
}

/// Field holding a railing's height, its type's top rail height, feet
/// (RE-231).
pub const RAILING_HEIGHT_FIELD: &str = "m_railing_height";

/// Field holding a stair railing's `Length`, its path along its stair,
/// feet (RE-254).
pub const RAILING_LENGTH_FIELD: &str = "m_railing_length";

/// Give each railing of a stair whose path is one line along that stair's
/// runs its `Length` ([`crate::native_stairs::railing_lengths`], RE-254).
fn attach_railing_lengths(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    if !crate::native_stairs::RAILING_LENGTH_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let railings: BTreeSet<u64> = products
        .iter()
        .filter(|element| element.class == "Railing")
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    let Ok(lengths) = crate::native_stairs::railing_lengths(rf, &railings) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Railing")
    {
        if let Some(length) = element
            .id
            .and_then(|id| lengths.get(&u64::from(id)))
            .copied()
        {
            element.fields.push((
                RAILING_LENGTH_FIELD.into(),
                InstanceField::Float {
                    value: length,
                    size: 8,
                },
            ));
        }
    }
}

/// Give each railing its type's top rail height
/// ([`crate::native_stairs::railing_type_heights`], RE-231).
fn attach_railing_heights(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    if !crate::native_stairs::RAILING_HEIGHT_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(u64::from(*id)),
            _ => None,
        })
    };
    let types: BTreeSet<u64> = products
        .iter()
        .filter(|element| element.class == "Railing")
        .filter_map(type_of)
        .collect();
    let Ok(heights) = crate::native_stairs::railing_type_heights(rf, &types) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Railing")
    {
        if let Some(height) = type_of(element).and_then(|id| heights.get(&id)).copied() {
            element.fields.push((
                RAILING_HEIGHT_FIELD.into(),
                InstanceField::Float {
                    value: height,
                    size: 8,
                },
            ));
        }
    }
}

/// Field recording that [`FAMILY_NAME_FIELD`] is a system family's name
/// derived by [`system_family`], not read from the file (RE-63).
pub const FAMILY_NAME_SOURCE_FIELD: &str = "m_family_name_source";

/// Value of [`FAMILY_NAME_SOURCE_FIELD`].
pub const SYSTEM_FAMILY_SOURCE: &str = "system_family_by_category";

/// Give each system-family element with a type name (#322) its system
/// family's name ([`system_family`]), so it is named `Family:Type:ElementId`
/// as Revit names it (RE-63). Whether a wall's, ceiling's or roof's type has
/// compound layers is the type's: an element of the type drawn in layers
/// shows it, and otherwise the type's own data is read
/// ([`crate::partition_compound_structure::scan_type_layers`]).
fn attach_system_family_names(
    rf: &mut RevitFile,
    revit_version: u32,
    elements: &mut [&mut Vec<DecodedElement>],
) {
    use crate::partition_compound_structure as pcs;
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let shows_layers = |element: &DecodedElement| {
        element.fields.iter().any(|(name, _)| {
            name == WALL_LAYERS_FIELD
                || name == SLAB_LAYERS_FIELD
                || name == ROOF_TYPE_THICKNESS_FIELD
        })
    };
    let mut layered: BTreeSet<u32> = elements
        .iter()
        .flat_map(|list| list.iter())
        .filter(|element| shows_layers(element))
        .filter_map(type_of)
        .collect();
    let pending: BTreeSet<u32> = elements
        .iter()
        .flat_map(|list| list.iter())
        .filter(|element| {
            matches!(
                element.class.as_str(),
                "Wall" | "Ceiling" | "Roof" | "CurtainWallPanel"
            )
        })
        .filter_map(type_of)
        .filter(|id| !layered.contains(id))
        .collect();
    if !pending.is_empty() && pcs::layer_layout(revit_version).is_some() {
        if let Ok(records) = crate::elem_table::parse_records(rf) {
            let declared = crate::elem_table::declared_ids(&records);
            // Revit 2023 has no type records, and its materials no element
            // records either: a layer's material is only held to be
            // declared (RE-112).
            let materials: BTreeSet<u32> =
                if crate::partition_element_records_2023::is_32bit_release(revit_version) {
                    declared.clone()
                } else {
                    crate::partition_type_records::scan_type_records(
                        rf,
                        revit_version,
                        crate::partition_type_records::OST_MATERIALS,
                        &declared,
                    )
                    .unwrap_or_default()
                    .iter()
                    .map(|record| record.element_id)
                    .collect()
                };
            if let Ok(types) =
                pcs::scan_type_layers(rf, revit_version, &pending, &materials, &declared)
            {
                layered.extend(
                    types
                        .into_iter()
                        .filter(|(_, layers)| !layers.is_empty())
                        .map(|(id, _)| id),
                );
            }
        }
    }
    let locale = rf.basic_file_info().ok().and_then(|info| info.locale);
    for element in elements.iter_mut().flat_map(|list| list.iter_mut()) {
        let has = |field: &str| element.fields.iter().any(|(name, _)| name == field);
        if !has(TYPE_NAME_FIELD) || has(FAMILY_NAME_FIELD) {
            continue;
        }
        let has_layers = type_of(element).is_some_and(|id| layered.contains(&id));
        let Some(family) = system_family(&element.class, has_layers) else {
            continue;
        };
        element.fields.push((
            FAMILY_NAME_FIELD.into(),
            InstanceField::String(localized_system_family(family, locale.as_deref()).into()),
        ));
        element.fields.push((
            FAMILY_NAME_SOURCE_FIELD.into(),
            InstanceField::String(SYSTEM_FAMILY_SOURCE.into()),
        ));
    }
}

/// Give each wall its type's layers, exterior first, each with its
/// material's shading, and the plan direction of its exterior face: the
/// right of its location line's direction when its flip flag is set, the
/// left otherwise (RE-53, [`crate::partition_compound_structure`],
/// [`crate::partition_materials`]). A wall whose word is 1 also gets its
/// centreline and its type's thickness, from which the exporter builds its
/// body (RE-54). A wall without a type, a location line or an orientation
/// gets none of these. Membranes, which have no width, are left out.
/// The field prefix of the openings a wall's edited elevation profile cuts
///: `m_profile_opening_<k>`, the opening's outline as model-feet
/// points in the wall's vertical plane, and `m_profile_opening_<k>_tag`, the
/// ElementId it is tagged with.
// Tracker: B55.
pub const PROFILE_OPENING_FIELD: &str = "m_profile_opening";

/// How far apart two sketch points may lie and still meet, and how far off a
/// plane or a side a point may lie and still be on it, feet.
// Tracker: B55.
const PROFILE_EPS_FEET: f64 = 1e-3;

/// A sketch line: its ElementId, start and end, model feet.
// Tracker: B55.
pub type SketchSegment = (u32, [f64; 3], [f64; 3]);

/// A sketch line in its plane: its ElementId, and its ends along and up the
/// plane.
// Tracker: B55.
type PlaneEdge = (u32, (f64, f64), (f64, f64));

/// Give each wall whose elevation profile was edited the openings that cuts
/// (RE-151's 63rd opening).
///
/// The profile is the wall's sketch, the curves its sketch lists (RE-97),
/// each read as a straight line
/// ([`crate::partition_beam_axes::scan_sketch_curves`]) whose ends lie in its
/// record's box. Where every line lies in one vertical plane and they close
/// one loop, each run of lines that leaves the loop's bounding rectangle cuts
/// the region between it and the rectangle's edge, which Revit's export
/// writes as an opening voiding the wall ([`elevation_profile_cuts`]). A wall
/// whose sketch holds an arc, or does not close, is left alone.
///
/// Measured on Core Interior's wall 55840 (Revit 2024), whose one opening
/// Revit's export tags 55859.
fn attach_wall_profile_openings(
    rf: &mut RevitFile,
    revit_version: u32,
    walls: &mut [DecodedElement],
) {
    use crate::partition_element_records as per;
    let wall_ids: BTreeSet<u32> = walls.iter().filter_map(|wall| wall.id).collect();
    if wall_ids.is_empty() || !crate::partition_beam_axes::supports_revit_version(revit_version) {
        return;
    }
    let declared = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Ok(lines) =
        per::scan_category_records_multi(rf, revit_version, &[per::OST_SKETCH_LINES], &declared)
    else {
        return;
    };
    let line_ids: BTreeSet<u32> = lines.iter().map(|record| record.element_id).collect();
    let lists: BTreeMap<u32, Vec<u32>> =
        crate::element_record_plan_profiles::scan_sketch_curve_lists(rf, revit_version, &line_ids)
            .into_iter()
            .filter(|(owner, _)| wall_ids.contains(owner))
            .collect();
    if lists.is_empty() {
        return;
    }
    let wanted: BTreeSet<u32> = lists.values().flatten().copied().collect();
    let Ok(curves) = crate::partition_beam_axes::scan_sketch_curves(rf, revit_version, &wanted)
    else {
        return;
    };
    let boxes: BTreeMap<u32, [f64; 6]> = lines
        .iter()
        .filter(|record| wanted.contains(&record.element_id))
        .map(|record| (record.element_id, record.bbox_feet))
        .collect();
    let in_box = |point: [f64; 3], bbox: &[f64; 6]| {
        (0..3).all(|axis| {
            point[axis] >= bbox[axis] - PROFILE_EPS_FEET
                && point[axis] <= bbox[axis + 3] + PROFILE_EPS_FEET
        })
    };
    for wall in walls.iter_mut() {
        let Some(curve_ids) = wall.id.and_then(|id| lists.get(&id)) else {
            continue;
        };
        let segments: Option<Vec<SketchSegment>> = curve_ids
            .iter()
            .map(|id| {
                let line = curves.get(id)?.line?;
                let bbox = boxes.get(id)?;
                let (start, end) = (line.start(), line.end());
                (in_box(start, bbox) && in_box(end, bbox)).then_some((*id, start, end))
            })
            .collect();
        let Some(segments) = segments else {
            continue;
        };
        for (k, (tag, outline)) in elevation_profile_cuts(&segments).into_iter().enumerate() {
            let points = outline
                .iter()
                .map(|point| {
                    InstanceField::Vector(
                        point
                            .iter()
                            .map(|value| InstanceField::Float {
                                value: *value,
                                size: 8,
                            })
                            .collect(),
                    )
                })
                .collect();
            wall.fields.push((
                format!("{PROFILE_OPENING_FIELD}_{k}"),
                InstanceField::Vector(points),
            ));
            wall.fields.push((
                format!("{PROFILE_OPENING_FIELD}_{k}_tag"),
                InstanceField::ElementId { tag: 0, id: tag },
            ));
        }
    }
}

/// The openings a wall's edited elevation profile cuts, from its sketch
/// lines (ElementId, start, end, model feet): each region between a
/// run of lines that leaves the profile's bounding rectangle and the
/// rectangle's edge, as model-feet points in the profile's plane,
/// counter-clockwise in its own along-and-up coordinates, tagged with the
/// highest ElementId of the run, as Revit's export tags wall 55840's one
/// opening (55859, also the last line of its sketch). Empty where the lines
/// do not lie in one vertical plane, do not close one loop, or never leave
/// the rectangle.
// Tracker: B55.
pub fn elevation_profile_cuts(segments: &[SketchSegment]) -> Vec<(u32, Vec<[f64; 3]>)> {
    let eps = PROFILE_EPS_FEET;
    let points: Vec<[f64; 3]> = segments.iter().flat_map(|(_, a, b)| [*a, *b]).collect();
    let plan = |a: [f64; 3], b: [f64; 3]| ((b[0] - a[0]).powi(2) + (b[1] - a[1]).powi(2)).sqrt();
    let mut far = (0.0, [0.0; 3], [0.0; 3]);
    for a in &points {
        for b in &points {
            let distance = plan(*a, *b);
            if distance > far.0 {
                far = (distance, *a, *b);
            }
        }
    }
    let (length, origin, toward) = far;
    if length <= eps {
        return Vec::new();
    }
    let axis = [
        (toward[0] - origin[0]) / length,
        (toward[1] - origin[1]) / length,
    ];
    // A point's place along the plane's axis and up it, and how far off the
    // plane it lies.
    let to_uv = |p: [f64; 3]| {
        let (dx, dy) = (p[0] - origin[0], p[1] - origin[1]);
        (
            (dx * axis[0] + dy * axis[1], p[2]),
            (dx * axis[1] - dy * axis[0]).abs(),
        )
    };
    if points.iter().any(|p| to_uv(*p).1 > eps) {
        return Vec::new();
    }
    let edges: Vec<PlaneEdge> = segments
        .iter()
        .map(|(id, a, b)| (*id, to_uv(*a).0, to_uv(*b).0))
        .collect();
    let meets = |a: (f64, f64), b: (f64, f64)| (a.0 - b.0).abs() <= eps && (a.1 - b.1).abs() <= eps;
    // Chain the lines into one loop: its corners, and the line leaving each.
    let Some(first) = edges.first() else {
        return Vec::new();
    };
    let mut corners = vec![first.1];
    let mut ids = vec![first.0];
    let mut end = first.2;
    let mut used = vec![false; edges.len()];
    used[0] = true;
    for _ in 1..edges.len() {
        let Some((index, next)) = edges.iter().enumerate().find_map(|(index, (_, a, b))| {
            if used[index] {
                None
            } else if meets(*a, end) {
                Some((index, *b))
            } else if meets(*b, end) {
                Some((index, *a))
            } else {
                None
            }
        }) else {
            return Vec::new();
        };
        used[index] = true;
        corners.push(end);
        ids.push(edges[index].0);
        end = next;
    }
    if !meets(end, corners[0]) {
        return Vec::new();
    }
    let count = corners.len();
    let area: f64 = (0..count)
        .map(|i| {
            let (a, b) = (corners[i], corners[(i + 1) % count]);
            a.0 * b.1 - b.0 * a.1
        })
        .sum();
    if area < 0.0 {
        corners = std::iter::once(corners[0])
            .chain(corners[1..].iter().rev().copied())
            .collect();
        ids.reverse();
    }
    let corner = |i: usize| corners[i % count];
    let (u_min, u_max, v_min, v_max) = corners.iter().fold(
        (f64::MAX, f64::MIN, f64::MAX, f64::MIN),
        |(a, b, c, d), (u, v)| (a.min(*u), b.max(*u), c.min(*v), d.max(*v)),
    );
    let (width, height) = (u_max - u_min, v_max - v_min);
    let perimeter = 2.0 * (width + height);
    // Where a point lies along the rectangle's edge, counter-clockwise from
    // its lower left corner; `None` off the edge.
    let along = |(u, v): (f64, f64)| {
        if (v - v_min).abs() <= eps {
            Some(u - u_min)
        } else if (u - u_max).abs() <= eps {
            Some(width + v - v_min)
        } else if (v - v_max).abs() <= eps {
            Some(width + height + u_max - u)
        } else if (u - u_min).abs() <= eps {
            Some(2.0 * width + height + v_max - v)
        } else {
            None
        }
    };
    let on_side = |a: (f64, f64), b: (f64, f64)| {
        [
            (a.1 - v_min, b.1 - v_min),
            (a.0 - u_max, b.0 - u_max),
            (a.1 - v_max, b.1 - v_max),
            (a.0 - u_min, b.0 - u_min),
        ]
        .iter()
        .any(|(x, y)| x.abs() <= eps && y.abs() <= eps)
    };
    let inside: Vec<bool> = (0..count)
        .map(|i| !on_side(corner(i), corner(i + 1)))
        .collect();
    let Some(start) = (0..count).find(|i| !inside[*i] && inside[(i + 1) % count]) else {
        return Vec::new();
    };
    let rectangle = [
        ((u_min, v_min), 0.0),
        ((u_max, v_min), width),
        ((u_max, v_max), width + height),
        ((u_min, v_max), 2.0 * width + height),
    ];
    let mut cuts = Vec::new();
    let mut i = start + 1;
    while i <= start + count {
        if !inside[i % count] {
            i += 1;
            continue;
        }
        let run_start = i;
        while inside[i % count] {
            i += 1;
        }
        let (a, b) = (corner(run_start), corner(i));
        let (Some(at_a), Some(at_b)) = (along(a), along(b)) else {
            return Vec::new();
        };
        let back = (at_b - at_a).rem_euclid(perimeter);
        if back <= eps {
            continue;
        }
        // The run from A to B, then back along the rectangle's edge,
        // clockwise, to A; reversed to run counter-clockwise.
        let mut outline: Vec<(f64, f64)> = (run_start..=i).map(corner).collect();
        let mut passed: Vec<(f64, (f64, f64))> = rectangle
            .iter()
            .map(|(point, at)| ((at_b - at).rem_euclid(perimeter), *point))
            .filter(|(distance, _)| *distance > eps && *distance < back - eps)
            .collect();
        passed.sort_by(|x, y| x.0.total_cmp(&y.0));
        outline.extend(passed.into_iter().map(|(_, point)| point));
        outline.reverse();
        let tag = (run_start..i)
            .map(|edge| ids[edge % count])
            .max()
            .expect("a run holds a line");
        cuts.push((
            tag,
            outline
                .into_iter()
                .map(|(u, v)| [origin[0] + axis[0] * u, origin[1] + axis[1] * u, v])
                .collect(),
        ));
    }
    cuts
}

/// The openings a wall's edited elevation profile cuts, as the partition MVP
/// gives them ([`PROFILE_OPENING_FIELD`]): each one's tag and outline.
// Tracker: B55.
pub fn profile_openings_from_fields(
    fields: &[(String, InstanceField)],
) -> Vec<(u32, Vec<[f64; 3]>)> {
    (0..)
        .map_while(|k| {
            let outline_name = format!("{PROFILE_OPENING_FIELD}_{k}");
            let tag_name = format!("{outline_name}_tag");
            let outline = fields.iter().find_map(|(name, value)| match value {
                InstanceField::Vector(points) if *name == outline_name => Some(points),
                _ => None,
            })?;
            let tag = fields.iter().find_map(|(name, value)| match value {
                InstanceField::ElementId { id, .. } if *name == tag_name => Some(*id),
                _ => None,
            })?;
            let points: Option<Vec<[f64; 3]>> = outline
                .iter()
                .map(|point| {
                    let InstanceField::Vector(values) = point else {
                        return None;
                    };
                    let mut xyz = values.iter().map(|value| match value {
                        InstanceField::Float { value, .. } => Some(*value),
                        _ => None,
                    });
                    Some([xyz.next()??, xyz.next()??, xyz.next()??])
                })
                .collect();
            Some((tag, points?))
        })
        .collect()
}

fn attach_wall_layers(rf: &mut RevitFile, revit_version: u32, walls: &mut [DecodedElement]) {
    use crate::partition_compound_structure as pcs;
    if !pcs::WALL_LINE_SUPPORTED_REVIT_VERSIONS.contains(&revit_version)
        || pcs::layer_layout(revit_version).is_none()
    {
        return;
    }
    // A 2023 wall keeps its record body, cut back at its joins (RE-120),
    // and takes only its layers and exterior side: its location line is not
    // read (RE-114).
    let centreline_bodies = !crate::partition_element_records_2023::is_32bit_release(revit_version);
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let wall_ids: BTreeSet<u32> = walls
        .iter()
        .filter(|wall| type_of(wall).is_some())
        .filter_map(|wall| wall.id)
        .collect();
    if wall_ids.is_empty() {
        return;
    }
    let types: BTreeSet<u32> = walls.iter().filter_map(type_of).collect();
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Some((materials, names)) = materials_and_names(rf, revit_version, &declared) else {
        return;
    };
    let (Ok(layers), Ok(orientations), Ok(lines), Ok(arcs), Ok(appearances), Ok(face_angles)) = (
        pcs::scan_type_layers(rf, revit_version, &types, &materials, &declared),
        pcs::scan_wall_orientations(rf, revit_version, &wall_ids),
        pcs::scan_wall_lines(rf, revit_version, &wall_ids),
        pcs::scan_wall_arcs(rf, revit_version, &wall_ids),
        crate::partition_materials::scan_material_appearances(rf, revit_version, &declared),
        pcs::scan_wall_type_face_angles(rf, revit_version, &types),
    ) else {
        return;
    };
    // W6: each wall's native record, for the walls its ends meet, whether
    // its top is joined to a roof or floor (RE-228), and whether anything
    // joins to or cuts it (RE-266).
    let crate::native_walls::WallRecords {
        walls: native,
        top_joined,
        uncut,
    } = if centreline_bodies {
        let ids: BTreeSet<u64> = wall_ids.iter().map(|&id| u64::from(id)).collect();
        crate::native_walls::native_walls_and_top_joins(rf, &ids).unwrap_or_default()
    } else {
        Default::default()
    };
    for wall in walls.iter_mut() {
        if let Some(joined) = wall.id.and_then(|id| top_joined.get(&u64::from(id))) {
            wall.fields
                .push((WALL_TOP_JOINED_FIELD.into(), InstanceField::Bool(*joined)));
        }
        if wall.id.is_some_and(|id| uncut.contains(&u64::from(id))) {
            wall.fields
                .push((WALL_UNCUT_FIELD.into(), InstanceField::Bool(true)));
        }
        let picked = wall.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(u64::from(*id)),
            _ => None,
        });
        let named = wall
            .id
            .and_then(|id| native.get(&u64::from(id)))
            .and_then(|native| native.type_id);
        if picked.is_some() && picked == named {
            wall.fields
                .push((WALL_TYPE_CONFIRMED_FIELD.into(), InstanceField::Bool(true)));
        }
    }
    // RE-91: a layer that takes its category's material takes the one the
    // document's object styles give walls, where it is set and named.
    let category_material = crate::partition_materials::scan_category_material(
        rf,
        revit_version,
        crate::partition_element_records::OST_WALLS,
    )
    .ok()
    .flatten()
    .filter(|id| names.contains_key(id));
    let layers: BTreeMap<u32, Vec<pcs::CompoundLayer>> = layers
        .into_iter()
        .map(|(type_id, type_layers)| {
            let type_layers = type_layers
                .into_iter()
                .map(|layer| pcs::CompoundLayer {
                    material: layer.material.or(category_material),
                    ..layer
                })
                .collect();
            (type_id, type_layers)
        })
        .collect();
    for wall in walls.iter_mut() {
        let (Some(id), Some(type_id)) = (wall.id, type_of(wall)) else {
            continue;
        };
        // W6: a wall its partition data gives no orientation takes its
        // native record's word and flip, which equal the partition data's on
        // every wall that has both.
        let orientation = orientations
            .get(&id)
            .map(|orientation| (orientation.word, orientation.flip))
            .or_else(|| {
                let wall = native.get(&u64::from(id))?;
                Some((u32::try_from(wall.cross_section?).ok()?, wall.flipped?))
            });
        let (Some(type_layers), Some((word, flip))) = (layers.get(&type_id), orientation) else {
            continue;
        };
        let thickness: f64 = type_layers.iter().map(|layer| layer.width_feet).sum();
        let measured = thickness.is_finite() && thickness > 0.0;
        // RE-86: a wall with word 2 whose type leans only its exterior face
        // is tapered; its line is still its centreline at the top. Only a
        // straight tapered wall is measured.
        let taper = face_angles
            .get(&type_id)
            .filter(|_| word == 2 && lines.contains_key(&id))
            .and_then(|&[first, exterior, third]| {
                (first == 0.0 && third == 0.0 && exterior > 0.0 && exterior < FRAC_PI_4)
                    .then_some(exterior)
            });
        let centred = centreline_bodies && measured && (word == 1 || taper.is_some());
        let float = |value: f64| InstanceField::Float { value, size: 8 };
        // The direction the exterior side is taken from: the line's, or the
        // arc's tangent at its middle (RE-75).
        let (dx, dy) = if let Some(line) = lines.get(&id) {
            let (start, end) = (line.start(), line.end());
            let (dx, dy) = (end[0] - start[0], end[1] - start[1]);
            let length = dx.hypot(dy);
            if !length.is_finite() || length <= 1e-9 {
                continue;
            }
            if centred {
                for (names, point) in [(WALL_AXIS_START_FIELDS, start), (WALL_AXIS_END_FIELDS, end)]
                {
                    for (name, value) in names.iter().zip(point) {
                        wall.fields.push(((*name).into(), float(value)));
                    }
                }
            }
            (dx / length, dy / length)
        } else if let Some(arc) = arcs.get(&id) {
            if arc.x_axis[2].abs() > 1e-9 || arc.y_axis[2].abs() > 1e-9 {
                continue;
            }
            if centred {
                let values = [
                    arc.centre[0],
                    arc.centre[1],
                    arc.radius,
                    arc.start_angle,
                    arc.end_angle,
                    arc.x_axis[0],
                    arc.x_axis[1],
                    arc.y_axis[0],
                    arc.y_axis[1],
                ];
                for (name, value) in WALL_ARC_FIELDS.iter().zip(values) {
                    wall.fields.push(((*name).into(), float(value)));
                }
            }
            let (sin, cos) = ((arc.start_angle + arc.end_angle) * 0.5).sin_cos();
            let tangent = [
                -sin * arc.x_axis[0] + cos * arc.y_axis[0],
                -sin * arc.x_axis[1] + cos * arc.y_axis[1],
            ];
            let length = tangent[0].hypot(tangent[1]);
            if !length.is_finite() || length <= 1e-9 {
                continue;
            }
            (tangent[0] / length, tangent[1] / length)
        } else {
            continue;
        };
        if centred {
            wall.fields
                .push((WALL_TYPE_THICKNESS_FIELD.into(), float(thickness)));
            if let Some(angle) = taper {
                wall.fields
                    .push((WALL_EXTERIOR_FACE_ANGLE_FIELD.into(), float(angle)));
            }
        }
        let exterior = if flip { [dy, -dx] } else { [-dy, dx] };
        let bands = layer_bands_field(type_layers, &appearances, &names);
        if matches!(&bands, InstanceField::Vector(items) if items.is_empty()) {
            continue;
        }
        for (name, value) in WALL_EXTERIOR_FIELDS.iter().zip(exterior) {
            wall.fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
        wall.fields.push((WALL_LAYERS_FIELD.into(), bands));
    }
    // RE-88: a wall its data does not place (no orientation, line or arc)
    // still carries its type's layers, for its materials. With no exterior
    // side they are not drawn.
    for wall in walls.iter_mut() {
        if wall
            .fields
            .iter()
            .any(|(name, _)| name == WALL_LAYERS_FIELD)
        {
            continue;
        }
        let Some(type_layers) = type_of(wall).and_then(|type_id| layers.get(&type_id)) else {
            continue;
        };
        let bands = layer_bands_field(type_layers, &appearances, &names);
        if matches!(&bands, InstanceField::Vector(items) if items.is_empty()) {
            continue;
        }
        wall.fields.push((WALL_LAYERS_FIELD.into(), bands));
    }
    if centreline_bodies {
        attach_wall_butt_joins(rf, revit_version, walls, &layers, &native);
        attach_native_tee_reaches(walls, &native);
        attach_wall_lengths(walls, &native);
    }
}

/// Field holding a wall's Length, feet: its curve's length, where the curve
/// cut back at its joins is as long ([`crate::native_walls::trimmed_ends`],
/// RE-252), so Revit's export gives it either way; on a curtain wall, its
/// curve's length, which Revit's export writes as its
/// `Qto_CurtainWallQuantities.Length` (#1016).
pub const WALL_LENGTH_FIELD: &str = "m_wall_length";

/// Field set on a wall whose native `SWall` record names, in
/// `m_WallAttributesId`, the type rvt-rs picks for it ([`TYPE_ID_FIELD`]):
/// the wall's type as its saved file states it (RE-253). The export's
/// diagnostics list these walls for the quantity census.
pub const WALL_TYPE_CONFIRMED_FIELD: &str = "m_wall_type_confirmed";

/// Field holding the length of a wall's native curve, feet, on every wall with
/// a centreline whose native curve is the same line (RE-252): one of the two
/// lengths Revit's export may write as its `Length`. The export's diagnostics
/// list it (`wall_curve_lengths_feet`), not its IFC file, for the census to
/// compare with the other, Revit's own cut-back `Axis`, and count apart a
/// wall whose two lengths differ (the maintainer, 2026-10-26 and 2026-10-27).
pub const WALL_CURVE_LENGTH_FIELD: &str = "m_wall_curve_length";

/// Give each wall with a centreline whose native curve, cut back where its
/// body meets the walls joined at its ends, is as long as the curve, that
/// length ([`WALL_LENGTH_FIELD`]): the centreline's length, which Revit's
/// export writes as its `Length` whether it measures the curve or the cut
/// back curve (RE-252). The reach each end's join lists give
/// ([`WALL_JOIN_REACH_FIELDS`], or the largest of its layers' where they end
/// apart) is the second reading the record's must agree with.
fn attach_wall_lengths(
    walls: &mut [DecodedElement],
    native: &BTreeMap<u64, crate::native_walls::NativeWall>,
) {
    const SAME_LENGTH_FEET: f64 = 1e-4;
    let joined = crate::native_walls::joined_at_ends(native);
    let near = |a: [f64; 2], b: [f64; 2]| {
        (a[0] - b[0]).hypot(a[1] - b[1]) <= NATIVE_WALL_LINE_TOLERANCE_FEET
    };
    for wall in walls.iter_mut() {
        let Some(id) = wall.id.map(u64::from) else {
            continue;
        };
        if wall.class == CURTAIN_WALL_CLASS {
            if let Some(curve) = native.get(&id) {
                let length = (curve.end[0] - curve.start[0]).hypot(curve.end[1] - curve.start[1]);
                if length.is_finite() && length > 0.0 {
                    wall.fields.push((
                        WALL_LENGTH_FIELD.into(),
                        InstanceField::Float {
                            value: length,
                            size: 8,
                        },
                    ));
                }
            }
            continue;
        }
        let (Some(axis), Some(curve)) = (wall_axis_from_fields(&wall.fields), native.get(&id))
        else {
            continue;
        };
        let ends = if near(curve.start, axis.start) && near(curve.end, axis.end) {
            [0, 1]
        } else if near(curve.start, axis.end) && near(curve.end, axis.start) {
            [1, 0]
        } else {
            continue;
        };
        let reach_of = |slot: usize| {
            wall.fields.iter().find_map(|(name, value)| match value {
                InstanceField::Float { value, .. } if name == WALL_JOIN_REACH_FIELDS[slot] => {
                    Some(*value)
                }
                _ => None,
            })
        };
        let layer_reach_of = |slot: usize| {
            wall.fields.iter().find_map(|(name, value)| match value {
                InstanceField::Vector(items) if name == WALL_JOIN_LAYER_REACH_FIELDS[slot] => items
                    .iter()
                    .map(|item| match item {
                        InstanceField::Float { value, .. } => Some(*value),
                        _ => None,
                    })
                    .collect::<Option<Vec<f64>>>()?
                    .into_iter()
                    .max_by(|a, b| a.abs().total_cmp(&b.abs())),
                _ => None,
            })
        };
        let mut reaches = [None, None];
        for (slot, end) in ends.into_iter().enumerate() {
            reaches[end] = reach_of(slot).or_else(|| layer_reach_of(slot));
        }
        let curve_length = (curve.end[0] - curve.start[0]).hypot(curve.end[1] - curve.start[1]);
        if curve_length.is_finite() && curve_length > 0.0 {
            wall.fields.push((
                WALL_CURVE_LENGTH_FIELD.into(),
                InstanceField::Float {
                    value: curve_length,
                    size: 8,
                },
            ));
        }
        let Some([start, end]) = crate::native_walls::trimmed_ends(id, native, &joined, reaches)
        else {
            continue;
        };
        let length = (curve.end[0] - curve.start[0]).hypot(curve.end[1] - curve.start[1]);
        if ((end - start) - length).abs() <= SAME_LENGTH_FEET && length.is_finite() && length > 0.0
        {
            wall.fields.push((
                WALL_LENGTH_FIELD.into(),
                InstanceField::Float {
                    value: length,
                    size: 8,
                },
            ));
        }
    }
}

/// How close a wall's native curve's ends must be to its centreline's to be
/// taken as the same line, feet.
const NATIVE_WALL_LINE_TOLERANCE_FEET: f64 = 1e-4;

/// At each end of a wall with a centreline where its native record says
/// another wall meets that end with its middle, the body stops half that
/// wall's thickness short ([`crate::native_walls::tee_reach`], RE-222),
/// in place of the reach its join lists give. An end whose layers each end
/// on their own line (RE-71, RE-74) keeps them, and so does one whose other
/// wall's thickness is not known: its type's, or its record box's thin
/// extent where it runs along a model axis.
fn attach_native_tee_reaches(
    walls: &mut [DecodedElement],
    native: &BTreeMap<u64, crate::native_walls::NativeWall>,
) {
    // A wall's type thickness, or, for a wall along a model axis, its record
    // box's thin extent, which is its thickness there (RE-26).
    let along_axis = |id: u64| {
        native.get(&id).is_some_and(|curve| {
            let (dx, dy) = (curve.end[0] - curve.start[0], curve.end[1] - curve.start[1]);
            dx.abs() <= 1e-9 || dy.abs() <= 1e-9
        })
    };
    let thickness: BTreeMap<u64, f64> = walls
        .iter()
        .filter_map(|wall| {
            let id = u64::from(wall.id?);
            let float = |wanted: &str| {
                wall.fields.iter().find_map(|(name, value)| match value {
                    InstanceField::Float { value, .. } if name == wanted => Some(*value),
                    _ => None,
                })
            };
            let thickness = float(WALL_TYPE_THICKNESS_FIELD).or_else(|| {
                float(crate::element_record_wall_joins::WALL_THICKNESS_FIELD)
                    .filter(|_| along_axis(id))
            })?;
            Some((id, thickness))
        })
        .collect();
    let near = |a: [f64; 2], b: [f64; 2]| {
        (a[0] - b[0]).hypot(a[1] - b[1]) <= NATIVE_WALL_LINE_TOLERANCE_FEET
    };
    for wall in walls.iter_mut() {
        let Some(id) = wall.id.map(u64::from) else {
            continue;
        };
        let (Some(axis), Some(curve)) = (wall_axis_from_fields(&wall.fields), native.get(&id))
        else {
            continue;
        };
        let ends = if near(curve.start, axis.start) && near(curve.end, axis.end) {
            [0, 1]
        } else if near(curve.start, axis.end) && near(curve.end, axis.start) {
            [1, 0]
        } else {
            continue;
        };
        for (slot, end) in ends.into_iter().enumerate() {
            let layered = [
                WALL_JOIN_LAYER_REACH_FIELDS[slot],
                WALL_JOIN_LAYER_EDGE_REACH_FIELDS[slot],
            ];
            if wall
                .fields
                .iter()
                .any(|(name, _)| layered.contains(&name.as_str()))
            {
                continue;
            }
            if let Some(reach) = crate::native_walls::tee_reach(id, end, native, |other| {
                thickness.get(&other).copied()
            }) {
                wall.fields
                    .retain(|(name, _)| name != WALL_JOIN_REACH_FIELDS[slot]);
                wall.fields.push((
                    WALL_JOIN_REACH_FIELDS[slot].into(),
                    InstanceField::Float {
                        value: reach,
                        size: 8,
                    },
                ));
            }
        }
    }
}

/// Give each wall with a centreline the wall it butt-joins at each end and
/// whether it runs through there, where its and its partner's join lists
/// decide it, and, between single-layer walls, how far past the end its
/// body reaches ([`crate::element_record_wall_joins::butt_joins`], RE-70).
fn attach_wall_butt_joins(
    rf: &mut RevitFile,
    revit_version: u32,
    walls: &mut [DecodedElement],
    type_layers: &BTreeMap<u32, Vec<crate::partition_compound_structure::CompoundLayer>>,
    native: &BTreeMap<u64, crate::native_walls::NativeWall>,
) {
    use crate::element_record_wall_joins as joins;
    let float = |wall: &DecodedElement, wanted: &str| {
        wall.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let lines: Vec<joins::WallLine> = walls
        .iter()
        .filter_map(|wall| {
            let axis = wall_axis_from_fields(&wall.fields)?;
            let base = float(wall, "m_locationZ")?;
            let type_id = wall.fields.iter().find_map(|(name, value)| match value {
                InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
                _ => None,
            })?;
            let layers: Vec<(f64, u32)> = type_layers
                .get(&type_id)?
                .iter()
                .filter(|layer| layer.width_feet > 0.0)
                .map(|layer| (layer.width_feet, layer.function))
                .collect();
            let [Some(ex), Some(ey)] = WALL_EXTERIOR_FIELDS.map(|name| float(wall, name)) else {
                return None;
            };
            Some(joins::WallLine {
                element_id: wall.id?,
                start: axis.start,
                end: axis.end,
                thickness_feet: axis.thickness_feet,
                layers,
                exterior: [ex, ey],
                base_feet: base,
                top_feet: base + float(wall, "m_bboxHeight")?,
                shells: native
                    .get(&u64::from(wall.id?))
                    .and_then(|native| native.shells),
            })
        })
        .collect();
    if lines.len() < 2 {
        return;
    }
    let every: BTreeSet<u32> = walls.iter().filter_map(|wall| wall.id).collect();
    let read: BTreeSet<u32> = lines.iter().map(|line| line.element_id).collect();
    let Ok(partners) = crate::partition_compound_structure::scan_wall_join_partners(
        rf,
        revit_version,
        &every,
        &read,
    ) else {
        return;
    };
    // RE-127: the joined-wall lists decide the L joints the join lists do not.
    let joined = crate::partition_compound_structure::scan_wall_joined_entries(
        rf,
        revit_version,
        &every,
        &read,
    )
    .unwrap_or_default();
    let found = joins::butt_joins(&lines, &partners, &joined);
    for wall in walls.iter_mut() {
        let Some(ends) = wall.id.and_then(|id| found.get(&id)) else {
            continue;
        };
        for (slot, join) in ends.iter().enumerate() {
            let Some(join) = join else {
                continue;
            };
            wall.fields.push((
                WALL_JOIN_PARTNER_FIELDS[slot].into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: join.partner,
                },
            ));
            wall.fields.push((
                WALL_JOIN_THROUGH_FIELDS[slot].into(),
                InstanceField::Bool(join.runs_through),
            ));
            if let Some(reach) = join.reach_feet {
                wall.fields.push((
                    WALL_JOIN_REACH_FIELDS[slot].into(),
                    InstanceField::Float {
                        value: reach,
                        size: 8,
                    },
                ));
            }
            if let Some(edges) = &join.layer_edge_reach_feet {
                wall.fields.push((
                    WALL_JOIN_LAYER_EDGE_REACH_FIELDS[slot].into(),
                    InstanceField::Vector(
                        edges
                            .iter()
                            .flatten()
                            .map(|value| InstanceField::Float {
                                value: *value,
                                size: 8,
                            })
                            .collect(),
                    ),
                ));
            }
            if let Some(reaches) = &join.layer_reach_feet {
                wall.fields.push((
                    WALL_JOIN_LAYER_REACH_FIELDS[slot].into(),
                    InstanceField::Vector(
                        reaches
                            .iter()
                            .map(|value| InstanceField::Float {
                                value: *value,
                                size: 8,
                            })
                            .collect(),
                    ),
                ));
            }
        }
    }
}

/// Fields holding where a stair run's sketch starts, model feet (RE-52).
pub const STAIR_RUN_ORIGIN_FIELDS: [&str; 3] = [
    "m_stair_run_origin_x",
    "m_stair_run_origin_y",
    "m_stair_run_origin_z",
];
/// Fields holding the unit plan direction a stair run climbs in (RE-52).
pub const STAIR_RUN_CLIMB_FIELDS: [&str; 2] = ["m_stair_run_climb_x", "m_stair_run_climb_y"];
/// Fields holding the unit plan direction across a stair run (RE-52).
pub const STAIR_RUN_ACROSS_FIELDS: [&str; 2] = ["m_stair_run_across_x", "m_stair_run_across_y"];
/// Field holding a stair run's width, feet (RE-52).
pub const STAIR_RUN_WIDTH_FIELD: &str = "m_stair_run_width";
/// Field holding a stair run's side view, `[along, up]` feet from its
/// sketch origin (RE-52).
pub const STAIR_RUN_PROFILE_FIELD: &str = "m_stair_run_profile";
/// Field carrying the side views of a run's further solids, after the first
/// in [`STAIR_RUN_PROFILE_FIELD`]: a riserless run's treads (#357).
pub const STAIR_RUN_PIECES_FIELD: &str = "m_stair_run_pieces";
/// Field holding the distance along a stair run's climb from its first
/// riser line to its last, feet: its flight's `Length` as Revit's export
/// gives it, with or without a riser at its top (#1016, RE-247).
pub const STAIR_RUN_LENGTH_FIELD: &str = "m_stair_run_length";

/// A stair run's treads and risers as [`STAIR_RUN_PROFILE_FIELD`] and its
/// companions record them (RE-52).
#[derive(Debug, Clone, PartialEq)]
pub struct StairRunBody {
    /// Where the run's sketch starts, model feet.
    pub origin: [f64; 3],
    /// Unit plan direction the run climbs in.
    pub climb: [f64; 2],
    /// Unit plan direction across the run.
    pub across: [f64; 2],
    /// Feet.
    pub width_feet: f64,
    /// Side view, `[along, up]` feet from `origin`, counter-clockwise.
    pub profile: Vec<[f64; 2]>,
    /// The side views of the run's further solids, where it is several
    /// (a riserless run's treads, #357); empty for one.
    pub pieces: Vec<Vec<[f64; 2]>>,
}

/// The run body recorded in `fields`, when every part of it is.
pub fn stair_run_body_from_fields(fields: &[(String, InstanceField)]) -> Option<StairRunBody> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let ring = |points: &[InstanceField]| {
        points
            .iter()
            .map(|point| match point {
                InstanceField::Vector(pair) => match pair.as_slice() {
                    [
                        InstanceField::Float { value: u, .. },
                        InstanceField::Float { value: z, .. },
                    ] => Some([*u, *z]),
                    _ => None,
                },
                _ => None,
            })
            .collect::<Option<Vec<[f64; 2]>>>()
    };
    let profile = fields.iter().find_map(|(name, value)| match value {
        InstanceField::Vector(points) if name == STAIR_RUN_PROFILE_FIELD => ring(points),
        _ => None,
    })?;
    let pieces = match fields
        .iter()
        .find(|(name, _)| name == STAIR_RUN_PIECES_FIELD)
    {
        Some((_, InstanceField::Vector(rings))) => rings
            .iter()
            .map(|r| match r {
                InstanceField::Vector(points) => ring(points).filter(|p| p.len() >= 3),
                _ => None,
            })
            .collect::<Option<Vec<_>>>()?,
        Some(_) => return None,
        None => Vec::new(),
    };
    let [ox, oy, oz] = STAIR_RUN_ORIGIN_FIELDS.map(float);
    let [cx, cy] = STAIR_RUN_CLIMB_FIELDS.map(float);
    let [ax, ay] = STAIR_RUN_ACROSS_FIELDS.map(float);
    Some(StairRunBody {
        origin: [ox?, oy?, oz?],
        climb: [cx?, cy?],
        across: [ax?, ay?],
        width_feet: float(STAIR_RUN_WIDTH_FIELD)?,
        profile: (profile.len() >= 3).then_some(profile)?,
        pieces,
    })
}

/// Give each straight stair run with separate treads and risers its side
/// view, from the plan sketch in its own data, its run type and its
/// stair's riser height (RE-52, [`crate::partition_stairs`]), and each run
/// whose run type reads that type's id and name. A run ending with a tread
/// has one riser line more than risers (RE-92); a run whose riser lines do
/// not number its risers so is left to its record box.
fn attach_stair_run_bodies(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_stairs as ps;
    use crate::partition_type_records as ptr;
    if !ps::supports_revit_version(revit_version) {
        if crate::native_stairs::NATIVE_RUN_REVIT_VERSIONS.contains(&revit_version) {
            attach_native_stair_run_bodies(rf, revit_version, products);
        }
        return;
    }
    let float = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let integer = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Integer { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let run_indices: Vec<usize> = products
        .iter()
        .enumerate()
        .filter(|(_, element)| element.class == "StairsRun" && element.id.is_some())
        .map(|(index, _)| index)
        .collect();
    if run_indices.is_empty() {
        return;
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let type_records = ptr::scan_type_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_STAIRS_RUNS,
        &declared,
    )
    .unwrap_or_default();
    let run_types = ptr::type_definition_ids(&type_records);
    let mut type_of: BTreeMap<usize, u32> = BTreeMap::new();
    for &index in &run_indices {
        if let Some((references, _)) = record_references(rf, &products[index]) {
            if let Some(type_id) = ptr::unique_type_reference(&references, &run_types) {
                type_of.insert(index, type_id);
            }
        }
    }
    let run_ids: BTreeSet<u32> = run_indices
        .iter()
        .filter_map(|&index| products[index].id)
        .collect();
    let type_ids: BTreeSet<u32> = type_of.values().copied().collect();
    let (Ok(lines), Ok(types)) = (
        ps::scan_run_lines(rf, revit_version, &run_ids),
        ps::scan_run_types(rf, revit_version, &type_ids),
    ) else {
        return;
    };
    let sketches: BTreeMap<u32, ps::RunSketch> = lines
        .iter()
        .filter_map(|(&id, lines)| Some((id, ps::run_sketch(lines)?)))
        .collect();
    let ends = ps::scan_run_ends(rf, revit_version, &sketches).unwrap_or_default();
    // Where each run's underside is cut, from its native record (#357); a
    // run that does not give it is cut at its base, as RE-92 measured.
    let base_cuts = crate::native_stairs::native_run_base_cuts(
        rf,
        &sketches.keys().map(|&id| u64::from(id)).collect(),
    )
    .unwrap_or_default();
    for index in run_indices {
        let element = &mut products[index];
        let Some(run_type) = type_of.get(&index).and_then(|id| types.get(id)) else {
            continue;
        };
        let has_type_name = element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_NAME_FIELD);
        if let (Some(name), false) = (&run_type.name, has_type_name) {
            element.fields.push((
                TYPE_ID_FIELD.into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: type_of[&index],
                },
            ));
            element
                .fields
                .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
        }
        element.fields.push((
            STAIR_NOSING_LENGTH_FIELD.into(),
            InstanceField::Float {
                value: run_type.nosing_length_feet,
                size: 8,
            },
        ));
        let (Some(riser_height), Some(risers)) = (
            float(element, STAIR_RISER_HEIGHT_FIELD),
            integer(element, STAIR_RISER_COUNT_FIELD),
        ) else {
            continue;
        };
        let run_ends = element.id.and_then(|id| ends.get(&id)).copied();
        if let Some(run_ends) = run_ends {
            let treads = risers - 1
                + i64::from(!run_ends.begin_with_riser)
                + i64::from(!run_ends.end_with_riser);
            element.fields.push((
                STAIR_TREAD_COUNT_FIELD.into(),
                InstanceField::Integer {
                    value: treads,
                    signed: false,
                    size: 4,
                },
            ));
        }
        let end_with_riser = run_ends.map(|ends| ends.end_with_riser);
        let riser_lines = risers + i64::from(end_with_riser == Some(false));
        let Some(mut sketch) = element
            .id
            .and_then(|id| sketches.get(&id))
            .filter(|sketch| i64::try_from(sketch.risers.len()) == Ok(riser_lines))
            .cloned()
        else {
            continue;
        };
        if let Some(cut) = element.id.and_then(|id| base_cuts.get(&u64::from(id))) {
            sketch.base_cut_feet = *cut;
        }
        let Some(pieces) = ps::run_side_pieces(&sketch, run_type, riser_height, end_with_riser)
        else {
            continue;
        };
        push_stair_run_body(element, &sketch, &pieces);
    }
}

/// Give each stair the nosing length every one of its runs has, where they
/// all have one and it is the same: revit-ifc's `NosingLengthCalculator`
/// (CLEANROOM.md source 5) takes a stair's from the type of its first run.
fn attach_stair_nosing_lengths(products: &mut [DecodedElement]) {
    let float = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let whole_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == AGGREGATE_WHOLE_FIELD => Some(*id),
            _ => None,
        })
    };
    let mut lengths: BTreeMap<u32, Vec<Option<f64>>> = BTreeMap::new();
    for element in products.iter().filter(|e| e.class == "StairsRun") {
        if let Some(stair) = whole_of(element) {
            lengths
                .entry(stair)
                .or_default()
                .push(float(element, STAIR_NOSING_LENGTH_FIELD));
        }
    }
    for element in products.iter_mut().filter(|e| e.class == "Stair") {
        let Some(found) = element.id.and_then(|id| lengths.get(&id)) else {
            continue;
        };
        let Some(Some(first)) = found.first().copied() else {
            continue;
        };
        if found.iter().all(|length| *length == Some(first)) {
            element.fields.push((
                STAIR_NOSING_LENGTH_FIELD.into(),
                InstanceField::Float {
                    value: first,
                    size: 8,
                },
            ));
        }
    }
}

/// Record a run's sketch and side view in its fields, where
/// [`stair_run_body_from_fields`] reads them (RE-52).
fn push_stair_run_body(
    element: &mut DecodedElement,
    sketch: &crate::partition_stairs::RunSketch,
    pieces: &[Vec<[f64; 2]>],
) {
    let scalar = |value: f64| InstanceField::Float { value, size: 8 };
    let ring = |points: &[[f64; 2]]| {
        InstanceField::Vector(
            points
                .iter()
                .map(|&[u, z]| InstanceField::Vector(vec![scalar(u), scalar(z)]))
                .collect(),
        )
    };
    let Some((profile, rest)) = pieces.split_first() else {
        return;
    };
    for (name, value) in STAIR_RUN_ORIGIN_FIELDS.iter().zip(sketch.origin) {
        element.fields.push(((*name).into(), scalar(value)));
    }
    for (name, value) in STAIR_RUN_CLIMB_FIELDS.iter().zip(sketch.climb) {
        element.fields.push(((*name).into(), scalar(value)));
    }
    for (name, value) in STAIR_RUN_ACROSS_FIELDS.iter().zip(sketch.across) {
        element.fields.push(((*name).into(), scalar(value)));
    }
    element
        .fields
        .push((STAIR_RUN_WIDTH_FIELD.into(), scalar(sketch.width_feet)));
    element
        .fields
        .push((STAIR_RUN_PROFILE_FIELD.into(), ring(profile)));
    if let Some(&last) = sketch.risers.last() {
        element
            .fields
            .push((STAIR_RUN_LENGTH_FIELD.into(), scalar(last)));
    }
    if !rest.is_empty() {
        element.fields.push((
            STAIR_RUN_PIECES_FIELD.into(),
            InstanceField::Vector(rest.iter().map(|r| ring(r)).collect()),
        ));
    }
}

/// Give each Revit 2025 stair run the treads and risers its native records
/// describe (#357, RE-217): its own run type, the one `OST_StairsRuns` type
/// definition its element record's reference list names (RE-28), as
/// [`attach_stair_run_bodies`] reads it on Revit 2024; its sketch and that
/// type's construction from [`crate::native_stairs::native_runs`]; drawn as
/// RE-92 draws a 2024 run ([`crate::partition_stairs::run_side_profile`]). A
/// run whose record names no one run type, whose records do not give its
/// sketch, or whose type the profile does not draw, keeps its box.
fn attach_native_stair_run_bodies(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_type_records as ptr;
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let type_records = ptr::scan_type_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_STAIRS_RUNS,
        &declared,
    )
    .unwrap_or_default();
    let run_types = ptr::type_definition_ids(&type_records);
    let mut runs: BTreeMap<u64, u64> = BTreeMap::new();
    for element in products
        .iter()
        .filter(|element| element.class == "StairsRun")
    {
        let (Some(id), Some((references, _))) = (element.id, record_references(rf, element)) else {
            continue;
        };
        if let Some(type_id) = ptr::unique_type_reference(&references, &run_types) {
            runs.insert(u64::from(id), u64::from(type_id));
        }
    }
    let Ok(native) = crate::native_stairs::native_runs(rf, &runs) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "StairsRun")
    {
        let Some(run) = element.id.and_then(|id| native.get(&u64::from(id))) else {
            continue;
        };
        element.fields.push((
            STAIR_NOSING_LENGTH_FIELD.into(),
            InstanceField::Float {
                value: run.run_type.nosing_length_feet,
                size: 8,
            },
        ));
        let Some(pieces) = crate::partition_stairs::run_side_pieces(
            &run.sketch,
            &run.run_type,
            run.riser_height_feet,
            run.end_with_riser,
        ) else {
            continue;
        };
        let has_type_name = element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_NAME_FIELD);
        if let (Some(name), false, Ok(type_id)) = (
            &run.run_type.name,
            has_type_name,
            u32::try_from(run.type_id),
        ) {
            element.fields.push((
                TYPE_ID_FIELD.into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: type_id,
                },
            ));
            element
                .fields
                .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
        }
        push_stair_run_body(element, &run.sketch, &pieces);
    }
}

/// Fields holding a spiral run's centre, model feet (#357).
pub const SPIRAL_RUN_CENTRE_FIELDS: [&str; 2] = ["m_spiral_run_centre_x", "m_spiral_run_centre_y"];
/// Fields holding a spiral run's inner and outer radius, feet (#357).
pub const SPIRAL_RUN_RADII_FIELDS: [&str; 2] =
    ["m_spiral_run_inner_radius", "m_spiral_run_outer_radius"];
/// Field holding a spiral run's treads, each `[bottom, top, down-run angle,
/// up-run angle at the outer radius, up-run angle at the inner radius]`, feet
/// and radians about the centre (#357).
pub const SPIRAL_RUN_TREADS_FIELD: &str = "m_spiral_run_treads";

/// One tread of a [`SpiralRunBody`]: its bottom and top, feet, the angle of
/// the riser line it starts at, below, and the angles at which its other edge
/// meets the outer and inner circles, radians about the centre.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SpiralTreadBody {
    pub bottom_feet: f64,
    pub top_feet: f64,
    pub down_angle: f64,
    pub up_angles: [f64; 2],
}

/// A spiral run's treads as [`SPIRAL_RUN_TREADS_FIELD`] and its companions
/// record them (#357).
#[derive(Debug, Clone, PartialEq)]
pub struct SpiralRunBody {
    pub centre: [f64; 2],
    /// Inner and outer radius, feet.
    pub radii_feet: [f64; 2],
    pub treads: Vec<SpiralTreadBody>,
}

/// The spiral run body recorded in `fields`, when every part of it is.
pub fn spiral_run_body_from_fields(fields: &[(String, InstanceField)]) -> Option<SpiralRunBody> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let treads = fields.iter().find_map(|(name, value)| match value {
        InstanceField::Vector(treads) if name == SPIRAL_RUN_TREADS_FIELD => Some(treads),
        _ => None,
    })?;
    let treads = treads
        .iter()
        .map(|tread| {
            let InstanceField::Vector(values) = tread else {
                return None;
            };
            let values: Vec<f64> = values
                .iter()
                .map(|value| match value {
                    InstanceField::Float { value, .. } => Some(*value),
                    _ => None,
                })
                .collect::<Option<_>>()?;
            match values.as_slice() {
                [bottom, top, down, outer, inner] => Some(SpiralTreadBody {
                    bottom_feet: *bottom,
                    top_feet: *top,
                    down_angle: *down,
                    up_angles: [*outer, *inner],
                }),
                _ => None,
            }
        })
        .collect::<Option<Vec<_>>>()?;
    let [cx, cy] = SPIRAL_RUN_CENTRE_FIELDS.map(float);
    let [r0, r1] = SPIRAL_RUN_RADII_FIELDS.map(float);
    (!treads.is_empty()).then_some(SpiralRunBody {
        centre: [cx?, cy?],
        radii_feet: [r0?, r1?],
        treads,
    })
}

/// The angle past a riser line, about a spiral's centre, at which a line
/// parallel to it at `offset` feet meets the circle of `radius`.
fn offset_angle(radius: f64, offset: f64) -> Option<f64> {
    (radius > offset && offset >= 0.0).then(|| (offset / radius).asin())
}

/// Give each spiral stair run of a type with treads and no risers, not
/// monolithic, its treads (#357), from its native records
/// ([`crate::native_stairs::native_spiral_runs`]) and its own run type, the
/// one `OST_StairsRuns` type definition its element record names (RE-28).
/// Each tread is an annular sector between the run's two radii, from the
/// riser line it starts at to the next, its top the tread's own, its type's
/// tread thickness deep. On the BIM4LCA office's run 3057703, a mirrored run
/// climbing clockwise, Revit's export runs each tread on past the next riser
/// line, under the tread above, to a line parallel to it at the type's
/// nosing length; a run with a nosing that is not measured so keeps its box.
fn attach_spiral_run_bodies(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_type_records as ptr;
    if !crate::native_stairs::NATIVE_SPIRAL_RUN_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let unbodied: Vec<usize> = products
        .iter()
        .enumerate()
        .filter(|(_, element)| {
            element.class == "StairsRun"
                && element.id.is_some()
                && !element
                    .fields
                    .iter()
                    .any(|(name, _)| name == STAIR_RUN_PROFILE_FIELD)
        })
        .map(|(index, _)| index)
        .collect();
    if unbodied.is_empty() {
        return;
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let type_records = ptr::scan_type_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_STAIRS_RUNS,
        &declared,
    )
    .unwrap_or_default();
    let run_types = ptr::type_definition_ids(&type_records);
    let mut runs: BTreeMap<u64, u64> = BTreeMap::new();
    for &index in &unbodied {
        let element = &products[index];
        let (Some(id), Some((references, _))) = (element.id, record_references(rf, element)) else {
            continue;
        };
        if let Some(type_id) = ptr::unique_type_reference(&references, &run_types) {
            runs.insert(u64::from(id), u64::from(type_id));
        }
    }
    let Ok(spirals) = crate::native_stairs::native_spiral_runs(rf, &runs) else {
        return;
    };
    let scalar = |value: f64| InstanceField::Float { value, size: 8 };
    for index in unbodied {
        let element = &mut products[index];
        let Some(run) = element.id.and_then(|id| spirals.get(&u64::from(id))) else {
            continue;
        };
        let kind = &run.run_type;
        if !(kind.treads && !kind.risers && !kind.monolithic && kind.tread_thickness_feet > 0.0) {
            continue;
        }
        // The way round the run climbs: towards smaller angles when the
        // second tread lies at smaller angles than the first.
        let clockwise = run.treads.windows(2).next().is_some_and(|pair| {
            let turn = std::f64::consts::TAU;
            let d = pair[1].angles[0] - pair[0].angles[0];
            d - turn * (d / turn).round() < 0.0
        });
        let nosing = kind.nosing_length_feet;
        if nosing > 0.0 && !(run.mirrored && clockwise) {
            continue;
        }
        let [r0, r1] = run.radii_feet;
        let (Some(inner), Some(outer)) = (offset_angle(r0, nosing), offset_angle(r1, nosing))
        else {
            continue;
        };
        let sign = if clockwise { -1.0 } else { 1.0 };
        let treads: Vec<InstanceField> = run
            .treads
            .iter()
            .map(|tread| {
                let [a0, a1] = tread.angles;
                let (down, up) = if clockwise { (a1, a0) } else { (a0, a1) };
                InstanceField::Vector(vec![
                    scalar(tread.top_feet - kind.tread_thickness_feet),
                    scalar(tread.top_feet),
                    scalar(down),
                    scalar(up + sign * outer),
                    scalar(up + sign * inner),
                ])
            })
            .collect();
        let has_type_name = element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_NAME_FIELD);
        if let (Some(name), false, Ok(type_id)) =
            (&kind.name, has_type_name, u32::try_from(run.type_id))
        {
            element.fields.push((
                TYPE_ID_FIELD.into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: type_id,
                },
            ));
            element
                .fields
                .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
        }
        for (name, value) in SPIRAL_RUN_CENTRE_FIELDS.iter().zip(run.centre) {
            element.fields.push(((*name).into(), scalar(value)));
        }
        for (name, value) in SPIRAL_RUN_RADII_FIELDS.iter().zip(run.radii_feet) {
            element.fields.push(((*name).into(), scalar(value)));
        }
        element.fields.push((
            SPIRAL_RUN_TREADS_FIELD.into(),
            InstanceField::Vector(treads),
        ));
    }
}

/// Bottom, feet, of a stair landing's body (#824): its type's thickness
/// below its top. The landing's own fields (`m_locationZ`, `m_bboxHeight`)
/// keep its record box, which spans its stair's storey.
pub const LANDING_BODY_BOTTOM_FIELD: &str = "m_landing_body_bottom";
/// Top, feet, of a stair landing's body (#824).
pub const LANDING_BODY_TOP_FIELD: &str = "m_landing_body_top";
/// [`crate::element_record_plan_profiles::PLAN_PROFILE_SOURCE_FIELD`] of a
/// landing outline read from the lines in its own element data (#824).
pub const LANDING_OUTLINE_SOURCE: &str = "partition_landing_lines";

/// Field holding a tread landing's outline (#824): each curve `[0, start x,
/// start y, end x, end y]` for a line or `[1, start, middle, end]` for an
/// arc through its middle point, model feet, in loop order.
pub const LANDING_TREAD_OUTLINE_FIELD: &str = "m_landing_tread_outline";
/// Field holding a tread landing's underside, feet (#824).
pub const LANDING_TREAD_BOTTOM_FIELD: &str = "m_landing_tread_bottom";
/// Field holding a tread landing's top, feet (#824).
pub const LANDING_TREAD_TOP_FIELD: &str = "m_landing_tread_top";

/// A tread landing as [`LANDING_TREAD_OUTLINE_FIELD`] and its companions
/// record it (#824).
#[derive(Debug, Clone, PartialEq)]
pub struct LandingTreadBody {
    pub outline: Vec<crate::native_stairs::LandingCurve>,
    pub bottom_feet: f64,
    pub top_feet: f64,
}

/// The tread landing body recorded in `fields`, when every part of it is.
pub fn landing_tread_body_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<LandingTreadBody> {
    use crate::native_stairs::LandingCurve;
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let curves = fields.iter().find_map(|(name, value)| match value {
        InstanceField::Vector(curves) if name == LANDING_TREAD_OUTLINE_FIELD => Some(curves),
        _ => None,
    })?;
    let outline = curves
        .iter()
        .map(|curve| {
            let InstanceField::Vector(values) = curve else {
                return None;
            };
            let values: Vec<f64> = values
                .iter()
                .map(|value| match value {
                    InstanceField::Float { value, .. } => Some(*value),
                    _ => None,
                })
                .collect::<Option<_>>()?;
            match values.as_slice() {
                [kind, ax, ay, bx, by] if *kind == 0.0 => {
                    Some(LandingCurve::Line([*ax, *ay], [*bx, *by]))
                }
                [kind, ax, ay, mx, my, bx, by] if *kind == 1.0 => {
                    Some(LandingCurve::Arc([*ax, *ay], [*mx, *my], [*bx, *by]))
                }
                _ => None,
            }
        })
        .collect::<Option<Vec<_>>>()?;
    let (bottom_feet, top_feet) = (
        float(LANDING_TREAD_BOTTOM_FIELD)?,
        float(LANDING_TREAD_TOP_FIELD)?,
    );
    (outline.len() >= 3 && top_feet > bottom_feet).then_some(LandingTreadBody {
        outline,
        bottom_feet,
        top_feet,
    })
}
/// How closely a landing's lines must lie at its top and meet each other,
/// feet. Its outline and slab must lie in its record box to
/// [`SKETCH_BOX_TOLERANCE_FEET`], as a sketched outline must.
pub const LANDING_LINE_TOLERANCE_FEET: f64 = 1e-6;

/// The plan outline a landing's own lines at `top_feet` make (#824): the
/// chains of lines that meet end to end, each joined to the chain with the
/// end nearest where the outline has reached by a straight edge, and closed
/// back to the first point. On the
/// BIM4LCA office a landing's lines at its top stop where its flights meet
/// it, and Revit's outline runs straight across there: the outline is
/// Revit's within 0.001 ft on all 21 monolithic landings. `None` for fewer
/// than three lines, or an outline that crosses itself or has no area.
fn landing_outline(
    lines: &[crate::partition_beam_axes::BoundedLine],
    top_feet: f64,
) -> Option<Vec<[f64; 2]>> {
    const TOL: f64 = LANDING_LINE_TOLERANCE_FEET;
    let gap = |a: [f64; 2], b: [f64; 2]| (a[0] - b[0]).hypot(a[1] - b[1]);
    let mut remaining: Vec<([f64; 2], [f64; 2])> = lines
        .iter()
        .filter_map(|line| {
            let (s, e) = (line.start(), line.end());
            ((s[2] - top_feet).abs() <= TOL && (e[2] - top_feet).abs() <= TOL)
                .then_some(([s[0], s[1]], [e[0], e[1]]))
        })
        .collect();
    if remaining.len() < 3 {
        return None;
    }
    // The lines that meet end to end, as chains of points.
    let mut chains: Vec<Vec<[f64; 2]>> = Vec::new();
    while !remaining.is_empty() {
        let (a, b) = remaining.remove(0);
        let mut chain = vec![a, b];
        loop {
            let tail = *chain.last()?;
            let head = chain[0];
            if let Some(i) = remaining
                .iter()
                .position(|(a, b)| gap(*a, tail) <= TOL || gap(*b, tail) <= TOL)
            {
                let (a, b) = remaining.remove(i);
                chain.push(if gap(a, tail) <= TOL { b } else { a });
            } else if let Some(i) = remaining
                .iter()
                .position(|(a, b)| gap(*a, head) <= TOL || gap(*b, head) <= TOL)
            {
                let (a, b) = remaining.remove(i);
                chain.insert(0, if gap(b, head) <= TOL { a } else { b });
            } else {
                break;
            }
        }
        chains.push(chain);
    }
    // Each chain after the first is the one with an end nearest where the
    // outline has reached, joined by a straight edge across the gap.
    let mut points = chains.remove(0);
    while !chains.is_empty() {
        let here = *points.last()?;
        let (index, reverse, _) = chains
            .iter()
            .enumerate()
            .flat_map(|(i, chain)| {
                [
                    (i, false, gap(chain[0], here)),
                    (i, true, gap(*chain.last().unwrap_or(&chain[0]), here)),
                ]
            })
            .min_by(|x, y| x.2.total_cmp(&y.2))?;
        let mut chain = chains.remove(index);
        if reverse {
            chain.reverse();
        }
        if gap(chain[0], here) <= TOL {
            chain.remove(0);
        }
        points.extend(chain);
    }
    if points.len() > 1 && gap(points[0], *points.last()?) <= TOL {
        points.pop();
    }
    let n = points.len();
    if n < 3 {
        return None;
    }
    let area: f64 = (0..n)
        .map(|i| {
            let (a, b) = (points[i], points[(i + 1) % n]);
            a[0] * b[1] - b[0] * a[1]
        })
        .sum::<f64>()
        / 2.0;
    if area.abs() <= TOL {
        return None;
    }
    let cross = |o: [f64; 2], a: [f64; 2], b: [f64; 2]| {
        (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    };
    for i in 0..n {
        for j in (i + 1)..n {
            if j == i + 1 || (i == 0 && j == n - 1) {
                continue;
            }
            let (p, q) = (points[i], points[(i + 1) % n]);
            let (r, s) = (points[j], points[(j + 1) % n]);
            let (d1, d2) = (cross(r, s, p), cross(r, s, q));
            let (d3, d4) = (cross(p, q, r), cross(p, q, s));
            let crosses = if d1 == 0.0 && d2 == 0.0 {
                // On one line: they meet only where their extents overlap.
                (0..2).all(|k| {
                    p[k].min(q[k]).max(r[k].min(s[k])) <= p[k].max(q[k]).min(r[k].max(s[k]))
                })
            } else {
                d1 * d2 <= 0.0 && d3 * d4 <= 0.0
            };
            if crosses {
                return None;
            }
        }
    }
    Some(points)
}

/// Name Revit 2025 stairs, runs and stringers as Revit's export names them
/// (RE-65), from their native records
/// ([`crate::native_stairs::native_stair_parts`], #323): each takes its
/// type, its type's name and its family, a stair the name
/// `Family:Stair:ElementId` and a part `<stair> Run 2`, numbered in
/// ElementId order among the exported parts of its kind on its stair. A
/// run's type is the one `OST_StairsRuns` type definition its element
/// record names (RE-28). Measured on the five R2025 stair models.
fn attach_native_stair_names(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_type_records as ptr;
    if !crate::native_stairs::NATIVE_STAIR_NAME_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let classes = ["Stair", "StairsRun", "StairsStringer"];
    let parts: BTreeSet<u64> = products
        .iter()
        .filter(|element| classes.contains(&element.class.as_str()))
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    if parts.is_empty() {
        return;
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let run_types = ptr::type_definition_ids(
        &ptr::scan_type_records(
            rf,
            revit_version,
            crate::partition_element_records::OST_STAIRS_RUNS,
            &declared,
        )
        .unwrap_or_default(),
    );
    let mut runs: BTreeMap<u64, u64> = BTreeMap::new();
    for element in products
        .iter()
        .filter(|element| element.class == "StairsRun")
    {
        let (Some(id), Some((references, _))) = (element.id, record_references(rf, element)) else {
            continue;
        };
        if let Some(type_id) = ptr::unique_type_reference(&references, &run_types) {
            runs.insert(u64::from(id), u64::from(type_id));
        }
    }
    let Ok(native) = crate::native_stairs::native_stair_parts(rf, &parts, &runs) else {
        return;
    };
    let mut members: BTreeMap<(u64, &'static str), BTreeSet<u64>> = BTreeMap::new();
    for element in products.iter() {
        let (Some(id), Some(word)) = (element.id.map(u64::from), stair_part_word(&element.class))
        else {
            continue;
        };
        if let Some(part) = native.get(&id) {
            members.entry((part.stair, word)).or_default().insert(id);
        }
    }
    let stair_names: BTreeMap<u64, String> = native
        .iter()
        .filter(|(id, part)| part.stair == **id)
        .map(|(id, part)| (*id, format!("{}:Stair:{id}", part.family)))
        .collect();
    for element in products.iter_mut() {
        let Some(id) = element.id.map(u64::from) else {
            continue;
        };
        let Some(part) = native.get(&id) else {
            continue;
        };
        let has = |field: &str| element.fields.iter().any(|(name, _)| name == field);
        if has(FAMILY_NAME_FIELD) {
            continue;
        }
        let (has_type_id, has_type_name, has_name) = (
            has(TYPE_ID_FIELD),
            has(TYPE_NAME_FIELD),
            has(ELEMENT_NAME_FIELD),
        );
        let name = match stair_part_word(&element.class) {
            None => stair_names.get(&id).cloned(),
            Some(word) => stair_names.get(&part.stair).and_then(|stair| {
                let rank = members
                    .get(&(part.stair, word))?
                    .iter()
                    .position(|m| *m == id)?;
                Some(format!("{stair} {word} {}", rank + 1))
            }),
        };
        let Ok(type_id) = u32::try_from(part.type_id) else {
            continue;
        };
        if !has_type_id {
            element.fields.push((
                TYPE_ID_FIELD.into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: type_id,
                },
            ));
        }
        if !has_type_name {
            element.fields.push((
                TYPE_NAME_FIELD.into(),
                InstanceField::String(part.type_name.clone()),
            ));
        }
        element.fields.push((
            FAMILY_NAME_FIELD.into(),
            InstanceField::String(part.family.into()),
        ));
        element.fields.push((
            FAMILY_NAME_SOURCE_FIELD.into(),
            InstanceField::String(TYPE_KIND_FAMILY_SOURCE.into()),
        ));
        if let (Some(name), false) = (name, has_name) {
            element
                .fields
                .push((ELEMENT_NAME_FIELD.into(), InstanceField::String(name)));
        }
    }
}

/// Field carrying the `m_runType` a stair run's treads all give
/// ([`crate::native_stairs::native_run_shapes`], #323), which names its
/// flight's predefined type
/// ([`crate::native_stairs::flight_predefined_type`]).
pub const STAIR_RUN_SHAPE_FIELD: &str = "m_stair_run_shape";

/// Give each stair run the shape its treads' native records give
/// ([`STAIR_RUN_SHAPE_FIELD`], #323).
fn attach_stair_run_shapes(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    if !crate::native_stairs::NATIVE_RUN_SHAPE_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let runs: BTreeSet<u64> = products
        .iter()
        .filter(|element| element.class == "StairsRun")
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    let Ok(shapes) = crate::native_stairs::native_run_shapes(rf, &runs) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "StairsRun")
    {
        if let Some(shape) = element.id.and_then(|id| shapes.get(&u64::from(id))) {
            element.fields.push((
                STAIR_RUN_SHAPE_FIELD.into(),
                InstanceField::Integer {
                    value: shape.run_type,
                    signed: true,
                    size: 4,
                },
            ));
        }
    }
    // Each stair's type from its runs, in ElementId order, and its landings
    // (#323).
    let whole = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == AGGREGATE_WHOLE_FIELD => Some(*id),
            _ => None,
        })
    };
    // Each stair's runs, by id with their shapes, and its landing count.
    type StairParts = (Vec<(u32, Option<crate::native_stairs::RunShape>)>, usize);
    let mut parts: BTreeMap<u32, StairParts> = BTreeMap::new();
    for element in products.iter() {
        let (Some(stair), Some(id)) = (whole(element), element.id) else {
            continue;
        };
        match element.class.as_str() {
            "StairsRun" => parts
                .entry(stair)
                .or_default()
                .0
                .push((id, shapes.get(&u64::from(id)).copied())),
            "StairsLanding" => parts.entry(stair).or_default().1 += 1,
            _ => {}
        }
    }
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Stair")
    {
        let Some((runs, landings)) = element.id.and_then(|id| parts.get_mut(&id)) else {
            continue;
        };
        runs.sort_by_key(|(id, _)| *id);
        let Some(shapes) = runs
            .iter()
            .map(|(_, shape)| *shape)
            .collect::<Option<Vec<_>>>()
        else {
            continue;
        };
        if let Some(kind) = crate::native_stairs::stair_predefined_type(&shapes, *landings) {
            element
                .fields
                .push((STAIR_TYPE_FIELD.into(), InstanceField::String(kind.into())));
        }
    }
}

/// Field naming the `IfcStairTypeEnum` value a stair's runs and landings
/// give it ([`crate::native_stairs::stair_predefined_type`], #323).
pub const STAIR_TYPE_FIELD: &str = "m_stair_type";

/// Give each monolithic stair landing the slab Revit draws (#824): its own
/// outline (`landing_outline`), from its top (`StairsLanding.m_baseElevation`)
/// down its type's thickness (`StairsLandingType.m_thickness`). The type is
/// the one `OST_StairsLandings` type definition its element record's
/// reference list names (RE-28), its stairs' landing type on all 22 of the
/// BIM4LCA office's. Revit's underside also follows the soffit of a flight
/// where it meets the landing, which is not drawn. A landing whose type is
/// not monolithic, whose lines do not make an outline in its record box, or
/// whose slab leaves its record box keeps its box.
fn attach_landing_slabs(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::element_record_plan_profiles as erpp;
    use crate::partition_type_records as ptr;
    const BOX: f64 = SKETCH_BOX_TOLERANCE_FEET;
    if !crate::native_stairs::NATIVE_LANDING_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    if !products
        .iter()
        .any(|element| element.class == "StairsLanding")
    {
        return;
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let type_records = ptr::scan_type_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_STAIRS_LANDINGS,
        &declared,
    )
    .unwrap_or_default();
    let landing_types = ptr::type_definition_ids(&type_records);
    let mut landings: BTreeMap<u64, u64> = BTreeMap::new();
    for element in products
        .iter()
        .filter(|element| element.class == "StairsLanding")
    {
        let (Some(id), Some((references, _))) = (element.id, record_references(rf, element)) else {
            continue;
        };
        if let Some(type_id) = ptr::unique_type_reference(&references, &landing_types) {
            landings.insert(u64::from(id), u64::from(type_id));
        }
    }
    let Ok((native, type_names)) =
        crate::native_stairs::native_landings_and_type_names(rf, &landings)
    else {
        return;
    };
    // Each landing's type and its name, as for a run (RE-28).
    for element in products
        .iter_mut()
        .filter(|element| element.class == "StairsLanding")
    {
        let Some(type_id) = element.id.and_then(|id| landings.get(&u64::from(id))) else {
            continue;
        };
        let (Some(name), Ok(type_id)) = (type_names.get(type_id), u32::try_from(*type_id)) else {
            continue;
        };
        if element
            .fields
            .iter()
            .any(|(field, _)| field == TYPE_NAME_FIELD)
        {
            continue;
        }
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: type_id,
            },
        ));
        element
            .fields
            .push((TYPE_NAME_FIELD.into(), InstanceField::String(name.clone())));
    }
    let ids: BTreeSet<u32> = native
        .keys()
        .filter_map(|id| u32::try_from(*id).ok())
        .collect();
    let lines =
        crate::partition_stairs::scan_landing_lines(rf, revit_version, &ids).unwrap_or_default();
    let scalar = |value: f64| InstanceField::Float { value, size: 8 };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "StairsLanding")
    {
        let Some(id) = element.id else {
            continue;
        };
        let (Some(landing), Some(lines), Some(bbox)) = (
            native.get(&u64::from(id)),
            lines.get(&id),
            element_record_bbox(element),
        ) else {
            continue;
        };
        if element
            .fields
            .iter()
            .any(|(name, _)| name == erpp::PLAN_PROFILE_OUTER_FIELD)
        {
            continue;
        }
        let bottom = landing.top_feet - landing.thickness_feet;
        if landing.top_feet > bbox[5] + BOX || bottom < bbox[2] - BOX {
            continue;
        }
        let Some(outline) = landing_outline(lines, landing.top_feet) else {
            continue;
        };
        if !outline.iter().all(|p| {
            p[0] >= bbox[0] - BOX
                && p[0] <= bbox[3] + BOX
                && p[1] >= bbox[1] - BOX
                && p[1] <= bbox[4] + BOX
        }) {
            continue;
        }
        let segments: Vec<[f64; 4]> = (0..outline.len())
            .map(|i| {
                let (a, b) = (outline[i], outline[(i + 1) % outline.len()]);
                [a[0], a[1], b[0], b[1]]
            })
            .collect();
        let Some(profile) = erpp::plan_profile_from_lines(&segments) else {
            continue;
        };
        element
            .fields
            .extend(profile.fields().into_iter().map(|(name, value)| {
                if name == erpp::PLAN_PROFILE_SOURCE_FIELD {
                    (name, InstanceField::String(LANDING_OUTLINE_SOURCE.into()))
                } else {
                    (name, value)
                }
            }));
        element
            .fields
            .push((LANDING_BODY_BOTTOM_FIELD.into(), scalar(bottom)));
        element
            .fields
            .push((LANDING_BODY_TOP_FIELD.into(), scalar(landing.top_feet)));
    }
    // #824: a landing that is not monolithic and takes its tread from its
    // runs is that tread, its outline arcs and all.
    let run_types = ptr::type_definition_ids(
        &ptr::scan_type_records(
            rf,
            revit_version,
            crate::partition_element_records::OST_STAIRS_RUNS,
            &declared,
        )
        .unwrap_or_default(),
    );
    let mut runs: BTreeMap<u64, u64> = BTreeMap::new();
    for element in products
        .iter()
        .filter(|element| element.class == "StairsRun")
    {
        let (Some(id), Some((references, _))) = (element.id, record_references(rf, element)) else {
            continue;
        };
        if let Some(type_id) = ptr::unique_type_reference(&references, &run_types) {
            runs.insert(u64::from(id), u64::from(type_id));
        }
    }
    let rest: BTreeMap<u64, u64> = landings
        .iter()
        .filter(|(id, _)| !native.contains_key(id))
        .map(|(id, type_id)| (*id, *type_id))
        .collect();
    let Ok(treads) = crate::native_stairs::native_tread_landings(rf, &rest, &runs) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "StairsLanding")
    {
        let (Some(landing), Some(bbox)) = (
            element.id.and_then(|id| treads.get(&u64::from(id))),
            element_record_bbox(element),
        ) else {
            continue;
        };
        let bottom = landing.top_feet - landing.thickness_feet;
        let inside = |p: [f64; 2]| {
            p[0] >= bbox[0] - BOX
                && p[0] <= bbox[3] + BOX
                && p[1] >= bbox[1] - BOX
                && p[1] <= bbox[4] + BOX
        };
        if landing.top_feet > bbox[5] + BOX
            || bottom < bbox[2] - BOX
            || !landing.outline.iter().all(|curve| match curve {
                crate::native_stairs::LandingCurve::Line(a, b) => inside(*a) && inside(*b),
                crate::native_stairs::LandingCurve::Arc(a, m, b) => {
                    inside(*a) && inside(*m) && inside(*b)
                }
            })
        {
            continue;
        }
        let float = |value: f64| InstanceField::Float { value, size: 8 };
        let curves = landing
            .outline
            .iter()
            .map(|curve| {
                let values: Vec<f64> = match curve {
                    crate::native_stairs::LandingCurve::Line(a, b) => {
                        vec![0.0, a[0], a[1], b[0], b[1]]
                    }
                    crate::native_stairs::LandingCurve::Arc(a, m, b) => {
                        vec![1.0, a[0], a[1], m[0], m[1], b[0], b[1]]
                    }
                };
                InstanceField::Vector(values.into_iter().map(float).collect())
            })
            .collect();
        element.fields.push((
            LANDING_TREAD_OUTLINE_FIELD.into(),
            InstanceField::Vector(curves),
        ));
        element
            .fields
            .push((LANDING_TREAD_BOTTOM_FIELD.into(), float(bottom)));
        element
            .fields
            .push((LANDING_TREAD_TOP_FIELD.into(), float(landing.top_feet)));
    }
}

/// Fields holding the first end of a beam's location line, model feet
/// (RE-49).
pub const BEAM_AXIS_START_FIELDS: [&str; 3] = [
    "m_beam_axis_start_x",
    "m_beam_axis_start_y",
    "m_beam_axis_start_z",
];
/// Fields holding the second end of a beam's location line, model feet
/// (RE-49).
pub const BEAM_AXIS_END_FIELDS: [&str; 3] = [
    "m_beam_axis_end_x",
    "m_beam_axis_end_y",
    "m_beam_axis_end_z",
];

/// The record box `[min x, min y, min z, max x, max y, max z]` of an element
/// built from a partition element record: its location fields hold the plan
/// centre and the base.
pub fn element_record_bbox(element: &DecodedElement) -> Option<[f64; 6]> {
    let field = |wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let (x, y, z) = (
        field("m_locationX")?,
        field("m_locationY")?,
        field("m_locationZ")?,
    );
    let (width, depth, height) = (
        field("m_bboxWidth")?,
        field("m_bboxDepth")?,
        field("m_bboxHeight")?,
    );
    Some([
        x - width / 2.0,
        y - depth / 2.0,
        z,
        x + width / 2.0,
        y + depth / 2.0,
        z + height,
    ])
}

/// The two ends of a beam's location line, when the partition MVP gave it one
/// (RE-49).
pub fn beam_axis_from_fields(fields: &[(String, InstanceField)]) -> Option<([f64; 3], [f64; 3])> {
    let field = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let point = |names: [&str; 3]| Some([field(names[0])?, field(names[1])?, field(names[2])?]);
    Some((point(BEAM_AXIS_START_FIELDS)?, point(BEAM_AXIS_END_FIELDS)?))
}

/// Give each structural-framing element the location line its data carries,
/// when the line and the element's record box make a beam solid
/// ([`crate::partition_beam_axes::beam_body`], RE-49). A line that leaves the
/// box, or a box no solid along the line reproduces, is not attached.
fn attach_beam_axes(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_beam_axes as pba;
    if !pba::supports_revit_version(revit_version) {
        return;
    }
    let beams: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.class == "StructuralFraming")
        .filter_map(|element| element.id)
        .collect();
    if beams.is_empty() {
        return;
    }
    let Ok(lines) = pba::scan_bounded_lines(rf, revit_version, &beams) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "StructuralFraming")
    {
        let Some(line) = element.id.and_then(|id| lines.get(&id)) else {
            continue;
        };
        let (start, end) = (line.start(), line.end());
        let resolves = element_record_bbox(element)
            .and_then(|bbox| pba::beam_body(bbox, start, end))
            .is_some();
        if !resolves {
            continue;
        }
        for (names, point) in [(BEAM_AXIS_START_FIELDS, start), (BEAM_AXIS_END_FIELDS, end)] {
            for (name, value) in names.iter().zip(point) {
                element
                    .fields
                    .push(((*name).into(), InstanceField::Float { value, size: 8 }));
            }
        }
    }
}

/// Fields holding the first end of a pipe's centreline, model feet (RE-131).
pub const PIPE_AXIS_START_FIELDS: [&str; 3] = [
    "m_pipe_axis_start_x",
    "m_pipe_axis_start_y",
    "m_pipe_axis_start_z",
];
/// Fields holding the second end of a pipe's centreline, model feet (RE-131).
pub const PIPE_AXIS_END_FIELDS: [&str; 3] = [
    "m_pipe_axis_end_x",
    "m_pipe_axis_end_y",
    "m_pipe_axis_end_z",
];
/// Field holding a pipe's outside radius, feet (RE-131).
pub const PIPE_RADIUS_FIELD: &str = "m_pipe_radius";
/// Fields holding the keys of the connector entries at a pipe's first and
/// second end (#847), each a vector of `[element, connector index]` pairs.
pub const PIPE_END_KEYS_FIELDS: [&str; 2] = ["m_pipe_start_keys", "m_pipe_end_keys"];
/// Fields holding a duct's two ends, model feet: the centres of the faces of
/// its record box across its length (#847, RE-134).
pub const DUCT_ENDS_FIELDS: [[&str; 3]; 2] = [
    ["m_duct_start_x", "m_duct_start_y", "m_duct_start_z"],
    ["m_duct_end_x", "m_duct_end_y", "m_duct_end_z"],
];
/// Fields holding the keys of the connector entries at a duct's two ends
/// (#847), as [`PIPE_END_KEYS_FIELDS`] for a pipe.
pub const DUCT_END_KEYS_FIELDS: [&str; 2] = ["m_duct_start_keys", "m_duct_end_keys"];
/// Fields holding a duct's or pipe's `m_dWidthOrDiameter` and `m_dHeight`,
/// feet (RE-134).
pub const CURVE_SIZE_FIELDS: [&str; 2] = ["m_curve_width", "m_curve_height"];
/// Field holding a duct's length along its axis, feet: the dimension of its
/// record box its width and height leave (RE-134).
pub const DUCT_LENGTH_FIELD: &str = "m_duct_length";
/// Field holding a pipe's inner diameter, feet, from its curve object
/// (RE-157).
pub const PIPE_INNER_DIAMETER_FIELD: &str = "m_pipe_inner_diameter";
/// How closely a duct's width and height must match two of its box's
/// dimensions, feet.
pub const CURVE_BOX_TOLERANCE_FEET: f64 = 2e-3;

/// A duct's or pipe's width and height, feet (RE-134), when read.
pub fn curve_size_from_fields(fields: &[(String, InstanceField)]) -> Option<(f64, f64)> {
    let field = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    Some((field(CURVE_SIZE_FIELDS[0])?, field(CURVE_SIZE_FIELDS[1])?))
}

/// Field carrying the Function of an element's type: `FUNCTION_PARAM` (0
/// interior, 1 exterior), RE-158, or a wall type's native `m_function`, the
/// same values followed by foundation, retaining, soffit and core shaft
/// (RE-185).
pub const TYPE_FUNCTION_FIELD: &str = "m_type_function";

/// Give each element of `groups` whose type is known its type's Function,
/// the integer entry `FUNCTION_PARAM` in the type's own data object
/// (RE-158). A type whose entries disagree, or that has none, gives nothing.
fn attach_type_functions(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 6],
) {
    use crate::partition_room_parameters as prp;
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let types: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter().filter_map(type_of))
        .collect();
    let functions = prp::scan_integer_parameter(rf, revit_version, &types, prp::FUNCTION_PARAMETER);
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        if let Some(&function) = type_of(element).and_then(|id| functions.get(&id)) {
            element.fields.push((
                TYPE_FUNCTION_FIELD.into(),
                InstanceField::Integer {
                    value: i64::from(function),
                    signed: false,
                    size: 4,
                },
            ));
        }
    }
}

/// Releases whose walls' native type Function is measured (RE-185, RE-193).
pub const WALL_TYPE_FUNCTION_REVIT_VERSIONS: &[u32] = &[2024, 2025];

/// Give each of `walls` with no [`TYPE_FUNCTION_FIELD`] its type's Function
/// from the type's native record ([`crate::native_wall_types`], RE-185).
/// Nothing on a release not measured, or where the native records are not
/// read.
fn attach_wall_type_functions<'a>(
    rf: &mut RevitFile,
    revit_version: u32,
    walls: impl IntoIterator<Item = &'a mut DecodedElement>,
) {
    if !WALL_TYPE_FUNCTION_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let has_function = |element: &DecodedElement| {
        element
            .fields
            .iter()
            .any(|(name, _)| name == TYPE_FUNCTION_FIELD)
    };
    let mut walls: Vec<&mut DecodedElement> = walls
        .into_iter()
        .filter(|element| !has_function(element))
        .collect();
    let ids: BTreeSet<u64> = walls
        .iter()
        .filter_map(|element| element.id.map(u64::from))
        .collect();
    if ids.is_empty() {
        return;
    }
    let Ok(functions) = crate::native_wall_types::wall_type_functions(rf, &ids) else {
        return;
    };
    for element in walls.iter_mut() {
        if let Some(&function) = element.id.and_then(|id| functions.get(&u64::from(id))) {
            element.fields.push((
                TYPE_FUNCTION_FIELD.into(),
                InstanceField::Integer {
                    value: function,
                    signed: true,
                    size: 8,
                },
            ));
        }
    }
}

/// Prefix of a field carrying the Yes/No value of a project or shared
/// parameter on an element, named by the parameter's name (RE-193).
pub const NAMED_PARAMETER_FIELD_PREFIX: &str = "m_named_parameter:";

/// Prefix of a field carrying the same value on the element's type.
pub const TYPE_NAMED_PARAMETER_FIELD_PREFIX: &str = "m_type_named_parameter:";

/// The name of the parameter Revit's exporter reads `IsExternal` from (RE-193).
pub const IS_EXTERNAL_PARAMETER_NAME: &str = "IsExternal";

/// Field carrying the `IsExternal` Revit's exporter calculates for an element
/// (RE-193), which a parameter named for the property set it is written in
/// takes precedence over ([`crate::ifc::export_content`]).
pub const IS_EXTERNAL_FIELD: &str = "m_is_external";

/// Classes whose `IsExternal` Revit's exporter takes from their type's
/// Function, so one whose Function is not read gets none: a value calculated
/// without it would be a guess (fail closed). A window's host does not give
/// it: on the R2025 models the host wall's value is Revit's on 6 of 18.
const IS_EXTERNAL_FUNCTION_CLASSES: &[&str] = &[
    "Wall",
    CURTAIN_WALL_CLASS,
    CURTAIN_PANEL_WALL_CLASS,
    "Door",
    "Window",
    "Floor",
    "BuildingPad",
];

/// Classes whose `IsExternal` is not established: on the BIM4LCA office
/// Revit's export writes most curtain mullions and panels as not external
/// where their curtain wall is, and some as external (RE-193).
const IS_EXTERNAL_UNKNOWN_CLASSES: &[&str] = &["CurtainWallMullion", "CurtainWallPanel"];

/// The `IsExternal` Revit's exporter calculates for `element` (RE-193),
/// following revit-ifc's `CategoryUtil.IsElementExternal` (CLEANROOM.md
/// source 5): a parameter named [`IS_EXTERNAL_PARAMETER_NAME`] on the
/// element, then on its type; its type's Function, external unless interior
/// (0); a roof is external; otherwise not external, where `last_step`
/// allows it. `None` for the classes whose value cannot be calculated from
/// what is read, and where the last step is not allowed.
fn calculated_is_external(element: &DecodedElement, last_step: bool) -> Option<bool> {
    let flag = |wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Bool(flag) if name == wanted => Some(*flag),
            _ => None,
        })
    };
    if let Some(value) = flag(&format!(
        "{NAMED_PARAMETER_FIELD_PREFIX}{IS_EXTERNAL_PARAMETER_NAME}"
    ))
    .or_else(|| {
        flag(&format!(
            "{TYPE_NAMED_PARAMETER_FIELD_PREFIX}{IS_EXTERNAL_PARAMETER_NAME}"
        ))
    }) {
        return Some(value);
    }
    let function = element.fields.iter().find_map(|(name, value)| match value {
        InstanceField::Integer { value, .. } if name == TYPE_FUNCTION_FIELD => Some(*value),
        _ => None,
    });
    if let Some(function) = function {
        return Some(function != 0);
    }
    if element.class == "Roof" {
        return Some(true);
    }
    let class = element.class.as_str();
    if !last_step
        || IS_EXTERNAL_FUNCTION_CLASSES.contains(&class)
        || IS_EXTERNAL_UNKNOWN_CLASSES.contains(&class)
    {
        return None;
    }
    Some(false)
}

/// Releases where the calculation's last step, not external, is measured
/// (RE-193). The parameters and a type's Function are read on every release
/// from 2024, as RE-158 read a door's and a floor's.
pub const IS_EXTERNAL_LAST_STEP_REVIT_VERSIONS: &[u32] = &[2024, 2025];

/// Give each element of `groups` the Yes/No parameters named `IsExternal` or
/// `<property set>.IsExternal` that it carries ([`NAMED_PARAMETER_FIELD_PREFIX`];
/// for the plain name also its type's, [`TYPE_NAMED_PARAMETER_FIELD_PREFIX`]),
/// then the value Revit's exporter calculates ([`IS_EXTERNAL_FIELD`]). Revit's
/// exporter reads `Pset_WallCommon.IsExternal` on a wall before anything else,
/// and the BIM4LCA office defines one such parameter for each of twelve
/// property sets (RE-193).
fn attach_is_external(
    rf: &mut RevitFile,
    revit_version: u32,
    mut groups: [&mut Vec<DecodedElement>; 8],
) {
    use crate::partition_room_parameters as prp;
    let last_step = IS_EXTERNAL_LAST_STEP_REVIT_VERSIONS.contains(&revit_version);
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let parameters: Vec<(String, u32)> = prp::find_parameter_definitions(rf, revit_version)
        .into_iter()
        .filter(|(name, _)| {
            name == IS_EXTERNAL_PARAMETER_NAME
                || name.ends_with(&format!(".{IS_EXTERNAL_PARAMETER_NAME}"))
        })
        .collect();
    if !parameters.is_empty() {
        let owners: BTreeSet<u32> = groups
            .iter()
            .flat_map(|elements| elements.iter())
            .flat_map(|element| element.id.into_iter().chain(type_of(element)))
            .collect();
        let ids: Vec<i64> = parameters.iter().map(|(_, id)| i64::from(*id)).collect();
        let mut found = prp::scan_integer_parameters(rf, revit_version, &owners, &ids);
        let values: Vec<(String, BTreeMap<u32, u32>)> = parameters
            .into_iter()
            .map(|(name, id)| {
                let values = found.remove(&i64::from(id)).unwrap_or_default();
                (name, values)
            })
            .collect();
        for element in groups.iter_mut().flat_map(|elements| elements.iter_mut()) {
            let type_id = type_of(element);
            for (name, found) in &values {
                if let Some(&value) = element.id.and_then(|id| found.get(&id)) {
                    element.fields.push((
                        format!("{NAMED_PARAMETER_FIELD_PREFIX}{name}"),
                        InstanceField::Bool(value != 0),
                    ));
                }
                if let (true, Some(&value)) = (
                    name == IS_EXTERNAL_PARAMETER_NAME,
                    type_id.and_then(|id| found.get(&id)),
                ) {
                    element.fields.push((
                        format!("{TYPE_NAMED_PARAMETER_FIELD_PREFIX}{name}"),
                        InstanceField::Bool(value != 0),
                    ));
                }
            }
        }
    }
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        if let Some(external) = calculated_is_external(element, last_step) {
            element
                .fields
                .push((IS_EXTERNAL_FIELD.into(), InstanceField::Bool(external)));
        }
    }
}

/// Give each element of `groups` the values of the project or shared
/// parameters named `<property set>.<property>` for a property of a standard
/// set ([`crate::ifc::standard_property_sets`]) that its own data object holds
/// (RE-194), and, for each such property the element holds no
/// `<property set>.<property>` parameter for, of one named for the property
/// alone, as revit-ifc's `PropertySetEntryMap` looks the qualified name up
/// before the bare one (CLEANROOM.md source 5; RE-227: the BIM4LCA office's
/// `FireExit`, which Revit's export writes as `Pset_DoorCommon.FireExit`),
/// each as a field [`NAMED_PARAMETER_FIELD_PREFIX`]`<set>.<property>`: a
/// Yes/No's 0 or 1 as a boolean, an integer, a text of one or more
/// characters, a positive length in feet, or a length or thermal
/// transmittance as stored. The latest partition's copy decides, so a text
/// emptied there gets nothing, though an older copy holds one: on the
/// BIM4LCA office at building permit 74 columns' `FireRating`. `IsExternal`
/// is [`attach_is_external`]'s. Of the models measured, only the BIM4LCA
/// office defines such parameters.
/// `<set>.<property>` parameters left out where the file holds a value,
/// because Revit's export writes none (the maintainer, 2026-10-29: no
/// property value Revit's export omits). `Pset_DoorWindowGlazingType.IsWired`:
/// every one of the BIM4LCA office's 1,337 elements carrying it holds 0, and
/// its export writes it on none (RE-194 §4).
const REVIT_OMITTED_PARAMETERS: &[&str] = &["Pset_DoorWindowGlazingType.IsWired"];

fn attach_named_parameters(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 8],
) {
    use crate::ifc::standard_property_sets::{self as sps, StandardPropertyKind as Kind};
    use crate::partition_room_parameters::{self as prp, EntryKind, EntryValue};
    let definitions = prp::find_parameter_definitions(rf, revit_version);
    // Qualified names first: an element's bare-named value only fills a
    // property its qualified one leaves empty.
    let mut parameters: Vec<(String, i64, Kind)> = definitions
        .iter()
        .filter_map(|(name, id)| {
            let (set, property) = name.split_once('.')?;
            let kind = sps::property_kind(set, property)
                .filter(|_| property != IS_EXTERNAL_PARAMETER_NAME)?;
            Some((name.clone(), i64::from(*id), kind))
        })
        .collect();
    for (name, id) in &definitions {
        if name.contains('.') || name == IS_EXTERNAL_PARAMETER_NAME {
            continue;
        }
        for set in sps::STANDARD_PROPERTY_SETS {
            if let Some(kind) = set.property_kind(name) {
                parameters.push((format!("{}.{name}", set.name), i64::from(*id), kind));
            }
        }
    }
    parameters.retain(|(name, _, _)| !REVIT_OMITTED_PARAMETERS.contains(&name.as_str()));
    if parameters.is_empty() {
        return;
    }
    let entry_kind = |kind: Kind| match kind {
        Kind::Boolean | Kind::Count | Kind::Integer => EntryKind::Word,
        Kind::Identifier | Kind::Label | Kind::Text => EntryKind::Text,
        Kind::Length | Kind::PositiveLength | Kind::ThermalTransmittance => EntryKind::Real,
    };
    // A bare name several sets hold is one parameter: scan it once.
    let mut scanned = BTreeSet::new();
    let wanted: Vec<(i64, EntryKind)> = parameters
        .iter()
        .filter(|(_, id, _)| scanned.insert(*id))
        .map(|(_, id, kind)| (*id, entry_kind(*kind)))
        .collect();
    let owners: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter())
        .filter_map(|element| element.id)
        .collect();
    let found = prp::scan_parameter_entries(rf, revit_version, &owners, &wanted);
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        let Some(id) = element.id else {
            continue;
        };
        for (name, parameter, kind) in &parameters {
            let Some(value) = found.get(parameter).and_then(|values| values.get(&id)) else {
                continue;
            };
            let field_name = format!("{NAMED_PARAMETER_FIELD_PREFIX}{name}");
            if element.fields.iter().any(|(held, _)| *held == field_name) {
                continue;
            }
            let field = match (kind, value) {
                (Kind::Boolean, EntryValue::Word(word @ (0 | 1))) => {
                    InstanceField::Bool(*word == 1)
                }
                // How a negative integer is stored is not measured.
                (Kind::Count | Kind::Integer, EntryValue::Word(count))
                    if i32::try_from(*count).is_ok() =>
                {
                    InstanceField::Integer {
                        value: i64::from(*count),
                        signed: false,
                        size: 4,
                    }
                }
                (_, EntryValue::Text(text)) if !text.is_empty() => {
                    InstanceField::String(text.clone())
                }
                (Kind::PositiveLength, EntryValue::Real(length)) if *length <= 0.0 => continue,
                (_, EntryValue::Real(value)) if *value == 0.0 || value.is_normal() => {
                    InstanceField::Float {
                        value: *value,
                        size: 8,
                    }
                }
                _ => continue,
            };
            element.fields.push((field_name, field));
        }
    }
}

/// Field holding whether a wall's top is joined to a roof or floor, from its
/// native record ([`crate::native_walls::native_walls_and_top_joins`],
/// RE-228): Revit's `Pset_WallCommon.ExtendToStructure`.
pub const WALL_TOP_JOINED_FIELD: &str = "m_wall_top_joined";

/// Field set on a wall whose native record holds no `JoinToRoofGStep`,
/// `CutPairGStep` or `WallCutoutGStep`
/// ([`crate::native_walls::native_walls_and_top_joins`], RE-266): its body
/// is as tall as Revit's, and Revit's export writes that as its `Height`.
pub const WALL_UNCUT_FIELD: &str = "m_wall_uncut";

/// Field carrying the name of the phase an element was created in
/// ([`crate::partition_phases`], #755).
pub const PHASE_CREATED_FIELD: &str = "m_phase_created";

/// Give each element the one phase its record's reference list names
/// ([`crate::partition_phases::phase_created`]).
fn attach_phases_created(rf: &mut RevitFile, groups: [&mut Vec<DecodedElement>; 6]) {
    let phases = crate::partition_phases::phase_names(rf).unwrap_or_default();
    if phases.is_empty() {
        return;
    }
    for element in groups.into_iter().flat_map(|group| group.iter_mut()) {
        let Some((references, _)) = record_references(rf, element) else {
            continue;
        };
        if let Some((_, name)) = crate::partition_phases::phase_created(&references, &phases) {
            element.fields.push((
                PHASE_CREATED_FIELD.into(),
                InstanceField::String(name.into()),
            ));
        }
    }
}

/// Field carrying an element's value of the shared parameter `Serial Number`
/// (RE-156).
pub const SERIAL_NUMBER_FIELD: &str = "m_serial_number";
/// Name of the shared parameter whose value Revit's export writes as
/// `SerialNumber` (RE-156).
pub const SERIAL_NUMBER_PARAMETER_NAME: &str = "Serial Number";

/// Give each element of `groups` its value of the shared parameter `Serial
/// Number`: the text entry with the parameter's ElementId in the element's
/// own data object (RE-156). A file with no such parameter changes nothing.
fn attach_serial_numbers(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 6],
) {
    use crate::partition_room_parameters as prp;
    let definitions = prp::find_parameter_definitions(rf, revit_version);
    let Some(&parameter) = definitions.get(SERIAL_NUMBER_PARAMETER_NAME) else {
        return;
    };
    let ids: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter().filter_map(|element| element.id))
        .collect();
    let values = prp::scan_text_parameter(rf, revit_version, &ids, i64::from(parameter));
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        if let Some(value) = element.id.and_then(|id| values.get(&id)) {
            element.fields.push((
                SERIAL_NUMBER_FIELD.into(),
                InstanceField::String(value.clone()),
            ));
        }
    }
}

/// Field carrying a pipe fitting's nominal diameter, feet (RE-165).
pub const FITTING_NOMINAL_DIAMETER_FIELD: &str = "m_fitting_nominal_diameter";

/// Give each pipe fitting its nominal diameter
/// ([`crate::partition_fitting_sizes`], RE-165). A fitting whose connectors
/// disagree, or whose object is not found, gets nothing.
fn attach_fitting_nominal_diameters(
    rf: &mut RevitFile,
    revit_version: u32,
    products: &mut [DecodedElement],
) {
    use crate::partition_fitting_sizes as pfs;
    let fittings: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.class == "PipeFitting")
        .filter_map(|element| element.id)
        .collect();
    let diameters =
        pfs::scan_fitting_nominal_diameters(rf, revit_version, &fittings).unwrap_or_default();
    for element in products.iter_mut() {
        if element.class != "PipeFitting" {
            continue;
        }
        if let Some(&diameter) = element.id.and_then(|id| diameters.get(&id)) {
            element.fields.push((
                FITTING_NOMINAL_DIAMETER_FIELD.into(),
                InstanceField::Float {
                    value: diameter,
                    size: 8,
                },
            ));
        }
    }
}

/// Prefix of the field naming an MEP system an element is a member of: the
/// system's ElementId follows, and the field holds its name, empty where it
/// has none (RE-162).
pub const MEP_SYSTEM_FIELD_PREFIX: &str = "m_mep_system_";

/// The MEP systems an element is a member of, by ElementId, with their names
/// (RE-162).
pub fn mep_systems_from_fields(fields: &[(String, InstanceField)]) -> Vec<(u32, Option<String>)> {
    fields
        .iter()
        .filter_map(|(name, value)| {
            let id = name.strip_prefix(MEP_SYSTEM_FIELD_PREFIX)?.parse().ok()?;
            let InstanceField::String(system_name) = value else {
                return None;
            };
            Some((id, Some(system_name.clone()).filter(|n| !n.is_empty())))
        })
        .collect()
}

/// Give each element of `groups` the MEP systems it is a member of
/// ([`crate::partition_mep_systems`], RE-162).
fn attach_mep_systems(
    rf: &mut RevitFile,
    revit_version: u32,
    mut groups: [&mut Vec<DecodedElement>; 6],
) {
    use crate::partition_mep_systems as pms;
    if !pms::supports_revit_version(revit_version) {
        return;
    }
    let ids: BTreeSet<u32> = groups
        .iter()
        .flat_map(|elements| elements.iter().filter_map(|element| element.id))
        .collect();
    let (systems, diagnostics) = match pms::scan_mep_systems_report(rf, revit_version, &ids) {
        Ok(report) => (report.systems, report.diagnostics),
        Err(error) => (Vec::new(), vec![error.to_string()]),
    };
    if let Some(element) = groups.iter_mut().flat_map(|g| g.iter_mut()).next() {
        element.provenance.warnings.extend(diagnostics.into_iter().map(|d| format!("RVT_MEP: {d}")));
    }
    if systems.is_empty() {
        return;
    }
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        let Some(id) = element.id else {
            continue;
        };
        for system in systems.iter().filter(|system| system.members.contains(&id)) {
            element.fields.push((
                format!("{MEP_SYSTEM_FIELD_PREFIX}{}", system.id),
                InstanceField::String(system.name.clone().unwrap_or_default()),
            ));
        }
    }
}

/// Give each duct and pipe the width and height its curve object holds, and
/// each one still without a type (a duct, or a pipe RE-130's reference list
/// does not type) its curve's type and that type's name
/// ([`crate::partition_curve_fields`], RE-134;
/// [`crate::partition_names::find_mep_curve_type_names`], RE-130). An element
/// whose anchor is not found gets nothing.
fn attach_curve_fields(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_curve_fields as pcf;
    if !pcf::supports_revit_version(revit_version) {
        return;
    }
    let is_curve = |element: &DecodedElement| matches!(element.class.as_str(), "Duct" | "Pipe");
    let mut by_stream: BTreeMap<String, Vec<(u32, [f64; 6])>> = BTreeMap::new();
    for element in products.iter().filter(|element| is_curve(element)) {
        if let (Some(id), Some(bbox), Some(stream)) = (
            element.id,
            element_record_bbox(element),
            element_source_stream(element),
        ) {
            by_stream.entry(stream).or_default().push((id, bbox));
        }
    }
    let Ok(fields) = pcf::scan_curve_fields(rf, revit_version, &by_stream) else {
        return;
    };
    if fields.is_empty() {
        return;
    }
    let pipes: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.class == "Pipe")
        .filter_map(|element| element.id)
        .collect();
    let diameters = pcf::scan_pipe_diameters(rf, revit_version, &pipes).unwrap_or_default();
    let has = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().any(|(name, _)| name == wanted)
    };
    let wanted: BTreeSet<u32> = products
        .iter()
        .filter(|element| is_curve(element) && !has(element, TYPE_NAME_FIELD))
        .filter_map(|element| Some(fields.get(&element.id?)?.type_id))
        .collect();
    let mut names: BTreeMap<u32, Option<String>> = BTreeMap::new();
    if !wanted.is_empty() {
        for stream in rf.partition_stream_names() {
            let Ok(inflated) = rf.inflated_partition(&stream) else {
                continue;
            };
            for (id, name) in
                crate::partition_names::find_mep_curve_type_names(inflated.bytes(), &wanted)
            {
                match names.get_mut(&id) {
                    None => {
                        names.insert(id, Some(name));
                    }
                    Some(held) => {
                        if held.as_deref() != Some(name.as_str()) {
                            *held = None;
                        }
                    }
                }
            }
        }
    }
    for element in products.iter_mut().filter(|element| is_curve(element)) {
        let Some(curve) = element.id.and_then(|id| fields.get(&id)).copied() else {
            continue;
        };
        for (name, value) in CURVE_SIZE_FIELDS
            .iter()
            .zip([curve.width_feet, curve.height_feet])
        {
            element
                .fields
                .push(((*name).into(), InstanceField::Float { value, size: 8 }));
        }
        // A pipe's inner diameter (RE-157).
        if let Some(&(inner, _)) = element.id.and_then(|id| diameters.get(&id)) {
            element.fields.push((
                PIPE_INNER_DIAMETER_FIELD.into(),
                InstanceField::Float {
                    value: inner,
                    size: 8,
                },
            ));
        }
        // A duct along one of the model's axes: its box is its section by its
        // length (RE-134: 25 of 25 RE1 ducts).
        if element.class == "Duct" {
            if let Some(length) = element_record_bbox(element)
                .and_then(|bbox| curve.length_in_box(bbox, CURVE_BOX_TOLERANCE_FEET))
            {
                element.fields.push((
                    DUCT_LENGTH_FIELD.into(),
                    InstanceField::Float {
                        value: length,
                        size: 8,
                    },
                ));
            }
        }
        if !is_curve(element) || has(element, TYPE_NAME_FIELD) {
            continue;
        }
        let Some(Some(type_name)) = names.get(&curve.type_id) else {
            continue;
        };
        element.fields.push((
            TYPE_ID_FIELD.into(),
            InstanceField::ElementId {
                tag: 0,
                id: curve.type_id,
            },
        ));
        element.fields.push((
            TYPE_NAME_FIELD.into(),
            InstanceField::String(type_name.clone()),
        ));
    }
    attach_duct_system_families(rf, products);
}

/// Give each typed duct the system family its type's shape names
/// (`Rectangular Duct`, `Round Duct`, `Oval Duct`,
/// [`crate::native_duct_shapes`]), so it is named
/// `Family:Type:ElementId` as Revit names it. A file whose release the native
/// record path does not read leaves its ducts without one.
fn attach_duct_system_families(rf: &mut RevitFile, products: &mut [DecodedElement]) {
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let has = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().any(|(name, _)| name == wanted)
    };
    let types: BTreeSet<u64> = products
        .iter()
        .filter(|element| {
            element.class == "Duct"
                && has(element, TYPE_NAME_FIELD)
                && !has(element, FAMILY_NAME_FIELD)
        })
        .filter_map(type_of)
        .map(u64::from)
        .collect();
    if types.is_empty() {
        return;
    }
    let Ok(shapes) = crate::native_duct_shapes::duct_type_shapes(rf, &types) else {
        return;
    };
    let locale = rf.basic_file_info().ok().and_then(|info| info.locale);
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Duct")
    {
        if has(element, FAMILY_NAME_FIELD) {
            continue;
        }
        let Some(shape) = type_of(element).and_then(|id| shapes.get(&u64::from(id))) else {
            continue;
        };
        element.fields.push((
            FAMILY_NAME_FIELD.into(),
            InstanceField::String(
                localized_system_family(shape.system_family(), locale.as_deref()).into(),
            ),
        ));
        element.fields.push((
            FAMILY_NAME_SOURCE_FIELD.into(),
            InstanceField::String(SYSTEM_FAMILY_SOURCE.into()),
        ));
        element.fields.push((
            DUCT_SHAPE_FIELD.into(),
            InstanceField::String(shape.ifc_shape().into()),
        ));
    }
}

/// Field carrying a duct's shape as IFC names it (`RECTANGULAR`, `ROUND`,
/// `FLATOVAL`), from its type.
// Tracker: B43.
pub const DUCT_SHAPE_FIELD: &str = "m_duct_shape";

/// The cylinder the partition MVP gave a pipe, when its connector entries
/// and record box made one (RE-131).
pub fn pipe_body_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<crate::partition_pipe_axes::PipeBody> {
    let field = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let point = |names: [&str; 3]| Some([field(names[0])?, field(names[1])?, field(names[2])?]);
    Some(crate::partition_pipe_axes::PipeBody {
        start: point(PIPE_AXIS_START_FIELDS)?,
        end: point(PIPE_AXIS_END_FIELDS)?,
        radius_feet: field(PIPE_RADIUS_FIELD)?,
    })
}

/// Give each pipe the cylinder its connector entries and its record box make
/// ([`crate::partition_pipe_axes`], RE-131). A pipe whose ends are not found,
/// or whose two ends and box no cylinder reproduces, is not given one and
/// keeps its box.
fn attach_pipe_axes(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_pipe_axes as ppa;
    if !ppa::supports_revit_version(revit_version) {
        return;
    }
    let mut by_stream: BTreeMap<String, Vec<(u32, [f64; 6])>> = BTreeMap::new();
    for element in products.iter().filter(|element| element.class == "Pipe") {
        if let (Some(id), Some(bbox), Some(stream)) = (
            element.id,
            element_record_bbox(element),
            element_source_stream(element),
        ) {
            by_stream.entry(stream).or_default().push((id, bbox));
        }
    }
    if by_stream.is_empty() {
        return;
    }
    let Ok(bodies) = ppa::scan_pipe_bodies(rf, revit_version, &by_stream) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Pipe")
    {
        let Some(body) = element.id.and_then(|id| bodies.get(&id)) else {
            continue;
        };
        for (names, point) in [
            (PIPE_AXIS_START_FIELDS, body.start),
            (PIPE_AXIS_END_FIELDS, body.end),
        ] {
            for (name, value) in names.iter().zip(point) {
                element
                    .fields
                    .push(((*name).into(), InstanceField::Float { value, size: 8 }));
            }
        }
        element.fields.push((
            PIPE_RADIUS_FIELD.into(),
            InstanceField::Float {
                value: body.radius_feet,
                size: 8,
            },
        ));
    }
    // #847: the keys at each end say which of the pipe's connectors it is.
    let mut ends = ppa::CurveEnds::new();
    for element in products.iter().filter(|element| element.class == "Pipe") {
        if let (Some(id), Some(stream), Some(body)) = (
            element.id,
            element_source_stream(element),
            pipe_body_from_fields(&element.fields),
        ) {
            ends.entry(stream)
                .or_default()
                .push((id, [body.start, body.end]));
        }
    }
    let Ok(keys) = ppa::scan_pipe_end_keys(rf, revit_version, &ends) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Pipe")
    {
        let Some(end_keys) = element.id.and_then(|id| keys.get(&id)) else {
            continue;
        };
        for (name, keys) in PIPE_END_KEYS_FIELDS.iter().zip(end_keys) {
            element.fields.push(((*name).into(), end_keys_field(keys)));
        }
    }
}

/// A duct's two ends ([`DUCT_ENDS_FIELDS`], #847), where its box gave them.
pub fn duct_ends_from_fields(fields: &[(String, InstanceField)]) -> Option<[[f64; 3]; 2]> {
    let field = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let point = |names: [&str; 3]| Some([field(names[0])?, field(names[1])?, field(names[2])?]);
    Some([point(DUCT_ENDS_FIELDS[0])?, point(DUCT_ENDS_FIELDS[1])?])
}

/// The keys of the connector entries at a duct's two ends
/// ([`DUCT_END_KEYS_FIELDS`], #847).
pub fn duct_end_keys_from_fields(
    fields: &[(String, InstanceField)],
) -> [Vec<crate::partition_pipe_axes::EntryKey>; 2] {
    end_keys_from_fields(fields, DUCT_END_KEYS_FIELDS)
}

/// The keys of the connector entries at a pipe's first and second end
/// ([`PIPE_END_KEYS_FIELDS`], #847).
pub fn pipe_end_keys_from_fields(
    fields: &[(String, InstanceField)],
) -> [Vec<crate::partition_pipe_axes::EntryKey>; 2] {
    end_keys_from_fields(fields, PIPE_END_KEYS_FIELDS)
}

/// A vector-of-pairs keys field ([`PIPE_END_KEYS_FIELDS`]) for each of
/// `names`.
fn end_keys_from_fields(
    fields: &[(String, InstanceField)],
    names: [&str; 2],
) -> [Vec<crate::partition_pipe_axes::EntryKey>; 2] {
    let keys = |wanted: &str| {
        fields
            .iter()
            .find_map(|(name, value)| match value {
                InstanceField::Vector(pairs) if name == wanted => Some(
                    pairs
                        .iter()
                        .filter_map(|pair| match pair {
                            InstanceField::Vector(parts) => match parts.as_slice() {
                                [
                                    InstanceField::Integer { value: element, .. },
                                    InstanceField::Integer { value: index, .. },
                                ] => Some((
                                    u64::try_from(*element).ok()?,
                                    u32::try_from(*index).ok()?,
                                )),
                                _ => None,
                            },
                            _ => None,
                        })
                        .collect(),
                ),
                _ => None,
            })
            .unwrap_or_default()
    };
    [keys(names[0]), keys(names[1])]
}

/// The keys field values for `keys` ([`PIPE_END_KEYS_FIELDS`]).
fn end_keys_field(keys: &[crate::partition_pipe_axes::EntryKey]) -> InstanceField {
    InstanceField::Vector(
        keys.iter()
            .map(|(element, index)| {
                InstanceField::Vector(vec![
                    InstanceField::Integer {
                        value: i64::try_from(*element).unwrap_or(i64::MAX),
                        signed: true,
                        size: 8,
                    },
                    InstanceField::Integer {
                        value: i64::from(*index),
                        signed: false,
                        size: 4,
                    },
                ])
            })
            .collect(),
    )
}

/// Give each duct along one of the model's axes its two ends, the centres of
/// its record box's faces across its length (RE-134), and the keys of the
/// connector entries there (#847), which say which of its connectors each
/// end is, as for a pipe. A duct whose box leaves no single length axis is
/// given neither.
fn attach_duct_end_keys(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_pipe_axes as ppa;
    if !ppa::supports_revit_version(revit_version) {
        return;
    }
    let mut ends = ppa::CurveEnds::new();
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Duct")
    {
        let (Some(id), Some(bbox), Some((width, height)), Some(stream)) = (
            element.id,
            element_record_bbox(element),
            curve_size_from_fields(&element.fields),
            element_source_stream(element),
        ) else {
            continue;
        };
        let dims = [bbox[3] - bbox[0], bbox[4] - bbox[1], bbox[5] - bbox[2]];
        let near = |a: f64, b: f64| (a - b).abs() <= CURVE_BOX_TOLERANCE_FEET;
        let axes: Vec<usize> = (0..3)
            .filter(|&axis| {
                let (a, b) = (dims[(axis + 1) % 3], dims[(axis + 2) % 3]);
                (near(a, width) && near(b, height)) || (near(a, height) && near(b, width))
            })
            .collect();
        let [axis] = axes.as_slice() else {
            continue;
        };
        let centre = [
            (bbox[0] + bbox[3]) / 2.0,
            (bbox[1] + bbox[4]) / 2.0,
            (bbox[2] + bbox[5]) / 2.0,
        ];
        let mut start = centre;
        let mut end = centre;
        start[*axis] = bbox[*axis];
        end[*axis] = bbox[*axis + 3];
        for (names, point) in DUCT_ENDS_FIELDS.iter().zip([start, end]) {
            for (name, value) in names.iter().zip(point) {
                element
                    .fields
                    .push(((*name).into(), InstanceField::Float { value, size: 8 }));
            }
        }
        ends.entry(stream).or_default().push((id, [start, end]));
    }
    let Ok(keys) = ppa::scan_pipe_end_keys(rf, revit_version, &ends) else {
        return;
    };
    for element in products
        .iter_mut()
        .filter(|element| element.class == "Duct")
    {
        let Some(end_keys) = element.id.and_then(|id| keys.get(&id)) else {
            continue;
        };
        for (name, keys) in DUCT_END_KEYS_FIELDS.iter().zip(end_keys) {
            element.fields.push(((*name).into(), end_keys_field(keys)));
        }
    }
}

/// The field naming the element joined at connector `connector` of a duct,
/// pipe or fitting (RE-138, RE-141).
pub fn connector_element_field(connector: u32) -> String {
    format!("m_connector_{connector}_element")
}

/// The field naming that element's connector index (RE-138, RE-141).
pub fn connector_index_field(connector: u32) -> String {
    format!("m_connector_{connector}_index")
}

/// The joins of an element: its connector, then the element and connector
/// index it is joined to (RE-138, RE-141).
pub type ConnectorJoins = Vec<(u32, u32, u32)>;

/// The joins of a duct, pipe or fitting, from its fields (RE-138, RE-141).
pub fn connector_joins_from_fields(fields: &[(String, InstanceField)]) -> ConnectorJoins {
    let mut joins = ConnectorJoins::new();
    for (name, value) in fields {
        let InstanceField::ElementId { id: other, .. } = value else {
            continue;
        };
        let Some(connector) = name
            .strip_prefix("m_connector_")
            .and_then(|rest| rest.strip_suffix("_element"))
            .and_then(|number| number.parse::<u32>().ok())
        else {
            continue;
        };
        let index_name = connector_index_field(connector);
        let other_index = fields.iter().find_map(|(name, value)| match value {
            InstanceField::Integer { value, .. } if *name == index_name => {
                u32::try_from(*value).ok()
            }
            _ => None,
        });
        if let Some(other_index) = other_index {
            joins.push((connector, *other, other_index));
        }
    }
    joins
}

/// The classes of the family instances whose connectors are read for joins:
/// the MEP categories, whose families carry connectors.
const JOINED_CLASSES: [&str; 18] = [
    "DuctFitting",
    "PipeFitting",
    "DuctTerminal",
    "DuctAccessory",
    "PipeAccessory",
    "PlumbingFixture",
    "Sprinkler",
    "MechanicalEquipment",
    "ElectricalEquipment",
    "ElectricalFixture",
    "LightingFixture",
    "LightingDevice",
    "FireAlarmDevice",
    "DataDevice",
    "CableTrayFitting",
    "ConduitFitting",
    "SpecialtyEquipment",
    "FoodServiceEquipment",
];

/// Give each element the element and connector joined at each of its
/// connectors. Where the native record path reads the file, the joins are
/// the ones its family instances' connectors list
/// ([`crate::native_connectors::family_instance_joins`], RE-171); elsewhere,
/// on the release the list form is measured on, the lists after a duct's or
/// pipe's anchor and those with a fitting first
/// ([`crate::partition_connector_pairs`], RE-138, RE-141). A connector with no
/// join read is left without the fields.
fn attach_connector_pairs(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_connector_pairs as pcp;
    // Only the family instances of the MEP categories are read: decoding
    // every family instance cost a second on Core Interior's furniture.
    let instances: BTreeSet<u64> = products
        .iter()
        .filter(|element| JOINED_CLASSES.contains(&element.class.as_str()))
        .filter_map(|element| element.id)
        .map(u64::from)
        .collect();
    if instances.is_empty() {
        return;
    }
    let pairs = match crate::native_connectors::family_instance_joins(rf, &instances) {
        Ok(pairs) => pairs,
        Err(_) if pcp::supports_revit_version(revit_version) => {
            let ids_of = |classes: &[&str]| -> BTreeSet<u64> {
                products
                    .iter()
                    .filter(|element| classes.contains(&element.class.as_str()))
                    .filter_map(|element| element.id)
                    .map(u64::from)
                    .collect()
            };
            let everything = products
                .iter()
                .filter_map(|element| element.id)
                .map(u64::from)
                .collect();
            let mut pairs =
                pcp::scan_connector_pairs(rf, &ids_of(&["Duct", "Pipe"])).unwrap_or_default();
            pairs.extend(
                pcp::scan_fitting_pairs(rf, &ids_of(&["DuctFitting", "PipeFitting"]), &everything)
                    .unwrap_or_default(),
            );
            pairs
        }
        Err(_) => return,
    };
    let mut by_element: BTreeMap<u64, Vec<&pcp::ConnectorPair>> = BTreeMap::new();
    for pair in &pairs {
        by_element.entry(pair.element).or_default().push(pair);
    }
    for element in products.iter_mut() {
        let Some(own) = element.id.and_then(|id| by_element.get(&u64::from(id))) else {
            continue;
        };
        let mut joined: BTreeSet<u32> = BTreeSet::new();
        for pair in own {
            let Ok(other) = u32::try_from(pair.other) else {
                continue;
            };
            if !joined.insert(pair.index) {
                continue;
            }
            element.fields.push((
                connector_element_field(pair.index),
                InstanceField::ElementId { tag: 0, id: other },
            ));
            element.fields.push((
                connector_index_field(pair.index),
                InstanceField::Integer {
                    value: i64::from(pair.other_index),
                    signed: false,
                    size: 4,
                },
            ));
        }
    }
}

/// Make every wall a curtain-wall mullion names a curtain wall, and give
/// each panel and mullion that names exactly one of them that wall as its
/// aggregate whole (RE-46).
///
/// A curtain wall owns its grid's mullions, and each mullion's reference
/// list names its wall. On Snowdon Towers the walls named by a mullion are
/// exactly the 42 Revit exports as `IfcCurtainWall` aggregates, and on RE1
/// Architecture the one; no other wall is named by a mullion. Walls named
/// only by a panel are basic walls used as a panel's infill, which Revit
/// exports as `IfcWall`, so a panel alone does not make a curtain wall.
///
/// Some parts name no wall at all, only their sibling mullions: on Snowdon,
/// the mullions of the "Solar Panels" curtain walls. Such a part takes the
/// one curtain wall whose record box contains its own (RE-62). That is
/// Revit's parent for all 89 such mullions and the 3 such panels that
/// Revit's export aggregates.
///
/// A door or window set in a curtain wall's grid in place of a panel is one
/// of its parts too, as Revit's export aggregates RE1 Architecture's door
/// 445975 under curtain wall 445961. It takes the curtain wall of the
/// one grid its record names. Naming a curtain wall directly is not enough:
/// on Snowdon Towers three doors name curtain wall 1506500 and Revit leaves
/// them standalone (RE-46). No record box decides a door either.
// Tracker: B64.
fn attach_curtain_walls(
    rf: &mut RevitFile,
    revit_version: u32,
    walls: &mut [DecodedElement],
    products: &mut [DecodedElement],
    openings: [&mut Vec<DecodedElement>; 2],
) {
    let wall_ids: BTreeSet<u32> = walls.iter().filter_map(|wall| wall.id).collect();
    if wall_ids.is_empty() {
        return;
    }
    let mut references: Vec<Option<Vec<u64>>> = Vec::with_capacity(products.len());
    let mut curtain_walls: BTreeSet<u32> = BTreeSet::new();
    for product in products.iter() {
        if !CURTAIN_WALL_PART_CLASSES.contains(&product.class.as_str()) {
            references.push(None);
            continue;
        }
        let list = record_references(rf, product).map(|(list, _)| list);
        if product.class == "CurtainWallMullion" {
            for id in list.iter().flatten() {
                if let Ok(id) = u32::try_from(*id) {
                    if wall_ids.contains(&id) {
                        curtain_walls.insert(id);
                    }
                }
            }
        }
        references.push(list);
    }
    let opening_references: Vec<Vec<Option<Vec<u64>>>> = openings
        .iter()
        .map(|elements| {
            elements
                .iter()
                .map(|element| record_references(rf, element).map(|(list, _)| list))
                .collect()
        })
        .collect();
    // RE-72: a part names the curtain grid it lies on, and the grid's own
    // data names its curtain wall.
    let unrecorded: BTreeSet<u32> = references
        .iter()
        .chain(opening_references.iter().flatten())
        .flatten()
        .flatten()
        .filter_map(|&id| u32::try_from(id).ok())
        .filter(|id| !wall_ids.contains(id))
        .collect();
    let grids = scan_curtain_grid_walls(rf, revit_version, &unrecorded, &wall_ids);
    curtain_walls.extend(grids.values().copied());
    if curtain_walls.is_empty() {
        return;
    }
    for wall in walls.iter_mut() {
        if wall.id.is_some_and(|id| curtain_walls.contains(&id)) {
            wall.class = CURTAIN_WALL_CLASS.into();
        }
    }
    // RE-62: the record boxes of the curtain walls, for parts whose record
    // names none.
    let wall_boxes: Vec<(u32, [f64; 6])> = walls
        .iter()
        .filter_map(|wall| Some((wall.id?, element_record_bbox(wall)?)))
        .filter(|(id, _)| curtain_walls.contains(id))
        .collect();
    for (product, list) in products.iter_mut().zip(references) {
        let Some(list) = list else {
            continue;
        };
        let named: BTreeSet<u32> = list
            .iter()
            .filter_map(|&id| u32::try_from(id).ok())
            .filter(|id| curtain_walls.contains(id) && Some(*id) != product.id)
            .collect();
        let on_grid: BTreeSet<u32> = list
            .iter()
            .filter_map(|&id| u32::try_from(id).ok())
            .filter_map(|id| grids.get(&id).copied())
            .collect();
        let whole = match (on_grid.len(), named.len()) {
            (1, _) => on_grid.iter().next().copied(),
            (0, 1) => named.iter().next().copied(),
            (0, 0) => element_record_bbox(product).and_then(|part| {
                let mut inside = wall_boxes
                    .iter()
                    .filter(|(_, wall)| box_contains(wall, &part, CURTAIN_PART_BOX_TOLERANCE_FEET))
                    .map(|(id, _)| *id);
                let first = inside.next()?;
                inside.next().is_none().then_some(first)
            }),
            _ => None,
        };
        if let Some(whole) = whole {
            product.fields.push((
                AGGREGATE_WHOLE_FIELD.into(),
                InstanceField::ElementId { tag: 0, id: whole },
            ));
        }
    }
    for (elements, lists) in openings.into_iter().zip(opening_references) {
        for (element, list) in elements.iter_mut().zip(lists) {
            let Some(list) = list else {
                continue;
            };
            let ids: Vec<u32> = list
                .iter()
                .filter_map(|&id| u32::try_from(id).ok())
                .collect();
            let on_grid: BTreeSet<u32> =
                ids.iter().filter_map(|id| grids.get(id).copied()).collect();
            if let (1, Some(&whole)) = (on_grid.len(), on_grid.iter().next()) {
                element.fields.push((
                    AGGREGATE_WHOLE_FIELD.into(),
                    InstanceField::ElementId { tag: 0, id: whole },
                ));
            }
        }
    }
}

/// Where a curtain grid's element data names its curtain wall, as a `u64`
/// at both offsets past the data's ElementId (RE-72).
pub const CURTAIN_GRID_WALL_OFFSETS: [usize; 2] = [85, 478];

/// The curtain wall each id in `candidates` names as a curtain grid, by
/// the grid's ElementId (RE-72): its element data carries a wall in
/// `walls` at both [`CURTAIN_GRID_WALL_OFFSETS`]. A grid whose copies
/// disagree is left out.
fn scan_curtain_grid_walls(
    rf: &mut RevitFile,
    revit_version: u32,
    candidates: &BTreeSet<u32>,
    walls: &BTreeSet<u32>,
) -> BTreeMap<u32, u32> {
    let Some(header) = crate::partition_names::element_data_header(revit_version) else {
        return BTreeMap::new();
    };
    let mut found: BTreeMap<u32, Option<u32>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let buf = inflated.bytes();
        for hit in memchr::memmem::find_iter(buf, &header) {
            let id_at = hit + header.len();
            let Some(id) = le_bytes::u64_at(buf, id_at)
                .and_then(|id| u32::try_from(id).ok())
                .filter(|id| candidates.contains(id))
            else {
                continue;
            };
            let [first, second] =
                CURTAIN_GRID_WALL_OFFSETS.map(|offset| le_bytes::u64_at(buf, id_at + 8 + offset));
            let wall = match (first, second) {
                (Some(first), Some(second)) if first == second => u32::try_from(first)
                    .ok()
                    .filter(|wall| walls.contains(wall)),
                _ => None,
            };
            let Some(wall) = wall else {
                continue;
            };
            match found.get_mut(&id) {
                None => {
                    found.insert(id, Some(wall));
                }
                Some(held) => {
                    if *held != Some(wall) {
                        *held = None;
                    }
                }
            }
        }
    }
    found
        .into_iter()
        .filter_map(|(id, wall)| wall.map(|wall| (id, wall)))
        .collect()
}

/// How far past a curtain wall's record box a part's box may reach and
/// still lie inside it (RE-62): 0.05 ft places every measured part, and
/// 0.01 ft misses mullions whose profile reaches past the wall's box.
const CURTAIN_PART_BOX_TOLERANCE_FEET: f64 = 0.05;

/// `inner` lies inside `outer`, both `[min x, min y, min z, max x, max y,
/// max z]`, within `tolerance` on every side.
fn box_contains(outer: &[f64; 6], inner: &[f64; 6], tolerance: f64) -> bool {
    (0..3).all(|axis| {
        inner[axis] >= outer[axis] - tolerance && inner[axis + 3] <= outer[axis + 3] + tolerance
    })
}

/// Placed instances of every
/// [`crate::partition_element_records::PRODUCT_RECORD_CATEGORIES`]
/// category, each decoded under its class name (RE-33).
///
/// The selection is the #211 instance rule, the same one that reproduces
/// the exported wall, door, window and column sets; one sweep of the
/// partitions serves all thirteen categories. Bodies are the record
/// bounding box, and a Level binds only when the record's reference list
/// names exactly one.
pub fn product_instances_from_partition_records(
    rf: &mut RevitFile,
    revit_version: u32,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    use crate::partition_element_records::PRODUCT_RECORD_CATEGORIES;
    if !crate::partition_element_records::supports_revit_version(revit_version) {
        return Ok(Vec::new());
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(Vec::new()),
    };
    if declared.is_empty() {
        return Ok(Vec::new());
    }
    let categories: Vec<i64> = PRODUCT_RECORD_CATEGORIES.iter().map(|(c, _)| *c).collect();
    let records = crate::partition_element_records::scan_category_records_multi(
        rf,
        revit_version,
        &categories,
        &declared,
    )?;
    let records = without_non_primary_options(rf, records);
    let mut by_category: BTreeMap<i64, Vec<_>> = BTreeMap::new();
    for record in records {
        by_category
            .entry(record.builtin_category)
            .or_default()
            .push(record);
    }
    let mut out = Vec::new();
    for (category, class) in PRODUCT_RECORD_CATEGORIES {
        if let Some(records) = by_category.remove(&category) {
            out.extend(instances_from_records(records, class, level_ids));
        }
    }
    Ok(out)
}

/// Recover room instances from partition element records (#90, RE-29).
///
/// `OST_Rooms` under the #211 instance rule reproduces the exported
/// room ElementId set exactly; the number, name and host Level come
/// from the room's own parameter block
/// ([`crate::partition_room_parameters`]), joined by ElementId only.
///
/// The parameter join is attached, never required: a room whose block
/// does not decode, or whose blocks disagree, still emits with its
/// record body and keeps the identity the record gives it.
pub fn rooms_from_partition_category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    let Some(records) = category_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_ROOMS,
    )?
    else {
        return Ok(Vec::new());
    };
    let room_ids: BTreeSet<u32> = records
        .iter()
        .filter(|record| record.is_exported_instance())
        .map(|record| record.element_id)
        .collect();
    let parameters =
        crate::partition_room_parameters::scan_room_parameters(rf, revit_version, &room_ids)
            .unwrap_or_default();
    let mut rooms = room_instances_from_records(records, &parameters, level_ids);
    // RE-117: a room's number and name are the ones its parameter entries
    // give it; RE-29's block stands in where they are not read, and still
    // gives the Level. On Snowdon Towers the block names 1 of 54 rooms, and
    // that one wrongly.
    attach_room_parameter_entries(rf, revit_version, &room_ids, &mut rooms);
    // RE-153: a room's Floor Finish.
    let finishes = crate::partition_room_parameters::scan_room_text_parameter(
        rf,
        revit_version,
        &room_ids,
        crate::partition_room_parameters::ROOM_FINISH_FLOOR_PARAMETER,
    );
    for room in rooms.iter_mut() {
        if let Some(finish) = room.id.and_then(|id| finishes.get(&id)) {
            room.fields.push((
                ROOM_FLOOR_FINISH_FIELD.into(),
                InstanceField::String(finish.clone()),
            ));
        }
    }
    Ok(rooms)
}

/// Field carrying a room's Floor Finish (RE-153).
pub const ROOM_FLOOR_FINISH_FIELD: &str = "m_room_floor_finish";

/// Give each room in `rooms` the number and name its parameter entries
/// hold (RE-117), in place of any read before that differs; a room whose
/// block agrees keeps the block as its source.
fn attach_room_parameter_entries(
    rf: &mut RevitFile,
    revit_version: u32,
    room_ids: &BTreeSet<u32>,
    rooms: &mut [DecodedElement],
) {
    let entries =
        crate::partition_room_parameters::scan_room_parameter_entries(rf, revit_version, room_ids);
    for room in rooms.iter_mut() {
        let Some((number, name)) = room.id.and_then(|id| entries.get(&id)) else {
            continue;
        };
        let text = |wanted: &str| {
            room.fields.iter().find_map(|(field, value)| match value {
                InstanceField::String(text) if field == wanted => Some(text.clone()),
                _ => None,
            })
        };
        // Where RE-29's block already agrees, it keeps its provenance.
        if text("m_name").as_ref() == Some(name) && text(ROOM_NUMBER_FIELD).as_ref() == Some(number)
        {
            continue;
        }
        room.fields.retain(|(field, _)| {
            field != "m_name" && field != ROOM_NUMBER_FIELD && field != ROOM_PARAMETER_SOURCE_FIELD
        });
        room.fields
            .push(("m_name".into(), InstanceField::String(name.clone())));
        room.fields.push((
            ROOM_NUMBER_FIELD.into(),
            InstanceField::String(number.clone()),
        ));
        room.fields.push((
            ROOM_PARAMETER_SOURCE_FIELD.into(),
            InstanceField::String(
                crate::partition_room_parameters::ROOM_PARAMETER_ENTRY_SOURCE.into(),
            ),
        ));
    }
}

/// Give each room the outline of its stored solid (RE-101,
/// [`crate::partition_room_boundaries`]), read from the partition of the
/// room's own record and kept only where it spans the record's box. A room
/// whose solid does not close keeps its box.
fn attach_room_outlines(rf: &mut RevitFile, revit_version: u32, rooms: &mut [DecodedElement]) {
    use crate::partition_room_boundaries as prb;
    if !prb::ROOM_SOLID_SUPPORTED_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    // Each stream's room solids are found in one pass (B85): a search per
    // room took 1.2 s on Autodesk's 2025 rme_advanced sample.
    let mut solids = std::collections::HashMap::new();
    for room in rooms.iter_mut() {
        let (Some(id), Some(stream)) = (room.id, element_source_stream(room)) else {
            continue;
        };
        let float = |wanted: &str| {
            room.fields.iter().find_map(|(name, value)| match value {
                InstanceField::Float { value, .. } if name == wanted => Some(*value),
                _ => None,
            })
        };
        let (Some(cx), Some(cy), Some(z), Some(dx), Some(dy), Some(dz)) = (
            float("m_locationX"),
            float("m_locationY"),
            float("m_locationZ"),
            float("m_bboxWidth"),
            float("m_bboxDepth"),
            float("m_bboxHeight"),
        ) else {
            continue;
        };
        let bbox = [
            cx - dx / 2.0,
            cy - dy / 2.0,
            z,
            cx + dx / 2.0,
            cy + dy / 2.0,
            z + dz,
        ];
        let (inflated, headers) = match solids.entry(stream) {
            std::collections::hash_map::Entry::Occupied(held) => held.into_mut(),
            std::collections::hash_map::Entry::Vacant(slot) => {
                let Ok(inflated) = rf.inflated_partition(slot.key()) else {
                    continue;
                };
                let headers = prb::solid_headers_by_id(inflated.bytes());
                slot.insert((inflated, headers))
            }
        };
        let Some(headers) = headers.get(&u64::from(id)) else {
            continue;
        };
        if let Some(profile) = prb::outline_of_solids(inflated.bytes(), headers, bbox) {
            let mut fields = profile.fields();
            for (name, value) in fields.iter_mut() {
                if name == crate::element_record_plan_profiles::PLAN_PROFILE_SOURCE_FIELD {
                    *value = InstanceField::String(prb::ROOM_OUTLINE_SOURCE.into());
                }
            }
            room.fields.extend(fields);
        }
    }
}

/// Releases a room's `Qto_SpaceBaseQuantities.Height` is read on (RE-255).
pub const ROOM_HEIGHT_REVIT_VERSIONS: &[u32] = &[2024, 2025, 2026];

/// Field holding a room's height, feet (RE-255).
pub const ROOM_HEIGHT_FIELD: &str = "m_room_height";

/// Give each room whose native record holds its stored solid's faces (two
/// `Face` objects or more) its `RoomElem.m_height` as its height: Revit's
/// export writes it as the space's `Height` on every such room of the
/// BIM4LCA office, the R2025 models and the held-out Revit 2026 house
/// (RE-255). A room with no faces in its
/// record gets none: on the office Revit's `Height` is another value on all
/// 20 of those.
fn attach_room_heights(rf: &mut RevitFile, revit_version: u32, rooms: &mut [DecodedElement]) {
    if !ROOM_HEIGHT_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let ids: BTreeSet<u64> = rooms
        .iter()
        .filter_map(|room| room.id.map(u64::from))
        .collect();
    if ids.is_empty() {
        return;
    }
    let options = crate::native_document::Options {
        selected_ids: ids,
        ..crate::native_document::Options::default()
    };
    let mut heights: BTreeMap<u64, f64> = BTreeMap::new();
    let read = crate::native_document::extract_graphs(rf, &options, |record| {
        let Some(graph) = record.graph.as_ref() else {
            return Ok(());
        };
        let faces = graph
            .objects
            .iter()
            .filter(|o| o.class_name == "Face")
            .count();
        let height = graph
            .objects
            .iter()
            .find(|o| o.class_name == "RoomElem")
            .and_then(|o| o.fields.get("m_height"))
            .and_then(serde_json::Value::as_f64)
            .filter(|h| h.is_finite() && *h > 0.0);
        if let (true, Some(height)) = (faces >= 2, height) {
            heights.insert(record.identity.element_id, height);
        }
        Ok(())
    });
    if read.is_err() {
        return;
    }
    for room in rooms.iter_mut() {
        if let Some(height) = room.id.and_then(|id| heights.get(&u64::from(id))).copied() {
            room.fields.push((
                ROOM_HEIGHT_FIELD.into(),
                InstanceField::Float {
                    value: height,
                    size: 8,
                },
            ));
        }
    }
}

fn element_source_stream(element: &DecodedElement) -> Option<String> {
    element.fields.iter().find_map(|(name, value)| match value {
        InstanceField::String(stream) if name == "m_source_stream" => Some(stream.clone()),
        _ => None,
    })
}

/// Field carrying a recovered room number.
pub const ROOM_NUMBER_FIELD: &str = "m_number";
/// Field recording where the room number / name came from.
pub const ROOM_PARAMETER_SOURCE_FIELD: &str = "m_room_parameter_source";

/// Room instance selection with the number / name / Level join
/// attached (#90, RE-29).
///
/// The Level the parameter block names is used only when the record's
/// own counted reference list did **not** already name one, so the
/// RE-27 carrier stays the primary. On `2024_Core_Interior.rvt` both
/// carriers answer for all 116 rooms and they agree 116 of 116.
pub fn room_instances_from_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
    parameters: &BTreeMap<u32, crate::partition_room_parameters::RoomParameters>,
    level_ids: &BTreeSet<u32>,
) -> Vec<DecodedElement> {
    select_instance_records(records)
        .values()
        .map(|record| {
            let mut decoded = element_record_decoded(record, "Room", level_ids);
            if let Some(block) = parameters.get(&record.element_id) {
                decoded
                    .fields
                    .push(("m_name".into(), InstanceField::String(block.name.clone())));
                decoded.fields.push((
                    ROOM_NUMBER_FIELD.into(),
                    InstanceField::String(block.number.clone()),
                ));
                decoded.fields.push((
                    ROOM_PARAMETER_SOURCE_FIELD.into(),
                    InstanceField::String(
                        crate::partition_room_parameters::ROOM_PARAMETER_SOURCE.into(),
                    ),
                ));
                let already_bound = decoded.fields.iter().any(|(name, _)| {
                    name == crate::element_record_level_refs::LEVEL_REFERENCE_FIELD
                });
                if !already_bound {
                    if let Some(id) = block.level_element_id(level_ids) {
                        decoded.fields.push((
                            crate::element_record_level_refs::LEVEL_REFERENCE_FIELD.into(),
                            InstanceField::ElementId { tag: 0, id },
                        ));
                        if let Some(slot) = decoded
                            .fields
                            .iter_mut()
                            .find(|(name, _)| name == "m_level_bound")
                        {
                            slot.1 = InstanceField::Bool(true);
                        }
                    }
                }
            }
            decoded
        })
        .collect()
}

/// Recover architectural column instances from partition element
/// records (#204, instance rule replaced in #211).
///
/// The `OST_Columns` sweep carries the type-symbol envelopes too, so
/// the family/type join of #215 costs no extra inflate — see
/// [`column_instances_from_records`].
pub fn columns_from_partition_category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    let (column_records, wall_records) = column_and_wall_records(rf, revit_version)?;
    let wall_instances: Vec<crate::partition_element_records::PartitionElementRecord> =
        select_instance_records(wall_records)
            .into_values()
            .collect();
    Ok(column_instances_from_records(
        column_records,
        level_ids,
        &wall_instances,
    ))
}

/// The `OST_Columns` and `OST_Walls` records of one file, from a
/// single partition sweep.
///
/// The two categories travel together because the column body is the
/// column's prism minus the prisms of the walls it names
/// ([`crate::element_record_column_cuts`]), and
/// [`crate::partition_element_records::scan_category_records_multi`]
/// reads both out of one pass over the inflated streams.
fn column_and_wall_records(
    rf: &mut RevitFile,
    revit_version: u32,
) -> Result<(
    Vec<crate::partition_element_records::PartitionElementRecord>,
    Vec<crate::partition_element_records::PartitionElementRecord>,
)> {
    use crate::partition_element_records as per;

    if !per::supports_revit_version(revit_version) {
        return Ok((Vec::new(), Vec::new()));
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok((Vec::new(), Vec::new())),
    };
    if declared.is_empty() {
        return Ok((Vec::new(), Vec::new()));
    }
    let records = per::scan_category_records_multi(
        rf,
        revit_version,
        &[per::OST_COLUMNS, per::OST_WALLS],
        &declared,
    )?;
    let records = without_non_primary_options(rf, records);
    Ok(records
        .into_iter()
        .partition(|record| record.builtin_category == per::OST_COLUMNS))
}

/// Recover wall instances from partition element records (#211), with
/// the join-trimmed body of RE-26.
pub fn walls_from_partition_category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    let Some(records) = category_records(
        rf,
        revit_version,
        crate::partition_element_records::OST_WALLS,
    )?
    else {
        return Ok(Vec::new());
    };
    Ok(wall_instances_from_records(records, level_ids))
}

/// The `Level` ElementIds the #219 / RE-27 reference-list join tests
/// against, or an empty set on a release / file with no proven Level
/// framing (the join then resolves nothing and every element keeps the
/// elevation join it already had).
pub fn level_element_ids(rf: &mut RevitFile, revit_version: u32) -> Result<BTreeSet<u32>> {
    if !crate::partition_level_records::supports_revit_version(revit_version) {
        return Ok(BTreeSet::new());
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(BTreeSet::new()),
    };
    crate::partition_level_records::scan_partition_level_ids(rf, revit_version, &declared)
}

/// Every partition element record of one `BuiltInCategory`, or `None`
/// on a release / file where the shape is not proven.
fn category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    builtin_category: i64,
) -> Result<Option<Vec<crate::partition_element_records::PartitionElementRecord>>> {
    if !crate::partition_element_records::supports_revit_version(revit_version) {
        return Ok(None);
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(None),
    };
    if declared.is_empty() {
        return Ok(None);
    }
    let records = crate::partition_element_records::scan_category_records(
        rf,
        revit_version,
        builtin_category,
        &declared,
    )?;
    Ok(Some(without_non_primary_options(rf, records)))
}

/// Recover placed element instances of one `BuiltInCategory` from
/// partition element records (#211).
///
/// Fail-closed pipeline, each step justified in
/// [`crate::partition_element_records`]:
///
/// 1. Every candidate record's leading `u64` must be an ElementId
///    declared in `Global/ElemTable`, and the record must carry the
///    fixed bbox marker — a random byte match cannot become an
///    element.
/// 2. The record must be a standalone placed instance:
///    [`crate::partition_element_records::PartitionElementRecord::is_exported_instance`] — no container
///    reference at `+0x32`, placement kind at `+0x42` equal to
///    [`crate::partition_element_records::PLACEMENT_KIND_INSTANCE`].
///
/// Nothing here invents an ElementId, a level binding, or a profile
/// shape: the emitted geometry is exactly the recorded bounding box.
pub fn instances_from_partition_category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    builtin_category: i64,
    class: &str,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    if !crate::partition_element_records::supports_revit_version(revit_version) {
        return Ok(Vec::new());
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(Vec::new()),
    };
    if declared.is_empty() {
        return Ok(Vec::new());
    }
    let records = crate::partition_element_records::scan_category_records(
        rf,
        revit_version,
        builtin_category,
        &declared,
    )?;
    let records = without_non_primary_options(rf, records);
    Ok(instances_from_records(records, class, level_ids))
}

/// Instance selection over already-decoded category records — split
/// out so the rule is unit-testable without a corpus file.
///
/// The selector is the direct test
/// [`crate::partition_element_records::PartitionElementRecord::is_exported_instance`]. It supersedes
/// the family-local bbox proxy plus highest-id-per-footprint collapse
/// that #204 shipped for columns: both reproduced the 256 exported
/// columns, only the direct test also reproduces the exact exported
/// id sets for walls, doors and windows (#211).
pub fn instances_from_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
    class: &str,
    level_ids: &BTreeSet<u32>,
) -> Vec<DecodedElement> {
    select_instance_records(records)
        .values()
        .map(|record| element_record_decoded(record, class, level_ids))
        .collect()
}

/// Field carrying the recovered host ElementId of a door or window.
///
/// The name is the one [`crate::elements::openings::Door`] /
/// [`crate::elements::openings::Window`] already read from
/// schema-field decodes, so the recovered value flows through the
/// existing `recover_door_host` / `recover_window_host` path without
/// a second host concept.
pub const OPENING_HOST_FIELD: &str = "m_hostId";

/// Field recording where [`OPENING_HOST_FIELD`] came from.
pub const OPENING_HOST_PROVENANCE_FIELD: &str = "m_host_provenance";

/// Value of [`OPENING_HOST_PROVENANCE_FIELD`] for the RE-23 carrier.
pub const OPENING_HOST_PROVENANCE: &str = "partition_element_record_reference_list";

/// Field carrying the exported walls a door's or window's reference list
/// names, nearest to its own ElementId first (#439). The
/// host is chosen from them once curtain walls are known
/// ([`bind_opening_hosts`]); the field is then removed.
const OPENING_HOST_CANDIDATES_FIELD: &str = "m_hostCandidateIds";

/// Door / window instance selection with the host-wall binding
/// attached (#222, RE-23, #439).
///
/// The host is a wall the record's counted list at `+0x88` names: one of
/// `host_candidates`, the ElementIds already selected as exported wall
/// instances by the same rule. Wall-set membership is what makes a
/// wrong read fail closed rather than invent a host. The list is in
/// ascending ElementId order, so RE-23's slot immediately before the
/// record's own id is only the nearest smaller id; a host with a larger
/// id than its door comes after it, and families that list their type
/// (Door-Opening, Schematic Opening Cut) put it between (#439, RE-85).
/// When the list names several walls, the nearest below the record's
/// own id is taken, then the nearest above. The partition pass then
/// skips curtain walls.
///
/// Measured against Revit's own export (`IfcRelVoidsElement` ∘
/// `IfcRelFillsElement`, read with IfcOpenShell): on
/// `2024_Core_Interior.rvt` 138 of 138 `(host wall, filling element)`
/// pairs, as with RE-23's slot. On Snowdon Towers (local only) every
/// door and window record naming exactly one wall names Revit's host
/// (235), and each of the 6 naming several takes a wall Revit cuts for
/// it, 3 of them the one it fills.
pub fn opening_instances_from_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
    class: &str,
    host_candidates: &BTreeSet<u32>,
    level_ids: &BTreeSet<u32>,
) -> Vec<DecodedElement> {
    select_instance_records(records)
        .values()
        .map(|record| {
            let mut decoded = element_record_decoded(record, class, level_ids);
            attach_host_candidates(record, host_candidates, &mut decoded);
            decoded
        })
        .collect()
}

/// Record on `decoded` the walls in `host_candidates` that `record`'s
/// reference list names, nearest to its own ElementId first, and take the
/// nearest as its host until [`bind_opening_hosts`] has seen curtain walls
/// (#439, RE-85). The list is in ascending ElementId order: the nearest
/// wall below the record's own id comes first, then the nearest above.
fn attach_host_candidates(
    record: &crate::partition_element_records::PartitionElementRecord,
    host_candidates: &BTreeSet<u32>,
    decoded: &mut DecodedElement,
) {
    let walls: Vec<u32> = record
        .references
        .iter()
        .filter_map(|id| u32::try_from(*id).ok())
        .filter(|id| *id != record.element_id && host_candidates.contains(id))
        .collect();
    let (below, above): (Vec<u32>, Vec<u32>) =
        walls.iter().partition(|id| **id < record.element_id);
    let candidates: Vec<u32> = below.into_iter().rev().chain(above).collect();
    let Some(&host) = candidates.first() else {
        return;
    };
    decoded.fields.push((
        OPENING_HOST_CANDIDATES_FIELD.into(),
        InstanceField::Vector(
            candidates
                .iter()
                .map(|&id| InstanceField::ElementId { tag: 0, id })
                .collect(),
        ),
    ));
    decoded.fields.push((
        OPENING_HOST_FIELD.into(),
        InstanceField::ElementId { tag: 0, id: host },
    ));
    decoded.fields.push((
        OPENING_HOST_PROVENANCE_FIELD.into(),
        InstanceField::String(OPENING_HOST_PROVENANCE.into()),
    ));
}

/// Bind each door or window to the first of its host candidates that is
/// not a curtain wall, and drop the candidate list (#439). Revit's export
/// cuts no opening for a door or window whose only candidate is a
/// curtain wall; such an element keeps no host.
fn bind_opening_hosts(walls: &[DecodedElement], openings: &mut [DecodedElement]) {
    let curtain_walls: BTreeSet<u32> = walls
        .iter()
        .filter(|wall| wall.class == CURTAIN_WALL_CLASS)
        .filter_map(|wall| wall.id)
        .collect();
    for element in openings.iter_mut() {
        let candidates = element_ids_field(element, OPENING_HOST_CANDIDATES_FIELD);
        if candidates.is_empty() {
            continue;
        }
        // A curtain wall's door or window (B64) is set in no wall.
        let part_of_curtain_wall = element
            .fields
            .iter()
            .any(|(name, _)| name == AGGREGATE_WHOLE_FIELD);
        let host = candidates
            .into_iter()
            .find(|id| !curtain_walls.contains(id))
            .filter(|_| !part_of_curtain_wall);
        element.fields.retain(|(name, _)| {
            name != OPENING_HOST_CANDIDATES_FIELD
                && name != OPENING_HOST_FIELD
                && name != OPENING_HOST_PROVENANCE_FIELD
        });
        if let Some(host) = host {
            element.fields.push((
                OPENING_HOST_FIELD.into(),
                InstanceField::ElementId { tag: 0, id: host },
            ));
            element.fields.push((
                OPENING_HOST_PROVENANCE_FIELD.into(),
                InstanceField::String(OPENING_HOST_PROVENANCE.into()),
            ));
        }
    }
}

/// Recover door / window instances of one `BuiltInCategory` and bind
/// each to its host wall (#222, RE-23).
pub fn openings_from_partition_category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    builtin_category: i64,
    class: &str,
    host_candidates: &BTreeSet<u32>,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    if !crate::partition_element_records::supports_revit_version(revit_version) {
        return Ok(Vec::new());
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(Vec::new()),
    };
    if declared.is_empty() {
        return Ok(Vec::new());
    }
    let records = crate::partition_element_records::scan_category_records(
        rf,
        revit_version,
        builtin_category,
        &declared,
    )?;
    let records = without_non_primary_options(rf, records);
    Ok(opening_instances_from_records(
        records,
        class,
        host_candidates,
        level_ids,
    ))
}

/// `records` without those in a non-primary design option: Revit's own
/// export writes the main model and each option set's primary option, and
/// leaves the other options out (#319, RE-40). Elements of an option whose
/// set is unresolved are kept.
fn without_non_primary_options(
    rf: &mut RevitFile,
    mut records: Vec<crate::partition_element_records::PartitionElementRecord>,
) -> Vec<crate::partition_element_records::PartitionElementRecord> {
    let options = rf.memoised_design_options();
    // Elements not in the export phase are left out too, as Revit's export
    // leaves them out, except rooms (#328, RE-184).
    let phases = rf.memoised_phase_filter();
    records.retain(|record| !options.excludes(record) && !phases.excludes(record));
    records
}

/// Revit 2023 elements from their partition element records (RE-81): each
/// placed instance of a [`crate::partition_element_records::RECOVERED_CATEGORIES`]
/// category, with its box as its body, into the bucket its category
/// feeds. Components nested in doors and windows are left out
/// ([`nested_in_openings`]). Doors and windows bind to their host wall by
/// the 2024 rule (RE-85) on 2023's reference lists, and every element to
/// the one Level its list names (RE-107). No names, types, joins or design
/// options: their 2023 layouts are not decoded.
fn recover_2023_records(rf: &mut RevitFile, revit_version: u32, out: &mut PartitionSchemaMvp) {
    use crate::partition_element_records as per;
    let records = crate::partition_element_records_2023::scan_records(rf, revit_version);
    let names = type_and_family_names_2023(rf, &records);
    let system_types = system_type_names_2023(rf, revit_version, &records);
    let selected = select_newest_instance_records(records);
    // Only a family instance can be nested; a host wall and the doors it
    // hosts name each other too (RE-76's class tag, at the same place on
    // 2023).
    let family_instance = rf.memoised_schema_classes().ok().and_then(|classes| {
        classes
            .classes
            .iter()
            .find(|class| class.name == "FamilyInstance")
            .map(|class| class.tag)
    });
    let nested = match family_instance {
        Some(tag) => nested_in_openings(&selected, tag),
        None => BTreeSet::new(),
    };
    // Each record names its Level in its reference list, as on 2024
    // (RE-107).
    let level_ids = level_element_ids(rf, revit_version).unwrap_or_default();
    for record in selected.values() {
        if nested.contains(&record.element_id) {
            continue;
        }
        let Some((_, class)) = per::RECOVERED_CATEGORIES
            .iter()
            .find(|(category, _)| *category == record.builtin_category)
        else {
            continue;
        };
        let mut decoded = element_record_decoded(record, class, &level_ids);
        if let Some((type_id, type_name, family_name)) = names.get(&record.element_id) {
            decoded.fields.push((
                TYPE_ID_FIELD.into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: *type_id,
                },
            ));
            decoded.fields.push((
                TYPE_NAME_FIELD.into(),
                InstanceField::String(type_name.clone()),
            ));
            decoded.fields.push((
                FAMILY_NAME_FIELD.into(),
                InstanceField::String(family_name.clone()),
            ));
        } else if let Some((type_id, type_name)) = system_types.get(&record.element_id) {
            decoded.fields.push((
                TYPE_ID_FIELD.into(),
                InstanceField::ElementId {
                    tag: 0,
                    id: *type_id,
                },
            ));
            decoded.fields.push((
                TYPE_NAME_FIELD.into(),
                InstanceField::String(type_name.clone()),
            ));
        }
        match record.builtin_category {
            per::OST_WALLS => out.walls.push(decoded),
            per::OST_DOORS => out.doors.push(decoded),
            per::OST_WINDOWS => out.windows.push(decoded),
            per::OST_FLOORS | per::OST_BUILDING_PAD => out.slabs.push(decoded),
            per::OST_ROOMS => out.rooms.push(decoded),
            per::OST_COLUMNS => out.columns.push(decoded),
            _ => out.products.push(decoded),
        }
    }
    // --- Walls cut back by the walls they join, by 2024's solver (RE-26,
    // RE-29): a 2023 record box is the untrimmed wall too, and its
    // reference list names the walls it joins (RE-120) ---
    let wall_records: Vec<per::PartitionElementRecord> = out
        .walls
        .iter()
        .filter_map(|wall| wall.id.and_then(|id| selected.get(&id)).cloned())
        .collect();
    let trims = crate::element_record_wall_joins::join_trims(&wall_records);
    for wall in out.walls.iter_mut() {
        if let Some((record, trim)) = wall
            .id
            .and_then(|id| Some((selected.get(&id)?, trims.get(&id)?)))
        {
            apply_wall_join_trim(wall, record, trim);
        }
    }
    // --- Beams stopped at the faces of the columns their records name
    // (RE-122) ---
    let framing: Vec<per::PartitionElementRecord> = out
        .products
        .iter()
        .filter(|element| element.class == "StructuralFraming")
        .filter_map(|element| element.id.and_then(|id| selected.get(&id)).cloned())
        .collect();
    let columns: Vec<per::PartitionElementRecord> = selected
        .values()
        .filter(|record| {
            matches!(
                record.builtin_category,
                per::OST_COLUMNS | per::OST_STRUCTURAL_COLUMNS
            ) && !nested.contains(&record.element_id)
        })
        .cloned()
        .collect();
    let beam_trims = crate::element_record_beam_cuts::beam_column_trims(&framing, &columns);
    for beam in out.products.iter_mut() {
        if let Some(trim) = beam.id.and_then(|id| beam_trims.get(&id)) {
            apply_beam_column_trim(beam, trim);
        }
    }
    // --- Rooms' numbers and names (RE-117) ---
    let room_ids: BTreeSet<u32> = out.rooms.iter().filter_map(|room| room.id).collect();
    attach_room_parameter_entries(rf, revit_version, &room_ids, &mut out.rooms);
    let wall_ids: BTreeSet<u32> = out.walls.iter().filter_map(|wall| wall.id).collect();
    for element in out.doors.iter_mut().chain(out.windows.iter_mut()) {
        if let Some(record) = element.id.and_then(|id| selected.get(&id)) {
            attach_host_candidates(record, &wall_ids, element);
        }
    }
    bind_opening_hosts(&out.walls, &mut out.doors);
    bind_opening_hosts(&out.walls, &mut out.windows);
}

/// ElementIds of the instances in `selected` nested in a door or window
/// (RE-81): a family instance (class tag `family_instance`) whose
/// reference list names a placed door or window that names it back. Revit's export writes some of these and leaves out
/// others, by a rule not decoded (on a 2023 project it keeps a window's
/// frame and sill cut and drops its mullion pattern), so all are left out
/// rather than guessed.
fn nested_in_openings(
    selected: &BTreeMap<u32, crate::partition_element_records::PartitionElementRecord>,
    family_instance: u16,
) -> BTreeSet<u32> {
    use crate::partition_element_records::{OST_DOORS, OST_WINDOWS};
    let is_opening = |category: i64| category == OST_DOORS || category == OST_WINDOWS;
    selected
        .values()
        .filter(|child| child.class_tag == family_instance && !is_opening(child.builtin_category))
        .filter(|child| {
            child.references.iter().any(|&reference| {
                u32::try_from(reference)
                    .ok()
                    .and_then(|parent| selected.get(&parent))
                    .is_some_and(|parent| {
                        is_opening(parent.builtin_category)
                            && parent.references.contains(&u64::from(child.element_id))
                    })
            })
        })
        .map(|child| child.element_id)
        .collect()
}

/// Instance selection proper: one record per exported ElementId.
fn select_instance_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
) -> BTreeMap<u32, crate::partition_element_records::PartitionElementRecord> {
    use crate::partition_element_records::PartitionElementRecord;
    use std::collections::BTreeMap;

    // One record per ElementId: a single element can be framed more
    // than once across partitions, and the frames can disagree on the
    // vertical extent. Keep the greatest z-extent — that is the
    // element's full body, and it is measured: against the reference
    // export's `IfcExtrudedAreaSolid.Depth`, first-by-(stream, offset)
    // agrees on 67 of 80 slabs and greatest-extent on 79 of 80 (the
    // 80th is exported as two stacked solids whose depths sum to the
    // recorded extent) (#212, RE-22).
    //
    // Ties go to the **newest** frame — the greatest (stream, offset)
    // — because a Revit 2024 project rewrites an edited element into a
    // higher-numbered `Partitions/NN` stream and leaves the earlier
    // copy in place. On `2024_Core_Interior.rvt` 171 of 360 walls and
    // 96 of 132 doors carry two frames that disagree about the plan
    // box, and the newest one is the current state (RE-26 §3):
    //
    // - the newest frame's thin plan extent equals the nominal
    //   thickness of the `IfcWallType` Revit's export assigns on
    //   **360 of 360** walls; the oldest frame's on 201;
    // - the newest frame's type slot in the counted reference list
    //   at `+0x88` equals that `IfcWallType.Tag` on **356 of 360**;
    //   the oldest frame's on 183;
    // - the `u32` at `+12` of the element's `Global/ElemTable` record
    //   (from `0x06`, #152; `+0x1c` in the older `0x1E` framing), its
    //   last-modification counter, ranks the same way — 36 on every one of the 480
    //   instances whose newest frame is `Partitions/59`, 35 on the 12
    //   whose newest is `/55`, 33 on the 18 whose newest is `/51`,
    //   and at most 30 on the 344 framed only in `/46`.
    //
    // No frame of any instance on that file disagrees about the box's
    // `z`, so this cannot move an element between storeys — checked
    // over all 976 multi-framed instances.
    let mut by_id: BTreeMap<u32, PartitionElementRecord> = BTreeMap::new();
    for record in records {
        // A placed instance with no volume has no 3D body, and Revit's
        // export leaves it out (#309); see `has_volume`.
        if !record.is_exported_instance() || !record.has_volume() {
            continue;
        }
        let better = match by_id.get(&record.element_id) {
            None => true,
            Some(existing) => {
                let candidate = z_extent_key(&record);
                let held = z_extent_key(existing);
                candidate > held
                    || (candidate == held
                        && (record.stream.as_str(), record.offset)
                            > (existing.stream.as_str(), existing.offset))
            }
        };
        if better {
            by_id.insert(record.element_id, record);
        }
    }
    without_nested_components(by_id)
}

/// Each Revit 2023 family instance's type ElementId, type name and family
/// name (RE-109), by ElementId. Its type is the one id in its reference
/// list, wherever it sits, that is a symbol record of its own category with
/// a 2023 name entry ([`crate::partition_names::name_entries_2023`]). Its
/// family is the one id the type's own record references that has a name
/// entry and no element record. An instance whose type or family is not
/// unique gets nothing.
/// Categories whose types are system-family types (RE-111): walls, floors,
/// roofs and ceilings.
const SYSTEM_TYPE_CATEGORIES_2023: [i64; 4] = [
    crate::partition_element_records::OST_WALLS,
    crate::partition_element_records::OST_FLOORS,
    -2_000_035,
    -2_000_038,
];

/// Each exported 2023 wall's, floor's, roof's and ceiling's type and its
/// name, by ElementId (RE-111).
///
/// A 2023 system-family type has no record and no name entry (RE-109). Its
/// name is in its element data, read as on 2024
/// ([`crate::partition_names::find_element_data_names_2023`]). Of the ids
/// an element's record names that have such a name and neither a record
/// nor a name entry, the type is the one whose naming records are of a
/// strict subset of the categories that name each of the others: a wall
/// type is named by walls and the doors and windows they host, a floor
/// type by floors, where the document's other named elements are named by
/// records of more categories. No such one, no type.
fn system_type_names_2023(
    rf: &mut RevitFile,
    revit_version: u32,
    records: &[crate::partition_element_records::PartitionElementRecord],
) -> BTreeMap<u32, (u32, String)> {
    let Ok(table) = crate::elem_table::parse_records(rf) else {
        return BTreeMap::new();
    };
    let declared = crate::elem_table::declared_ids(&table);
    let entries = crate::partition_names::name_entries_2023(rf, &declared);
    let recorded: BTreeSet<u32> = records.iter().map(|record| record.element_id).collect();
    let mut named_by: BTreeMap<u32, BTreeSet<i64>> = BTreeMap::new();
    for record in records {
        for &reference in &record.references {
            if let Ok(id) = u32::try_from(reference) {
                if !recorded.contains(&id) && !entries.contains_key(&id) {
                    named_by
                        .entry(id)
                        .or_default()
                        .insert(record.builtin_category);
                }
            }
        }
    }
    let wanted: BTreeSet<u32> = named_by.keys().copied().collect();
    let mut names: BTreeMap<u32, Option<String>> = BTreeMap::new();
    for stream in rf.partition_stream_names() {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        for (id, name) in crate::partition_names::find_element_data_names_32(
            inflated.bytes(),
            revit_version,
            &wanted,
        ) {
            match names.get(&id) {
                None => {
                    names.insert(id, Some(name));
                }
                Some(held) if held.as_deref() != Some(name.as_str()) => {
                    names.insert(id, None);
                }
                _ => {}
            }
        }
    }
    let mut out = BTreeMap::new();
    for record in records.iter().filter(|record| {
        record.is_exported_instance()
            && SYSTEM_TYPE_CATEGORIES_2023.contains(&record.builtin_category)
    }) {
        let candidates: BTreeSet<u32> = record
            .references
            .iter()
            .filter_map(|&reference| u32::try_from(reference).ok())
            .filter(|id| matches!(names.get(id), Some(Some(_))))
            .collect();
        let most_specific = candidates.iter().copied().filter(|id| {
            candidates.iter().all(|other| {
                other == id
                    || (named_by[id].is_subset(&named_by[other]) && named_by[id] != named_by[other])
            })
        });
        let mut picked = most_specific;
        let (Some(type_id), None) = (picked.next(), picked.next()) else {
            continue;
        };
        if let Some(Some(name)) = names.get(&type_id) {
            out.insert(record.element_id, (type_id, name.clone()));
        }
    }
    out
}

fn type_and_family_names_2023(
    rf: &mut RevitFile,
    records: &[crate::partition_element_records::PartitionElementRecord],
) -> BTreeMap<u32, (u32, String, String)> {
    use crate::partition_element_records::PLACEMENT_KIND_SYMBOL;
    let Ok(table) = crate::elem_table::parse_records(rf) else {
        return BTreeMap::new();
    };
    let names =
        crate::partition_names::name_entries_2023(rf, &crate::elem_table::declared_ids(&table));
    let recorded: BTreeSet<u32> = records.iter().map(|record| record.element_id).collect();
    let mut symbols: BTreeMap<i64, BTreeSet<u32>> = BTreeMap::new();
    let mut symbol_records: BTreeMap<
        u32,
        &crate::partition_element_records::PartitionElementRecord,
    > = BTreeMap::new();
    for record in records
        .iter()
        .filter(|record| record.placement_kind == PLACEMENT_KIND_SYMBOL)
    {
        symbols
            .entry(record.builtin_category)
            .or_default()
            .insert(record.element_id);
        symbol_records.insert(record.element_id, record);
    }
    let family_of = |type_id: u32| {
        let record = symbol_records.get(&type_id)?;
        let mut families = record.references.iter().filter_map(|&reference| {
            let id = u32::try_from(reference).ok()?;
            (id != type_id && !recorded.contains(&id))
                .then(|| names.get(&id))
                .flatten()
        });
        let family = families.next()?;
        families.next().is_none().then(|| family.clone())
    };
    let mut out = BTreeMap::new();
    for record in records
        .iter()
        .filter(|record| record.is_exported_instance())
    {
        // The type is anywhere in the list: a type made after the instance
        // has the larger id, and another type can sit between them.
        let Some(set) = symbols.get(&record.builtin_category) else {
            continue;
        };
        let mut types = record.references.iter().filter_map(|&reference| {
            let id = u32::try_from(reference).ok()?;
            (set.contains(&id) && names.contains_key(&id)).then_some(id)
        });
        let (Some(type_id), None) = (types.next(), types.next()) else {
            continue;
        };
        let (Some(type_name), Some(family_name)) = (names.get(&type_id), family_of(type_id)) else {
            continue;
        };
        out.insert(record.element_id, (type_id, type_name.clone(), family_name));
    }
    out
}

/// [`select_instance_records`] for Revit 2023 (RE-107): of an element's
/// frames, the newest, in the highest-numbered partition and then the
/// latest in it. A 2023 project's frames can disagree about their height,
/// where a Level moved after an earlier save: on modelo_bim four columns
/// run from -13.12 ft in `Partitions/1` and from -5.58 ft in
/// `Partitions/2`, and Revit's export draws them from -1.7 m (-5.58 ft),
/// on the Level the newer frame names. The greatest extent would keep the
/// stale one.
fn select_newest_instance_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
) -> BTreeMap<u32, crate::partition_element_records::PartitionElementRecord> {
    use crate::partition_element_records::PartitionElementRecord;
    let partition = |record: &PartitionElementRecord| {
        record
            .stream
            .rsplit('/')
            .next()
            .and_then(|n| n.parse::<u32>().ok())
            .unwrap_or(0)
    };
    let mut by_id: BTreeMap<u32, PartitionElementRecord> = BTreeMap::new();
    for record in records {
        if !record.is_exported_instance() || !record.has_volume() {
            continue;
        }
        let newer = by_id.get(&record.element_id).is_none_or(|held| {
            (partition(&record), record.offset) > (partition(held), held.offset)
        });
        if newer {
            by_id.insert(record.element_id, record);
        }
    }
    without_nested_components(by_id)
}

/// `by_id` without the shared nested components of MEP devices (#96): a
/// nested device and its parent, in the same
/// [`crate::partition_element_records::NESTED_COMPONENT_CATEGORIES`]
/// category, each list the other among their references, and the nested
/// one, created after its parent, has the larger ElementId. On RE1
/// Electrical each receptacle, switch and junction-box symbol nested in a
/// device is such a pair, and Revit's export leaves the nested one out
/// (21 of 21). Other categories are left alone: joined walls and connected
/// fittings reference each other too.
fn without_nested_components(
    mut by_id: BTreeMap<u32, crate::partition_element_records::PartitionElementRecord>,
) -> BTreeMap<u32, crate::partition_element_records::PartitionElementRecord> {
    use crate::partition_element_records::NESTED_COMPONENT_CATEGORIES;
    let nested: Vec<u32> = by_id
        .values()
        .filter(|child| NESTED_COMPONENT_CATEGORIES.contains(&child.builtin_category))
        .filter(|child| {
            child.references.iter().any(|&reference| {
                u32::try_from(reference)
                    .ok()
                    .filter(|&parent| parent < child.element_id)
                    .and_then(|parent| by_id.get(&parent))
                    .is_some_and(|parent| {
                        parent.builtin_category == child.builtin_category
                            && parent.references.contains(&u64::from(child.element_id))
                    })
            })
        })
        .map(|child| child.element_id)
        .collect();
    for id in nested {
        by_id.remove(&id);
    }
    by_id
}

/// Vertical extent of a record's bounding box, quantised to 1e-4 ft
/// so two frames of the same element compare exactly.
fn z_extent_key(record: &crate::partition_element_records::PartitionElementRecord) -> i64 {
    let (_, _, dz) = record.extents_feet();
    if !dz.is_finite() {
        return i64::MIN;
    }
    (dz * 10_000.0).round() as i64
}

/// Recover slab instances from partition element records (#212, RE-22).
///
/// Two `BuiltInCategory` ids feed one class, because Revit's own
/// exporter maps both to `IfcSlab`:
/// [`crate::partition_element_records::OST_FLOORS`] (class `Floor`)
/// and [`crate::partition_element_records::OST_BUILDING_PAD`]
/// (class `BuildingPad`). The pad is kept as its own class rather
/// than relabelled a floor — the mapping to `IFCSLAB` happens in
/// [`crate::ifc::category_map`], where it is visible.
///
/// Per-element IFC export-type overrides are attached later, with every
/// other element's, by `attach_ifc_export_overrides` (RE-45).
///
/// The plate's sketched plan profile
/// ([`crate::element_record_plan_profiles`]) is attached in the same
/// pass when it closes — the `OST_SketchLines` records that carry it
/// are read from the same stream sweep, so the profile costs one
/// extra needle search rather than a second inflate (#31, RE-25).
pub fn slabs_from_partition_category_records(
    rf: &mut RevitFile,
    revit_version: u32,
    level_ids: &BTreeSet<u32>,
) -> Result<Vec<DecodedElement>> {
    use crate::partition_element_records as per;

    if !per::supports_revit_version(revit_version) {
        return Ok(Vec::new());
    }
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return Ok(Vec::new()),
    };
    if declared.is_empty() {
        return Ok(Vec::new());
    }
    let categories = [
        per::OST_FLOORS,
        per::OST_BUILDING_PAD,
        per::OST_SKETCH_LINES,
    ];
    let scanned = per::scan_category_records_multi(rf, revit_version, &categories, &declared)?;
    let scanned = without_non_primary_options(rf, scanned);
    let sketch_lines: Vec<per::PartitionElementRecord> = scanned
        .iter()
        .filter(|record| record.builtin_category == per::OST_SKETCH_LINES)
        .cloned()
        .collect();
    // Each plate's box is the record its element is built from (RE-26: the
    // newest, tallest copy), not the first copy found: an outline is held
    // to it, and an edited slab keeps its older box in an older partition
    // (#824).
    let plates: BTreeMap<u32, [f64; 4]> = select_instance_records(
        scanned
            .iter()
            .filter(|record| {
                record.builtin_category == per::OST_FLOORS
                    || record.builtin_category == per::OST_BUILDING_PAD
            })
            .cloned()
            .collect(),
    )
    .into_iter()
    .map(|(id, record)| {
        let b = record.bbox_feet;
        (id, [b[0], b[1], b[3], b[4]])
    })
    .collect();
    let profiles =
        sketch_plan_profiles(rf, revit_version, &sketch_lines, &plates, &BTreeSet::new());

    let mut out = Vec::new();
    for (category, class) in [
        (per::OST_FLOORS, "Floor"),
        (per::OST_BUILDING_PAD, "BuildingPad"),
    ] {
        let records: Vec<per::PartitionElementRecord> = scanned
            .iter()
            .filter(|record| record.builtin_category == category)
            .cloned()
            .collect();
        for mut decoded in instances_from_records(records, class, level_ids) {
            if let Some(id) = decoded.id {
                if let Some(profile) = profiles.get(&id) {
                    decoded.fields.extend(profile.fields());
                }
            }
            out.push(decoded);
        }
    }
    Ok(out)
}

/// How closely an outline read from its sketch lines' own curves must span
/// its element's record box (RE-96), feet.
pub const SKETCH_BOX_TOLERANCE_FEET: f64 = 1e-3;

/// Sketched plan profiles of the elements in `owners` (their plan record
/// boxes, `[min x, min y, max x, max y]`), from their Sketch's curve list
/// where it has one (RE-97) or else the lines naming them, and their
/// `OST_SketchLines` records: the RE-25 solve over the records' boxes and,
/// where that does not close, the exact ends each sketch line's own data
/// carries (RE-50, [`crate::partition_beam_axes::scan_bounded_lines`]). A
/// line counts only when it is level and both its ends lie in its own
/// record's box; an element any of whose lines does not count keeps no
/// profile, except that a zero-length line on one of the others' ends is
/// left out (RE-95). A sketch line's curve may be an arc instead (RE-96,
/// [`crate::partition_beam_axes::scan_sketch_curves`]): it counts where it
/// lies in a horizontal plane and every point of it, drawn as chords, lies
/// in its record's box, and where its record does not also hold as a line.
/// An outline with an arc is kept only where it spans its element's record
/// box.
fn sketch_plan_profiles(
    rf: &mut RevitFile,
    revit_version: u32,
    sketch_lines: &[crate::partition_element_records::PartitionElementRecord],
    owners: &BTreeMap<u32, [f64; 4]>,
    skip: &BTreeSet<u32>,
) -> BTreeMap<u32, crate::element_record_plan_profiles::PlanProfile> {
    use crate::element_record_plan_profiles as erpp;
    use std::collections::BTreeMap;
    let sketch_lines = current_sketch_records(rf, sketch_lines);
    let sketch_lines = sketch_lines.as_slice();
    // RE-97: where an element's Sketch lists its curves, that list is the
    // sketch's membership; a line's own owner reference names another
    // element where the sketch was edited.
    let line_ids: BTreeSet<u32> = sketch_lines.iter().map(|r| r.element_id).collect();
    let lists: BTreeMap<u32, Vec<u32>> =
        erpp::scan_sketch_curve_lists(rf, revit_version, &line_ids)
            .into_iter()
            .filter(|(owner, _)| owners.contains_key(owner))
            .map(|(owner, mut curves)| {
                curves.retain(|id| !skip.contains(id));
                (owner, curves)
            })
            .collect();
    let listed: BTreeMap<u32, u32> = lists
        .iter()
        .flat_map(|(owner, curves)| curves.iter().map(move |id| (*id, *owner)))
        .collect();
    let remapped: Vec<crate::partition_element_records::PartitionElementRecord> = sketch_lines
        .iter()
        .filter(|record| !skip.contains(&record.element_id))
        .filter_map(|record| {
            let owner = match listed.get(&record.element_id) {
                Some(owner) => Some(*owner),
                None => record
                    .owner_reference
                    .filter(|owner| !lists.contains_key(owner)),
            }?;
            let mut record = record.clone();
            record.owner_reference = Some(owner);
            Some(record)
        })
        .collect();
    // An element whose list differs from the lines naming it keeps an outline
    // only where it spans its record box, as an arc outline does (RE-96).
    let mut named: BTreeMap<u32, BTreeSet<u32>> = BTreeMap::new();
    for record in sketch_lines
        .iter()
        .filter(|record| !skip.contains(&record.element_id))
    {
        if let Some(owner) = record.owner_reference {
            named.entry(owner).or_default().insert(record.element_id);
        }
    }
    let relisted: BTreeSet<u32> = lists
        .iter()
        .filter(|(owner, curves)| {
            named.get(owner) != Some(&curves.iter().copied().collect::<BTreeSet<u32>>())
        })
        .map(|(owner, _)| *owner)
        .collect();
    let spans_box = |owner: u32, profile: &erpp::PlanProfile| {
        owners.get(&owner).is_some_and(|plan_box| {
            profile.plan_extent_feet().is_some_and(|extent| {
                extent
                    .iter()
                    .zip(plan_box)
                    .all(|(a, b)| (a - b).abs() <= SKETCH_BOX_TOLERANCE_FEET)
            })
        })
    };
    let sketch_lines = remapped.as_slice();
    let mut profiles = erpp::plan_profiles_from_sketch_line_records(sketch_lines);
    profiles.retain(|owner, profile| !relisted.contains(owner) || spans_box(*owner, profile));
    profiles.retain(|owner, _| owners.contains_key(owner));
    // RE-96: a quarter arc's ends are two corners of its record box, so the
    // box solve closes its sketch with the arc's chord. An owner with a line
    // whose box is not flat in plan and whose curve reads as an arc, not as a
    // line, is read from its lines' curves below instead (#824).
    let eps = erpp::VERTEX_EPS_FEET;
    let diagonal: BTreeMap<u32, (u32, [f64; 6])> = sketch_lines
        .iter()
        .filter(|record| {
            let b = record.bbox_feet;
            b[3] - b[0] > eps && b[4] - b[1] > eps
        })
        .filter_map(|record| {
            let owner = record
                .owner_reference
                .filter(|owner| profiles.contains_key(owner))?;
            Some((record.element_id, (owner, record.bbox_feet)))
        })
        .collect();
    if !diagonal.is_empty() {
        let ids: BTreeSet<u32> = diagonal.keys().copied().collect();
        let curves = crate::partition_beam_axes::scan_sketch_curves(rf, revit_version, &ids)
            .unwrap_or_default();
        for (id, (owner, bbox)) in &diagonal {
            let Some(curve) = curves.get(id) else {
                continue;
            };
            let inside = |p: [f64; 3]| {
                (0..3).all(|axis| p[axis] >= bbox[axis] - eps && p[axis] <= bbox[axis + 3] + eps)
            };
            let line = curve
                .line
                .as_ref()
                .is_some_and(|line| inside(line.start()) && inside(line.end()));
            let arc = curve.arc.as_ref().is_some_and(|arc| {
                erpp::arc_points(arc).is_some_and(|points| points.iter().all(|&p| inside(p)))
            });
            if arc && !line {
                profiles.remove(owner);
            }
        }
    }
    let mut unsolved: BTreeMap<u32, BTreeMap<u32, [f64; 6]>> = BTreeMap::new();
    for record in sketch_lines {
        let Some(owner) = record.owner_reference else {
            continue;
        };
        if owners.contains_key(&owner) && !profiles.contains_key(&owner) {
            unsolved
                .entry(owner)
                .or_default()
                .entry(record.element_id)
                .or_insert(record.bbox_feet);
        }
    }
    if unsolved.is_empty() {
        return profiles;
    }
    let ids: BTreeSet<u32> = unsolved
        .values()
        .flat_map(|lines| lines.keys().copied())
        .collect();
    let (Ok(lines), Ok(curves)) = (
        crate::partition_beam_axes::scan_sketch_bounded_lines(rf, revit_version, &ids),
        crate::partition_beam_axes::scan_sketch_curves(rf, revit_version, &ids),
    ) else {
        return profiles;
    };
    let arcs: BTreeMap<u32, crate::partition_beam_axes::BoundedArc> = curves
        .iter()
        .filter_map(|(&id, curve)| Some((id, curve.arc?)))
        .collect();
    // RE-95: a sketch line whose box is a single point is a zero-length
    // segment with no line of its own. It adds no edge, and is dropped where
    // its point ends another of the sketch's lines.
    let is_point = |bbox: &[f64; 6]| (0..3).all(|axis| (bbox[axis + 3] - bbox[axis]).abs() <= eps);
    for (owner, segments) in unsolved {
        let ends: Vec<[f64; 3]> = segments
            .keys()
            .filter_map(|id| lines.get(id))
            .flat_map(|line| [line.start(), line.end()])
            .chain(
                segments
                    .keys()
                    .filter_map(|id| arcs.get(id))
                    .flat_map(|arc| [arc.point(arc.start_angle), arc.point(arc.end_angle)]),
            )
            .collect();
        let exact: Option<ExactSketch> = segments
            .iter()
            .filter(|(id, bbox)| {
                let point = [bbox[0], bbox[1], bbox[2]];
                !(is_point(bbox)
                    && !lines.contains_key(id)
                    && !arcs.contains_key(id)
                    && ends
                        .iter()
                        .any(|end| (0..3).all(|axis| (end[axis] - point[axis]).abs() <= eps)))
            })
            .map(|(id, bbox)| {
                let inside = |p: [f64; 3]| {
                    (0..3)
                        .all(|axis| p[axis] >= bbox[axis] - eps && p[axis] <= bbox[axis + 3] + eps)
                };
                let line = lines.get(id).and_then(|line| {
                    let (a, b) = (line.start(), line.end());
                    (inside(a) && inside(b) && (a[2] - b[2]).abs() <= eps)
                        .then(|| vec![[a[0], a[1], b[0], b[1]]])
                });
                let arc = arcs.get(id).and_then(|arc| {
                    let points = erpp::arc_points(arc)?;
                    let flat = arc.x_axis[2].abs() <= eps && arc.y_axis[2].abs() <= eps;
                    (flat && points.iter().all(|&p| inside(p))).then(|| {
                        points
                            .windows(2)
                            .map(|pair| [pair[0][0], pair[0][1], pair[1][0], pair[1][1]])
                            .collect::<Vec<_>>()
                    })
                });
                match (line, arc) {
                    (Some(chords), None) => Some((*id, chords, false)),
                    (None, Some(chords)) => Some((*id, chords, true)),
                    _ => None,
                }
            })
            .collect::<Option<Vec<(u32, Vec<[f64; 4]>, bool)>>>()
            .map(|curves| {
                let has_arc = curves.iter().any(|(_, _, arc)| *arc);
                // RE-151: each line's first chord is an edge of its loop.
                let points = curves
                    .iter()
                    .filter_map(|(id, chords, _)| {
                        let c = chords.first()?;
                        Some((*id, ((c[0] + c[2]) / 2.0, (c[1] + c[3]) / 2.0)))
                    })
                    .collect();
                let chords: Vec<[f64; 4]> = curves
                    .into_iter()
                    .flat_map(|(_, chords, _)| chords)
                    .collect();
                (chords, has_arc, points)
            });
        let Some((mut profile, has_arc, points)) = exact.and_then(|(chords, has_arc, points)| {
            Some((erpp::plan_profile_from_lines(&chords)?, has_arc, points))
        }) else {
            continue;
        };
        // RE-96: an outline with an arc spans the element's own record box,
        // or the sketch holds curves that are not the element's edge.
        if !(has_arc || relisted.contains(&owner)) || spans_box(owner, &profile) {
            erpp::tag_voids(&mut profile, &points);
            profile.segment_ids = segments.keys().copied().collect();
            profiles.insert(owner, profile);
        }
    }
    profiles
}

/// `records` with each sketch line whose records in different partitions
/// disagree on its box kept only in its current partition (RE-216,
/// [`crate::native_document`]), or left out where that cannot be told (#824).
/// Copies that agree are kept as they are.
fn current_sketch_records(
    rf: &mut RevitFile,
    records: &[crate::partition_element_records::PartitionElementRecord],
) -> Vec<crate::partition_element_records::PartitionElementRecord> {
    let partition = |record: &crate::partition_element_records::PartitionElementRecord| {
        record
            .stream
            .strip_prefix("Partitions/")
            .and_then(|n| n.parse::<u32>().ok())
    };
    let mut boxes: BTreeMap<u32, Vec<[f64; 6]>> = BTreeMap::new();
    let mut holders: BTreeMap<u32, BTreeSet<u32>> = BTreeMap::new();
    for record in records {
        boxes
            .entry(record.element_id)
            .or_default()
            .push(record.bbox_feet);
        if let Some(p) = partition(record) {
            holders.entry(record.element_id).or_default().insert(p);
        }
    }
    let disagreeing: BTreeMap<u32, BTreeSet<u32>> = boxes
        .iter()
        .filter(|(_, b)| b.iter().any(|bbox| *bbox != b[0]))
        .filter_map(|(id, _)| Some((*id, holders.get(id)?.clone())))
        .collect();
    if disagreeing.is_empty() {
        return records.to_vec();
    }
    let current = crate::native_document::current_partitions(rf, &disagreeing);
    records
        .iter()
        .filter(|record| match disagreeing.get(&record.element_id) {
            None => true,
            Some(_) => current
                .get(&record.element_id)
                .is_some_and(|&p| partition(record) == Some(p)),
        })
        .cloned()
        .collect()
}

/// A sketch read from its lines' exact ends: the chords, whether any is an
/// arc's, and each line's ElementId with a point on its edge (RE-151).
type ExactSketch = (Vec<[f64; 4]>, bool, Vec<(u32, (f64, f64))>);

/// Classes whose plan outline is their sketch's: roofs (RE-50) and, since
/// RE-98, ceilings.
pub const SKETCHED_PRODUCT_CLASSES: &[&str] = &["Roof", "Ceiling"];

/// Give each roof and ceiling the plan outline its sketch lines close
/// (RE-50, RE-98), as a floor has (RE-25). The body is the record box's
/// height; a shed roof's slope is attached later ([`attach_roof_slopes`],
/// RE-56).
fn attach_roof_profiles(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_element_records as per;
    let float = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let roofs: BTreeMap<u32, [f64; 4]> = products
        .iter()
        .filter(|element| SKETCHED_PRODUCT_CLASSES.contains(&element.class.as_str()))
        .filter_map(|element| {
            let (x, y) = (
                float(element, "m_locationX")?,
                float(element, "m_locationY")?,
            );
            let (w, d) = (
                float(element, "m_bboxWidth")?,
                float(element, "m_bboxDepth")?,
            );
            Some((
                element.id?,
                [x - w / 2.0, y - d / 2.0, x + w / 2.0, y + d / 2.0],
            ))
        })
        .collect();
    if roofs.is_empty() || !per::supports_revit_version(revit_version) {
        return;
    }
    let declared = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Ok(sketch_lines) =
        per::scan_category_records_multi(rf, revit_version, &[per::OST_SKETCH_LINES], &declared)
    else {
        return;
    };
    // RE-199: a slope arrow is one of its roof's sketch lines but no part of
    // the outline.
    let line_ids: BTreeSet<u32> = sketch_lines.iter().map(|line| line.element_id).collect();
    let arrows: BTreeSet<u32> =
        crate::partition_roof_slopes::scan_arrow_heights(rf, revit_version, &line_ids)
            .map(|found| found.into_keys().collect())
            .unwrap_or_default();
    let profiles = sketch_plan_profiles(rf, revit_version, &sketch_lines, &roofs, &arrows);
    for roof in products
        .iter_mut()
        .filter(|element| SKETCHED_PRODUCT_CLASSES.contains(&element.class.as_str()))
    {
        if let Some(profile) = roof.id.and_then(|id| profiles.get(&id)) {
            roof.fields.extend(profile.fields());
        }
    }
}

/// One curve of a shaft's sketch as chords, and whether it is a straight
/// line (RE-100).
type ShaftCurve = (Vec<[(f64, f64); 2]>, bool);

/// A shaft's plan outline and the bottom and top of its height, feet
/// (RE-99).
type ShaftOutline = (Vec<(f64, f64)>, (f64, f64));

/// Cross product (square feet) below which a line's end counts as on
/// another line when testing whether two sketch lines cross (RE-99).
pub const SHAFT_CROSSING_EPS: f64 = 1e-6;

/// How far an element may reach past a shaft's height and still be cut by it
/// (RE-99), feet.
pub const SHAFT_HEIGHT_TOLERANCE_FEET: f64 = 1e-3;

/// Cut each shaft opening's outline from the floors, roofs and ceilings its
/// height passes through (RE-99). A shaft (`OST_ShaftOpening`) is sketched
/// as a floor is, and its record box spans its height. An element whose
/// outline is one piece, lies within the shaft's height, and holds the
/// shaft's outline strictly inside its outer loop and clear of its voids
/// takes the outline as a void. An element the shaft only partly overlaps
/// is left as it is.
fn attach_shaft_voids(
    rf: &mut RevitFile,
    revit_version: u32,
    groups: [&mut Vec<DecodedElement>; 2],
) {
    use crate::element_record_plan_profiles as erpp;
    use crate::partition_element_records as per;
    if !per::supports_revit_version(revit_version) {
        return;
    }
    let declared = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Ok(scanned) = per::scan_category_records_multi(
        rf,
        revit_version,
        &[per::OST_SHAFT_OPENING, per::OST_SKETCH_LINES],
        &declared,
    ) else {
        return;
    };
    let mut boxes: BTreeMap<u32, [f64; 4]> = Default::default();
    let mut heights: BTreeMap<u32, (f64, f64)> = Default::default();
    for record in scanned
        .iter()
        .filter(|record| record.builtin_category == per::OST_SHAFT_OPENING)
    {
        let b = record.bbox_feet;
        boxes
            .entry(record.element_id)
            .or_insert([b[0], b[1], b[3], b[4]]);
        heights.entry(record.element_id).or_insert((b[2], b[5]));
    }
    if boxes.is_empty() {
        return;
    }
    let sketch_lines: Vec<per::PartitionElementRecord> = scanned
        .into_iter()
        .filter(|record| record.builtin_category == per::OST_SKETCH_LINES)
        .collect();
    let shafts: Vec<ShaftOutline> = shaft_outlines(rf, revit_version, &sketch_lines, &boxes)
        .into_iter()
        .filter_map(|(id, outline)| Some((outline, *heights.get(&id)?)))
        .collect();
    let float = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    for element in groups.into_iter().flat_map(|elements| elements.iter_mut()) {
        let Some(profile) = erpp::plan_profile_from_fields(&element.fields) else {
            continue;
        };
        let (Some(base), Some(height)) = (
            float(element, "m_locationZ"),
            float(element, "m_bboxHeight"),
        ) else {
            continue;
        };
        if !profile.pieces.is_empty() {
            continue;
        }
        let eps = SHAFT_HEIGHT_TOLERANCE_FEET;
        let voids: Vec<Vec<(f64, f64)>> = shafts
            .iter()
            .filter(|(outline, (bottom, top))| {
                base >= bottom - eps
                    && base + height <= top + eps
                    && erpp::loop_within(&profile.outer_xy, outline)
                    && profile
                        .inner_xy
                        .iter()
                        .all(|void| erpp::loops_disjoint(void, outline))
            })
            .map(|(outline, _)| outline.clone())
            .collect();
        if !voids.is_empty() {
            erpp::add_voids_to_fields(&mut element.fields, &voids);
        }
    }
}

/// Each shaft's outline (RE-99), `shafts` its plan record boxes. A shaft's
/// sketch holds its boundary and the symbolic lines drawn across it, the
/// diagonals of the X Revit shows in plan; lines that cross another of the
/// sketch's lines are those, and are left out. The rest must be straight
/// lines read exactly (RE-50), or a full circle (RE-100), that close into one
/// loop spanning the shaft's record box. Its lines are those its Sketch
/// lists (RE-97), or else those naming it.
fn shaft_outlines(
    rf: &mut RevitFile,
    revit_version: u32,
    sketch_lines: &[crate::partition_element_records::PartitionElementRecord],
    shafts: &BTreeMap<u32, [f64; 4]>,
) -> BTreeMap<u32, Vec<(f64, f64)>> {
    use crate::element_record_plan_profiles as erpp;
    use std::collections::BTreeMap;
    let line_ids: BTreeSet<u32> = sketch_lines.iter().map(|r| r.element_id).collect();
    let lists = erpp::scan_sketch_curve_lists(rf, revit_version, &line_ids);
    let mut members: BTreeMap<u32, BTreeSet<u32>> = BTreeMap::new();
    for &shaft in shafts.keys() {
        let listed = lists
            .get(&shaft)
            .map(|curves| curves.iter().copied().collect());
        let named = || {
            sketch_lines
                .iter()
                .filter(|r| r.owner_reference == Some(shaft))
                .map(|r| r.element_id)
                .collect()
        };
        members.insert(shaft, listed.unwrap_or_else(named));
    }
    let ids: BTreeSet<u32> = members.values().flatten().copied().collect();
    let (Ok(lines), Ok(circles)) = (
        crate::partition_beam_axes::scan_bounded_lines(rf, revit_version, &ids),
        crate::partition_beam_axes::scan_sketch_circles(rf, revit_version, &ids),
    ) else {
        return BTreeMap::new();
    };
    let cross = |o: (f64, f64), a: (f64, f64), b: (f64, f64)| {
        (a.0 - o.0) * (b.1 - o.1) - (a.1 - o.1) * (b.0 - o.0)
    };
    // Strictly across: each end of one line clearly off the other, so lines
    // meeting at a corner, whose ends agree only to round-off, do not count.
    let apart = |o: (f64, f64), p: (f64, f64), q: (f64, f64), r: (f64, f64)| {
        let (c1, c2) = (cross(o, p, q), cross(o, p, r));
        c1 * c2 < 0.0 && c1.abs() > SHAFT_CROSSING_EPS && c2.abs() > SHAFT_CROSSING_EPS
    };
    let crossing =
        |[a, b]: [(f64, f64); 2], [c, d]: [(f64, f64); 2]| apart(a, b, c, d) && apart(c, d, a, b);
    let mut out = BTreeMap::new();
    for (shaft, ids) in members {
        // Each line, or a full circle drawn as chords (RE-100); only lines
        // can be the crossing diagonals left out.
        let curves: Option<Vec<ShaftCurve>> = ids
            .iter()
            .map(|id| {
                if let Some(line) = lines.get(id) {
                    let (a, b) = (line.start(), line.end());
                    return ((a[2] - b[2]).abs() <= erpp::VERTEX_EPS_FEET)
                        .then(|| (vec![[(a[0], a[1]), (b[0], b[1])]], true));
                }
                let circle = circles.get(id)?;
                let flat = circle.x_axis[2].abs() <= erpp::VERTEX_EPS_FEET
                    && circle.y_axis[2].abs() <= erpp::VERTEX_EPS_FEET;
                let points = erpp::arc_points(circle).filter(|_| flat)?;
                let chords = points
                    .windows(2)
                    .map(|pair| [(pair[0][0], pair[0][1]), (pair[1][0], pair[1][1])])
                    .collect();
                Some((chords, false))
            })
            .collect();
        let Some(curves) = curves else {
            continue;
        };
        let straight: Vec<[(f64, f64); 2]> = curves
            .iter()
            .filter(|(_, line)| *line)
            .flat_map(|(chords, _)| chords.iter().copied())
            .collect();
        let boundary: Vec<[f64; 4]> = curves
            .iter()
            .filter(|(chords, line)| !*line || !straight.iter().any(|t| crossing(chords[0], *t)))
            .flat_map(|(chords, _)| chords.iter().map(|[a, b]| [a.0, a.1, b.0, b.1]))
            .collect();
        let Some(profile) = erpp::plan_profile_from_lines(&boundary) else {
            continue;
        };
        let spans = profile.plan_extent_feet().is_some_and(|extent| {
            extent
                .iter()
                .zip(&shafts[&shaft])
                .all(|(a, b)| (a - b).abs() <= SKETCH_BOX_TOLERANCE_FEET)
        });
        if spans && profile.inner_xy.is_empty() && profile.pieces.is_empty() {
            out.insert(shaft, profile.outer_xy);
        }
    }
    out
}

/// Fields holding the plan start and end of the (first) roof edge that
/// defines the roof's slope, model feet (RE-56). Further edges of a gable or
/// hip use [`roof_slope_edge_fields`] (RE-199).
pub const ROOF_SLOPE_EDGE_FIELDS: [&str; 4] = [
    "m_roof_slope_edge_start_x",
    "m_roof_slope_edge_start_y",
    "m_roof_slope_edge_end_x",
    "m_roof_slope_edge_end_y",
];
/// Field holding that edge's slope angle from horizontal, radians (RE-56).
pub const ROOF_SLOPE_ANGLE_FIELD: &str = "m_roof_slope_angle";
/// Field holding a roof by extrusion's top, `(u, z)` points along the plane
/// its sketch is in, `u` rising, model feet (RE-211).
pub const ROOF_EXTRUSION_TOP_FIELD: &str = "m_roof_extrusion_top";
/// Field holding a roof by extrusion's underside, as
/// [`ROOF_EXTRUSION_TOP_FIELD`] (RE-211).
pub const ROOF_EXTRUSION_BOTTOM_FIELD: &str = "m_roof_extrusion_bottom";
/// Field holding the model axis a roof by extrusion runs along, 0 for x and
/// 1 for y; `u` is the other horizontal axis (RE-211).
pub const ROOF_EXTRUSION_AXIS_FIELD: &str = "m_roof_extrusion_axis";
/// How closely a roof by extrusion's section must reproduce its record box,
/// feet (RE-211).
pub const ROOF_EXTRUSION_BOX_TOLERANCE_FEET: f64 = 1e-3;
/// Chords a sketch's B-spline is drawn with in a roof by extrusion's
/// section (RE-211), shared among its knot spans by their lengths.
pub const ROOF_EXTRUSION_SPLINE_SEGMENTS: usize = 256;
/// The fewest chords any knot span of a sketch's B-spline is drawn with, so
/// a short span is never skipped (RE-211).
pub const ROOF_EXTRUSION_MIN_SPAN_SEGMENTS: usize = 4;
/// The share of a sketch spline's span its second and last but one points
/// lie in from its ends (RE-211).
pub const ROOF_EXTRUSION_END_SHARE: f64 = 1e-4;
/// How far a sketch spline may stray from the chords it is drawn with in a
/// roof by extrusion's section, feet (RE-211).
pub const ROOF_EXTRUSION_CHORD_FEET: f64 = 1e-4;
/// The most points a sketch's B-spline is drawn with in a roof by
/// extrusion's section; a curve that needs more is left out (RE-211).
pub const ROOF_EXTRUSION_MAX_SPLINE_POINTS: usize = 4096;
/// How far apart two sketch curves' ends may be and still join in a roof by
/// extrusion's profile, feet (RE-211).
pub const ROOF_EXTRUSION_JOIN_FEET: f64 = 1e-4;

/// A roof by extrusion's section (RE-211): its top and its underside, each
/// `(u, z)` with `u` rising along the plane its sketch is in, and the model
/// axis it runs along.
#[derive(Debug, Clone, PartialEq)]
pub struct RoofExtrusion {
    pub axis: usize,
    pub top: Vec<(f64, f64)>,
    pub bottom: Vec<(f64, f64)>,
}

/// The [`RoofExtrusion`] the extrusion-roof pass recorded in an element's
/// fields (RE-211).
pub fn roof_extrusion_from_fields(fields: &[(String, InstanceField)]) -> Option<RoofExtrusion> {
    let field = |wanted: &str| {
        fields
            .iter()
            .find_map(|(name, value)| (name == wanted).then_some(value))
    };
    let axis = match field(ROOF_EXTRUSION_AXIS_FIELD)? {
        InstanceField::Integer { value, .. } => usize::try_from(*value).ok().filter(|a| *a < 2)?,
        _ => return None,
    };
    Some(RoofExtrusion {
        axis,
        top: crate::element_record_plan_profiles::points_from_field(field(
            ROOF_EXTRUSION_TOP_FIELD,
        )?)?,
        bottom: crate::element_record_plan_profiles::points_from_field(field(
            ROOF_EXTRUSION_BOTTOM_FIELD,
        )?)?,
    })
}

/// A sketch spline's points for a roof by extrusion's top (RE-211): each
/// knot span inside the curve's domain cut into its share of
/// [`ROOF_EXTRUSION_SPLINE_SEGMENTS`] chords, at least
/// [`ROOF_EXTRUSION_MIN_SPAN_SEGMENTS`], with the knots among the points, and
/// a point [`ROOF_EXTRUSION_END_SHARE`] of its span in from each end, so the
/// first and last chords lie along the curve's ends, which the plumb cuts
/// follow. Each chord is then halved until the curve at its quarter, half
/// and three-quarter points lies within [`ROOF_EXTRUSION_CHORD_FEET`] of it,
/// so a span short in parameter but long on the curve is still followed.
/// `None` where that takes more than [`ROOF_EXTRUSION_MAX_SPLINE_POINTS`]
/// points or halving no longer moves the parameter.
fn roof_extrusion_spline_points(
    spline: &crate::partition_beam_axes::BoundedSpline,
) -> Option<Vec<[f64; 3]>> {
    let (start, end) = (spline.start_parameter, spline.end_parameter);
    let span = end - start;
    if !(span.is_finite() && span > 0.0) {
        return None;
    }
    let mut breaks = vec![start];
    breaks.extend(
        spline
            .knots
            .iter()
            .copied()
            .filter(|&k| k > start && k < end),
    );
    breaks.push(end);
    breaks.dedup();
    let mut parameters = vec![
        start + span * ROOF_EXTRUSION_END_SHARE,
        end - span * ROOF_EXTRUSION_END_SHARE,
    ];
    for pair in breaks.windows(2) {
        let (a, b) = (pair[0], pair[1]);
        let share = (ROOF_EXTRUSION_SPLINE_SEGMENTS as f64 * (b - a) / span).ceil() as usize;
        let segments = share.max(ROOF_EXTRUSION_MIN_SPAN_SEGMENTS);
        parameters.extend((0..segments).map(|i| a + (b - a) * i as f64 / segments as f64));
    }
    parameters.push(end);
    parameters.sort_by(f64::total_cmp);
    parameters.dedup();
    let mut points = vec![spline.point(start)?];
    let mut done = (start, points[0]);
    for &target in &parameters[1..] {
        let mut pending = vec![(target, spline.point(target)?)];
        while let Some(&(b, to)) = pending.last() {
            let (a, from) = done;
            let mut straight = true;
            for share in [0.25, 0.5, 0.75] {
                let on = spline.point(a + (b - a) * share)?;
                if chord_distance(on, from, to) > ROOF_EXTRUSION_CHORD_FEET {
                    straight = false;
                    break;
                }
            }
            if straight {
                points.push(to);
                if points.len() > ROOF_EXTRUSION_MAX_SPLINE_POINTS {
                    return None;
                }
                done = (b, to);
                pending.pop();
            } else {
                let middle = a + (b - a) / 2.0;
                if !(middle > a && middle < b) {
                    return None;
                }
                pending.push((middle, spline.point(middle)?));
            }
        }
    }
    Some(points)
}

/// How far `point` lies from the segment `from`..`to`.
fn chord_distance(point: [f64; 3], from: [f64; 3], to: [f64; 3]) -> f64 {
    let along = [to[0] - from[0], to[1] - from[1], to[2] - from[2]];
    let off = [point[0] - from[0], point[1] - from[1], point[2] - from[2]];
    let length = along.iter().map(|v| v * v).sum::<f64>();
    let t = if length > 0.0 {
        (off.iter().zip(&along).map(|(o, a)| o * a).sum::<f64>() / length).clamp(0.0, 1.0)
    } else {
        0.0
    };
    off.iter()
        .zip(&along)
        .map(|(o, a)| (o - t * a).powi(2))
        .sum::<f64>()
        .sqrt()
}

/// The underside of a roof whose top is `top` (`(u, z)`, `u` rising) and
/// whose thickness is `thickness`, measured square to the top: the top
/// offset down by it, its ends carried along their tangents to the plumb
/// lines through the top's ends and cut there (RE-211). `None` where the
/// underside does not rise along `u` throughout, as where the top curves
/// tighter than the thickness.
pub fn roof_extrusion_bottom(top: &[(f64, f64)], thickness: f64) -> Option<Vec<(f64, f64)>> {
    if top.len() < 2 || !(thickness.is_finite() && thickness > 0.0) {
        return None;
    }
    // Each segment's normal down from it, and each point's offset: an end
    // along its segment's normal, a joint where the two segments' offsets
    // meet, `t (n1 + n2) / (1 + n1 · n2)` from it.
    let normals: Vec<(f64, f64)> = top
        .windows(2)
        .map(|pair| {
            let (du, dv) = (pair[1].0 - pair[0].0, pair[1].1 - pair[0].1);
            let length = du.hypot(dv);
            (length > 0.0).then(|| (dv / length, -du / length))
        })
        .collect::<Option<_>>()?;
    let mut offset = Vec::with_capacity(top.len());
    for (i, &(u, v)) in top.iter().enumerate() {
        let (a, b) = (
            normals[i.saturating_sub(1)],
            normals[i.min(normals.len() - 1)],
        );
        let scale = 1.0 + a.0 * b.0 + a.1 * b.1;
        if scale < 1e-6 {
            return None;
        }
        offset.push((
            u + thickness * (a.0 + b.0) / scale,
            v + thickness * (a.1 + b.1) / scale,
        ));
    }
    // An end carried along its tangent past the plumb line through the top's
    // end, however short its last chord: twice the profile's run and
    // thickness, divided by how far the tangent leans along `u`.
    let reach = 2.0 * ((top[top.len() - 1].0 - top[0].0).abs() + thickness);
    let carried = |a: (f64, f64), b: (f64, f64)| {
        let (du, dv) = (b.0 - a.0, b.1 - a.1);
        let length = du.hypot(dv);
        if length > 0.0 {
            let distance = reach / (du.abs() / length).max(1e-3);
            (b.0 + distance * du / length, b.1 + distance * dv / length)
        } else {
            b
        }
    };
    let mut chain = vec![carried(offset[1], offset[0])];
    chain.extend(offset.iter().copied());
    chain.push(carried(offset[offset.len() - 2], offset[offset.len() - 1]));
    let (low, high) = (top[0].0, top[top.len() - 1].0);
    let mut bottom = Vec::new();
    for pair in chain.windows(2) {
        let ((u0, v0), (u1, v1)) = (pair[0], pair[1]);
        for edge in [low, high] {
            if (u0 - edge) * (u1 - edge) < 0.0 {
                bottom.push((edge, v0 + (v1 - v0) * (edge - u0) / (u1 - u0)));
            }
        }
        if (low..=high).contains(&u1) {
            bottom.push((u1, v1));
        }
    }
    let rises = bottom.windows(2).all(|pair| pair[1].0 > pair[0].0);
    let ends = bottom.first().is_some_and(|p| (p.0 - low).abs() < 1e-9)
        && bottom.last().is_some_and(|p| (p.0 - high).abs() < 1e-9);
    (rises && ends).then_some(bottom)
}

/// Give each roof by extrusion its section (RE-211). Such a roof is
/// sketched in a vertical plane: every sketch line of it is flat along one
/// horizontal model axis, at one place along it. Its profile is those lines
/// joined end to end, rising along the plane's other horizontal axis, each a
/// straight line or a B-spline ([`crate::partition_beam_axes::BoundedSpline`])
/// within its record box. The profile is the roof's top; its type's layers
/// give the thickness square to it, and both ends are cut plumb. The section
/// is kept only where it reproduces the roof's record box across the plane
/// to [`ROOF_EXTRUSION_BOX_TOLERANCE_FEET`]; the roof then runs along the
/// axis over its box. Measured on `11_RoofByExtrusion` (R2025): every one of
/// the 1,187 vertices of Revit's body within 0.001 ft of the section.
fn attach_extrusion_roofs(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_beam_axes as pba;
    use crate::partition_element_records as per;
    if !pba::SKETCH_SPLINE_SUPPORTED_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let float = |element: &DecodedElement, wanted: &str| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let boxes: BTreeMap<u32, [f64; 6]> = products
        .iter()
        .filter(|element| element.class == "Roof" && type_of(element).is_some())
        .filter(|element| {
            crate::element_record_plan_profiles::plan_profile_from_fields(&element.fields).is_none()
        })
        .filter_map(|element| {
            let (x, y, z) = (
                float(element, "m_locationX")?,
                float(element, "m_locationY")?,
                float(element, "m_locationZ")?,
            );
            let (w, d, h) = (
                float(element, "m_bboxWidth")?,
                float(element, "m_bboxDepth")?,
                float(element, "m_bboxHeight")?,
            );
            Some((
                element.id?,
                [x - w / 2.0, y - d / 2.0, z, x + w / 2.0, y + d / 2.0, z + h],
            ))
        })
        .collect();
    if boxes.is_empty() {
        return;
    }
    let declared = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Ok(sketch_lines) =
        per::scan_category_records_multi(rf, revit_version, &[per::OST_SKETCH_LINES], &declared)
    else {
        return;
    };
    // A roof's lines are those its Sketch lists (RE-97), which an edited
    // sketch's lines' owner references need not name, or else those naming
    // it.
    let all_lines: BTreeSet<u32> = sketch_lines.iter().map(|line| line.element_id).collect();
    let lists =
        crate::element_record_plan_profiles::scan_sketch_curve_lists(rf, revit_version, &all_lines);
    let listed: BTreeMap<u32, u32> = lists
        .iter()
        .filter(|(roof, _)| boxes.contains_key(roof))
        .flat_map(|(&roof, curves)| curves.iter().map(move |&line| (line, roof)))
        .collect();
    let roof_of = |line: &per::PartitionElementRecord| {
        listed.get(&line.element_id).copied().or_else(|| {
            line.owner_reference
                .filter(|owner| boxes.contains_key(owner) && !lists.contains_key(owner))
        })
    };
    // A line framed in more than one partition is one line: its first copy.
    let mut copies: BTreeMap<u32, BTreeMap<u32, &per::PartitionElementRecord>> = BTreeMap::new();
    for line in &sketch_lines {
        if let Some(owner) = roof_of(line) {
            let kept = copies.entry(owner).or_default();
            let first = kept.get(&line.element_id).is_none_or(|held| {
                (line.stream.as_str(), line.offset) < (held.stream.as_str(), held.offset)
            });
            if first {
                kept.insert(line.element_id, line);
            }
        }
    }
    let lines_of: BTreeMap<u32, Vec<&per::PartitionElementRecord>> = copies
        .into_iter()
        .map(|(owner, lines)| (owner, lines.into_values().collect()))
        .collect();
    // The axis each roof's sketch is flat along, where all its lines are flat
    // along the same one at the same place.
    let planes: BTreeMap<u32, (usize, f64)> = lines_of
        .iter()
        .filter_map(|(&roof, lines)| {
            let flat = |line: &per::PartitionElementRecord, k: usize| {
                (line.bbox_feet[k + 3] - line.bbox_feet[k]).abs() < 1e-6
            };
            let axis = (0..2).find(|&k| lines.iter().all(|line| flat(line, k)))?;
            let at = lines.first()?.bbox_feet[axis];
            lines
                .iter()
                .all(|line| (line.bbox_feet[axis] - at).abs() < 1e-6)
                .then_some((roof, (axis, at)))
        })
        .collect();
    if planes.is_empty() {
        return;
    }
    let line_ids: BTreeSet<u32> = planes
        .keys()
        .flat_map(|roof| lines_of[roof].iter().map(|line| line.element_id))
        .collect();
    let splines = pba::scan_sketch_splines(rf, revit_version, &line_ids).unwrap_or_default();
    let straight = pba::scan_sketch_bounded_lines(rf, revit_version, &line_ids).unwrap_or_default();
    let types: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.id.is_some_and(|id| planes.contains_key(&id)))
        .filter_map(type_of)
        .collect();
    let materials: BTreeSet<u32> = crate::partition_type_records::scan_type_records(
        rf,
        revit_version,
        crate::partition_type_records::OST_MATERIALS,
        &declared,
    )
    .unwrap_or_default()
    .iter()
    .map(|record| record.element_id)
    .collect();
    let Ok(layers) = crate::partition_compound_structure::scan_type_layers(
        rf,
        revit_version,
        &types,
        &materials,
        &declared,
    ) else {
        return;
    };
    let inside = |point: [f64; 3], record: &[f64; 6]| {
        (0..3).all(|k| {
            point[k] >= record[k] - pba::END_TOLERANCE_FEET
                && point[k] <= record[k + 3] + pba::END_TOLERANCE_FEET
        })
    };
    for roof in products.iter_mut() {
        let Some(id) = roof.id else {
            continue;
        };
        let (Some(&(axis, _)), Some(record)) = (planes.get(&id), boxes.get(&id)) else {
            continue;
        };
        let Some(thickness) = type_of(roof)
            .and_then(|t| layers.get(&t))
            .map(|layers| layers.iter().map(|layer| layer.width_feet).sum::<f64>())
        else {
            continue;
        };
        let u_axis = 1 - axis;
        // Each line's points across the plane, from its own data, within its
        // record box.
        let mut curves: Vec<Vec<(f64, f64)>> = Vec::new();
        for line in &lines_of[&id] {
            let points = if let Some(spline) = splines.get(&line.element_id) {
                spline
                    .control_points
                    .iter()
                    .all(|&[_, x, y, z]| inside([x, y, z], &line.bbox_feet))
                    .then(|| roof_extrusion_spline_points(spline))
                    .flatten()
            } else {
                straight.get(&line.element_id).and_then(|segment| {
                    let ends = [segment.start(), segment.end()];
                    ends.iter()
                        .all(|end| inside(*end, &line.bbox_feet))
                        .then(|| ends.to_vec())
                })
            };
            let Some(points) = points else {
                curves.clear();
                break;
            };
            let mut across: Vec<(f64, f64)> = points.iter().map(|p| (p[u_axis], p[2])).collect();
            if across.last().map(|p| p.0) < across.first().map(|p| p.0) {
                across.reverse();
            }
            curves.push(across);
        }
        if curves.is_empty() {
            continue;
        }
        curves.sort_by(|a, b| a[0].0.total_cmp(&b[0].0));
        let mut top: Vec<(f64, f64)> = Vec::new();
        let mut joined = true;
        for curve in &curves {
            match top.last() {
                None => top.extend(curve.iter().copied()),
                Some(&(u, v)) => {
                    let (cu, cv) = curve[0];
                    if (cu - u).hypot(cv - v) > ROOF_EXTRUSION_JOIN_FEET {
                        joined = false;
                        break;
                    }
                    top.extend(curve.iter().skip(1).copied());
                }
            }
        }
        if !joined || !top.windows(2).all(|pair| pair[1].0 > pair[0].0) {
            continue;
        }
        let Some(bottom) = roof_extrusion_bottom(&top, thickness) else {
            continue;
        };
        let us = || top.iter().chain(&bottom).map(|p| p.0);
        let vs = || top.iter().chain(&bottom).map(|p| p.1);
        let section = [
            us().fold(f64::INFINITY, f64::min),
            vs().fold(f64::INFINITY, f64::min),
            us().fold(f64::NEG_INFINITY, f64::max),
            vs().fold(f64::NEG_INFINITY, f64::max),
        ];
        let wanted = [record[u_axis], record[2], record[u_axis + 3], record[5]];
        let reproduces = section
            .iter()
            .zip(wanted)
            .all(|(got, want)| (got - want).abs() <= ROOF_EXTRUSION_BOX_TOLERANCE_FEET);
        // The extrusion runs over the record box along `axis`, wherever its
        // sketch plane is: Revit's Start and End may put it to one side.
        if !reproduces {
            continue;
        }
        roof.fields.push((
            ROOF_EXTRUSION_AXIS_FIELD.into(),
            InstanceField::Integer {
                value: axis as i64,
                signed: false,
                size: 8,
            },
        ));
        roof.fields.push((
            ROOF_EXTRUSION_TOP_FIELD.into(),
            crate::element_record_plan_profiles::loop_field(&top),
        ));
        roof.fields.push((
            ROOF_EXTRUSION_BOTTOM_FIELD.into(),
            crate::element_record_plan_profiles::loop_field(&bottom),
        ));
    }
}

/// Field holding the roof's type thickness, its layers summed (RE-56).
pub const ROOF_TYPE_THICKNESS_FIELD: &str = "m_roof_type_thickness";
/// Field holding how far the first defining edge's plane is raised at the
/// edge, feet, written only when not 0 (RE-199); further edges add
/// `_<index>` ([`roof_slope_plate_offset_field`]).
pub const ROOF_SLOPE_PLATE_OFFSET_FIELD: &str = "m_roof_slope_plate_offset";

/// [`ROOF_SLOPE_PLATE_OFFSET_FIELD`] for the `index`th defining edge.
pub fn roof_slope_plate_offset_field(index: usize) -> String {
    match index {
        0 => ROOF_SLOPE_PLATE_OFFSET_FIELD.to_string(),
        _ => format!("{ROOF_SLOPE_PLATE_OFFSET_FIELD}_{index}"),
    }
}

/// A roof edge's slope: the edge that defines it, its angle, and the roof's
/// thickness measured square to the slope (RE-56).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct RoofSlope {
    /// Plan start of the defining edge, model feet.
    pub edge_start: [f64; 2],
    /// Plan end of the defining edge, model feet.
    pub edge_end: [f64; 2],
    /// Slope from horizontal, radians.
    pub angle_radians: f64,
    /// The roof type's layers summed, feet.
    pub thickness_feet: f64,
    /// How far the edge's plane is raised at the edge, feet (RE-199).
    pub plate_offset_feet: f64,
}

/// The names of the start, end and angle fields of a roof's `index`th
/// defining edge: [`ROOF_SLOPE_EDGE_FIELDS`] and [`ROOF_SLOPE_ANGLE_FIELD`]
/// for the first, the same names with `_<index>` after `edge` or `angle`
/// for each further one (RE-199).
pub fn roof_slope_edge_fields(index: usize) -> [String; 5] {
    let names = [
        ROOF_SLOPE_EDGE_FIELDS[0],
        ROOF_SLOPE_EDGE_FIELDS[1],
        ROOF_SLOPE_EDGE_FIELDS[2],
        ROOF_SLOPE_EDGE_FIELDS[3],
        ROOF_SLOPE_ANGLE_FIELD,
    ];
    names.map(|name| match index {
        0 => name.to_string(),
        _ => match name.find("_edge_") {
            Some(at) => format!("{}_edge_{index}_{}", &name[..at], &name[at + 6..]),
            None => format!("{name}_{index}"),
        },
    })
}

/// The slope [`ROOF_SLOPE_EDGE_FIELDS`], [`ROOF_SLOPE_ANGLE_FIELD`] and
/// [`ROOF_TYPE_THICKNESS_FIELD`] record: the first defining edge.
pub fn roof_slope_from_fields(fields: &[(String, InstanceField)]) -> Option<RoofSlope> {
    roof_slopes_from_fields(fields).into_iter().next()
}

/// Every defining edge a roof's fields record, in order
/// ([`roof_slope_edge_fields`]); empty when none is.
pub fn roof_slopes_from_fields(fields: &[(String, InstanceField)]) -> Vec<RoofSlope> {
    let float = |wanted: &str| {
        fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == wanted => Some(*value),
            _ => None,
        })
    };
    let Some(thickness_feet) = float(ROOF_TYPE_THICKNESS_FIELD) else {
        return Vec::new();
    };
    (0..)
        .map_while(|index| {
            let [sx, sy, ex, ey, angle] = roof_slope_edge_fields(index).map(|name| float(&name));
            Some(RoofSlope {
                edge_start: [sx?, sy?],
                edge_end: [ex?, ey?],
                angle_radians: angle?,
                thickness_feet,
                plate_offset_feet: float(&roof_slope_plate_offset_field(index)).unwrap_or(0.0),
            })
        })
        .collect()
}

/// Give each roof whose sketch lines all carry a slope block, exactly one
/// of them defining the roof's slope, that edge, its angle and its type's
/// thickness (RE-56, [`crate::partition_roof_slopes`]). A roof with no
/// defining edge is flat and gets nothing; one with two or more (a hip or
/// a gable) gets nothing either, as its surfaces are not built.
fn attach_roof_slopes(rf: &mut RevitFile, revit_version: u32, products: &mut [DecodedElement]) {
    use crate::partition_element_records as per;
    use crate::partition_roof_slopes as prs;
    if !prs::ROOF_SLOPE_SUPPORTED_REVIT_VERSIONS.contains(&revit_version) {
        return;
    }
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    let roofs: BTreeSet<u32> = products
        .iter()
        .filter(|element| element.class == "Roof" && type_of(element).is_some())
        .filter(|element| {
            crate::element_record_plan_profiles::plan_profile_from_fields(&element.fields).is_some()
        })
        .filter_map(|element| element.id)
        .collect();
    if roofs.is_empty() {
        return;
    }
    let declared = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Ok(sketch_lines) =
        per::scan_category_records_multi(rf, revit_version, &[per::OST_SKETCH_LINES], &declared)
    else {
        return;
    };
    // RE-97: where a roof's Sketch lists its curves, that list is its
    // membership; once the sketch is edited a line's owner reference names
    // another element (RE-199, on 2025).
    let all_lines: BTreeSet<u32> = sketch_lines.iter().map(|line| line.element_id).collect();
    let lists =
        crate::element_record_plan_profiles::scan_sketch_curve_lists(rf, revit_version, &all_lines);
    let mut edges: BTreeMap<u32, BTreeSet<u32>> = Default::default();
    for line in &sketch_lines {
        if let Some(owner) = line
            .owner_reference
            .filter(|owner| roofs.contains(owner) && !lists.contains_key(owner))
        {
            edges.entry(owner).or_default().insert(line.element_id);
        }
    }
    for (owner, curves) in lists.iter().filter(|(owner, _)| roofs.contains(owner)) {
        edges
            .entry(*owner)
            .or_default()
            .extend(curves.iter().copied());
    }
    let line_ids: BTreeSet<u32> = edges.values().flatten().copied().collect();
    let Ok(slopes) = prs::scan_edge_slopes(rf, revit_version, &line_ids) else {
        return;
    };
    let unblocked: BTreeSet<u32> = line_ids
        .iter()
        .filter(|line| !slopes.contains_key(line))
        .copied()
        .collect();
    let Ok(arrows) = prs::scan_arrow_heights(rf, revit_version, &unblocked) else {
        return;
    };
    // Every defining edge of a roof whose edges all carry a block: one is a
    // shed (RE-56), more a gable or hip (RE-199). A roof whose edges define
    // none, with one slope arrow, rises along the arrow (RE-199).
    let mut defining: BTreeMap<u32, Vec<(u32, f64, f64)>> = Default::default();
    let mut sloped_by_arrow: BTreeMap<u32, (u32, prs::ArrowHeights)> = Default::default();
    for (&roof, lines) in &edges {
        let (blocked, rest): (Vec<u32>, Vec<u32>) =
            lines.iter().partition(|line| slopes.contains_key(line));
        if let [arrow] = rest.as_slice() {
            let flat = blocked.iter().all(|line| !slopes[line].defines_slope);
            if let (true, Some(heights)) = (flat, arrows.get(arrow)) {
                sloped_by_arrow.insert(roof, (*arrow, *heights));
            }
            continue;
        }
        if !rest.is_empty() {
            continue;
        }
        let sloped: Vec<(u32, f64, f64)> = lines
            .iter()
            .filter_map(|line| slopes.get(line).map(|slope| (*line, slope)))
            .filter(|(_, slope)| slope.defines_slope)
            .map(|(line, slope)| (line, slope.angle_radians, slope.plate_offset_feet))
            .collect();
        if !sloped.is_empty() {
            defining.insert(roof, sloped);
        }
    }
    if defining.is_empty() && sloped_by_arrow.is_empty() {
        return;
    }
    let defining_lines: BTreeSet<u32> = defining
        .values()
        .flatten()
        .map(|(line, _, _)| *line)
        .chain(sloped_by_arrow.values().map(|(line, _)| *line))
        .collect();
    let types: BTreeSet<u32> = products
        .iter()
        .filter(|element| {
            element
                .id
                .is_some_and(|id| defining.contains_key(&id) || sloped_by_arrow.contains_key(&id))
        })
        .filter_map(type_of)
        .collect();
    let materials: BTreeSet<u32> = crate::partition_type_records::scan_type_records(
        rf,
        revit_version,
        crate::partition_type_records::OST_MATERIALS,
        &declared,
    )
    .unwrap_or_default()
    .iter()
    .map(|record| record.element_id)
    .collect();
    let sloped_roofs: BTreeSet<u32> = defining
        .keys()
        .chain(sloped_by_arrow.keys())
        .copied()
        .collect();
    let fascia = prs::scan_fascia_depths(rf, revit_version, &sloped_roofs).unwrap_or_default();
    let cuts = prs::scan_rafter_cuts(rf, revit_version, &sloped_roofs);
    let (Ok(lines), Ok(layers)) = (
        crate::partition_beam_axes::scan_sketch_bounded_lines(rf, revit_version, &defining_lines),
        crate::partition_compound_structure::scan_type_layers(
            rf,
            revit_version,
            &types,
            &materials,
            &declared,
        ),
    ) else {
        return;
    };
    for roof in products
        .iter_mut()
        .filter(|element| element.class == "Roof")
    {
        let (Some(id), Some(type_id)) = (roof.id, type_of(roof)) else {
            continue;
        };
        let Some(type_layers) = layers.get(&type_id) else {
            continue;
        };
        // An arrow is a shed whose edge runs through the arrow's tail square
        // to it, rising from the tail's height to the head's along it.
        let edges: Option<Vec<RoofEdgeSlope>> =
            if let Some((line_id, heights)) = sloped_by_arrow.get(&id) {
                lines.get(line_id).and_then(|line| {
                    let (tail, head) = (line.start(), line.end());
                    let run = (head[0] - tail[0]).hypot(head[1] - tail[1]);
                    let slope = heights.rise_over_run(run);
                    (run > 1e-9 && slope > 0.0 && slope.is_finite()).then(|| {
                        let (ux, uy) = ((head[0] - tail[0]) / run, (head[1] - tail[1]) / run);
                        let across = [tail[0] - uy, tail[1] + ux, tail[2]];
                        vec![(tail, across, slope.atan(), 0.0)]
                    })
                })
            } else {
                defining.get(&id).and_then(|sloped| {
                    sloped
                        .iter()
                        .map(|(line_id, angle, offset)| {
                            lines
                                .get(line_id)
                                .map(|line| (line.start(), line.end(), *angle, *offset))
                        })
                        .collect()
                })
            };
        let Some(edges) = edges else {
            continue;
        };
        let thickness: f64 = type_layers.iter().map(|layer| layer.width_feet).sum();
        if !(thickness.is_finite() && thickness > 0.0) {
            continue;
        }
        for (index, (start, end, angle, offset)) in edges.into_iter().enumerate() {
            for (name, value) in roof_slope_edge_fields(index)
                .into_iter()
                .zip([start[0], start[1], end[0], end[1], angle])
            {
                roof.fields
                    .push((name, InstanceField::Float { value, size: 8 }));
            }
            if offset != 0.0 {
                roof.fields.push((
                    roof_slope_plate_offset_field(index),
                    InstanceField::Float {
                        value: offset,
                        size: 8,
                    },
                ));
            }
        }
        roof.fields.push((
            ROOF_TYPE_THICKNESS_FIELD.into(),
            InstanceField::Float {
                value: thickness,
                size: 8,
            },
        ));
        if let Some(&depth) = fascia.get(&id) {
            roof.fields.push((
                ROOF_FASCIA_DEPTH_FIELD.into(),
                InstanceField::Float {
                    value: depth,
                    size: 8,
                },
            ));
        }
        if let Some(cut) = cuts.get(&id) {
            roof.fields.push((
                ROOF_RAFTER_CUT_FIELD.into(),
                InstanceField::String(cut.name().into()),
            ));
        }
    }
}

/// Field holding a roof's rafter cut, a [`crate::partition_roof_slopes::RafterCut`]
/// name, where it is read (RE-199).
pub const ROOF_RAFTER_CUT_FIELD: &str = "m_roof_rafter_cut";

/// The [`ROOF_RAFTER_CUT_FIELD`] a roof's fields record.
pub fn roof_rafter_cut_from_fields(
    fields: &[(String, InstanceField)],
) -> Option<crate::partition_roof_slopes::RafterCut> {
    fields.iter().find_map(|(name, value)| match value {
        InstanceField::String(cut) if name == ROOF_RAFTER_CUT_FIELD => {
            crate::partition_roof_slopes::RafterCut::from_name(cut)
        }
        _ => None,
    })
}

/// Field holding a roof's fascia depth, feet, where it is read (RE-199).
pub const ROOF_FASCIA_DEPTH_FIELD: &str = "m_roof_fascia_depth";

/// The [`ROOF_FASCIA_DEPTH_FIELD`] a roof's fields record.
pub fn roof_fascia_depth_from_fields(fields: &[(String, InstanceField)]) -> Option<f64> {
    fields.iter().find_map(|(name, value)| match value {
        InstanceField::Float { value, .. } if name == ROOF_FASCIA_DEPTH_FIELD => Some(*value),
        _ => None,
    })
}

/// A roof edge's start and end, its slope angle, and how far its plane is
/// raised at the edge (RE-199).
type RoofEdgeSlope = ([f64; 3], [f64; 3], f64, f64);

/// Classes whose type's layers stack from the top down (RE-57).
pub const STACKED_LAYER_CLASSES: &[&str] = &["Floor", "BuildingPad", "Roof", "Ceiling"];

/// How closely a slab's type layers must add up to its record box's height
/// for them to be its layers, feet.
pub const SLAB_LAYER_HEIGHT_TOLERANCE_FEET: f64 = 1e-4;

/// The materials layers may name and their names, on `revit_version`:
/// the `OST_Materials` type records and RE-58's names on 2024 and 2025, and
/// RE-113's material objects and names on 2023.
fn materials_and_names(
    rf: &mut RevitFile,
    revit_version: u32,
    declared: &BTreeSet<u32>,
) -> Option<(BTreeSet<u32>, BTreeMap<u32, String>)> {
    if crate::partition_element_records_2023::is_32bit_release(revit_version) {
        return Some(crate::partition_materials::scan_materials_32(
            rf,
            revit_version,
            declared,
        ));
    }
    let materials = crate::partition_type_records::scan_type_records(
        rf,
        revit_version,
        crate::partition_type_records::OST_MATERIALS,
        declared,
    )
    .unwrap_or_default()
    .iter()
    .map(|record| record.element_id)
    .collect();
    let names =
        crate::partition_materials::scan_material_names(rf, revit_version, declared).ok()?;
    Some((materials, names))
}

/// Give each floor, building pad, roof and ceiling its type's layers, top
/// first, each with its material's shading (RE-57), where they add up to its
/// record box's height: the plate is then exactly its layers. A roof drawn
/// along its slope (RE-56) is left out.
fn attach_slab_layers(
    rf: &mut RevitFile,
    revit_version: u32,
    mut elements: Vec<&mut DecodedElement>,
) {
    use crate::partition_compound_structure as pcs;
    if pcs::layer_layout(revit_version).is_none() {
        return;
    }
    let type_of = |element: &DecodedElement| {
        element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::ElementId { id, .. } if name == TYPE_ID_FIELD => Some(*id),
            _ => None,
        })
    };
    elements.retain(|element| {
        STACKED_LAYER_CLASSES.contains(&element.class.as_str())
            && type_of(element).is_some()
            && roof_slope_from_fields(&element.fields).is_none()
    });
    if elements.is_empty() {
        return;
    }
    let types: BTreeSet<u32> = elements
        .iter()
        .filter_map(|element| type_of(element))
        .collect();
    let declared: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let Some((materials, names)) = materials_and_names(rf, revit_version, &declared) else {
        return;
    };
    let (Ok(layers), Ok(appearances)) = (
        pcs::scan_type_layers(rf, revit_version, &types, &materials, &declared),
        crate::partition_materials::scan_material_appearances(rf, revit_version, &declared),
    ) else {
        return;
    };
    // RE-115: a layer that takes its category's material takes the one the
    // document's object styles give the element's category, as a wall's
    // does (RE-91), where it is set and named.
    let mut category_materials: BTreeMap<&str, Option<u32>> = BTreeMap::new();
    for (class, category) in [
        ("Floor", crate::partition_element_records::OST_FLOORS),
        ("Roof", crate::partition_element_records::OST_ROOFS),
        ("Ceiling", crate::partition_element_records::OST_CEILINGS),
    ] {
        let material =
            crate::partition_materials::scan_category_material(rf, revit_version, category)
                .ok()
                .flatten()
                .filter(|id| names.contains_key(id));
        category_materials.insert(class, material);
    }
    for element in elements {
        let Some(type_layers) = type_of(element).and_then(|id| layers.get(&id)) else {
            continue;
        };
        let category_material = category_materials
            .get(element.class.as_str())
            .copied()
            .flatten();
        let type_layers: Vec<pcs::CompoundLayer> = type_layers
            .iter()
            .map(|layer| pcs::CompoundLayer {
                material: layer.material.or(category_material),
                ..*layer
            })
            .collect();
        let type_layers = &type_layers;
        // B41: a ceiling's finish, its finish layers' materials. It is the
        // type's, so it does not wait on the height check below.
        if element.class == "Ceiling" {
            if let Some(finish) = finish_of_layers(type_layers, &names) {
                element
                    .fields
                    .push((COVERING_FINISH_FIELD.into(), InstanceField::String(finish)));
            }
        }
        let height = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == "m_bboxHeight" => Some(*value),
            _ => None,
        });
        let total: f64 = type_layers.iter().map(|layer| layer.width_feet).sum();
        if !height.is_some_and(|h| (h - total).abs() <= SLAB_LAYER_HEIGHT_TOLERANCE_FEET) {
            continue;
        }
        let bands = layer_bands_field(type_layers, &appearances, &names);
        if matches!(&bands, InstanceField::Vector(items) if !items.is_empty()) {
            element.fields.push((SLAB_LAYERS_FIELD.into(), bands));
        }
    }
}

/// Field holding a ceiling's finish, the names of its type's finish layers'
/// materials each followed by `;`.
// Tracker: B41.
pub const COVERING_FINISH_FIELD: &str = "m_covering_finish";

/// The names of the materials of `layers`' finish layers (functions 4 and
/// 5, [`crate::partition_compound_structure`]), each followed by `;`, as
/// Revit's export writes `Pset_CoveringCommon.Finish` (6 of 6 RE1 ceilings,
/// one finish layer each). `None` when there is no finish layer, or one
/// whose material's name is not read.
fn finish_of_layers(
    layers: &[crate::partition_compound_structure::CompoundLayer],
    names: &BTreeMap<u32, String>,
) -> Option<String> {
    let finishes: Vec<&crate::partition_compound_structure::CompoundLayer> = layers
        .iter()
        .filter(|layer| matches!(layer.function, 4 | 5))
        .collect();
    if finishes.is_empty() {
        return None;
    }
    let mut out = String::new();
    for layer in finishes {
        out.push_str(names.get(&layer.material?)?);
        out.push(';');
    }
    Some(out)
}

/// Back-compat alias for the #204 entry point.
pub fn columns_from_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
    level_ids: &BTreeSet<u32>,
) -> Vec<DecodedElement> {
    column_instances_from_records(records, level_ids, &[])
}

/// Field carrying the ElementId of the family/type symbol a placed
/// instance was recovered from (#215, RE-26).
pub const TYPE_SYMBOL_FIELD: &str = "m_type_symbol_id";
/// Field carrying the type symbol's plan width, in feet.
pub const TYPE_PROFILE_WIDTH_FIELD: &str = "m_type_profile_width";
/// Field carrying the type symbol's plan depth, in feet.
pub const TYPE_PROFILE_DEPTH_FIELD: &str = "m_type_profile_depth";
/// Field recording where the section in the two fields above came from.
pub const TYPE_PROFILE_SOURCE_FIELD: &str = "m_type_profile_source";
/// Value of [`TYPE_PROFILE_SOURCE_FIELD`] for the RE-26 carrier.
pub const TYPE_PROFILE_SOURCE: &str = "family_type_symbol_envelope";
/// How far the type section may sit from the instance envelope, in feet.
///
/// The join is accepted only when the symbol's plan extents match the
/// instance's — a symbol that does not is a symbol this decoder has
/// misread, or an instance that is scaled or rotated, and either way
/// the box it would emit is not the one the record states. On
/// `2024_Core_Interior.rvt` all 256 columns pass with a worst
/// disagreement of 8.0e-15 ft.
pub const TYPE_PROFILE_EPS_FEET: f64 = 1e-6;

/// Column instance selection with the family/type symbol join
/// attached (#215, RE-26).
///
/// The same category sweep carries both sides: the placed instances
/// (`is_exported_instance`) and the type-symbol envelopes
/// (`is_type_symbol`, RE-21 §5). Each instance names its symbol in
/// the counted reference list at `+0x88` —
/// [`crate::partition_element_records::PartitionElementRecord::type_symbol_reference`]
/// — and the symbol's own bounding box is the section in family
/// coordinates.
///
/// Measured on `2024_Core_Interior.rvt`: 256 of 256 exported columns
/// join to symbol `5755`, which is the `IfcColumnType.Tag` Revit's
/// own export writes for every one of them, and the section it gives
/// is the 2 ft square the instance envelope already carried — so the
/// join moves no vertex on this file. What it changes is where the
/// profile comes from: the type says the section is a rectangle,
/// instead of a box happening to be square.
pub fn column_instances_from_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
    level_ids: &BTreeSet<u32>,
    wall_records: &[crate::partition_element_records::PartitionElementRecord],
) -> Vec<DecodedElement> {
    use crate::partition_element_records::PartitionElementRecord;
    use std::collections::BTreeMap;

    let symbols: BTreeMap<u32, [f64; 6]> = records
        .iter()
        .filter(|record| record.is_type_symbol())
        .map(|record| (record.element_id, record.bbox_feet))
        .collect();
    let symbol_ids: BTreeSet<u32> = symbols.keys().copied().collect();
    let selected = select_instance_records(records);
    let instances: Vec<PartitionElementRecord> = selected.values().cloned().collect();
    let cuts = crate::element_record_column_cuts::column_cut_boxes(&instances, wall_records);
    let joined = crate::element_record_column_cuts::column_joined_walls(&instances, wall_records);
    selected
        .values()
        .map(|record: &PartitionElementRecord| {
            let mut decoded = element_record_decoded(record, "Column", level_ids);
            for &wall in joined.get(&record.element_id).into_iter().flatten() {
                decoded.fields.push((
                    crate::element_record_column_cuts::COLUMN_JOINED_WALL_FIELD.into(),
                    InstanceField::ElementId { tag: 0, id: wall },
                ));
            }
            if let Some(symbol) = record
                .type_symbol_reference(&symbol_ids)
                .and_then(|id| symbols.get(&id).map(|bbox| (id, *bbox)))
            {
                attach_type_symbol_profile(&mut decoded, record, symbol.0, &symbol.1);
            }
            if let Some(cut) = cuts.get(&record.element_id) {
                apply_column_join_cut(&mut decoded, cut);
            }
            decoded
        })
        .collect()
}

/// Field naming the Level of an element whose record names it in an id list
/// (RE-174), rather than in the association record.
pub const LEVEL_FROM_LIST_FIELD: &str = "m_level_parameter_from_list";

/// Field naming the highest of the several Levels an element's record names
/// in its id lists: a beam's or brace's Reference Level (RE-175).
pub const REFERENCE_LEVEL_FROM_LIST_FIELD: &str = "m_reference_level_from_list";

/// Give `element` its level fields (RE-172, RE-174, RE-175, RE-176).
fn attach_level_parameters(
    rf: &mut RevitFile,
    element: &mut DecodedElement,
    parameters: &BTreeMap<u32, crate::partition_level_parameters::LevelParameters>,
    names: &BTreeMap<u32, String>,
    elevations: &BTreeMap<u32, f64>,
) {
    use crate::partition_level_parameters as lp;
    let found = element
        .id
        .and_then(|id| parameters.get(&id))
        // A stair's record is read as a stair's only for a stair.
        .filter(|p| p.stair.is_none() || element.class == "Stair");
    let push = |element: &mut DecodedElement, name: &str, value: String| {
        element
            .fields
            .push((name.into(), InstanceField::String(value)));
    };
    if let Some(found) = found {
        if let Some(level) = &found.level {
            push(element, lp::LEVEL_PARAMETER_FIELD, level.clone());
        }
        if let Some(top) = &found.top {
            push(element, lp::TOP_LEVEL_PARAMETER_FIELD, top.clone());
        }
        if let Some((_, top)) = &found.stair {
            push(element, lp::TOP_LEVEL_PARAMETER_FIELD, top.clone());
        }
        return;
    }
    // The Level an element names in its record's id lists (RE-174): the
    // second list's if it names any, else the first's, if exactly one
    // recovered Level is named. A beam or brace naming more than one also
    // lists the Level(s) below its own: its Reference Level is the highest
    // (RE-175), kept apart as it is proven for those classes only.
    let (Some(stream), Some(offset)) = (
        element.fields.iter().find_map(|(n, v)| match v {
            InstanceField::String(s) if n == "m_source_stream" => Some(s.clone()),
            _ => None,
        }),
        element.fields.iter().find_map(|(n, v)| match v {
            InstanceField::Integer { value, .. } if n == "m_source_offset" => {
                usize::try_from(*value).ok()
            }
            _ => None,
        }),
    ) else {
        return;
    };
    let Ok(inflated) = rf.inflated_partition(&stream) else {
        return;
    };
    let buf = inflated.bytes();
    let at = offset + crate::partition_element_records::REFERENCE_LIST_OFFSET;
    let Some(first) = crate::partition_element_records::decode_reference_list(buf, at) else {
        return;
    };
    let second = at
        .checked_add(4 + first.len() * 8)
        .and_then(|at| crate::partition_element_records::decode_reference_list(buf, at))
        .unwrap_or_default();
    let ids: BTreeSet<u32> = names.keys().copied().collect();
    let mut named = crate::element_record_level_refs::named_levels(&second, &ids);
    if named.is_empty() {
        named = crate::element_record_level_refs::named_levels(&first, &ids);
    }
    if named.len() > 1 && element.class == "Stair" {
        // A stair whose association record gives no Base and Top Level
        // lists them, and at most the Level above its top (RE-176).
        if let Some((base, top)) = stair_levels_from_list(&named, elevations) {
            push(element, lp::LEVEL_PARAMETER_FIELD, names[&base].clone());
            push(element, lp::TOP_LEVEL_PARAMETER_FIELD, names[&top].clone());
            element
                .fields
                .push((LEVEL_FROM_LIST_FIELD.into(), InstanceField::Bool(true)));
        }
        return;
    }
    if named.len() > 1 {
        if let Some(level) = highest_level(&named, elevations) {
            push(
                element,
                REFERENCE_LEVEL_FROM_LIST_FIELD,
                names[&level].clone(),
            );
        }
        return;
    }
    if let [only] = named[..] {
        push(element, lp::LEVEL_PARAMETER_FIELD, names[&only].clone());
        element
            .fields
            .push((LEVEL_FROM_LIST_FIELD.into(), InstanceField::Bool(true)));
    }
}

/// A stair's Base and Top Level from the Levels its record lists: the
/// lowest and the next above it (RE-176). `None` unless every named Level
/// has an elevation and the lowest three are at distinct elevations.
fn stair_levels_from_list(named: &[u32], elevations: &BTreeMap<u32, f64>) -> Option<(u32, u32)> {
    let mut by_height: Vec<(f64, u32)> = named
        .iter()
        .map(|id| Some((*elevations.get(id)?, *id)))
        .collect::<Option<_>>()?;
    by_height.sort_by(|a, b| a.0.total_cmp(&b.0));
    let above = |low: f64, high: f64| high - low > 1e-6;
    match by_height[..] {
        [(b, base), (t, top)] if above(b, t) => Some((base, top)),
        [(b, base), (t, top), (n, _), ..] if above(b, t) && above(t, n) => Some((base, top)),
        _ => None,
    }
}

/// The Level of `named` with the highest elevation; `None` unless every
/// named Level has an elevation and the highest is unique (RE-175).
fn highest_level(named: &[u32], elevations: &BTreeMap<u32, f64>) -> Option<u32> {
    let mut by_height: Vec<(f64, u32)> = named
        .iter()
        .map(|id| Some((*elevations.get(id)?, *id)))
        .collect::<Option<_>>()?;
    by_height.sort_by(|a, b| b.0.total_cmp(&a.0));
    match by_height[..] {
        [(top, id), (next, _), ..] if top - next > 1e-6 => Some(id),
        _ => None,
    }
}

/// Field recording where a column's bottom came from, when not its record.
pub const COLUMN_Z_SOURCE_FIELD: &str = "m_column_z_source";
/// Value of [`COLUMN_Z_SOURCE_FIELD`] for a bottom read from the geometry node.
pub const COLUMN_Z_GEOMETRY_NODE: &str = "partition_geometry_node";

/// Give each column whose record box starts at z = 0.0 the bottom its
/// geometry node holds (RE-173).
fn apply_column_node_bottoms(rf: &mut RevitFile, lists: [&mut Vec<DecodedElement>; 2]) {
    let is_column = |e: &DecodedElement| matches!(e.class.as_str(), "Column" | "StructuralColumn");
    let mut targets = BTreeMap::new();
    for list in lists.iter() {
        for element in list.iter().filter(|e| is_column(e)) {
            if let (Some(id), Some(bbox)) = (element.id, element_record_bbox(element)) {
                if bbox[2] == 0.0 {
                    targets.insert(id, bbox);
                }
            }
        }
    }
    let bottoms = crate::partition_column_nodes::column_bottoms(rf, &targets);
    for list in lists {
        for element in list.iter_mut().filter(|e| is_column(e)) {
            let Some(&bottom) = element.id.and_then(|id| bottoms.get(&id)) else {
                continue;
            };
            let Some(bbox) = targets.get(&element.id.unwrap_or_default()) else {
                continue;
            };
            for (name, value) in element.fields.iter_mut() {
                match name.as_str() {
                    "m_locationZ" => {
                        *value = InstanceField::Float {
                            value: bottom,
                            size: 8,
                        }
                    }
                    "m_bboxHeight" => {
                        *value = InstanceField::Float {
                            value: bbox[5] - bottom,
                            size: 8,
                        }
                    }
                    _ => {}
                }
            }
            element.fields.push((
                COLUMN_Z_SOURCE_FIELD.into(),
                InstanceField::String(COLUMN_Z_GEOMETRY_NODE.into()),
            ));
        }
    }
}

/// Bottom, feet, of a column's body after its geometry joins (RE-178). The
/// column's own fields (`m_locationZ`, `m_bboxHeight`) keep its extent.
pub const COLUMN_BODY_BOTTOM_FIELD: &str = "m_column_body_bottom";
/// Top, feet, of a column's body after its geometry joins (RE-178).
pub const COLUMN_BODY_TOP_FIELD: &str = "m_column_body_top";

/// Give each column that a joined slab or roof cuts the z-range of its cut
/// body, from its geometry node (RE-178). Only the body follows it.
fn apply_column_cut_bodies(rf: &mut RevitFile, lists: [&mut Vec<DecodedElement>; 2]) {
    let is_column = |e: &DecodedElement| matches!(e.class.as_str(), "Column" | "StructuralColumn");
    let targets: BTreeMap<u32, [f64; 6]> = lists
        .iter()
        .flat_map(|list| list.iter().filter(|e| is_column(e)))
        .filter_map(|e| Some((e.id?, element_record_bbox(e)?)))
        .collect();
    let extents = crate::partition_column_nodes::column_cut_extents(rf, &targets);
    for list in lists {
        for element in list.iter_mut().filter(|e| is_column(e)) {
            let Some(&(bottom, top)) = element.id.and_then(|id| extents.get(&id)) else {
                continue;
            };
            for (name, value) in [
                (COLUMN_BODY_BOTTOM_FIELD, bottom),
                (COLUMN_BODY_TOP_FIELD, top),
            ] {
                element
                    .fields
                    .push((name.into(), InstanceField::Float { value, size: 8 }));
            }
        }
    }
}

/// Rewrite a column's placement and extents to the cut body, and say
/// where that body came from (#239, RE-29 §5).
///
/// The type section recovered by [`attach_type_symbol_profile`] is
/// the *uncut* family section and stays on the element as the type's
/// own fact; what changes is the emitted solid, which is the record
/// prism minus the walls the record names.
fn apply_column_join_cut(
    decoded: &mut DecodedElement,
    cut: &crate::element_record_column_cuts::ColumnCut,
) {
    use crate::element_record_column_cuts as cuts;

    let bbox = cut.bbox_feet;
    let replacements: [(&str, f64); 6] = [
        ("m_locationX", (bbox[0] + bbox[3]) * 0.5),
        ("m_locationY", (bbox[1] + bbox[4]) * 0.5),
        ("m_locationZ", bbox[2]),
        ("m_bboxWidth", bbox[3] - bbox[0]),
        ("m_bboxDepth", bbox[4] - bbox[1]),
        ("m_bboxHeight", bbox[5] - bbox[2]),
    ];
    for (name, value) in decoded.fields.iter_mut() {
        if let Some((_, replacement)) = replacements
            .iter()
            .find(|(field, _)| *field == name.as_str())
        {
            *value = InstanceField::Float {
                value: *replacement,
                size: 8,
            };
        }
    }
    decoded.fields.push((
        cuts::COLUMN_BODY_SOURCE_FIELD.into(),
        InstanceField::String(cuts::COLUMN_BODY_JOIN_CUT.into()),
    ));
    decoded.fields.push((
        cuts::COLUMN_CUT_WALL_COUNT_FIELD.into(),
        InstanceField::Integer {
            value: cut.wall_count as i64,
            signed: false,
            size: 8,
        },
    ));
}

/// Attach the type symbol's section to a placed instance, when the
/// section agrees with the instance's own plan envelope.
fn attach_type_symbol_profile(
    decoded: &mut DecodedElement,
    record: &crate::partition_element_records::PartitionElementRecord,
    symbol_id: u32,
    symbol_bbox: &[f64; 6],
) {
    let width = symbol_bbox[3] - symbol_bbox[0];
    let depth = symbol_bbox[4] - symbol_bbox[1];
    if !(width.is_finite() && depth.is_finite()) || width <= 0.0 || depth <= 0.0 {
        return;
    }
    let (dx, dy, _) = record.extents_feet();
    if (width - dx).abs() > TYPE_PROFILE_EPS_FEET || (depth - dy).abs() > TYPE_PROFILE_EPS_FEET {
        return;
    }
    decoded.fields.push((
        TYPE_SYMBOL_FIELD.into(),
        InstanceField::ElementId {
            tag: 0,
            id: symbol_id,
        },
    ));
    decoded.fields.push((
        TYPE_PROFILE_WIDTH_FIELD.into(),
        InstanceField::Float {
            value: width,
            size: 8,
        },
    ));
    decoded.fields.push((
        TYPE_PROFILE_DEPTH_FIELD.into(),
        InstanceField::Float {
            value: depth,
            size: 8,
        },
    ));
    decoded.fields.push((
        TYPE_PROFILE_SOURCE_FIELD.into(),
        InstanceField::String(TYPE_PROFILE_SOURCE.into()),
    ));
}

/// Wall instance selection with the join-trimmed body attached
/// (RE-26).
///
/// The record box is the wall's untrimmed prism; Revit's exported
/// body is the same prism after the joins cut it back, and
/// [`crate::element_record_wall_joins`] recovers the cut from the
/// recovered wall set alone. A wall the solver declines keeps its
/// record box and says so in `m_wall_body_source`.
pub fn wall_instances_from_records(
    records: Vec<crate::partition_element_records::PartitionElementRecord>,
    level_ids: &BTreeSet<u32>,
) -> Vec<DecodedElement> {
    use crate::element_record_wall_joins as joins;

    let selected = select_instance_records(records);
    let boxes: Vec<crate::partition_element_records::PartitionElementRecord> =
        selected.values().cloned().collect();
    let trims = joins::join_trims(&boxes);
    selected
        .values()
        .map(|record| {
            let mut decoded = element_record_decoded(record, "Wall", level_ids);
            if let Some(trim) = trims.get(&record.element_id) {
                apply_wall_join_trim(&mut decoded, record, trim);
            }
            decoded
        })
        .collect()
}

/// Rewrite a wall's plan centre and plan extents to the trimmed body.
fn apply_wall_join_trim(
    decoded: &mut DecodedElement,
    record: &crate::partition_element_records::PartitionElementRecord,
    trim: &crate::element_record_wall_joins::WallJoinTrim,
) {
    use crate::element_record_wall_joins as joins;

    let low = record.bbox_feet[trim.axis] + trim.start_feet;
    let high = record.bbox_feet[trim.axis + 3] - trim.end_feet;
    let (centre_field, extent_field) = if trim.axis == 0 {
        ("m_locationX", "m_bboxWidth")
    } else {
        ("m_locationY", "m_bboxDepth")
    };
    for (name, value) in decoded.fields.iter_mut() {
        if name == centre_field {
            *value = InstanceField::Float {
                value: (low + high) * 0.5,
                size: 8,
            };
        } else if name == extent_field {
            *value = InstanceField::Float {
                value: high - low,
                size: 8,
            };
        }
    }
    decoded.fields.push((
        joins::WALL_BODY_SOURCE_FIELD.into(),
        InstanceField::String(joins::WALL_BODY_JOIN_TRIMMED.into()),
    ));
    decoded.fields.push((
        joins::WALL_THICKNESS_FIELD.into(),
        InstanceField::Float {
            value: trim.thickness_feet,
            size: 8,
        },
    ));
    decoded.fields.push((
        joins::WALL_TRIM_START_FIELD.into(),
        InstanceField::Float {
            value: trim.start_feet,
            size: 8,
        },
    ));
    decoded.fields.push((
        joins::WALL_TRIM_END_FIELD.into(),
        InstanceField::Float {
            value: trim.end_feet,
            size: 8,
        },
    ));
}

/// Rewrite a beam's plan centre and extent along its run to the
/// column-cut body (RE-122).
fn apply_beam_column_trim(
    decoded: &mut DecodedElement,
    trim: &crate::element_record_beam_cuts::BeamColumnTrim,
) {
    use crate::element_record_beam_cuts as cuts;
    let (centre_field, extent_field) = if trim.axis == 0 {
        ("m_locationX", "m_bboxWidth")
    } else {
        ("m_locationY", "m_bboxDepth")
    };
    for (name, value) in decoded.fields.iter_mut() {
        if name == centre_field {
            *value = InstanceField::Float {
                value: (trim.low_feet + trim.high_feet) * 0.5,
                size: 8,
            };
        } else if name == extent_field {
            *value = InstanceField::Float {
                value: trim.high_feet - trim.low_feet,
                size: 8,
            };
        }
    }
    decoded.fields.push((
        cuts::BEAM_BODY_SOURCE_FIELD.into(),
        InstanceField::String(cuts::BEAM_BODY_COLUMN_CUT.into()),
    ));
}

/// RE-59: give each record-backed element whose record names two Levels
/// its base constraint ([`crate::element_record_level_refs::base_constraint_level`])
/// as its host Level, from the Levels' own elevations (RE-51). Nothing
/// changes where the Levels' elevations are not recovered.
fn resolve_base_constraint_levels(
    elevations: &BTreeMap<u32, f64>,
    elements: &mut [&mut Vec<DecodedElement>],
) {
    use crate::element_record_level_refs as refs;
    if elevations.is_empty() {
        return;
    }
    for element in elements.iter_mut().flat_map(|list| list.iter_mut()) {
        let mut named = Vec::new();
        let mut base = None;
        for (name, value) in &element.fields {
            match (name.as_str(), value) {
                (refs::CONSTRAINT_LEVELS_FIELD, InstanceField::Vector(ids)) => {
                    named = ids
                        .iter()
                        .filter_map(|id| match id {
                            InstanceField::ElementId { id, .. } => Some(*id),
                            _ => None,
                        })
                        .collect();
                }
                ("m_locationZ", InstanceField::Float { value, .. }) => base = Some(*value),
                _ => {}
            }
        }
        let Some(level) = base.and_then(|z| refs::base_constraint_level(&named, elevations, z))
        else {
            continue;
        };
        bind_record_level(element, level, refs::BASE_CONSTRAINT_SOURCE);
    }
}

/// Give a record-backed element `level` as its host Level, recording how.
/// Value of the level-bind source field for a beam bound by its top
/// (`resolve_framing_top_levels`).
pub const FRAMING_TOP_LEVEL_SOURCE: &str = "structural_framing_top_level";

/// Bind each Revit 2023 structural framing element to the one Level at its
/// record box's top, in place of the Level its record names (RE-119). A
/// beam sits under its reference Level: on a 2023 project Revit's export
/// puts four beams spanning 3.2 to 4.0 m on the 4.0 m Level, and four
/// foundation beams spanning -0.8 to 0.0 m on the 0.0 m Level, where their
/// records name the 0.0 m Level and none. Nothing changes where no Level, or
/// more than one, is at the top.
fn resolve_framing_top_levels(
    elevations: &BTreeMap<u32, f64>,
    elements: &mut [&mut Vec<DecodedElement>],
) {
    use crate::element_record_level_refs as refs;
    const TOLERANCE_FEET: f64 = 1e-3;
    for element in elements.iter_mut().flat_map(|list| list.iter_mut()) {
        if element.class != "StructuralFraming" {
            continue;
        }
        let float = |wanted: &str| {
            element.fields.iter().find_map(|(name, value)| match value {
                InstanceField::Float { value, .. } if name == wanted => Some(*value),
                _ => None,
            })
        };
        let (Some(base), Some(height)) = (float("m_locationZ"), float("m_bboxHeight")) else {
            continue;
        };
        let top = base + height;
        let mut at_top = elevations
            .iter()
            .filter(|(_, elevation)| (**elevation - top).abs() <= TOLERANCE_FEET)
            .map(|(id, _)| *id);
        let (Some(level), None) = (at_top.next(), at_top.next()) else {
            continue;
        };
        element.fields.retain(|(name, _)| {
            name != refs::LEVEL_REFERENCE_FIELD && name != refs::LEVEL_BIND_SOURCE_FIELD
        });
        bind_record_level(element, level, FRAMING_TOP_LEVEL_SOURCE);
    }
}

fn bind_record_level(element: &mut DecodedElement, level: u32, source: &str) {
    use crate::element_record_level_refs as refs;
    for (name, value) in element.fields.iter_mut() {
        if name == "m_level_bound" {
            *value = InstanceField::Bool(true);
        }
    }
    element.fields.push((
        refs::LEVEL_REFERENCE_FIELD.into(),
        InstanceField::ElementId { tag: 0, id: level },
    ));
    element.fields.push((
        refs::LEVEL_BIND_SOURCE_FIELD.into(),
        InstanceField::String(source.into()),
    ));
}

fn element_ids_field(element: &DecodedElement, field: &str) -> Vec<u32> {
    element
        .fields
        .iter()
        .find_map(|(name, value)| match value {
            InstanceField::Vector(ids) if name == field => Some(
                ids.iter()
                    .filter_map(|id| match id {
                        InstanceField::ElementId { id, .. } => Some(*id),
                        _ => None,
                    })
                    .collect(),
            ),
            _ => None,
        })
        .unwrap_or_default()
}

fn record_level(element: &DecodedElement) -> Option<u32> {
    element.fields.iter().find_map(|(name, value)| match value {
        InstanceField::ElementId { id, .. }
            if name == crate::element_record_level_refs::LEVEL_REFERENCE_FIELD =>
        {
            Some(*id)
        }
        _ => None,
    })
}

/// RE-60: a Level for record-backed elements whose record names none.
///
/// - A railing takes the Level of the one stair or ramp its record names,
///   where that has one.
/// - A plumbing fixture takes the Level the objects its record names carry
///   ([`crate::partition_level_records::scan_level_objects`]), where they
///   carry one (RE-68 §6). On Snowdon Towers that is Revit's storey for all
///   4 such fixtures, where their base elevation gives another.
/// - Any other element takes that Level only where it is also the highest
///   Level at or below the element's base
///   ([`crate::element_record_level_refs::level_at_or_below`]). For light
///   fixtures, slab edges and wall sweeps the objects alone name a Level
///   other than Revit's on 73 of the 214 that name one.
fn resolve_hosted_levels(
    rf: &mut RevitFile,
    elevations: &BTreeMap<u32, f64>,
    elements: &mut [&mut Vec<DecodedElement>],
) {
    use crate::element_record_level_refs as refs;
    if elevations.is_empty() {
        return;
    }
    let pending = elements.iter().flat_map(|list| list.iter()).any(|element| {
        record_level(element).is_none()
            && !element_ids_field(element, refs::REFERENCES_FIELD).is_empty()
    });
    if !pending {
        return;
    }
    let hosts: BTreeMap<u32, Option<u32>> = elements
        .iter()
        .flat_map(|list| list.iter())
        .filter(|element| matches!(element.class.as_str(), "Stair" | "Ramp"))
        .filter_map(|element| Some((element.id?, record_level(element))))
        .collect();
    let declared = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => return,
    };
    let level_ids: BTreeSet<u32> = elevations.keys().copied().collect();
    let level_objects =
        crate::partition_level_records::scan_level_objects(rf, &declared, &level_ids);
    for element in elements.iter_mut().flat_map(|list| list.iter_mut()) {
        if record_level(element).is_some() {
            continue;
        }
        let references = element_ids_field(element, refs::REFERENCES_FIELD);
        if references.is_empty() {
            continue;
        }
        if element.class == "Railing" {
            let named: Vec<&Option<u32>> =
                references.iter().filter_map(|id| hosts.get(id)).collect();
            if let [Some(level)] = named.as_slice() {
                bind_record_level(element, *level, refs::HOST_SOURCE);
            }
            continue;
        }
        let carried: BTreeSet<u32> = references
            .iter()
            .filter_map(|id| level_objects.get(id).copied())
            .collect();
        let base = element.fields.iter().find_map(|(name, value)| match value {
            InstanceField::Float { value, .. } if name == "m_locationZ" => Some(*value),
            _ => None,
        });
        let (Some(&level), 1) = (carried.first(), carried.len()) else {
            continue;
        };
        if element.class == "PlumbingFixture" {
            bind_record_level(element, level, refs::PLUMBING_LEVEL_OBJECT_SOURCE);
            continue;
        }
        let Some(base) = base else {
            continue;
        };
        if refs::level_at_or_below(elevations, base) == Some(level) {
            bind_record_level(element, level, refs::LEVEL_OBJECT_SOURCE);
        }
    }
}

/// A record-backed element's base elevation, feet.
fn record_base_feet(element: &DecodedElement) -> Option<f64> {
    element.fields.iter().find_map(|(name, value)| match value {
        InstanceField::Float { value, .. } if name == "m_locationZ" => Some(*value),
        _ => None,
    })
}

/// RE-68: a stair or ramp that names no Level, or several (a multistory
/// stair names three), takes the one Level its base sits exactly at, so
/// its railings can follow it (RE-60). On Snowdon Towers these are the
/// three multistory stairs, whose base is L3's elevation; Revit writes
/// each one on L3 and again on L4.
fn resolve_base_at_level(
    elevations: &BTreeMap<u32, f64>,
    elements: &mut [&mut Vec<DecodedElement>],
) {
    use crate::element_record_level_refs as refs;
    for element in elements.iter_mut().flat_map(|list| list.iter_mut()) {
        if record_level(element).is_some() || !matches!(element.class.as_str(), "Stair" | "Ramp") {
            continue;
        }
        let Some(base) = record_base_feet(element) else {
            continue;
        };
        let mut at = elevations
            .iter()
            .filter(|(_, at)| (**at - base).abs() <= 1e-3);
        if let (Some((&level, _)), None) = (at.next(), at.next()) {
            bind_record_level(element, level, refs::BASE_AT_LEVEL_SOURCE);
        }
    }
}

/// Classes Revit's export places by elevation when their record names no
/// Level of their own (RE-68): on Snowdon Towers every unplaced slab edge,
/// light fixture, wall sweep, generic model, hardscape element and stair is
/// on the Level [`crate::element_record_level_refs::elevation_band_level`]
/// gives, while plumbing fixtures follow the Level object they name instead.
pub const ELEVATION_PLACED_CLASSES: &[&str] = &[
    "SlabEdge",
    "LightingFixture",
    "WallSweep",
    "GenericModel",
    "Hardscape",
    "Stair",
];

/// RE-68: a Level for record-backed elements still without one after RE-59
/// and RE-60.
///
/// - An element takes the Level of the one element of its own class its
///   record names, where that has one: the parts of a nested light-fixture
///   family follow the fixture that holds them.
/// - Otherwise an element of [`ELEVATION_PLACED_CLASSES`] takes the Level
///   its base elevation gives, within a fail-closed band
///   ([`crate::element_record_level_refs::elevation_band_level`]).
///
/// Measured on Snowdon Towers against every copy Revit writes of each
/// element (a multistory stair and its railings appear once per storey).
fn resolve_remaining_levels(
    elevations: &BTreeMap<u32, f64>,
    elements: &mut [&mut Vec<DecodedElement>],
) {
    use crate::element_record_level_refs as refs;
    if elevations.is_empty() {
        return;
    }
    let leveled: BTreeMap<u32, (String, u32)> = elements
        .iter()
        .flat_map(|list| list.iter())
        .filter_map(|element| Some((element.id?, (element.class.clone(), record_level(element)?))))
        .collect();
    for element in elements.iter_mut().flat_map(|list| list.iter_mut()) {
        if record_level(element).is_some() {
            continue;
        }
        let references = element_ids_field(element, refs::REFERENCES_FIELD);
        let same_class: BTreeSet<u32> = references
            .iter()
            .filter_map(|id| leveled.get(id))
            .filter(|(class, _)| *class == element.class)
            .map(|(_, level)| *level)
            .collect();
        let hosts = references
            .iter()
            .filter(|id| {
                leveled
                    .get(id)
                    .is_some_and(|(class, _)| *class == element.class)
            })
            .count();
        if let (1, Some(&level)) = (hosts, same_class.first()) {
            bind_record_level(element, level, refs::SAME_CLASS_HOST_SOURCE);
            continue;
        }
        if !ELEVATION_PLACED_CLASSES.contains(&element.class.as_str()) {
            continue;
        }
        if let Some(level) =
            record_base_feet(element).and_then(|base| refs::elevation_band_level(elevations, base))
        {
            bind_record_level(element, level, refs::BASE_ELEVATION_SOURCE);
        }
    }
}

fn element_record_decoded(
    record: &crate::partition_element_records::PartitionElementRecord,
    class: &str,
    level_ids: &BTreeSet<u32>,
) -> DecodedElement {
    let (cx, cy) = record.plan_centre_feet();
    let (dx, dy, dz) = record.extents_feet();
    let level_id =
        crate::element_record_level_refs::unique_level_reference(&record.references, level_ids);
    let mut fields = vec![
        (
            "m_locationX".into(),
            InstanceField::Float { value: cx, size: 8 },
        ),
        (
            "m_locationY".into(),
            InstanceField::Float { value: cy, size: 8 },
        ),
        (
            "m_locationZ".into(),
            InstanceField::Float {
                value: record.bbox_feet[2],
                size: 8,
            },
        ),
        (
            "m_bboxWidth".into(),
            InstanceField::Float { value: dx, size: 8 },
        ),
        (
            "m_bboxDepth".into(),
            InstanceField::Float { value: dy, size: 8 },
        ),
        (
            "m_bboxHeight".into(),
            InstanceField::Float { value: dz, size: 8 },
        ),
        (
            "m_builtinCategory".into(),
            InstanceField::Integer {
                value: record.builtin_category,
                signed: true,
                size: 8,
            },
        ),
        (
            "m_source_stream".into(),
            InstanceField::String(record.stream.clone()),
        ),
        (
            "m_source_offset".into(),
            InstanceField::Integer {
                value: record.offset as i64,
                signed: false,
                size: 8,
            },
        ),
        (
            CLASS_TAG_FIELD.into(),
            InstanceField::Integer {
                value: i64::from(record.class_tag),
                signed: false,
                size: 2,
            },
        ),
        (
            "m_source".into(),
            InstanceField::String("partition_element_record".into()),
        ),
        // The host Level, when the record's counted reference list
        // names exactly one of them (#219, RE-27). The extrusion
        // height below is still the recorded bbox extent, never a
        // level-to-level span.
        (
            "m_level_bound".into(),
            InstanceField::Bool(level_id.is_some()),
        ),
    ];
    if level_id.is_none() {
        // RE-59: base and top constraint, resolved against the Levels'
        // elevations by `resolve_base_constraint_levels`.
        let named = crate::element_record_level_refs::named_levels(&record.references, level_ids);
        if named.is_empty() {
            // RE-60: what the record names instead, resolved by
            // `resolve_hosted_levels`.
            let mut references: Vec<u32> = Vec::new();
            for slot in &record.references {
                if let Ok(id) = u32::try_from(*slot) {
                    if id != record.element_id && !references.contains(&id) {
                        references.push(id);
                    }
                }
            }
            if !references.is_empty() {
                fields.push((
                    crate::element_record_level_refs::REFERENCES_FIELD.into(),
                    InstanceField::Vector(
                        references
                            .iter()
                            .map(|&id| InstanceField::ElementId { tag: 0, id })
                            .collect(),
                    ),
                ));
            }
        }
        if named.len() == 2 {
            fields.push((
                crate::element_record_level_refs::CONSTRAINT_LEVELS_FIELD.into(),
                InstanceField::Vector(
                    named
                        .iter()
                        .map(|&id| InstanceField::ElementId { tag: 0, id })
                        .collect(),
                ),
            ));
        }
    }
    if let Some(id) = level_id {
        fields.push((
            crate::element_record_level_refs::LEVEL_REFERENCE_FIELD.into(),
            InstanceField::ElementId { tag: 0, id },
        ));
    }
    let provenance = ElementProvenance::partition(
        &record.stream,
        record.offset,
        "partition_element_record",
        "partition_schema_mvp::element_category_record",
        0.8,
        Some("level_binding_unresolved"),
    );
    DecodedElement {
        id: Some(record.element_id),
        class: class.into(),
        fields,
        byte_range: record.offset
            ..record
                .offset
                .saturating_add(crate::partition_element_records::RECORD_MIN_LEN),
        provenance,
    }
}

fn levels_from_storeys_and_names(
    walls: &[PartitionArcWall],
    level_names: &[String],
) -> Vec<DecodedElement> {
    let recovery = partition_arc_walls::recover_storeys_from_arc_walls(walls, level_names);
    // A name that no Level's elevation confirms is not a storey: the names
    // are candidates from partition strings, and on a file whose Levels are
    // not read they are often not the model's (a Revit 2026 house gave
    // `Ground floor`, `Level 1` and `Roof`, none of its four Levels, and a
    // family with no Levels gave `Level 1` and `Roof`), each written at
    // elevation 0 (RE-124). Such a file has no storeys (fail closed).
    if recovery.storeys.is_empty() {
        return Vec::new();
    }
    recovery
        .storeys
        .into_iter()
        .enumerate()
        .map(|(i, s)| level_decoded(&s.name, Some(s.elevation_feet), i))
        .collect()
}

fn level_decoded(name: &str, elevation: Option<f64>, index: usize) -> DecodedElement {
    let mut fields = vec![
        ("m_name".into(), InstanceField::String(name.to_string())),
        ("m_isBuildingStory".into(), InstanceField::Bool(true)),
        (
            "m_source".into(),
            InstanceField::String("partition_schema_mvp".into()),
        ),
    ];
    if let Some(elev) = elevation {
        fields.push((
            "m_elevation".into(),
            InstanceField::Float {
                value: elev,
                size: 8,
            },
        ));
    }
    let confidence = if elevation.is_some() { 0.75 } else { 0.55 };
    DecodedElement {
        id: None,
        class: "Level".into(),
        fields,
        byte_range: index..index,
        provenance: ElementProvenance::partition(
            "partition",
            index,
            "partition_schema_mvp",
            "partition_schema_mvp::level",
            confidence,
            if elevation.is_none() {
                Some("elevation_unknown")
            } else {
                None
            },
        ),
    }
}

/// Every material the file declares, from its `OST_Materials` record
/// (RE-28), with the name (RE-58) and shading colour (RE-53) read from its
/// own object, in ElementId order; on Revit 2023 from its material objects
/// (RE-113, RE-116). A record whose name is not found is left out. `None`
/// on a release those layouts are not measured on, where the partition
/// display-name strings stand in ([`materials_from_names`]).
fn materials_from_records(rf: &mut RevitFile, revit_version: u32) -> Option<Vec<DecodedElement>> {
    use crate::partition_materials as pm;
    let revit_2023 = crate::partition_element_records_2023::is_32bit_release(revit_version);
    if !pm::MATERIALS_SUPPORTED_REVIT_VERSIONS.contains(&revit_version) && !revit_2023 {
        return None;
    }
    let declared = crate::elem_table::declared_ids(&crate::elem_table::parse_records(rf).ok()?);
    // Revit 2023 has no material records; its materials are the objects
    // carrying the 2023 material tag (RE-113).
    let (ids, names) = if revit_2023 {
        pm::scan_materials_32(rf, revit_version, &declared)
    } else {
        let ids: BTreeSet<u32> = crate::partition_type_records::scan_type_records(
            rf,
            revit_version,
            crate::partition_type_records::OST_MATERIALS,
            &declared,
        )
        .ok()?
        .iter()
        .map(|record| record.element_id)
        .collect();
        (
            ids,
            pm::scan_material_names(rf, revit_version, &declared).ok()?,
        )
    };
    let appearances = pm::scan_material_appearances(rf, revit_version, &declared).ok()?;
    Some(
        ids.into_iter()
            .filter_map(|id| {
                let name = names.get(&id)?;
                let mut fields = vec![("m_name".into(), InstanceField::String(name.clone()))];
                if let Some(appearance) = appearances.get(&id) {
                    fields.push((
                        "m_color".into(),
                        InstanceField::Integer {
                            value: i64::from(appearance.color_packed()),
                            signed: false,
                            size: 4,
                        },
                    ));
                    fields.push((
                        "m_transparency".into(),
                        InstanceField::Float {
                            value: f64::from(appearance.transparency),
                            size: 4,
                        },
                    ));
                }
                fields.push((
                    "m_source".into(),
                    InstanceField::String("partition_materials".into()),
                ));
                Some(DecodedElement {
                    id: Some(id),
                    class: "Material".into(),
                    fields,
                    byte_range: 0..0,
                    provenance: ElementProvenance::partition(
                        "partition",
                        0,
                        "partition_materials",
                        "partition_materials::material_record",
                        0.9,
                        None::<String>,
                    ),
                })
            })
            .collect(),
    )
}

fn materials_from_names(name_set: &BTreeSet<(NameBucket, String)>) -> Vec<DecodedElement> {
    name_set
        .iter()
        .filter(|(b, n)| *b == NameBucket::MaterialLike && is_strict_material_name(n))
        .enumerate()
        .map(|(i, (_, name))| {
            DecodedElement {
                id: None,
                class: "Material".into(),
                fields: vec![
                    ("m_name".into(), InstanceField::String(name.clone())),
                    (
                        "m_source".into(),
                        InstanceField::String("partition_schema_mvp".into()),
                    ),
                ],
                byte_range: i..i,
                provenance: Default::default(),
            }
            .with_provenance(ElementProvenance::partition(
                "partition",
                i,
                "partition_schema_mvp",
                "partition_schema_mvp::material_name",
                0.6,
                None::<String>,
            ))
        })
        .collect()
}

/// Reject schedule / schema / compound material path noise.
pub fn is_strict_material_name(s: &str) -> bool {
    let t = s.trim();
    if t.len() < 3 || t.len() > 48 {
        return false;
    }
    if t.contains(':') || t.contains('/') || t.contains('\\') || t.contains('.') {
        return false;
    }
    let lower = t.to_ascii_lowercase();
    if lower.contains("schema") || lower.ends_with(" material") || lower.contains("default") {
        return false;
    }
    // Keep classify_name's material bucket; just tighten.
    classify_name(t) == Some(NameBucket::MaterialLike)
}

fn partition_streams_largest_first(rf: &mut RevitFile) -> Vec<String> {
    let mut streams: Vec<(usize, String)> = rf
        .stream_names()
        .into_iter()
        .filter(|s| s.starts_with("Partitions/"))
        .filter_map(|s| {
            let raw = rf.read_stream(&s).ok()?;
            Some((raw.len(), s))
        })
        .collect();
    streams.sort_by(|a, b| b.0.cmp(&a.0).then_with(|| a.1.cmp(&b.1)));
    streams.into_iter().map(|(_, s)| s).collect()
}

fn rect_openings_from_partitions(
    rf: &mut RevitFile,
    revit_version: u32,
    limits: WalkerLimits,
) -> Result<Vec<DecodedElement>> {
    let mut out = Vec::new();
    let opening_cap = limits.max_candidates.min(5_000);

    // Confirm related ids against ElemTable when available — never invent
    // Door/Window classes from the index alone.
    let elem_ids: BTreeSet<u32> = match crate::elem_table::parse_records(rf) {
        Ok(records) => crate::elem_table::declared_ids(&records),
        Err(_) => BTreeSet::new(),
    };

    // Largest partition first — 2024 Core Interior openings live in
    // the ~98 MiB Partitions/46 stream.
    for stream in partition_streams_largest_first(rf) {
        let Ok(inflated) = rf.inflated_partition(&stream) else {
            continue;
        };
        let concat = inflated.bytes();
        let offsets = ArcWallRectOpeningIndex::find_all_for_revit_version(revit_version, concat);
        for off in offsets {
            if out.len() >= opening_cap {
                break;
            }
            let Ok(rec) = ArcWallRectOpeningIndex::decode(concat, off) else {
                continue;
            };
            let a_in = elem_ids.contains(&rec.related_id_a);
            let b_in = elem_ids.contains(&rec.related_id_b);
            // related_id_a is the historical host *candidate* (RE-15);
            // ElemTable confirmation only proves the id is declared —
            // not that it is a Wall host or a Door/Window instance.
            let host_confirmed = a_in;
            out.push(DecodedElement {
                id: None,
                class: "ArcWallRectOpening".into(),
                fields: vec![
                    (
                        "m_index".into(),
                        InstanceField::Integer {
                            value: i64::from(rec.index),
                            signed: false,
                            size: 4,
                        },
                    ),
                    (
                        "m_related_id_a".into(),
                        InstanceField::ElementId {
                            tag: 0,
                            id: rec.related_id_a,
                        },
                    ),
                    (
                        "m_related_id_b".into(),
                        InstanceField::ElementId {
                            tag: 0,
                            id: rec.related_id_b,
                        },
                    ),
                    (
                        "m_related_id_a_in_elem_table".into(),
                        InstanceField::Bool(a_in),
                    ),
                    (
                        "m_related_id_b_in_elem_table".into(),
                        InstanceField::Bool(b_in),
                    ),
                    (
                        "m_host_id".into(),
                        InstanceField::ElementId {
                            tag: 0,
                            id: rec.related_id_a,
                        },
                    ),
                    (
                        "m_host_elem_table_confirmed".into(),
                        InstanceField::Bool(host_confirmed),
                    ),
                    (
                        "m_host_provenance".into(),
                        InstanceField::String(if host_confirmed {
                            "related_id_a_in_elem_table".into()
                        } else {
                            "related_id_a_unvalidated".into()
                        }),
                    ),
                    (
                        "m_source_stream".into(),
                        InstanceField::String(stream.clone()),
                    ),
                    (
                        "m_source_offset".into(),
                        InstanceField::Integer {
                            value: off as i64,
                            signed: false,
                            size: 8,
                        },
                    ),
                    (
                        "m_source".into(),
                        InstanceField::String("partition_rect_opening_index".into()),
                    ),
                ],
                byte_range: off..off
                    .saturating_add(crate::rect_opening_index::OPENING_INDEX_STRIDE),
                provenance: ElementProvenance::partition(
                    &stream,
                    off,
                    "partition_rect_opening_index",
                    "partition_schema_mvp::arcwall_rect_opening",
                    if host_confirmed { 0.7 } else { 0.55 },
                    if host_confirmed {
                        None
                    } else {
                        Some("related_id_a_unvalidated")
                    },
                ),
            });
        }
        // Openings concentrate in one large partition; stop once we
        // found any validated index rows.
        if !out.is_empty() {
            break;
        }
    }
    Ok(out)
}
